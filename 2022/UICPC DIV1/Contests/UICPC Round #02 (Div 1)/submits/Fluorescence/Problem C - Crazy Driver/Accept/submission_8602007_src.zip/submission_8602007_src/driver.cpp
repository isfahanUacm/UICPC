#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
int main(){
    int n; cin>>n;
    lli mn = 1000000+5;
    lli c[100000+5];
    int t[100000+5];
    for(int i=1; i<n; i++){
        cin>>c[i];
    }
    for(int i=0; i<n; i++){
        cin>>t[i];
    }
    int time=0;
    lli cost = 0;
    for(int i=1; i<n; i++){
        mn = min(mn, c[i]);
        if(time+1 >= t[i]){
            time++;
            cost += c[i];
        }
        else{
            lli temp = t[i]-time-1;
            if(temp %2 != 0){
                temp++;
            }
            cost += c[i];
            cost += (temp)*mn;
            time += temp+1;
        }
    }
    cout<<cost;
}