#include <bits/stdc++.h>
using namespace std;

int main(){
    long long int a;
    cin>>a;
    double res = sqrt(a);
    cout<<fixed<<setprecision(10)<<4*res;
}