#include <bits/stdc++.h>
using namespace std;
int r, s;
bool inrange(int i, int j){
    return i>=0 && j>= 0 && j<s && i<r;
}

int main(){
    int mv[8][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}, {1,-1}, {-1, 1}, {1, 1}, {-1, -1}};
    char grid[53][53];
    vector<pair<int, int>> emp;
    cin>>r>>s;
    char c;
    bool f = false;
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < s; ++j) {
            cin>>c;
            grid[i][j] = c;
            if(c == '.'){
                f = true;
                emp.push_back({i, j});
            }
        }
    }
    if(!f){
        int cnt = 0;
        for (int i = 0; i < r; ++i) {
            for (int j = 0; j < s; ++j) {
                if(grid[i][j] == 'o'){
                    for (int k = 0; k < 8; ++k) {
                        if(inrange(i+mv[k][0], j+mv[k][1]) && grid[i+mv[k][0]][j+mv[k][1]] == 'o' ){
                            cnt++;
                        }
                    }
                }
            }
        }
        cout<<cnt/2;
    }
    else{
        int mx=0;
        int cnt = 0;
        int seati, seatj;

        for (int e = 0; e <emp.size() ; ++e) {
            for (int k = 0; k < 8; ++k) {
                if(inrange(emp[e].first+mv[k][0], emp[e].second+mv[k][1]) && grid[emp[e].first+mv[k][0]][emp[e].second+mv[k][1]] == 'o'){
                    cnt++;
                }
            }
            if(cnt>mx){
                mx = cnt;
                seati=emp[e].first, seatj=emp[e].second;
            }
            cnt = 0;
        }
        grid[seati][seatj] = 'o';
        cnt = 0;
        for (int i = 0; i < r; ++i) {
            for (int j = 0; j < s; ++j) {
                if(grid[i][j] == 'o'){
                    for (int k = 0; k < 8; ++k) {
                        if(inrange(i+mv[k][0], j+mv[k][1]) && grid[i+mv[k][0]][j+mv[k][1]] == 'o' ){
                            cnt++;
                        }
                    }
                }
            }
        }
        cout<<cnt/2;
    }

}