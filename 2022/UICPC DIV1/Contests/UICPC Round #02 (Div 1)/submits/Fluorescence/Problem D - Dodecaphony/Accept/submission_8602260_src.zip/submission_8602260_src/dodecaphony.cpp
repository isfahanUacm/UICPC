#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
map<string, int> MAP;
vector<string> vec(15);
void solve(){
    MAP["C"] = 0;
    MAP["C#"] = 1;
    MAP["D"] = 2;
    MAP["D#"] = 3;
    MAP["E"] = 4;
    MAP["F"] = 5;
    MAP["F#"] = 6;
    MAP["G"] = 7;
    MAP["G#"] = 8;
    MAP["A"] = 9;
    MAP["A#"] = 10;
    MAP["B"] = 11;
    vec[0] = "C";
    vec[1] = "C#";
    vec[2] = "D";
    vec[3] = "D#";
    vec[4] = "E";
    vec[5] = "F";
    vec[6] = "F#";
    vec[7] = "G";
    vec[8] = "G#";
    vec[9] = "A";
    vec[10] = "A#";
    vec[11] = "B";

}
vector<string> a, b;
int n;
bool t(){
    int temp = MAP[b[0]] - MAP[a[0]];
    if(temp <0) temp += 12;
    for(int i=1; i<n; i++){
        int x = MAP[b[i]] - MAP[a[i]];
        if(x<0) x += 12;
        if(x != temp){
            return false;
        }
    }
    return true;
}
bool R(){
    for(int i=0; i<n; i++){
        if(MAP[a[i]] != MAP[b[n-i-1]]){
            return false;
        }
    }
    return true;
}
bool I(){
    int t1 = MAP[a[0]];
    if(a[0] != b[0]){
        return false;
    }
    for(int i=1; i<n; i++){
        int x = MAP[a[i]] - t1;
        if(x<0) x += 12;

        int y = (t1 - x);
        if(y<0) y+=12;

        if(vec[y] != b[i]){
            return false;
        }
    }
    return true;
}
int main(){
    cin>>n;
    solve();
    
    for(int i=0; i<n; i++){
        string s; cin>>s;
        a.push_back(s);
    }
    for(int i=0; i<n; i++){
        string s; cin>>s;
        b.push_back(s);
    }
    if(t()){
        cout<<"Transposition";
    }
    else if(R()){
        cout<<"Retrograde";
    }
    else if(I()){
        cout<<"Inversion";
    }
    else cout<<"Nonsense";
}