#include <bits/stdc++.h>
using namespace std;

int airport, days, flights;
struct Airport{
    int day, cap, v;
};

vector<vector<Airport>> adj(14);
int exist[10][14];

bool optimal(){
    for (int i = 0; i < days; ++i) {
        for (int j = 0; j < airport; ++j) {
            int w = exist[i][j];
            for(Airport a: adj[j]){
                if(a.day==i){
                    if(a.cap > w)
                        return false;
                    w = w-a.cap;
                    exist[i+1][a.v] += a.cap;
                }
            }
            exist[i+1][j] += w;
        }
    }
    return true;
}

int main(){
    cin>>airport>>days>>flights;
    for (int i = 0; i < 10; ++i)
        for (int j = 0; j < 14; ++j)
            exist[i][j]=0;

    int u, v, d, c;
    for (int i = 0; i < flights; ++i) {
        cin>>u>>v>>d>>c;
        adj[u-1].push_back({d-1, c, v-1});
    }

    for (int i = 0; i < airport*days; ++i) {
        cin>>u>>d>>c;
        exist[d-1][u-1] += c;
    }
    if(optimal()) cout<<"optimal";
    else cout<<"suboptimal";
}