while(True):
    h,t = map(int,input().split())
    if (h+t)==0:
        break
    steps = 0
    if t!=0:
        if not((t%2)==0):
            steps += 1
            t += 1
        if not(((t//2 + h)%2)==0):
            steps += 2
            t += 2
        
        steps += t//2
        h += t//2
        
    if (h==1):
        print(-1)
    else:
        steps += (h//2)
        print(steps)