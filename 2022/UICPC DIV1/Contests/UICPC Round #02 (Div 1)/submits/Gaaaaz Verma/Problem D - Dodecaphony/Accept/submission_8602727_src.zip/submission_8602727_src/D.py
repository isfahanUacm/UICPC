import sys
t = int(input())
l1 = input().split()
l2 = input().split()
d = {
    'C' : 0,
    'C#': 1,
    'D' : 2,
    'D#': 3,
    'E' : 4,
    'F': 5,
    'F#' : 6,
    'G': 7,
    'G#' : 8,
    'A': 9,
    'A#' : 10,
    'B': 11,
}
k = list(d.keys())

v = list(d.values())
c1 = True
c2 = True
c3 = True
#trans
for i in range(t):
    dif = d[l1[0]] - d[l2[0]]
    if (d[l1[i]] - d[l2[i]]) != dif:
        c1 = False
        break
if c1:
    print('Transposition')
    sys.exit()
l3 = l2[::-1]
if l1 != l3:
    c2 = False

if c2:
    print('Retrograde')
    sys.exit()

for i in range(t):
    dif = d[l1[i]] - d[l1[0]]
    inv = (-1 * dif)
    temp = (d[l1[0]] + inv) % 12
    if l2[i] != k[v.index(temp)]:
        c3 = False
        break


if c3:
    print('Inversion')
    sys.exit()
print('Nonsense')

