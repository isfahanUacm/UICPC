import java.util.ArrayList;
import java.util.Scanner;
public class Q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<String> def = new ArrayList<>();
        def.add("C");
        def.add("C#");
        def.add("D");
        def.add("D#");
        def.add("E");
        def.add("F");
        def.add("F#");
        def.add("G");
        def.add("G#");
        def.add("A");
        def.add("A#");
        def.add("B");

        String[] s1 = new String[n];
        String[] s2 = new String[n];
        for (int i = 0; i < n; i++) s1[i] = sc.next();
        for (int i = 0; i < n; i++) s2[i] = sc.next();
        boolean t = true,i = true,r=true;
        String n1 , n2;
        int indexN1 , indexN2;
        int diff = def.indexOf(s1[0]) - def.indexOf(s2[0]);
        int index = def.indexOf(s1[0]);
        if (!s1[0].equals(s2[0])) i = false;
        for (int j = 0; j < n; j++) {
            n1 = s1[j];
            n2 = s2[j];
            indexN1 = def.indexOf(n1);
            indexN2 = def.indexOf(n2);
            if (i && j > 0) {
                int dif = indexN1 - index;
                if (dif == 0 && !n1.equals(n2)) i =false;
                if (dif > 0) {
                    if (index-dif<0) {
                        if (!def.get(index-dif+12).equals(n2)) i = false;
                    }
                    else if (!def.get(index-dif).equals(n2)) i = false;
                }
                if (dif < 0) {
                    if (index+dif>11) {
                        if (!def.get(index+dif-12).equals(n2)) i = false;
                    }
                    else if (!def.get(index+dif).equals(n2)) i = false;
                }
            }
            if (t && indexN1 - indexN2 != diff) t =false;
            if (r && !n1.equals(s2[n-j-1])) r = false;
        }
        if (t) System.out.println("Transposition");
        else if (r) System.out.println("Retrograde");
        else if (i) System.out.println("Inversion");
        else System.out.println("Nonsense");
    }
}