import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            sc.nextInt();
            int n = sc.nextInt();
            long ans = n+1;
            ans += ((n-3)/2)+1;
            for (int j = 3; j < n; j++) {
                for (int k = j+1; k <= n; k++) {
                    if (check(k,j) == 1) ans++;
                }
            }
            System.out.println(i+1 + " " + ans);
        }
    }
    public static int check(int a , int b) {
        if (a == 0 || b == 0) return 0;
        if (a == b) return a;
        if (a > b) return check(a-b, b);
        return check(a, b-a);
    }
}