//package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int gates = sc.nextInt();
        int costs[] = new int[gates - 1];
        int times[] = new int[gates];
        int gate = 0, time = 0, cost = 0;

        for (int i = 0; i < gates - 1; i++)
            costs[i] = sc.nextInt();
        for (int i = 0; i < gates; i++)
            times[i] = sc.nextInt();
        while (gate != gates - 1) {
            gate++;
            time++;
            cost += costs[gate - 1];
            if (time < times[gate]) {
                gate--;
                time++;
                cost += costs[gate];
            }
            if (gate < gates - 1)
                if (time + 1 < times[gate + 1])
                    if (costs[gate - 1] < costs[gate]) {
                        gate--;
                        time++;
                        cost += costs[gate];
                    }

        }
        System.out.println(cost);


    }
}








