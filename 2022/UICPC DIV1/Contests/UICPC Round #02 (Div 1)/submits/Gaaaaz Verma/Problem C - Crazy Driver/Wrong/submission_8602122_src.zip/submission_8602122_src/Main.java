import java.util.Scanner;
public class Main
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] dis = new int[n-1];
        int[] time = new int[n];
        for (int i = 0; i < n-1; i++) dis[i] = sc.nextInt();
        for (int i = 0; i < n; i++) time[i] = sc.nextInt();
        int diff = time[n-1] - time[0];
        int hour = 0 , index = 0 , cost = 0;
        while (true) {
            if (index == n-1) break;
            if (hour+1 < time[index+1]) {
                hour += 2;
                cost += dis[index]*2;
            } else {
                hour++;
                cost += dis[index];
                index++;
                //==============
                //System.out.println("index " + index );
                if (index < n-1 && dis[index-1] < dis[index]) {
                    while (true) {
                        //System.out.println("hour " + hour );
                        if (hour+1 >= time[index+1]) break;
                        else {
                            //System.out.println("slm");
                            hour += 2;
                            cost += dis[index-1]*2;
                        }
                    }
                }
            }
        }
        System.out.println(cost);
    }
}