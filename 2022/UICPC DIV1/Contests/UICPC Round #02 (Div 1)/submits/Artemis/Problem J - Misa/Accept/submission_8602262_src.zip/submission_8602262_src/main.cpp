#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int n, m;

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < m;
}

int main() {
    cin >> n >> m;
    char arr[n][m];

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> arr[i][j];
        }
    }

    ll ans = 0;
    ll mx = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            ll temp = 0;
            for (int k = -1; k <= 1; ++k) {
                for (int l = -1; l <= 1; ++l) {
                    if (k == 0 && l == 0)
                        continue;
                    if (ir(i + k, j + l) && arr[i + k][j + l] == 'o') {
                        temp++;
                    }
                }
            }
            if (arr[i][j] == 'o')
                ans += temp;
            else
                mx = max(mx, temp);
        }
    }
    cout << ans / 2 + mx << endl;
}