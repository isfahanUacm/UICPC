#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int n, m;

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < m;
}

int main() {
    cin >> n >> m;
    char arr[n][m];

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> arr[i][j];
        }
    }

    ll ans = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (arr[i][j] == '.')
                continue;
            for (int k = -2; k <= 2; ++k) {
                for (int l = -2; l <= 2; ++l) {
                    if (k == 0 && l == 0)
                        continue;
                    if (ir(i + k, j + l) && arr[i + k][j + l] == 'o') {
                        ans++;
                    }
                }
            }
        }
    }

    cout << ans / 2 << endl;
}