#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    int h, t;
    while (cin >> h >> t && h != 0) {
        ll ans = 0;

        if (h % 2 != 0) {
            int b = t % 4;
            if (b <= 2) {
                t += 2 - b;
                ans += 2 - b;
            }
            else {
                t += 6 - b;
                ans += 6 - b;
            }
        }
        else if (h % 2 == 0) {
            int b = t % 4;
            if (b != 0) {
                ans += 4 - b;
                t += 4 - b;
            }
        }
        int z = t / 2;
        ans += z;
        h += z;

        ans += h / 2;

        cout << ans << endl;
    }
}