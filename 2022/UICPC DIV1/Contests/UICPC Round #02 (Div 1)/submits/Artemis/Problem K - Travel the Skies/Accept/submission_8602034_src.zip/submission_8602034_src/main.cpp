#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

struct t {
    int u, v, day, cap;
};

int main() {
    int k, n, m;
    cin >> k >> n >> m;

    int arr[k + 10];
    memset(arr, 0, sizeof(arr));

    vector<t> vc;


    for (int i = 0; i < m; ++i) {
        t temp{};
        cin >> temp.u >> temp.v >> temp.day >> temp.cap;
        vc.push_back(temp);
    }

    int cm[k + 10][n + 10];
    for (int i = 0; i < k * n; ++i) {
        int t, tt, c;
        cin >> t >> tt >> c;
        cm[t][tt] = c;
    }

    bool possible = true;
    for (int i = 1; i <= n; ++i) {
        int added[k + 10];
        memset(added, 0, sizeof(added));
        for (int j = 1; j <= k; ++j) {
            arr[j] += cm[j][i];
        }

        for (auto temp: vc) {
            if (temp.day != i)
                continue;

            if (temp.day == i) {
                int u = temp.u;
                int v = temp.v;

                if (arr[u] >= temp.cap) {
                    arr[u] -= temp.cap;
                    added[v] += temp.cap;
                }
                else {
                    possible = false;
                }
            }
        }

        for (int l = 1; l <= k; ++l) {
            arr[l] += added[l];
        }
    }

    if (possible)
        cout << "optimal" << endl;
    else
        cout << "suboptimal" << endl;
}