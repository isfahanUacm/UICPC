#include<bits/stdc++.h>
using namespace std;
const int mx=10001;
int main(){
    int p,n,x;
    cin>>p;
    vector<int> prm_num(mx);
    for(int i=0;i<mx;i++) prm_num[i]=i;

    for(int i=2;i<mx;i++){
        if(prm_num[i]==i){
             for (int j=i; j<mx; j+=i)
                prm_num[j] -= prm_num[j] / i;
        }
    }
    while(p--){
        cin>>n>>x;
        int ans=1;
       for(int i=0;i<=x;i++) ans+=prm_num[i];
        cout<<n<<' '<<ans<<endl;
    }
    return 0;
}