#include<bits/stdc++.h>
using namespace std;
int arr[10003][10004];
bool rprime (int a, int b) {
  for ( ; ; ) {
    if (!(a %= b)) return b == 1 ;
    if (!(b %= a)) return a == 1 ;
  }
}
int main(){
    int p,n,x;
    cin>>p;
    for(int i=10000;i>=1;i--){
        for(int j=i-1;j>=1;j--){
            if(rprime(i,j)) arr[i][j]=1,arr[j][i]=1;
        }
    }
    while(p--){
        cin>>n>>x;
        int ans=2;
        for(int i=x;i>=1;i--){
            for(int j=i-1;j>=1;j--){
                if(arr[i][j]) ans++;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}