#include<bits/stdc++.h>
using namespace std;
int main(){
    double a,x;
    cin>>a;
    a=sqrt(a);
    printf("%0.7f",a*4);
    return 0;
}