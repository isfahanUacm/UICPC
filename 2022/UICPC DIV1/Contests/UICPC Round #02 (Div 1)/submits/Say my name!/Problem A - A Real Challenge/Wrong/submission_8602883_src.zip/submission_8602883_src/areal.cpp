#include <iostream>
#include <math.h>
using namespace std;
int main() {
int a;
cin>>a;
double b = sqrt(a);
b = b * 4;
    printf("%f\n",b);
    return 0;
}
