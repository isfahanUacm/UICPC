// 01N.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <math.h>
#include <cstring>
#include  <string>

int ConvertToNum(char [3]);
bool Retrograde(int [], int [], int );
bool Transposition(int[], int[], int);
bool Inversion(int [], int [], int );

using namespace std;

int MainOrder[12] = { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 };

int main()
{
	int n ;
	cin >> n;

	int* Array1 = new int[n];
	int* Array2 = new int[n];
	char Note[3];

	for (int i = 0; i < n; i++)
	{
		cin >> Note;
		Array1[i] = ConvertToNum(Note);
	}

	for (int i = 0; i < n; i++)
	{
		cin >> Note;
		Array2[i] = ConvertToNum(Note);
	}

	
    if (Transposition(Array1, Array2, n))
		cout << "Transposition";
	else if (Retrograde(Array1, Array2, n))
			cout << "Retrograde";
	else if (Inversion(Array1, Array2, n))
		cout << "Inversion";
	else
		cout << "Nonsense";
}

int ConvertToNum(char Note[3])

{
	if (strcmp(Note , "C") == 0)
		return 1;
	if (strcmp(Note ,"C#") == 0)
		return 2;
	if (strcmp(Note , "D") == 0)
		return 3;	
	if (strcmp(Note , "D#") == 0)
		return 4;	
	if (strcmp(Note , "E") == 0)
		return 5;	
	if (strcmp(Note , "F") == 0)
		return 6;	
	if (strcmp(Note , "F#") == 0)
		return 7;	
	if (strcmp(Note , "G") == 0)
		return 8;	
	if (strcmp(Note , "G#") == 0)
		return 9;	
	if (strcmp(Note , "A") == 0)
		return 10;	
	if (strcmp(Note , "A#") == 0)
		return 11;
	if (strcmp(Note , "B") == 0)
		return 12;

	return 0;
}

bool Retrograde(int Array1[] , int Array2[] , int n)
{
	int i;
	for (i = 0; i < n; i++)
	{
		if (Array2[n - 1 - i] != Array1[i])
			break;
	}

	if (i == n)
		return true;

	return false;

}

bool Transposition(int Array1[], int Array2[], int n)
{
	int a1 = 0, a2 = 0 , i;

	for (i = 0; i < n; i++)
	{
		a1 = Array2[i] - Array1[i];

		
		if (a1 < 0)
			a1 += 12;

		if (i == 0)
			a2 = a1;

		//cout << "   " << a1 << "   " << a2 << "   " << Array2[i] << "   " << Array1[i];
		
		if (a2 != a1)
			break;
	}
	if (i == n)
		return true;

	return false;

}

 bool Inversion(int Array1[], int Array2[], int n)
{
	int temp , FrstNote = MainOrder[Array1[0] - 1] , temp2 , temp3 , i;
	for (i = 0; i < n; i++)
	{
		temp = MainOrder[Array1[i] - 1];
		temp2 = temp - FrstNote;

		if (temp2 < 0)
			temp2 += 12;

		temp3 = FrstNote - temp2;

		if (temp3 < 0)
			temp3 += 12;

		if (temp3 != Array2[i])
			return false;
	}

	if(i == n)
		return true;
}

