#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <string>

using namespace std;

int main()
{
	int nRow, nCollumn;
	cin >> nRow >> nCollumn;
	int** grid = new int* [nRow+2];
	bool** statue = new bool* [nRow+2];
	for (int i = 0; i < nRow + 2; i++) statue[i] = new bool[nCollumn + 2];
	for (int i = 0; i < nRow + 2; i++) grid[i] = new int[nCollumn + 2];

	for (int i = 0; i < nRow + 2; i++) for (int j = 0; j < nCollumn + 2; j++) grid[i][j] = 0;
	for (int i = 0; i < nRow + 2; i++) for (int j = 0; j < nCollumn + 2; j++) statue[i][j] = false;

	for (int i = 1; i <= nRow; i++)
		for (int j = 1; j <= nCollumn; j++)
		{
			char temp;
			cin >> temp;
			if (temp == 'o')
			{
				grid[i][j] = 1;
				statue[i][j] = true;
			}
		}

	for (int i = 1; i <= nRow; i++)
	{
		for (int j = 1; j <= nCollumn; j++)
		{
			if (grid[i][j] == 1 && statue[i][j] == true)
			{
				if (i == 1 && j == 1)
				{
					if (!statue[i + 1][j] && i==0 && j==0 && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i + 1][j + 1] && i != 0 && j != 0) grid[i + 1][j + 1]++;
				}
				else if (i == nRow - 3 && j == 1)
				{
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i - 1][j + 1] && i != 0 && j != 0) grid[i - 1][j + 1]++;

				}
				else if (i == nRow - 3 && j == nCollumn - 3)
				{
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i][j - 1] && i != 0 && j != 0) grid[i][j - 1]++;
					if (!statue[i - 1][j - 1] && i != 0 && j != 0) grid[i - 1][j - 1]++;
				}
				else if (i == 1 && j == nCollumn - 3)
				{
					if (!statue[i + 1][j] && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i][j - 1] && i != 0 && j != 0) grid[i][j - 1]++;
					if (!statue[i + 1][j - 1] && i != 0 && j != 0) grid[i + 1][j - 1]++;
				}
				else if (i == 1)
				{
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i][j - 1] && i != 0 && j != 0) grid[i][j - 1]++;
					if (!statue[i + 1][j] && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i + 1][j + 1] && i != 0 && j != 0) grid[i + 1][j + 1]++;
					if (!statue[i + 1][j - 1] && i != 0 && j != 0) grid[i + 1][j - 1]++;

				}
				else if (j == 1)
				{
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i + 1][j] && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i + 1][j + 1] && i != 0 && j != 0) grid[i + 1][j + 1]++;
					if (!statue[i - 1][j + 1] && i != 0 && j != 0) grid[i - 1][j + 1]++;
				}
				else if (i == nRow - 3)
				{
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i][j - 1] && i != 0 && j != 0) grid[i][j - 1]++;;
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i - 1][j + 1] && i != 0 && j != 0) grid[i - 1][j + 1]++;
					if (!statue[i - 1][j - 1] && i != 0 && j != 0) grid[i - 1][j - 1]++;
				}
				else if (j == nCollumn - 3)
				{
					if (!statue[i + 1][j] && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i][j - 1] && i != 0 && j != 0) grid[i][j - 1]++;
					if (!statue[i + 1][j - 1] && i != 0 && j != 0) grid[i + 1][j - 1]++;
					if (!statue[i - 1][j - 1] && i != 0 && j != 0) grid[i - 1][j - 1]++;
				}
				else
				{
					if (!statue[i][j + 1] && i != 0 && j != 0) grid[i][j + 1]++;
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i][j - 1]++;
					if (!statue[i + 1][j] && i != 0 && j != 0) grid[i + 1][j]++;
					if (!statue[i + 1][j + 1] && i != 0 && j != 0) grid[i + 1][j + 1]++;
					if (!statue[i + 1][j - 1] && i != 0 && j != 0) grid[i + 1][j - 1]++;
					if (!statue[i - 1][j] && i != 0 && j != 0) grid[i - 1][j]++;
					if (!statue[i - 1][j + 1] && i != 0 && j != 0) grid[i - 1][j + 1]++;
					if (!statue[i - 1][j - 1] && i != 0 && j != 0) grid[i - 1][j - 1]++;
				}
			}
		}
	}
		
	int max = -1;
	int indexRow = -1;
	int indexCollumn = -1;

	for (int i =1; i <= nRow; i++)
	{
		for (int j = 1; j <= nCollumn; j++)
		{
			if (max < grid[i][j] && i != 0 && j != 0)
			{
				max = grid[i][j];
				indexRow = i;
				indexCollumn = j;
			}
		}
	}

	statue[indexRow][indexCollumn] = true;
	grid[indexRow][indexCollumn] = 1;

	int counter = 0;

	for (int i = 1; i <= nRow; i++)
	{
		for (int j = 1; j <= nCollumn; j++)
		{
			if (statue[i][j] == true && i != 0 && j != 0)
			{
				if (i == 1 && j == 1)
				{
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j + 1] && i != 0 && j != 0) counter++;
				}
				else if (i == nRow - 3 && j == 1)
				{
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
				}
				else if (i == nRow - 3 && j == nCollumn - 3)
				{

				}
				else if (i == 1 && j == nCollumn - 3)
				{
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j - 1] && i != 0 && j != 0) counter++;
				}
				else if (i == 1)
				{
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j - 1] && i != 0 && j != 0) counter++;

				}
				else if (j == 1)
				{
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j + 1] && i != 0 && j != 0) counter++;
				}
				else if (i == nRow - 3)
				{
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
				}
				else if (j == nCollumn - 3)
				{
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j - 1] && i != 0 && j != 0) counter++;
				}
				else
				{
					if (statue[i][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j + 1] && i != 0 && j != 0) counter++;
					if (statue[i + 1][j - 1] && i != 0 && j != 0) counter++;
				}
			}
		}

	}

	cout << counter;
		
	
}

