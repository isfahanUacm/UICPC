#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <string>

using namespace std;

int main()
{
	int tails = -1;
	int heads = -1;

	while (true)
	{
		cin >> heads;
		cin >> tails;
		int n = 0;
		if (tails == 0 && heads == 0) break;

		if (heads % 2 == 1 && tails == 0)
		{
			cout << -1;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 0 && tails % 4 == 0)
		{
			n += tails / 2;
			n += (tails / 2 + heads) / 2;
			cout << n;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 0 && tails % 4 != 0)
		{
			n += 4 - tails % 4;
			n += (tails + 4 - tails % 4) / 2;
			n += ((tails + 4 - tails % 4) / 2 + (heads)) / 2;
			cout << n;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 1 && tails % 4 == 0)
		{
			n += 2;
			n += (tails + 2) / 2;
			n += (heads + ((tails + 2) / 2)) / 2;;
			cout << n;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 1 && tails % 4 == 1)
		{
			n += tails % 4;
			n += (tails + tails % 4) / 2;
			n += ((tails + tails % 4) / 2 + heads) / 2;
			cout << n;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 1 && tails % 4 == 2)
		{
			n += (tails / 2);
			n += ((tails / 2) + heads) / 2;
			cout << n;
			cout << "\n";
			continue;
		}
		else if (heads % 2 == 1 && tails % 4 == 3)
		{
			n += tails % 4;
			n += (tails + tails % 4) / 2;
			n += ((tails + tails % 4) / 2 + heads) / 2;
			cout << n;
			cout << "\n";
			continue;
		}

		cout << "\n";
	}
}
