from math import sqrt

num = int(input())

costs = input().split(" ")
map_object = map(int, costs)
costs = list(map_object)

times = input().split(" ")
map_object = map(int, times)
times = list(map_object)

cost = 0
timer = 0

for i in costs:
    cost += i

for i in range(1, num):
    timer += 1
    while timer < times[i]:
        cost += 2 * min(costs[:i])
        timer += 2

print(cost)
