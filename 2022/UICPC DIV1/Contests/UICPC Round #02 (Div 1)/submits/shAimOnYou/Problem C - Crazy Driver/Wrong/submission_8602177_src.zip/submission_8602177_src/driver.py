from math import sqrt

num = int(input())

costs = input().split(" ")
map_object = map(int, costs)
costs = list(map_object)

times = input().split(" ")
map_object = map(int, times)
times = list(map_object)

cost = costs[0]
timer = 1

for i in range(1, num):
    if timer>=times[i]:
        cost+=costs[i-1]
    while timer < times[i]:
        cost += 2 * min(costs[:i])
        timer += 2

print(cost)
