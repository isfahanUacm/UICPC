import java.util.Scanner;

public class J {
    static int r, s;
    static char[][] table;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        r = sc.nextInt();
        s = sc.nextInt();

        table = new char[r][s];

        for (int i = 0; i < r; i++) {
            String line = sc.useDelimiter("\n").next();
            for (int j = 0; j < s; j++) {
                table[i][j] = line.charAt(j);
            }
        }

        int hands = 0;
        int max = 0;


        for (int i = 0; i < r; i++) {
            for (int j = 0; j < s; j++) {
                if (table[i][j] == 'o') {
                    hands += handshakes(i, j);
                } else {
                    max = Math.max(max, handshakes(i, j));
                }
            }
        }

        System.out.println(hands/2 + max);
    }

    static int handshakes(int x, int y) {
        int hands = 0;
        int[][] sides = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};

        for (int i = 0; i < 8; i++) {
            int x2 = x + sides[i][0];
            int y2 = y + sides[i][1];

            if (x2 >= 0 && y2 >= 0 && x2 < r && y2 < s) {
                if (table[x2][y2] == 'o') {
                    hands++;
                }
            }
        }
        return hands;
    }
}



