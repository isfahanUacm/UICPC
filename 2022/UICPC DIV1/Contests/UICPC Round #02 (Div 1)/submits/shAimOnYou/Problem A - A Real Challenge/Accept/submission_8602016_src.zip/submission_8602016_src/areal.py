from math import sqrt

a = int(input())
a = sqrt(a)
print(4 * a)
