from math import gcd


def phi(n):
    amount = 0
    for k in range(1, n + 1):
        if gcd(n, k) == 1:
            amount += 1
    return amount


x = int(input())

for i in range(x):
    order = int(input().split()[1])
    sum = 0
    for j in range(1, order+1):
        sum += phi(j)

    print(i+1, sum+1)
