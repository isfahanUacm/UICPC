#include <bits/stdc++.h>
using namespace std;

bool coprime(int a, int b) {

    if ( __gcd(a, b) == 1)
        return true;
    else
        return false;
}

int main()
{
    int n;
    cin >> n;
    while (n--) {
        int counter=0;
        int a,b;
        cin >> a >> b;

        for(int i=0;i<=b;i++){
            for(int j=i;j<=b;j++){
                if(coprime(i,j)){
                    counter++;
                }
            }
        }
        cout << counter << endl;
    }
    return 0;
}
