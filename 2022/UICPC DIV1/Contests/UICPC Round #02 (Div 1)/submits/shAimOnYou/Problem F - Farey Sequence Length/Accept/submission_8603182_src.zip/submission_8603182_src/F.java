import java.util.Scanner;

public class F {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int SZ = 10001;
        int[] lens = new int[SZ];

        for (int i = 1; i < SZ; i++) {
            lens[i] = i - 1;
        }

        for (int i = 2; i < SZ; i++) {

            boolean[] flg = new boolean[SZ];

            for (int j = 2; j <= i / 2; j++) {
                if (i % j != 0)
                    continue;

                for (int k = i + j; k < SZ; k += j) {
                    if (!flg[k]) {
                        flg[k] = true;
                        lens[k]--;
                    }
                }

                int z = i / j;
                for (int k = i + z; k < SZ; k += z) {
                    if (!flg[k]) {
                        flg[k] = true;
                        lens[k]--;
                    }
                }
            }
            for (int j = i + i; j < SZ; j += i) {
                if (!flg[j]) {
                    flg[j] = true;
                    lens[j]--;
                }
            }
        }

        for (int i = 2; i < SZ; i++)
            lens[i] += lens[i - 1];

        int t = sc.nextInt();
        while (t-- > 0) {
            int k = sc.nextInt();
            int n = sc.nextInt();
            System.out.println(k + " " + (lens[n] + 2));
        }
    }
}

