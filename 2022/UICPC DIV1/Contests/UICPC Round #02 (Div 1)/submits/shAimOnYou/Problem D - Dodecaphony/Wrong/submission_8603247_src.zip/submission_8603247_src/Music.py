notes = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def t(a, b):
    x = notes.index(b[0]) - notes.index(a[0])
    for i in range(len(a)):
        if(notes.index(b[i]) - notes.index(a[i]) != x):
            return False
    return True


def i(a, b):
    if(a[0] == b[0]):
        i = 0
        index = notes.index(a[0])
        for i in range(1, len(a)):
            index2 = notes.index(a[i])
            diff = -1 * (index2 - index)
            index2 += diff
            if(index2 < 0):
                index2 += 12
            if(index2 > 12):
                index2 -= 12
            if(notes[index2] != b[i]):
                return False
        return True
    else:
        return False


def r(a, b):
    return a == list(reversed(b))


count = int(input())

first = input().split()
second = input().split()


if(t(first, second)):
    print("Transposition")
elif(i(first, second)):
    print("Inversion")
elif(r(first, second)):
    print("Retrograde")
else:
    print("Nonsense")
