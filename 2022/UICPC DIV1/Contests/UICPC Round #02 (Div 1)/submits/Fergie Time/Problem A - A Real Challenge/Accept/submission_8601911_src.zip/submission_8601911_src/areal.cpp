#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
  ll n;
  cin>>n;
  double x=0;
  x=sqrt(n)*4;
  cout<<fixed<<setprecision(20)<<x;
}
