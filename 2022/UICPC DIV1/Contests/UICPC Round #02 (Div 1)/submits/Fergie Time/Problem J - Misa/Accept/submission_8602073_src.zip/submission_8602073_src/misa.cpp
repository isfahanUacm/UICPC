#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

int main()
{
    ll n, m;
    cin >> n >> m;
    vector<string> a(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    pll bestIndex = {-1, -1};
    ll maxHandshakes = 0;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            vector<pll> dirs = {{-1, -1}, {-1, +1}, {+1, -1}, {+1, +1}, {0, 1}, {1, 0}, {0, -1}, {-1, 0}};
            if (a[i][j] == '.')
            {
                ll temp = 0;
                for (pll dir : dirs)
                {
                    temp += (i + dir.first >= 0 && j + dir.second >= 0 && i + dir.first < n && j + dir.second < m && a[i + dir.first][j + dir.second] == 'o');
                }
                if (temp > maxHandshakes)
                {
                    maxHandshakes = temp;
                    bestIndex = {i, j};
                }
            }
        }
    }
    if (bestIndex.first != -1 && bestIndex.second != -1)
    {
        a[bestIndex.first][bestIndex.second] = 'o';
    }
    ll ans = 0;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            vector<pll> dirs = {{-1, -1}, {-1, +1}, {+1, -1}, {+1, +1}, {0, 1}, {1, 0}, {0, -1}, {-1, 0}};
            if (a[i][j] == 'o')
            {
                ll temp = 0;
                for (pll dir : dirs)
                {
                    temp += ((i + dir.first >= 0 && j + dir.second >= 0 && i + dir.first < n && j + dir.second < m && a[i + dir.first][j + dir.second] == 'o'));
                }
                ans += temp;
            }
        }
    }
    cout << ans / 2;
    return 0;
}