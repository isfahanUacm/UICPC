#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl

int main()
{
//   string m="C,C♯,D,D♯,E,F,F♯,G,G♯,A,A♯,B";
   vector<string> m;
   m.push_back("C");
   m.push_back("C#");
   m.push_back("D");
   m.push_back("D#");
   m.push_back("E");
   m.push_back("F");
   m.push_back("F#");
   m.push_back("G");
   m.push_back("G#");
   m.push_back("A");
   m.push_back("A#");
   m.push_back("B");
   int n;
   cin>>n;
   vector<string> m1(n);
   vector<string> m2(n);

   for(int i=0;i<n;i++){
       cin>>m1[i];
   }
   for(int i=0;i<n;i++){
       cin>>m2[i];
   }
   auto it = find(m.begin(), m.end(), m1[0]);
   int index = it - m.begin();
   auto it1 = find(m.begin(), m.end(), m2[0]);
   int index1 = it1 - m.begin();
   int shift=(index1 -index);
   bool flag=false;
   for(int i=1;i<n;i++){
       auto it2 = find(m.begin(), m.end(), m1[i]);
       int index2 = it2 - m.begin();
       int s=index2+shift;
       if(s >= 0){
           s=s%(m.size());
           if(m[s] != m2[i]){
              flag=true;
              break;
           }
       }
       else{
        s=s+m.size();
        if(m[s] != m2[i]){
           flag=true;
           break;
        }
       }
   }
   if(!flag){
       cout<<"Transposition"<<endl;
   }
   else{
       vector<string> mr(m2.rbegin(), m2.rend());
       if(mr == m1){
           cout<<"Retrograde"<<endl;
       }
       else{
           if(m1[0]==m2[0]){
               bool f=false;
               for(int i=1;i<n;i++){
                   auto it3 = find(m.begin(), m.end(), m1[i]);
                   int index3 = it3 - m.begin();
                   int shift_index=index3-index;
                   int s_index=shift_index;
                   s_index=index - s_index;
//                   cout<<index3<<endl;
//                   cout<<shift_index<<endl;
//                   cout<<m2[i]<<endl;
                   if(s_index>=0){
                       s_index=s_index % m.size();
//                       cout<<m[s_index]<<endl;
//                       cout<<s_index<<endl;
                       if(m[s_index] != m2[i]){
                           f=true;
                           break;
                       }
                   }
                   else{
                      s_index =m.size() + s_index;
//                      cout<<m[s_index]<<endl;
//                       cout<<s_index<<endl;
                      if(m[s_index] != m2[i]){
                          f=true;
                          break;
                      }

                   }
               }
               if(!f){
                   cout<<"Inversion"<<endl;
               }
               else{
                   cout<<"Nonsense"<<endl;
               }
           }
           else{
               cout<<"Nonsense"<<endl;
           }

       }
   }




}

