#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
int main()
{
    ll k, n, m;
    cin >> k >> n >> m;
    
    ll N = n;
    
    ll capacity[N][k][k];
    ll filled[N][k][k];
    ll people[N][k];
    fill(&capacity[0][0][0], &capacity[0][0][0] + N * k * k, 0);
    fill(&filled[0][0][0], &filled[0][0][0] + N * k * k, 0);
    fill(&people[0][0], &people[0][0] + N * k, 0);

    for(ll i = 0; i < m; i++)
    {
        ll u, v, d, z;
        cin >> u >> v >> d >> z;
        u--;
        v--;
        d--;
        capacity[d][u][v] += z;
    }
    for(ll i = 0; i < k * n; i++)
    {
        ll a, b, c;
        cin >> a >> b >> c;
        b--;
        a--;
        people[b][a] += c;
    }

    vector<ll> freePeople(k, 0);
    for(ll day = 0; day < n; day++)
    {
        for(ll i = 0; i < k; i++)
        {
            freePeople[i] += people[day][i];
        }
        vector<ll> currentFreePeople(k, 0);
        for(ll i = 0; i < k; i++)
        {
            for(ll j = 0; j < k; j++)
            {
                if(capacity[day][i][j])
                {
                    if((freePeople[i] + people[day][i]) >= capacity[day][i][j])
                    {
                        if(people[day][i] >= capacity[day][i][j])
                        {   
                            currentFreePeople[j] += capacity[day][i][j];
                            people[day][i] -= capacity[day][i][j];
                        }
                        else
                        {
                            ll delta = capacity[day][i][j] - people[day][i];

                            freePeople[i] -= delta;
                            people[day][i] = 0;
                            currentFreePeople[j] += capacity[day][i][j];
                        }
                    }
                    else
                    {
                        cout << "suboptimal";
                        return 0;
                    }
                }
            }
        }
        
        for(ll i = 0; i < freePeople.size(); i++)
        {
            freePeople[i] += currentFreePeople[i];
        }

    }
    cout << "optimal";
    return 0;
}