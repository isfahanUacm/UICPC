#include <iostream>

using namespace std;

int main()
{
    int h,t;
    while(cin >> h >> t && (h !=0 && t != 0))
    {
         int s = 0;
         if (t==0)
         {
             if(h%2 != 0)
                 s = -1;
             else
             {
                s = h /2;
             }
         }
         else
         {
             while(true)
             {
               if (t%2 == 0 && (h+(t/2))%2 == 0)
               {
                   s += (t/2) + ((h+(t/2))/2);
                   break;
               }
                t+= 1;
                s+=1;

             }
         }
          cout << s << endl;


        }

}

