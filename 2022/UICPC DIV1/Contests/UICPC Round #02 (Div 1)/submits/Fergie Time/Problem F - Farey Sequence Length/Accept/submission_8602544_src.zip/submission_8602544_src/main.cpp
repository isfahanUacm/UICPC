#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
vector<ll> phi_1_to_n(ll n)
{
    vector<ll> phi(n + 1);
    for (ll i = 0; i <= n; i++)
    {
        phi[i] = i;
    }

    for (ll i = 2; i <= n; i++)
    {
        if (phi[i] == i)
        {
            for (ll j = i; j <= n; j += i)
            {
                phi[j] -= phi[j] / i;
            }
        }
    }
    return phi;
}
int main()
{
    vector<ll> phi = phi_1_to_n(10000);
    ll t;
    cin >> t;
    while (t--)
    {
        ll k, n;
        cin >> k >> n;
        cout << k << " ";
        ll ans = 1;
        for (ll i = 1; i <= n; i++)
        {
            ans += phi[i];
        }
        cout << ans << endl;
    }
    return 0;
}