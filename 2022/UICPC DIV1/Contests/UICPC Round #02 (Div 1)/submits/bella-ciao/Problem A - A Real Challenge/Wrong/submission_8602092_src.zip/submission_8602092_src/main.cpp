#include <bits/stdc++.h>
using namespace std;

int main(){
    unsigned long long int n;
    cin >> n;
    cout << sqrt(n) * 4 << endl;
    return 0;
}
