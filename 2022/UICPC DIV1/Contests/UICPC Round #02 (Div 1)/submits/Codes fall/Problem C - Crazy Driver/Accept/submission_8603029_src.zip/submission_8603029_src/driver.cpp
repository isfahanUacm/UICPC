#include <iostream>
using namespace std;

int main()
{
    int n, i, j, place = 0, min;
    cin >> n;
    
    int cost[n-1];
    int time[n];
    long long totalcost = 0, nowtime = 0;
    
    for (i = 0; i < n-1; i++)
        cin >> cost[i];
        
    for (i = 0; i < n; i++)
        cin >> time[i];
    
    min = cost[0];
    while (!(place == n-1 && nowtime >= time[n-1]))
    {
        if (place == 0)
        {
            if (nowtime >= time[0])
            {
                totalcost += cost[place++];
            }
            nowtime++;
            continue;
        }
        
        if (cost[place-1] < min)
            min = cost[place-1];
            
        if (time[place] <= nowtime)
        {
            nowtime++;
            totalcost += cost[place++];
        }
        
        else
        {
            nowtime += 2;
            totalcost += (2 * min);
        }
    }
    
    cout << totalcost << endl;

    return 0;
}