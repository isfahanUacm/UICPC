#include <iostream>
using namespace std;

int main()
{
    int n, i, j, place = 0;
    cin >> n;
    
    int cost[n-1];
    int time[n];
    int totalcost = 0, nowtime = 0;
    
    for (i = 0; i < n-1; i++)
        cin >> cost[i];
        
    for (i = 0; i < n; i++)
        cin >> time[i];
    
    
    while (place != n-1)
    {
        if (place == 0)
        {
            if (nowtime >= time[0])
            {
                totalcost += cost[place++];
            }
            nowtime++;
            continue;
        }
        
        
        if (time[place] <= nowtime)
        {
            if (nowtime+1 >= time[place+1])
            {
                nowtime++;
                totalcost += cost[place++];
            }
            
            else
            {
                if (cost[place] <= cost[place-1])
                {
                    nowtime++;
                }
                else
                {
                    nowtime++;
                    totalcost += cost[--place];
                }
                
            }
        }
        
        else
        {
            nowtime++;
            totalcost += cost[--place];
        }
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    cout << totalcost << endl;

    return 0;
}