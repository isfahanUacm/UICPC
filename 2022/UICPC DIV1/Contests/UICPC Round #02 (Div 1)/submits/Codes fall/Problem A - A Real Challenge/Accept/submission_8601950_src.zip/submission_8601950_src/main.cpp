#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{
    double s, p, tool;
    cin >> s;
    tool = pow(s, 0.5);
    p = 4 * tool;
    cout << fixed << setprecision(20)  << p;
    return 0;
}
