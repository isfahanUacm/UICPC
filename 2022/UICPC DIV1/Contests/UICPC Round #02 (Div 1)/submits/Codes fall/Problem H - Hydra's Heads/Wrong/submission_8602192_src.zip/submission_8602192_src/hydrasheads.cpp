#include <iostream>
using namespace std;
int H, T,s,i;

int main()
{
    while (true)
    {
        s = 0;
        cin >> H >> T;
        if (H == 0 && T == 0)
        {
            break;
        }
        while (T > 1)
        {
            T -= 2; H++; s++;
        }
        while (H > 1)
        {
            H -= 2; s++;
        }
        if (H == 0 && T == 1)
        {
            for (i = 0; i < 3; i++)
            {
                T++; s++;
            }
            T -= 2; H++; s++; T -= 2; H++; s++; H -= 2; s++;
            cout << s << endl;
        }
        else if (H == 1 && T == 1)
        {
            T++; s++; T -= 2; H++; s++; H -= 2; s++;
            cout << s << endl;
        }
        else if (H == 1 && T == 0)
        {
            cout << -1 <<endl;
        }
        else if (H == 0 && T == 0)
        {
            cout << s << endl;
        }
    }
}
