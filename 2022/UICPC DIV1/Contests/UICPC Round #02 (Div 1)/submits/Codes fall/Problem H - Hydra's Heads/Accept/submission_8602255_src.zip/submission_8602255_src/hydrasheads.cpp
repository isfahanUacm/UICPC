#include <iostream>
using namespace std;

int main()
{
    while (true)
    {
        int h, t, a, b, c;
        cin >> h >> t;
        if (h == 0 && t == 0)
        {
            break;
        }
        a = ((h % 2) * 2 + (t % 4) * 3) % 4;
        b = (t + ((h % 2) * 2 + (t % 4) * 3) % 4);
        c = (h + (t + ((h % 2) * 2 + (t % 4) * 3) % 4) / 2);
        cout << (a + b / 2 + c / 2)<<endl;
    }
    return 0;
}