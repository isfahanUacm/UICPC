from math import pi , floor


def fanc(k):
    z = 0
    for j in range(2, k+1):
        z += fanc(floor(k/j))

    return (0.5*(k+3)*k) - z


n = int(input())
for i in range(n):
    k = int(input().split()[1])
    print(i+1, int(fanc(k)))
