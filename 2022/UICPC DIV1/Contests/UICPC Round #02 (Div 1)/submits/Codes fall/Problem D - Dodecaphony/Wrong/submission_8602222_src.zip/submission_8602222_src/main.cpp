#include <iostream>

using namespace std;

int charNum( char[3] );

int main()
{
    int l;
    cin >> l;
    int* x = new int[l];
    int* y = new int[l];

    for( int i = 0; i < l; i++ )
    {
        char n[3];
        cin >> n;
        x[i] = charNum( n );
    }
    for( int i = 0; i < l; i++ )
    {
        char n[3];
        cin >> n;
        y[i] = charNum( n );
    }
    while( true )
    {
        bool h1=true, h2=true, h3=true;
        // halat 2
        int* temp = new int[l];
        for( int i = 0; i < l; i++ )
        {
            temp[i] = y[i] - x[i];
        }
        for( int i = 0; i < l-1; i++ )
        {
            if( temp[i] != temp[i+1] )
            {
                h2 = false;
                break;
            }
        }
        if( h2 )
        {
            cout << "Transposition";
            break;
        }

        // halat 1
        int t = l-1;
        for( int i = 0; i < l; i++ )
        {
            if( x[i] != y[t] )
            {
                h1 = false;
                break;
            }
            t--;
        }
        if( h1 )
        {
            cout << "Retrograde";
            break;
        }



        // halat 3

        for( int i = 2; i < l; i++ )
        {
            if( x[0] != y[0] )
            {
                h3 = false;
                break;
            }
            if( x[1] != y[1] )
            {
                h3 = false;
                break;
            }
            if( temp[i] >= 0 )
            {
                h3 = false;
                break;
            }
        }
        if( h3 )
        {
            cout << "Inversion";
            break;
        }
        cout << "Nonsense";
        break;
    }
    return 0;
}

int charNum( char n[3] )
{
    switch( n[0] )
    {
    case 'C':
            if( n[1] == '#' )
                return 2;
            else
                return 1;
    case 'D':
             if( n[1] == '#' )
                return 4;
             else
                return 3;
    case 'E':
             return 5;
    case 'F':
             if( n[1] == '#' )
                return 7;
             else
                return 6;

    case 'G':
             if( n[1] == '#' )
                return 9;
             else
                return 8;
    case 'A':
             if( n[1] == '#' )
                return 11;
             else
                return 10;
    case 'B':
            return 12;
    }
}
