boats = []
for i in range(int(input())):
    boats.append(int(input()))

n = len(boats)
t = (n + 1) * [None]

t[0] = 0
for p in range(1, n+1):
    t[p] = min([(t[p-k]+max(boats[p-1] - boats[p-k] - 1800 + 20, 20 * k)+120)
               for k in range(1, p)])

print(t[n])
