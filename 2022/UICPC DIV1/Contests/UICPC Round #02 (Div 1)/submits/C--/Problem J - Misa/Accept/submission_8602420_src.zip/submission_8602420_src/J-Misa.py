r,c  = map(int,input().split())
matrix = []
for i in range(r):
    matrix.append(list(input()))
t=0
m=0
n = [-1,0,1]
for i in range(r):
    for j in range(c):
        if matrix[i][j] == '.':
            if m<9:
                count = 0
                for x in range(3):
                    for y in range(3):
                        if (not n[x]) and (not n[y]):
                            continue
                        ni = i+n[x]
                        if (ni < 0) or ( ni >= r):
                            continue
                        nj = j + n[y]
                        if (nj < 0 ) or ( nj >= c): 
                            continue
                        if (matrix[ni][nj] == 'o'):
                            count += 1
                if count>m:
                    m=count
        else:
            count = 0;
            for x in range(3):
                for y in range(3):
                    if (not n[x]) and (not n[y]):
                        continue
                    ni = i + n[x]
                    if (ni < 0) or (ni >= r): 
                        continue
                    nj = j + n[y]
                    if (nj < 0) or (nj >= c): 
                        continue
                    if (matrix[ni][nj] == 'o'):
                        count += 1
            t += count
print((t >> 1) + m)