from math import sqrt


i=int(input())
print(sqrt(i)*4)