#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int main()
{
	int a;
	cin >> a;
	cout << fixed<<setprecision(6)<< sqrt(a) * 4;
	return 0;
}