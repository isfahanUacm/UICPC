#include <iostream>
#include <math.h>

using namespace std;

int main()
{
	int a;
	cin >> a;
	cout << sqrt(a) * 4;
	return 0;
}