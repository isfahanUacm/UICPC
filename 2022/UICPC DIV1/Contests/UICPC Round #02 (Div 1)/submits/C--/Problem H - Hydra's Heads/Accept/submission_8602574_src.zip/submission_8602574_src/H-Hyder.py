inf = 1 << 29
def solve(h, t):
    if m.get((h,t)) :
        return m[(h, t)]
    best = inf
    if(h <= 2) and (t <= 2):
        best = min(best, solve(h, t+1))
    if(t >= 2):
        best = min(best, solve(h+1, t-2))
    if(h >= 2):
        best = min(best, solve(h-2, t))
    best += 1
    m[(h, t)] = best
    return best

m = dict()
m[(1, 0)] = inf
m[(0,0)] = 0;
m[(2,0)] = 1;
m[(1,2)] = 2;
m[(0,4)] = 3;

while(True):
    n,x = map(int,input().split())
    if(n == 0 ) and ( x == 0):
        break
    
    best = solve(n,x)
    if(best == inf):
        best = -1
    print(best)
