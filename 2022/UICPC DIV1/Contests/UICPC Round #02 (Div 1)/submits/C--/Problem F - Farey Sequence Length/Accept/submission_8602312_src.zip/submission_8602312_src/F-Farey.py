def f():
    for i in range(2, 10001):
        s[i] = i

    for i in range(2, 10000):
        if p[i] == 0:
            t = 2*i
            while t <= 10000:
                p[t] = 1
                s[t] = s[t]*(i-1)//i
                t += i
            s[i] = i-1


def solve():
    ans[2] = 3
    for i in range(3,10001)	:
        ans[i] = ans[i-1] + s[i]


ans = [0 for x in range(10001)]	
p = [0 for x in range(10001)]	
s = [0 for x in range(10001)]	

f()
solve()
for i in range(1,int(input())+1):
    x,n = map(int,input().split())
    print(i,ans[n])
