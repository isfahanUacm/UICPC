#include <iostream>
#include <map>

using namespace std;

map<string, int> notes;

bool Transposition(string* a, string* b, int l)
{
	int temp = notes[b[0]] - notes[a[0]];
	bool pos = true;
	if (temp < 0)
		pos = false;
	for (int i = 1; i < l; i++) {
		if (pos) {
			int x= notes[b[i]] - notes[a[i]];
			if (x < 0)
				x += 12;
			if (x != temp)
				return false;
		}
		else {
			int x = notes[b[i]] - notes[a[i]];
			if (x > 0)
				x -= 12;
			if (x != temp)
				return false;
		}
	}
	return true;
}

bool Retrograde(string* a, string* b, int l)
{
	for (int i = 0; i < l; i++)
		if (a[i] != b[l - i - 1])
			return false;
	return true;
}

bool Inversion(string* a, string* b, int l)
{
	if (a[0] != b[0])
		return false;
	for (int i = 1; i < l; i++) {
		if (a[i] == a[0] && b[i] != a[0])
			return false;
		int temp = notes[a[i]] - notes[a[0]];
		bool pos = true;
		if (temp < 0)
			pos = false;
		int j = notes[a[0]] - temp;
		if (pos) {
			if (j < 0)
				j +=12;
		}
		else {
			if (j > 0)
				j -= 12;
		}
		if (notes[b[i]] != j)
			return false;
	}
	return true;
}

string status(string* a, string* b, int l)
{
	if (Retrograde(a, b, l))
		return "Retrograde";
	if (Inversion(a, b, l))
		return "Inversion";
	if (Transposition(a, b, l))
		return "Transposition";
	return "Nonsense";
}

void make()
{
	notes["C"] = 1;
	notes["C#"] = 2;
	notes["D"] = 3;
	notes["D#"] = 4;
	notes["E"] = 5;
	notes["F"] = 6;
	notes["F#"] = 7;
	notes["G"] = 8;
	notes["G#"] = 9;
	notes["A"] = 10;
	notes["A#"] = 11;
	notes["B"] = 12;
}

int main()
{
	make();
	int l;
	cin >> l;
	string* a, * b;
	a = new string[l];
	b = new string[l];
	for (int i = 0; i < l; i++)
		cin >> a[i];
	for (int i = 0; i < l; i++)
		cin >> b[i];
	cout << status(a, b, l);
	return 0;
}