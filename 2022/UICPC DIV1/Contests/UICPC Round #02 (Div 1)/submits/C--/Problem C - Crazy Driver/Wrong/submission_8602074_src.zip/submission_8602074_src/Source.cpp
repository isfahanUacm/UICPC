#include <iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int* c = new int[n - 1];
	for (int i = 0; i < n - 1; i++)
		cin >> c[i];
	int* t = new int[n];
	for (int i = 0; i < n; i++)
		cin >> t[i];
	int cost = 0, time = t[1], crazy = 1;
	while (crazy < n) {
		if (t[crazy] <= time) {
			cost += c[crazy - 1];
			crazy++;
			time++;
		}
		else {
			time += 2;
			cost += 2 * c[crazy - 2];
		}
	}
	cout << cost;
	/*5
		5 4 2 8
		0 2 4 4 8*/

}