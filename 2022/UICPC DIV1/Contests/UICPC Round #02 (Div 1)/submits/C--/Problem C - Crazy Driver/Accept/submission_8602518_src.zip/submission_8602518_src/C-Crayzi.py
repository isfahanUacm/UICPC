now = 0
dist = 0
n = int(input())
c = [0]
t = []
m = [0 for x in range(n)]
b = [int(x) for x in input().split()]

c.extend(b)
m[1] = c[1]

for i in range(2,n):
    m[i] = min(m[i-1],c[i])
t.extend(list(map(int,input().split())))
for i in range(1,n):
    dist += c[i];
    now += 1
    if now < t[i] : 
        d = t[i] - now
        if (d & 1):
            d+=1
        now += d
        dist += d*m[i]

print(dist)
