#include <iostream>

using namespace std;

int main()
{
    int n, time = 0;
    long long int cost = 0;

    cin >> n;

    int costs[n], times[n], bests[n];

    for(int i = 1; i < n; i++)
    {
        cin >> costs[i];
    }

    for (int i = 0; i < n; i++)
    {
        cin >> times[i];
    }
    
    bests[1] = costs[1]; 

    for(int i = 2; i < n; i++)
    {
        if(bests[i-1] > costs[i])
        {
            bests[i] = costs[i];
        }
        else
        {
            bests[i] = bests[i-1];
        }
    }

    for(int i = 1; i < n; i++)
    {
        cost += costs[i];
        time++;

        if(time < times[i])
        {
            long long int distance = times[i]-time;
            if(distance % 2 != 0)
            {
                distance++;
            }
            cost += (distance)*bests[i];
            time += distance;
        }
    }

    cout << cost << endl;

    return 0;
}