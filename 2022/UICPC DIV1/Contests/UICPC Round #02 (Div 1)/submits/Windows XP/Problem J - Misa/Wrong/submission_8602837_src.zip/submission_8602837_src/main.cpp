#include <iostream>
#include <utility>

int R, S;
char seats_map[50][50];



bool can_shake_hands_with (int i, int j) {

    if (i < 0 || j < 0 || i >= R || j >= S) return false;

    if (seats_map[i][j] == 'o') return true;
    else return false;

}



int count_hand_shakes (int i, int j) {

    int result = 0;

    if (can_shake_hands_with(i - 1, j)) result += 1;
    if (can_shake_hands_with(i - 1, j + 1)) result += 1;
    if (can_shake_hands_with(i, j + 1)) result += 1;
    if (can_shake_hands_with(i + 1, j + 1)) result += 1;
    if (can_shake_hands_with(i + 1, j)) result += 1;
    if (can_shake_hands_with(i + 1, j - 1)) result += 1;
    if (can_shake_hands_with(i, j - 1)) result += 1;
    if (can_shake_hands_with(i - 1, j - 1)) result += 1;

    return result;

}



void find_seat () {

    int max = 0, imax = -1, jmax = -1;

    for (int i = 0; i < R; i++) {

        for (int j = 0; j < S; j++) {

            if (seats_map[i][j] == '.') {

                if (count_hand_shakes(i, j) > max) {

                    imax = i;
                    jmax = j;
                    max = count_hand_shakes(i, j);
                    
                }

            }

        }
    
    }

    if (imax >= 0 && jmax >= 0) seats_map[imax][jmax] = 'o';

    return;

}




int answer () {

    int result = 0;

    for (int i = 0; i < R; i++)
        for (int j = 0; j < S; j++)
            if (seats_map[i][j] == 'o') result += count_hand_shakes(i, j);

    return result / 2;

}




int main () {

    std :: cin >> R >> S;

    for (int i = 0; i < R; i++)
        for (int j = 0; j < S; j++)
            std :: cin >> seats_map[i][j];

    find_seat();

    for (int i = 0; i < R; i++) {
        for (int j = 0; j < S; j++)
            std :: cout << seats_map[i][j];
        std :: cout << std :: endl;
    }

    std :: cout << answer();

    return 0;

}