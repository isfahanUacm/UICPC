#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    int head = 0, tail = 1, moves;
    bool found;

    while (true)
    {
        cin >> head >> tail;

        if (head == 0 && tail == 0)
        {
            break;
        }

        found = false;
        moves = 0;

        while (head >= 2)
        {
            head -= 2;
            moves++;
        }

        if (head == 0 && tail == 0)
        {
            cout << moves << endl;
            continue;
        }

        while (tail > 2)
        {
            tail -= 2;
            head += 1;
            moves++;
        }

        if(tail == 2)
        {
            if(head % 2 == 0)
            {
                moves += 5;
                tail += 2;
            }
            else
            {
                moves += 1;
                tail -= 2;
                head += 1;
            }
        }
        else // tail == 1
        {
            if(head % 2 == 0)
            {
                moves += 5;
                head += 2;
                tail = 0;
            }
            else
            {
                moves += 2;
                tail = 0;
                head += 1;
            }
        }

        while(head >= 2)
        {
            moves++;
            head -= 2;
        }

        if (head == 1)
        {
            if (tail == 1)
            {
                moves += 3;
                cout << moves << endl;
                continue;
            }
            else
            {
                cout << -1 << endl;
                continue;
            }
        }
        else
        {
            if (tail == 1)
            {
                moves += 6;
                cout << moves << endl;
                continue;
            }
            else
            {
                cout << moves << endl;
            }
        }
    }

    return 0;
}