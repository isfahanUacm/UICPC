#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    int head = 0, tail = 1, moves;
    bool found;

    while (true)
    {
        cin >> head >> tail;

        if (head == 0 && tail == 0)
        {
            break;
        }

        found = false;
        moves = 0;

        while (head >= 2)
        {
            head -= 2;
            moves++;
        }

        if (head == 0 && tail == 0)
        {
            cout << moves << endl;
            continue;
        }

        while (tail >= 2)
        {
            tail -= 2;
            head += 1;
            moves++;
        }

        if (head == 0 && tail == 0)
        {
            cout << moves << endl;
            continue;
        }

        while (head >= 2)
        {
            head -= 2;
            moves++;
        }

        if (head == 1)
        {
            if (tail == 1)
            {
                moves += 3;
                cout << moves << endl;
                continue;
            }
            else
            {
                cout << -1 << endl;
                continue;
            }
        }
        else
        {
            if (tail == 1)
            {
                moves += 6;
                cout << moves << endl;
                continue;
            }
            else
            {
                cout << moves << endl;
            }
        }
    }

    return 0;
}