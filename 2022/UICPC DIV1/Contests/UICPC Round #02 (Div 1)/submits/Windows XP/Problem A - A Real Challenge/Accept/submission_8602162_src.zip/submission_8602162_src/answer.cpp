#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    cout << fixed;
    cout << setprecision(9);
    unsigned long long int area;
    double z;

    cin >> area;

    z = sqrt(area);

    cout << 4*z << endl;

    return 0;
}