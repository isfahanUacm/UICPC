#include<iostream>
using namespace std;
int timecal(int arrive_time[],int numbers,int flag,int current_time,int total_time){
    int i=flag;
    while (((current_time+120)>=arrive_time[i])&&(i<numbers))
    {
        if(current_time<arrive_time[i]){
             total_time+=arrive_time[i]-current_time;
             current_time+=arrive_time[i]-current_time;
        }

        total_time+=20;
        current_time+=20;

        i++;
    }
    if(i==numbers){
        return total_time;
    }
    else{
        i++;
        total_time+=timecal(arrive_time,numbers,i,current_time,total_time);
        return total_time-20;
    }
}
int main(){
    int numbers;
    cin>>numbers;
    int arrive_time[numbers];
    for(int i=0;i<numbers;i++)
        cin>>arrive_time[i];
    int total_time=140;
    int current_time=20;

    if(numbers==1){
        cout<<140;
        return 0;
    }

    current_time+=arrive_time[0];
    current_time+=1800;
    total_time=timecal(arrive_time,numbers,1,current_time,total_time);
    cout<<total_time;
    return 0;
}
