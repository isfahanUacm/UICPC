#include<iostream>
using namespace std;
long timecal(long arrive_time[],long numbers,int flag,long current_time,long total_time){
    int i=flag;
    if(i<numbers){
        while (((current_time+120)>arrive_time[i])&&(i<numbers))
        {
        if(current_time<arrive_time[i]){
             total_time+=arrive_time[i]-current_time;
             current_time+=arrive_time[i]-current_time;
        }

        total_time+=20;
        current_time+=20;

        i++;
        }
    }
    
    if(i==numbers){
        return total_time;
    }
    else{
        current_time=arrive_time[i];
        total_time=total_time+140;
        i++;
        total_time=timecal(arrive_time,numbers,i,current_time,total_time);
        return total_time;
    }
}
int main(){
    long numbers;
    cin>>numbers;
    long arrive_time[numbers];
    for(int i=0;i<numbers;i++)
        cin>>arrive_time[i];
    long total_time=140;
    long current_time=20;

    if(numbers==1){
        cout<<140;
        return 0;
    }

    current_time+=arrive_time[0];
    current_time+=1800;
    total_time=timecal(arrive_time,numbers,1,current_time,total_time);
    cout<<total_time;
    return 0;
}
