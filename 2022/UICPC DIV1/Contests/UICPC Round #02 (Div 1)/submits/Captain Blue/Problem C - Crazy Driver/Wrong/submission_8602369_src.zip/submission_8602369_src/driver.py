import math
ans = 0
t=0
n = int(input())
fee = input().split()
time = input().split()
for i in range(n-1):
    fee[i] = int(fee[i])
for i in range(n):
    time[i] = int(time[i])
# ans += fee[0]
# t+=1
for i in range(n-1):
    flag = 0
    q = i
    # if(time[i+1]==time[i]):
    #     ans+=fee[i]
    #     t+=1
    #     print(ans , '@',1,fee[i] ,i)
    if(time[i+1]-t==2):  
        ans += 2*fee[i] 
        t+=2
        q -= 1
        # print(ans , '^',1,fee[i] ,i , 't:' , t , 'i:' , i)
        # continue
    for j in range(math.ceil((time[i+1]-t)/2)):
        # print('time report: ', time[i+1], t , j)
        flag = 1
        if(flag==0):
            ans += fee[i]
            t+=1
            if((time[i+1]-t<1)):
                    q+=1
            
            # q = q-1
            # print(ans , '*',1,fee[i] ,i)
            flag = 1
        else:
            if(fee[q-1]<=fee[q]):
                
                ans += fee[q-1]
                t+=1
                
                # print(ans,'&',2,fee[q-1],i)
                q = q-1
                
            else:
                ans += fee[q]
                # print(ans , '$', 3,fee[q],i)
                q += ((-1)**j)
                t+=1
                
                
    if(q>=(i)):
        continue
    # print(q,'##' , time[i+1] , t)
    while(q<i):
        q+=1
        ans += fee[q]
        t+=1
        print(4,fee[q],i)
        
    
    
print(ans)

        