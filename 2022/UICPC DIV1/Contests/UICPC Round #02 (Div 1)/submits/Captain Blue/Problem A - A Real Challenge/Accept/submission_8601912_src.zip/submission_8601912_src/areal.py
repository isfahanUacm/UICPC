import math
a = int(input())
a = math.sqrt(a)
print(4*a)