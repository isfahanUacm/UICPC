
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class practice {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num=sc.nextInt();
        for (int i = 0; i < num; i++) {
            int k = sc.nextInt();
            int n = sc.nextInt();
            long count=(farey(n));
            System.out.print(k+" "+count);
            System.out.println();
        }

    }
    static long farey(int n)
    {
        // We know first two terms are 0/1 and 1/n
        double x1 = 0, y1 = 1, x2 = 1, y2 = n;
        long count=2;
        //System.out.printf("%.0f/%.0f %.0f/%.0f", x1, y1, x2, y2);

        double x, y = 0; // For next terms to be evaluated
        while (y != 1.0)
        {
            count++;
            x = Math.floor((y1 + n) / y2) * x2 - x1;
            y = Math.floor((y1 + n) / y2) * y2 - y1;
            //System.out.printf(" %.0f/%.0f", x, y);
            x1 = x2;
            x2 = x;
            y1 = y2;
            y2 = y;
        }
        return count;
}
}
