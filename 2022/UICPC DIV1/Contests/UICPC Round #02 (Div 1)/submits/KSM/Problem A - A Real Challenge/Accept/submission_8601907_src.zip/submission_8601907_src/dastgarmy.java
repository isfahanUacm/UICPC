import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class dastgarmy {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a = sc.nextDouble();
        System.out.println(4 * Math.sqrt(a));
        }
    }