import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<Integer> foo = new ArrayList<>();
        ArrayList<Integer> time = new ArrayList<>();
        for (int i = 0; i < n - 1; i++) {
            foo.add(sc.nextInt());
        }
        for (int i = 0; i < n; i++) {
            time.add(sc.nextInt());
        }
        int t = 0;
        int cost = 0;
        for (int i = 0; i < foo.size() - 1; i++) {
            if (foo.get(i) >= foo.get(i + 1)) {
                if (t >= time.get(i + 1)) {
                    t++;
                    cost += foo.get(i);
                } else if ((time.get(i + 1) - t) % 2 == 0) {
                    cost += foo.get(i) * (time.get(i + 1) - t + 1);
                    t += ((time.get(i + 1) - t) + 1);
                } else {
                    cost += foo.get(i) * (time.get(i + 1) - t);
                    t += (time.get(i + 1) - t);
                }
            } else if (foo.get(i) < foo.get(i + 1)) {
                if (t < time.get(i + 2) - 1 && (time.get(i + 2) - t - 1) % 2 == 0) {
                    cost += foo.get(i) * (time.get(i + 2) - t - 1 + 1);
                    cost += foo.get(i + 1);
                    t += (time.get(i + 2) - t - 1) + 1 + 1;
                    i++;
                } else if (t < time.get(i + 2) - 1) {
                    cost += foo.get(i) * (time.get(i + 2) - t - 1);
                    cost += foo.get(i + 1);
                    t += time.get(i + 2) - t - 1 + 1;
                    i++;
                }
            }
        }
        System.out.println(cost);
    }
}
