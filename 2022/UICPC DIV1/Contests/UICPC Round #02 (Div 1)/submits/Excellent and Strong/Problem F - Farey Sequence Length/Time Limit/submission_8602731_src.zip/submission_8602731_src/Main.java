import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            int index = sc.nextInt();
            int num = sc.nextInt();
            int ans = 1;
            for (int k = 1; k <= num; k++) {
                ans += findPrimePair(k);
            }
            System.out.println(index + " " + ans);
        }
    }

    static int phi(int n) {
        float result = n;

        for (int p = 2; p * p <= n; ++p) {
            if (n % p == 0) {
                while (n % p == 0)
                    n /= p;
                result *= (1.0 - (1.0 / (float) p));
            }
        }
        if (n > 1)
            result *= (1.0 - (1.0 / (float) n));

        return (int) result;
    }

    static void SieveOfEratosthenes(int n, boolean isPrime[]) {
        // Initialize all entries of boolean array
        // as true. A value in isPrime[i] will finally
        // be false if i is Not a prime, else true
        // bool isPrime[n+1];
        isPrime[0] = isPrime[1] = false;
        for (int i = 2; i <= n; i++)
            isPrime[i] = true;

        for (int p = 2; p * p <= n; p++) {
            // If isPrime[p] is not changed, then it is
            // a prime
            if (isPrime[p] == true) {
                // Update all multiples of p
                for (int i = p * 2; i <= n; i += p)
                    isPrime[i] = false;
            }
        }
    }

    // Function to print a prime pair
    // with given product
    static int findPrimePair(int n) {

        // Generating primes using Sieve
        boolean[] isPrime = new boolean[n + 1];
        SieveOfEratosthenes(n, isPrime);

        // Traversing all numbers to find first
        // pair
        for (int i = 2; i < n; i++) {
            int x = n / i;

            if (isPrime[i] && isPrime[x] && x != i && x * i == n) {
                return phi(i) * phi(x);
            }
        }

        return phi(1)*phi(n);
    }

}
