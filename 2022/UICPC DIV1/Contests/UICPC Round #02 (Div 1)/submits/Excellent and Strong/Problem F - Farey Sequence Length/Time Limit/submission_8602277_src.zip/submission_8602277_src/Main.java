import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            int index = sc.nextInt();
            System.out.println(index +" "+farey(sc.nextInt()));
        }
    }

    static int farey(int n) {
        double x1 = 0, y1 = 1, x2 = 1, y2 = n;
        int index = 2;
        double x, y = 0;
        while (y != 1.0) {
            index++;
            x = Math.floor((y1 + n) / y2) * x2 - x1;
            y = Math.floor((y1 + n) / y2) * y2 - y1;
            x1 = x2;
            x2 = x;
            y1 = y2;
            y2 = y;
        }
        return index;
    }
}
