#include <bits/stdc++.h>
using namespace std;

int main()
{
    double a;
    cin >> a;
    double l = sqrt(a);
    double ans = l * 4;
    printf("%.7lf" , ans);
}