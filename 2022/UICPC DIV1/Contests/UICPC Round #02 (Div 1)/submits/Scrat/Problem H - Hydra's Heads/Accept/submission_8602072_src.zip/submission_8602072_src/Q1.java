import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q1 {


    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        int n;
        int m;
        List<Integer> integers = new ArrayList<>();
        do {
            n = scanner.nextInt();
            m = scanner.nextInt();
            if (n == 0 && m == 0) break;
            integers.add(q(n,m));
        } while (true);
        integers.forEach(System.out::println);
    }

    private static int q(int h, int t) {
        int moves = 0;
        if (h % 2 == 0) {
            if (t % 4 != 0) {
                moves += 4 - t % 4;
                t += 4 - t % 4;
            }
            moves += t / 2;
            h += t / 2;
            moves += h / 2;
        } else {
            if (t == 0) return -1;
            if (t % 4 != 2) {
                if (t % 2 == 0) {
                    moves += 2;
                    t += 2;
                } else {
                    moves += t % 4;
                    t += t % 4;
                }
            }
            moves += t / 2;
            h += t / 2;
            moves += h / 2;
        }
        return moves;
    }
}
