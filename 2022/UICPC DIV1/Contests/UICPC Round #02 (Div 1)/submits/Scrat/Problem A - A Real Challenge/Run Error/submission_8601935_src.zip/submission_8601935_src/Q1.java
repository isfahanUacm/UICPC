import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q1 {


    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.println(Math.sqrt((double) n) * 4);
    }
}
