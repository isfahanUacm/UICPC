import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q1 {
    static int[][] chairs;
    static int n;
    static int m;

    public static void main(String[] args) throws FileNotFoundException {
        int shakes = 0;
        int max = 0;
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        m = scanner.nextInt();
        chairs = new int[n][m];
        for (int i = 0; i < n; i++) {
            String line = scanner.next();
            for (int j = 0; j < m; j++) {
                chairs[i][j] = 1;
                if (line.charAt(j) == '.')
                    chairs[i][j] = 0;
            }
        }
        for(int i=0;i<n;i++) {
            for(int j=0;j<m;j++) {
                if(chairs[i][i] == 0) {
                    int cur = count(i, j);
                    if(max < cur)
                        max = cur;
                }
                else {
                    shakes += count(i, j);
                }
            }
        }
        System.out.println(max + shakes /2);
    }

    static int count(int i, int j) {
        int c = 0;
        try {
            c += chairs[i - 1][j - 1];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i - 1][j + 1];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i - 1][j];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i + 1][j - 1];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i + 1][j + 1];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i + 1][j];
        } catch (Throwable ignored) {

        }
        try {
            c += chairs[i][j - 1];
        } catch (Throwable t) {

        }
        try {
            c += chairs[i][j + 1];
        } catch (Throwable t) {

        }
        return c;
    }
}
