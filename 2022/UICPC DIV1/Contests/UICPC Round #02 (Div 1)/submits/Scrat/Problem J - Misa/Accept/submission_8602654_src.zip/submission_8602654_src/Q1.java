import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q1 {
    static int[][] chairs;
    static int n;
    static int m;

    public static void main(String[] args) throws FileNotFoundException {
        long shakes = 0;
        long max = 0;
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();
        m = scanner.nextInt();
        chairs = new int[n][m];
        for (int i = 0; i < n; i++) {
            String line = scanner.next();
            for (int j = 0; j < m; j++) {
                chairs[i][j] = 1;
                if (line.charAt(j) == '.')
                    chairs[i][j] = 0;
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (chairs[i][j] == 0 && max < 9) {
                    int cur = count(i, j);
                    if (max < cur)
                        max = cur;
                } else if(chairs[i][j] == 1){
                    shakes += count(i, j);
                }
            }
        }
        System.out.println(max + shakes / 2);
    }

    static int count(int i, int j) {
        int c = 0;
        if (i - 1 != -1 && j - 1 != -1) c += chairs[i - 1][j - 1];
        if (i - 1 != -1 && j + 1 != m) c += chairs[i - 1][j + 1];
        if (i - 1 != -1) c += chairs[i - 1][j];
        if (i + 1 != n && j - 1 != -1) c += chairs[i + 1][j - 1];
        if (i + 1 != n && j + 1 != m) c += chairs[i + 1][j + 1];
        if (i + 1 != n) c += chairs[i + 1][j];
        if (j - 1 != -1) c += chairs[i][j - 1];
        if (j + 1 != m) c += chairs[i][j + 1];
        return c;
    }
}
