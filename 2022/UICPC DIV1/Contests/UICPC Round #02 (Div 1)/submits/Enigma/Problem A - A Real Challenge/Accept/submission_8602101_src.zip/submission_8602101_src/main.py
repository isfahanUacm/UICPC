import math
n = int(input())
a = math.sqrt(n)
b = int(a)
if a - b == 0:
    print(4 * b)
else:
    print(round((4 * a), 6))

