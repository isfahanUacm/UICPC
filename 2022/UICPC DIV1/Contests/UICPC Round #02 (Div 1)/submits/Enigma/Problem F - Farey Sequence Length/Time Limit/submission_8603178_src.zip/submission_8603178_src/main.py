a = int(input())
f = []
for i in range(a):
    c = input()
    split = c.split(" ")
    f.append(int(split[1]))
r = set()
w = []
for j in range(a):
    if j > 0:
        w.append(len(r))
        r.clear()
    for b in range(1, f[j]+1):
        for a in range(b+1):
            c = a / b
            r.add(c)

w.append(len(r))


for i in range(len(w)):
    print(f"{i+1} {w[i]}")