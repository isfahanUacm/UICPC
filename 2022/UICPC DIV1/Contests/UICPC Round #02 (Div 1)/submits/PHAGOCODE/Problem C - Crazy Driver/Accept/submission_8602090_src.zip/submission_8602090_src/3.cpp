#include<bits/stdc++.h>
using namespace std;
main() {
    int n;
    cin >> n;

    int c[n-1];
    for (int i=0; i<n-1; i++) {
        cin >> c[i];
    }
    
    int t[n];
    for (int i=0; i<n; i++) {
        cin >> t[i];
    }

    long long sum = 0;
    for (int i=0; i<n-1; i++) {
        sum += c[i];
    }

    int x = 0;
    int y = INT_MAX;
    for (int i=1; i<n; i++) {
        x++;
        y = min(y, c[i-1]);
        while (t[i] > x) {
            x += 2;
            sum += y*2;
        }
    }
    cout << sum;
    return 0;
}