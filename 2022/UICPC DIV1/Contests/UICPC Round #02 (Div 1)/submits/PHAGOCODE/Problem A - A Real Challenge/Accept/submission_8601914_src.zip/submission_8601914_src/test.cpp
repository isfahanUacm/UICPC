#include<bits/stdc++.h>
using namespace std;
main(){
    double n;
    cin >> n;
    double ans = 4*sqrt(n);
    cout << setprecision(20) << ans;
}
