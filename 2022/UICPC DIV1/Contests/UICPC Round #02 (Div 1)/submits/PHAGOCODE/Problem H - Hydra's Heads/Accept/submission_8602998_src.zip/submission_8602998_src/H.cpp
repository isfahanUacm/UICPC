#include<bits/stdc++.h>
using namespace std;
int main(){
    int sum = 0;
    while (1) {
        int h, t;
        cin >> h;
        cin >> t;
        if (!(h || t)) break;
        sum = 0;
        if (t == 0) {
            if (h%2 == 1) {sum = -1;}
            else {sum = h/2;}
        } else {
            if (t == 1) {sum++;t++;}
            if (h%2==1) {
                sum++;
                t-=2;
                h++;
            }
            int x;
            if (t%4 == 0 || t==0) x = 0;
            else x = 4-t%4;
            t += x;
            sum += x;
            sum += t/2+(h+t/2)/2;
        }
        cout << sum << endl;
    }
    return 0;
}
