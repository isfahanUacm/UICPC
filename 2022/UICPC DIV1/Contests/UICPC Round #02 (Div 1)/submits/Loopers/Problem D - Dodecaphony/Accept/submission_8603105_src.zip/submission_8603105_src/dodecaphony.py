keys = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


def transposition(a, b):
    d = abs(keys.index(a[0]) - keys.index(b[0]))
    for i in range(1, n):
        if abs(keys.index(a[i]) - keys.index(b[i])) != d:
            return 0
    return 1


def retrograde(a, b):
    return a[::-1] == b


def inversion(a, b):
    for i in range(n):
        d = keys.index(a[i]) - keys.index(a[0])
        res = keys.index(a[0]) - d
        if res < 0:
            res += 12
        res %= 12
        if keys.index(b[i]) != res:
            return 0
    return 1


n = int(input())
a = input().split()
b = input().split()

if transposition(a, b):
    print('Transposition')
elif retrograde(a, b):
    print('Retrograde')
elif inversion(a, b):
    print('Inversion')
else:
    print('Nonsense')