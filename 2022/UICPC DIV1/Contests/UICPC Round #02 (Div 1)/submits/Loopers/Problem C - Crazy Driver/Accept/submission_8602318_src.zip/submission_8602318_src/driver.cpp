#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    ll t = 1, ans = 0;
    cin >> N;
    vector<int> C(N - 1);
    vector<int> T(N);
    for (auto& i : C) cin >> i;
    for (auto& i : T) cin >> i;
    vector<int> mc(N - 1);
    mc[0] = C[0];
    for (int i = 1; i < N - 1; i++) {
        mc[i] = min(mc[i - 1], C[i]);
    }
    for (int i = 0; i < N - 1; i++) {
        ans += C[i];
        if (t < T[i + 1]) {
            ll x = T[i + 1] - t;
            x += (x & 1);
            ans += x * mc[i];
            t += x;
        }
        t++;
    }
    cout << ans << '\n';
    return 0;
}