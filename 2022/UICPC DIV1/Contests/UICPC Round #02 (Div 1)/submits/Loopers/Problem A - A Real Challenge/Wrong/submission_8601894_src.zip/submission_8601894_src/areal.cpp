#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    cout << setprecision(6) << fixed << sqrt(n) * 4 << '\n';
    return 0;
}