#include <iostream>
#include <vector>

using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int P;
    vector<int> v1(10001), v2(10001);
    v2[1] = 2;
    for (int i = 2; i <= 10000; i++) {
        v1[i] = i;
    }
    for (int i = 2; i <= 10000; i++) {
        if (v1[i] == i) {
            for (int j = i; j <= 10000; j += i) {
                v1[j] = v1[j] * (i - 1) / i;
            }
        }
    }
    for (int i = 2; i <= 10000; i++) {
        v2[i] = v2[i - 1] + v1[i];
    }
    cin >> P;
    while (P--) {
        int K, N;
        cin >> K >> N;
        cout << K << ' ' << v2[N] << '\n';
    }
}