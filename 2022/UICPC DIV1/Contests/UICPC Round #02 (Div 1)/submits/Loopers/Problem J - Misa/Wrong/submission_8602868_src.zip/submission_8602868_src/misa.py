ans = 0


def solve(x, y):
    global ans
    c = [-1, 0, +1]
    if a[x][y] == 'o':
        for i in c:
            for j in c:
                if i != 0 or j != 0:
                    if a[x + i][y + j] == 'o':
                        ans += 1


def solve2(x, y):
    ans3 = 0
    c = [-1, 0, +1]
    if a[x][y] == '.':
        for i in c:
            for j in c:
                if i != 0 or j != 0:
                    if a[x + i][y + j] == 'o':
                        ans3 += 1
    return ans3, x, y


r, s = map(int, input().split())
a = [['.' for i in range(s + 2)] for j in range(r + 2)]
for i in range(1, r + 1):
    tmp = input()
    for j in range(0, s):
        a[i][j + 1] = tmp[j]

ans2 = 0
for i in range(1, r + 1):
    for j in range(1, s + 1):
        ans3, f, g = solve2(i, j)
        ans2 = max(ans2, ans3)

if ans2 != 0:
    a[f][g] = 'o'

for i in range(1, r + 1):
    for j in range(1, s + 1):
        solve(i, j)


print((ans + ans2) // 2)
