h, t = map(int, input().split())
while h != 0 and t != 0:
    moves = 0
    while 1:
        x = h + (t >> 1)
        if (t & 1) != 0 or (x & 1) != 0:
            moves += 1
            t += 1
        else:
            moves += (t + x) >> 1
            break
    print(moves)
    h, t = map(int, input().split())
