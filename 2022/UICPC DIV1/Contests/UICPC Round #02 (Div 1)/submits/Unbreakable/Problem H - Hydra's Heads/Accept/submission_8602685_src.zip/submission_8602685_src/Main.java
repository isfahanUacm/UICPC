

import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        while (true) {
            int head = sc.nextInt();
            int tail = sc.nextInt();
            if (tail == 0 && head == 0) break;

            int addedTails = 0;
            if (head % 2 == 0) {
                // tail should be tail % 4 == 0
                switch (tail % 4) {
                    case 0:
                        addedTails = 0;
                        break;
                    case 1:
                        addedTails = 3;
                        break;
                    case 2:
                        addedTails = 2;
                        break;
                    case 3:
                        addedTails = 1;
                        break;
                }
            } else {
                // tail should be tail % 4 != 0
                // tail should be tail % 2 == 0
                switch (tail % 4) {
                    case 0:
                        addedTails = 2;
                        break;
                    case 1:
                        addedTails = 1;
                        break;
                    case 2:
                        addedTails = 0;
                        break;
                    case 3:
                        addedTails = 3;
                        break;
                }
            }
            int ans = addedTails;
            tail += addedTails;
            head += tail / 2;
            ans = (ans + tail / 2 + head / 2);
            System.out.println(ans);
        }
    }
}
