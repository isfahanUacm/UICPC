

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        BigDecimal a = new BigDecimal(sc.nextLong());
        MathContext mc = new MathContext(20);
        BigDecimal four = new BigDecimal(4);
        System.out.println(a.sqrt(mc).multiply(four));
    }
}
