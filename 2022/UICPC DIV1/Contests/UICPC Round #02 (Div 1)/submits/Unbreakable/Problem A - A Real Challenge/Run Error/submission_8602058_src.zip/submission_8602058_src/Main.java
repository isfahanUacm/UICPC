

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int s = sc.nextInt();
        BigDecimal a = new BigDecimal(s);
        MathContext mc = new MathContext(500);
        BigDecimal four = new BigDecimal(4);
        System.out.println(a.sqrt(mc).multiply(four));
    }
}
