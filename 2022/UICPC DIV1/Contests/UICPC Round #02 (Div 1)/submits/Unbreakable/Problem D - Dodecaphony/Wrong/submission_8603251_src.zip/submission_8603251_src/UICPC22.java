import java.util.ArrayList;
import java.util.Scanner;

public class UICPC22 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //String[] arr={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
        ArrayList<String> arr2 = new ArrayList<>();
        arr2.add("C");
        arr2.add("C#");
        arr2.add("D");
        arr2.add("D#");
        arr2.add("E");
        arr2.add("F");
        arr2.add("F#");
        arr2.add("G");
        arr2.add("G#");
        arr2.add("A");
        arr2.add("A#");
        arr2.add("B");

        int n = sc.nextInt();
        sc.nextLine();

        String s = sc.nextLine();
        String[] s1 = s.split(" ");
        String sd = sc.nextLine();

        String trans = "";
        for (int i = 0; i < n; i++) {
            int x = arr2.indexOf(s1[i]);
            int j = x + 2;
            if (j < 12) {
                trans += arr2.get(j);
            } else {
                trans += arr2.get(j - (12 - 1) - 1);
            }
        }
        if (trans.equals(sd.replaceAll(" ", ""))) {
            System.out.println("Transposition");
        } else {
            String inver = "";
            inver += s1[0];
            int x = arr2.indexOf(s1[0]);
            for (int i = 1; i < n; i++) {
                int x2 = arr2.indexOf(s1[i]);
                if (x2 - x >= 0) {
                    int temp = x2 - x;
                    if (x - temp >= 0) {
                        inver += arr2.get(x - temp);
                    } else {
                        inver += arr2.get(12 - 1 - Math.abs(x - temp) + 1);
                    }
                } else {
                    int temp = x - x2;
                    if (x + temp <= 11) {
                        inver += arr2.get(x + temp);
                    } else {
                        inver += arr2.get((Math.abs(temp - (12 - 1 - x)) - 1));
                    }
                }
            }
            if (inver.equals(sd.replaceAll(" ", ""))) {
                System.out.println("Inversion");
            } else {
                String rev = "";
                for (int i = n - 1; i >= 0; i--) {
                    rev += s1[i];
                }
                if (rev.equals(sd.replaceAll(" ", ""))) {
                    System.out.println("Retrograde");
                } else {
                    System.out.println("Nonsense");
                }
            }

        }
    }
}
