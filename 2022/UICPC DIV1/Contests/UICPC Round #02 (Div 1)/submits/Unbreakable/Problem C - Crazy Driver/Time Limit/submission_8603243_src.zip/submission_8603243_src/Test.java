import java.util.Scanner;

public class Test {

    static int getMin(int[] inputArray) {
        int minValue = inputArray[0];
        for (int i = 1; i < inputArray.length; i++) if (inputArray[i] < minValue) minValue = inputArray[i];
        return minValue;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] c = new int[n - 1];
        int[] t = new int[n];
        for (int i = 0; i < c.length; i++) c[i] = sc.nextInt();
        for (int i = 0; i < t.length; i++) t[i] = sc.nextInt();
        int cost = 0;
        int time = 0;
        int minCost = getMin(c);
        int lastHour = t[n - 1];
        int i = 0;

        while (i < c.length) {
            if (i > 0 && c[i - 1] == minCost) {
                int roadLength = t.length - i - 1;
                if (roadLength == 1 && (lastHour - roadLength != time)) cost += c[--i];
                else cost += c[i++];
                time++;
            } else if (t[i] > time) {
                cost += c[--i];
                time++;
            } else {
                cost += c[i++];
                time++;
            }
        }

        System.out.print(cost);
    }
}