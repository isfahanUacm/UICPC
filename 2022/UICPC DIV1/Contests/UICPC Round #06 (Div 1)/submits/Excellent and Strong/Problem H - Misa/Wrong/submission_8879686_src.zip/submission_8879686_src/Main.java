import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int s = sc.nextInt();
        int[][] x = new int[r][s];
        int seatRow = -1;
        int seatCol = -1;
        for (int i = 0; i < r; i++) {
            String row = sc.next();
            for (int j = 0; j < s; j++) {
                if (row.charAt(j) == 'o') {
                    x[i][j] = 1;
                } else {
                    seatRow = i;
                    seatCol = j;
                    x[i][j] = 0;
                }
            }
        }

        int handShake;
        if (seatRow == -1) {
            handShake = s + (s * (r - 1)) * 2;
        } else {
            handShake = 0;
            for (int i = 0; i < seatRow; i++) {
                for (int j = 0; j < s; j++) {
                    if (x[i][j] == 1) {
                        handShake++;
                    }
                }
            }
            int[] myRow = x[seatRow];
            int left = 0;
            int right = 0;
            for (int i = 0; i < seatCol; i++) {
                if (myRow[i] == 1) {
                    left++;
                }
            }
            for (int i = seatCol + 1; i < myRow.length; i++) {
                if (myRow[i] == 1) {
                    right++;
                }
            }
            handShake += Math.max(left, right);
        }
        System.out.println(handShake);
    }
}