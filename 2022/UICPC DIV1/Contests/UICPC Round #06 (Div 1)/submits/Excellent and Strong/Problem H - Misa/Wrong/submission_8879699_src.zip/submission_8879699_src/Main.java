import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        int s = sc.nextInt();
        int[][] x = new int[r][s];
        int seatRow = -1;
        for (int i = 0; i < r; i++) {
            String row = sc.next();
            for (int j = 0; j < s; j++) {
                if (row.charAt(j) == 'o') {
                    x[i][j] = 1;
                } else {
                    seatRow = i;
                    x[i][j] = 0;
                }
            }
        }

        int handShake;
        if (seatRow == -1) {
            handShake = s + (s * (r - 1)) * 2;
        } else {
            handShake = 0;
            for (int i = 0; i <= seatRow; i++) {
                for (int j = 0; j < s; j++) {
                    if (x[i][j] == 1) {
                        handShake++;
                    }
                }
            }
            for (int i = seatRow + 1; i < r; i++) {
                for (int j = 0; j < s; j++) {
                    if (x[i][j] == 1) {
                        handShake += 2;
                    }
                }
            }
        }
        System.out.println(handShake);
    }
}