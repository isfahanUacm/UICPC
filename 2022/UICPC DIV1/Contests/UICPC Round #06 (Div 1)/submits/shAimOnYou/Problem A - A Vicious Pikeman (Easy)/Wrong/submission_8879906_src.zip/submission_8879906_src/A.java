import java.util.Arrays;
import java.util.Scanner;

public class A {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int t = sc.nextInt();
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();

        Integer[] T = new Integer[n];
        T[0] = sc.nextInt();

        for (int i = 1; i < n; i++) {
            T[i] = (a * T[i - 1] + b) % c + 1;
        }

        Arrays.sort(T, Integer::compareTo);

        int max = 0, pen = 0, total = 0;
        for (int i = 0; i < n; i++) {
            if (total + T[i] > t)
                break;
            max++;
            pen = (pen + T[i] + total) % 1000000007;
            total += T[i];
        }

        System.out.println(max + " " + pen);
    }
}
