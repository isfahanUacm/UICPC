import java.util.Scanner;

public class D {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] m = new int[n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                int a = sc.nextInt();
                if (i != j) {
                    m[i] |= a;
                    m[j] |= a;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            System.out.println(m[i]);
        }
    }
}