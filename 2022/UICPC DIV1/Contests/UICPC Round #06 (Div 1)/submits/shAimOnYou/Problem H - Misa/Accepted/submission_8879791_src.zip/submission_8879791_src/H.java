import java.util.Scanner;

public class H {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int r = sc.nextInt();
        int s = sc.nextInt();
        int ans = 0;

        char[][] a = new char[r][];

        for (int i = 0; i < r; i++) {
            a[i] = sc.next().toCharArray();
        }

        int row = -1;
        int col = -1;
        int max = 0;

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < s; j++) {
                if (a[i][j] == '.') {
                    if (count(i, j, a) > max) {
                        row = i;
                        col = j;
                        max = count(i, j, a);
                    }
                }
            }
        }
        if (row >= 0)
            a[row][col] = 'o';

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < s; j++) {
                if (a[i][j] == 'o') {
                    ans += count(i, j, a);
                }
            }
        }
        System.out.println(ans / 2);
    }

    static int count(int r, int s, char[][] a) {
        int ans = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (r + i >= 0 &&
                        r + i < a.length &&
                        s + j >= 0 && s + j < a[0].length &&
                        a[r + i][s + j] == 'o' &&
                        (i != 0 || j != 0)
                )  ans++;
            }
        }
        return ans;
    }
}