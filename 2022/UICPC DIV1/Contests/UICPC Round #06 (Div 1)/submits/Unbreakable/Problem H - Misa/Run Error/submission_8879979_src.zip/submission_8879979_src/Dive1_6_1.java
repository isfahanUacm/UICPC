import java.util.Scanner;

public class Dive1_6_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int R = sc.nextInt();
        int S = sc.nextInt();
        char[][] map = new char[R][S];
        sc.nextLine();
        for (int i = 0; i < R; i++) {
            String s = sc.nextLine();
            for (int j = 0; j < s.length(); j++) {
                map[i][j] = s.charAt(j);
            }
        }

        long count = 0;
        long max = Integer.MIN_VALUE;
        boolean b = false;
        for (int i = 0; i < R; i++) {
            for (int j = 0; j < S; j++) {
                if (map[i][j] == '.') {
                    b = true;
                    break;
                }
            }
        }

        if (b) {
            for (int i = 0; i < R; i++) {
                for (int j = 0; j < S; j++) {
                    if (map[i][j] == '.') {

                        if (i < R && j == 0) {

                            if (i == 0 && j == 0) {
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j + 1] == 'o') {
                                    count += 1;
                                }
                            } else if (i == R - 1 && j == 0) {
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j + 1] == 'o') {
                                    count += 1;
                                }
                            } else {
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                            }

                        } else if (i < R && j == S - 1) {

                            if (i == 0 && j == S - 1) {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j - 1] == 'o') {
                                    count += 1;
                                }
                            } else if (i == R - 1 && j == S - 1) {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j - 1] == 'o') {
                                    count += 1;
                                }
                            } else {
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                            }

                        } else if (j < S && i == 0) {

                            if (i == 0 && j == S - 1) {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j - 1] == 'o') {
                                    count += 1;
                                }
                            } else if (i == 0 && j == 0) {
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j + 1] == 'o') {
                                    count += 1;
                                }
                            } else {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i + 1][j] == 'o') {
                                    count += 1;
                                }
                            }
                        } else if (j < S && i == R - 1) {

                            if (i == R - 1 && j == S - 1) {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j - 1] == 'o') {
                                    count += 1;
                                }
                            } else if (i == R - 1 && j == 0) {
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j + 1] == 'o') {
                                    count += 1;
                                }
                            } else {
                                if (map[i][j - 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i][j + 1] == 'o') {
                                    count += 1;
                                }
                                if (map[i - 1][j] == 'o') {
                                    count += 1;
                                }
                            }
                        } else {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j + 1] == 'o') {
                                count += 1;
                            }
                        }
                        if (count > max) {
                            max = count;
                            count = 0;
                        }
                    }
                }
            }
        } else {
            for (int i = 0; i < R; i++) {
                for (int j = 0; j < S; j++) {

                    if (i < R && j == 0) {

                        if (i == 0 && j == 0) {
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j + 1] == 'o') {
                                count += 1;
                            }
                        } else if (i == R - 1 && j == 0) {
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j + 1] == 'o') {
                                count += 1;
                            }
                        } else {
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                        }

                    } else if (i < R && j == S - 1) {

                        if (i == 0 && j == S - 1) {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j - 1] == 'o') {
                                count += 1;
                            }
                        } else if (i == R - 1 && j == S - 1) {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j - 1] == 'o') {
                                count += 1;
                            }
                        } else {
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                        }

                    } else if (j < S && i == 0) {

                        if (i == 0 && j == S - 1) {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j - 1] == 'o') {
                                count += 1;
                            }
                        } else if (i == 0 && j == 0) {
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j + 1] == 'o') {
                                count += 1;
                            }
                        } else {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i + 1][j] == 'o') {
                                count += 1;
                            }
                        }
                    } else if (j < S && i == R - 1) {

                        if (i == R - 1 && j == S - 1) {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j - 1] == 'o') {
                                count += 1;
                            }
                        } else if (i == R - 1 && j == 0) {
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j + 1] == 'o') {
                                count += 1;
                            }
                        } else {
                            if (map[i][j - 1] == 'o') {
                                count += 1;
                            }
                            if (map[i][j + 1] == 'o') {
                                count += 1;
                            }
                            if (map[i - 1][j] == 'o') {
                                count += 1;
                            }
                        }
                    } else {
                        if (map[i][j - 1] == 'o') {
                            count += 1;
                        }
                        if (map[i][j + 1] == 'o') {
                            count += 1;
                        }
                        if (map[i - 1][j] == 'o') {
                            count += 1;
                        }
                        if (map[i + 1][j] == 'o') {
                            count += 1;
                        }
                        if (map[i - 1][j - 1] == 'o') {
                            count += 1;
                        }
                        if (map[i - 1][j + 1] == 'o') {
                            count += 1;
                        }
                        if (map[i + 1][j + 1] == 'o') {
                            count += 1;
                        }
                        if (map[i + 1][j + 1] == 'o') {
                            count += 1;
                        }
                    }
                    if (count > max) {
                        max = count;
                        count = 0;
                    }
                }
            }
        }
        System.out.println(max);

    }
}
