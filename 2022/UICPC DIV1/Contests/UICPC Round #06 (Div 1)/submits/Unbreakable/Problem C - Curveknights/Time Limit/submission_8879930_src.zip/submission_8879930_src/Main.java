import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int noMaterial = sc.nextInt();
        int noDep = sc.nextInt();
        HashMap<Integer, Node> nodesMap = new HashMap();
        ArrayList<Node> nodesList = new ArrayList<>();

        for (int i = 0; i < noMaterial; i++) {
            int ordered = sc.nextInt();
            Node curNode = new Node(i, ordered);
            nodesList.add(curNode);
            nodesMap.put(i, curNode);
        }

        for (int i = 0; i < noDep; i++) {
            int subMat =  sc.nextInt();
            int goalMat = sc.nextInt();
            int quantitie = sc.nextInt();
            nodesMap.get(goalMat).deps.put(nodesMap.get(subMat), quantitie);
        }
        for (Node node : nodesList){
            node.provide_mat(node.ordered);
        }
        for (Node node : nodesList){
            System.out.print(node.noNeed + " ");
        }
    }
}
class Node{
    public Node(int name, int ordered) {
        this.name = name;
        this.ordered = ordered;
    }
    int name;
    HashMap<Node, Integer> deps = new HashMap<>();
    int noNeed;
    int ordered;
    void provide_mat(int n){
        if (n == 0) return;
        this.noNeed += n;
        for (Map.Entry<Node, Integer> entry : deps.entrySet()) {
            entry.getKey().provide_mat(entry.getValue() * n);
        }
    }
}