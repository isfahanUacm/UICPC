import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static int t1;
    static int A,B,C;
    public static void main(String[] args) {
        long noProb = sc.nextInt();
        long totalTime = sc.nextInt();
        A = sc.nextInt();
        B = sc.nextInt();
        C = sc.nextInt();
        t1 = sc.nextInt();

        ArrayList<Integer> times = new ArrayList<>();
        for (long i = 1; i <= noProb; i++) {
            times.add(t(i));
        }
        Collections.sort(times);
        long penalty = 0;
        long noSolved = 0;
        long curTime = 0;

        for (int i = 0; i < noProb; i++) {
            if (totalTime < (times.get(i) + curTime)){
                break;
            }
            noSolved++;
            curTime += times.get(i);
            penalty += curTime;
        }
        penalty = penalty % 1000000007;
        System.out.println(noSolved+ " " + penalty);
    }
    static int t(long i){
        if (i == 1) return t1;
        return ((A * t(i-1) + B) % C) + 1;
    }
}