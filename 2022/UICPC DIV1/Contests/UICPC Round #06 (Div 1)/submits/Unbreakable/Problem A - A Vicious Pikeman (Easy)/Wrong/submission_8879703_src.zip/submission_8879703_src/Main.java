import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static int t1;
    static int A,B,C;
    public static void main(String[] args) {
        int noProb = sc.nextInt();
        int totalTime = sc.nextInt();
        A = sc.nextInt();
        B = sc.nextInt();
        C = sc.nextInt();
        t1 = sc.nextInt();

        ArrayList<Integer> times = new ArrayList<>();
        for (int i = 1; i <= noProb; i++) {
            times.add(t(i));
        }
        Collections.sort(times);

        long penalty = 0;
        int noSolved = 0;
        int curTime = 0;

        for (int i = 0; i < noProb; i++) {
            if (totalTime < (times.get(0) + curTime)){
                break;
            }
            noSolved++;
            curTime += times.remove(0);
            penalty += curTime;
        }
        penalty = penalty % 1000000007;
        System.out.println(noSolved+ " " + penalty);
    }
    static int t(int i){
        if (i == 1) return t1;
        return ((A * t(i-1) + B) % C) + 1;
    }
}