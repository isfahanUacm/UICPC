#include <iostream>
#include <vector>
#include <array>

using namespace std;

constexpr array<pair<int, int>, 8> moves = {{ {-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1} }};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int r, s;
    cin >> r >> s;
    vector<vector<char>> v(r + 2, vector<char>(s + 2, '.'));
    for (int i = 1; i <= r; i++) {
        for (int j = 1; j <= s; j++) {
            cin >> v[i][j];
        }
    }
    int ans = 0;
    int a = 0, b = 0;
    for (int i = 1; i <= r; i++) {
        for (int j = 1; j <= s; j++) {
            int x = 0;
            for (int k = 0; k < 8; k++) {
                if (v[i][j] == '.' && v[i + moves[k].first][j + moves[k].second]== 'o')
                    x++;
            }
            if (x >= ans) {
                ans = x;
                a = i;
                b = j;
            }
        }
    }
    if (a != 0 || b != 0)
        v[a][b] = 'o';
    ans = 0;
    for (int i = 1; i <= r; i++) {
        for (int j = 1; j <= s; j++) {
            for (int k = 0; k < 8; k++) {
                if (v[i][j] == 'o' && v[i + moves[k].first][j + moves[k].second] == 'o')
                    ans++;
            }
        }
    }
    ans >>= 1;
    cout << ans << '\n';
    return 0;
}