#include<bits/stdc++.h>
using namespace std;
using ll=long long;
ll arr[1003][1003],res[1003];
int main(){
    ll t;
    cin>>t;
    for(int i=0;i<t;i++)
        for(int j=0;j<t;j++)
              cin>>arr[i][j];

    for(int i=0;i<t;i++){
        for(int j=0;j<t;j++){
            res[i]|=arr[i][j];
        }
    }
    for(int i=0;i<t;i++) cout<<res[i]<<' ';
    return 0;
}