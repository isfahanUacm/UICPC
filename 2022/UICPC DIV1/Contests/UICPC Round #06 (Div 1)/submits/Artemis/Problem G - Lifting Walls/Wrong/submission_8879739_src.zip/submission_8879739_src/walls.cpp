#include<bits/stdc++.h>
using namespace std;

int dis(pair<int,int> loc[],int x,int y,int r){
    int cnt=0;
    for(int i=0;i<4;i++){
        if(sqrt(pow(x-loc[i].first,2)+pow(y-loc[i].second,2))<=r) cnt++;
    }
    return cnt;
}
double j_ds(int x,int y,int a,int b){
    return sqrt(pow(x-a,2)+pow(y-b,2));
}

int main(){
    int l,w,n,r,x,y;
    cin>>l>>w>>n>>r;
    pair<int,int>crane[n],loc[4];
    loc[0]={-1*w/2,0},loc[1]={w/2,0},loc[2]={0,l/2},loc[3]={0,-1*l/2};
    for(int i=0;i<n;i++){
        cin>>crane[i].first>>crane[i].second;
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        int x=crane[i].first,y=crane[i].second;
        if(dis(loc,x,y,r)==4){
            cout<<"1\n";
            return 0;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i!=j){
                double w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
                double w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
                double w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
                double w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
                if(w1<=r && w2<=r && w3<=r && w4<=r){
                    cout<<"2\n";
                    return 0;
                }
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            for(int k=j+1;k<n;k++){
                double w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
                w1=min(w1,j_ds(loc[0].first,loc[0].second,crane[k].first,crane[k].second));
                double w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
                w2=min(w2,j_ds(loc[1].first,loc[1].second,crane[k].first,crane[k].second));
                double w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
                w3=min(w3,j_ds(loc[2].first,loc[2].second,crane[k].first,crane[k].second));
                double w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
                w4=min(w4,j_ds(loc[3].first,loc[3].second,crane[k].first,crane[k].second));
                if(w1<=r && w2<=r && w3<=r && w4<=r){
                    cout<<"3\n";
                    return 0;
                }
            }
        }
    }
    for(int i=0;i<n;i++){
    for(int j=i+1;j<n;j++){
        for(int k=j+1;k<n;k++){
            for(int h = k+1;j<n;h++){
                double w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
                w1 = min(w1,min(j_ds(loc[0].first,loc[0].second,crane[k].first,crane[k].second),j_ds(loc[0].first,loc[0].second,crane[h].first,crane[h].second)));
                double w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
                w2 = min(w2,min(j_ds(loc[1].first,loc[1].second,crane[k].first,crane[k].second),j_ds(loc[1].first,loc[1].second,crane[h].first,crane[h].second)));
                double w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
                w3 = min(w3,min(j_ds(loc[2].first,loc[2].second,crane[k].first,crane[k].second),j_ds(loc[2].first,loc[2].second,crane[h].first,crane[h].second)));
                double w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
                w4 = min(w4,min(j_ds(loc[3].first,loc[3].second,crane[k].first,crane[k].second),j_ds(loc[3].first,loc[3].second,crane[h].first,crane[h].second)));
                if(w1<=r && w2<=r && w3<=r && w4<=r){
                    cout<<"4\n";
                    return 0;
                }
            }
        }
    }
    }
    cout<<"Impossible\n";

    return 0;
}