#include<bits/stdc++.h>
using namespace std;
double_t eps = 1e-18;
int dis(pair<double_t,double_t> loc[],double_t x,double_t y,double_t r){
    int cnt=0;
    for(int i=0;i<4;i++){
        if(sqrt(pow(x-loc[i].first,2)+pow(y-loc[i].second,2))<r+eps) cnt++;
    }
    return cnt;
}
double_t j_ds(double_t x,double_t y,double_t a,double_t b){
    return sqrt(pow(x-a,2)+pow(y-b,2));
}

int main(){
    int n;
    double_t l,w;
    double_t r;
    cin>>l>>w>>n>>r;
    pair<double_t,double_t>crane[n],loc[4];
    loc[0]={-1.0*l/2.0,0},loc[1]={l/2.0,0},loc[2]={0,w/2.0},loc[3]={0,-1.0*w/2.0};
    for(int i=0;i<n;i++){
        cin>>crane[i].first>>crane[i].second;
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        double_t w1=j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second);
        double_t w2=j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second);
        double_t w3=j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second);
        double_t w4=j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second);
        if(w1 < r+eps && w2< r+eps && w3 <r+eps && w4<r+eps){
            cout<<"1\n";
            return 0;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            double_t w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
            double_t w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
            double_t w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
            double_t w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
            if(w1 < r+eps && w2< r+eps && w3 <r+eps && w4<r+eps){
                cout<<"2\n";
                return 0;
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            for(int k=j+1;k<n;k++){
                double_t w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
                w1=min(w1,j_ds(loc[0].first,loc[0].second,crane[k].first,crane[k].second));
                double_t w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
                w2=min(w2,j_ds(loc[1].first,loc[1].second,crane[k].first,crane[k].second));
                double_t w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
                w3=min(w3,j_ds(loc[2].first,loc[2].second,crane[k].first,crane[k].second));
                double_t w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
                w4=min(w4,j_ds(loc[3].first,loc[3].second,crane[k].first,crane[k].second));
                if(w1 < r+eps && w2< r+eps && w3 <r+eps && w4<r+eps){
                    cout<<"3\n";
                    return 0;
                }
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            for(int k=j+1;k<n;k++){
                for(int h = k+1;h<n;h++){
                    double_t w1=min(j_ds(loc[0].first,loc[0].second,crane[i].first,crane[i].second),j_ds(loc[0].first,loc[0].second,crane[j].first,crane[j].second));
                    w1 = min(w1,min(j_ds(loc[0].first,loc[0].second,crane[k].first,crane[k].second),j_ds(loc[0].first,loc[0].second,crane[h].first,crane[h].second)));
                    double_t w2=min(j_ds(loc[1].first,loc[1].second,crane[i].first,crane[i].second),j_ds(loc[1].first,loc[1].second,crane[j].first,crane[j].second));
                    w2 = min(w2,min(j_ds(loc[1].first,loc[1].second,crane[k].first,crane[k].second),j_ds(loc[1].first,loc[1].second,crane[h].first,crane[h].second)));
                    double_t w3=min(j_ds(loc[2].first,loc[2].second,crane[i].first,crane[i].second),j_ds(loc[2].first,loc[2].second,crane[j].first,crane[j].second));
                    w3 = min(w3,min(j_ds(loc[2].first,loc[2].second,crane[k].first,crane[k].second),j_ds(loc[2].first,loc[2].second,crane[h].first,crane[h].second)));
                    double_t w4=min(j_ds(loc[3].first,loc[3].second,crane[i].first,crane[i].second),j_ds(loc[3].first,loc[3].second,crane[j].first,crane[j].second));
                    w4 = min(w4,min(j_ds(loc[3].first,loc[3].second,crane[k].first,crane[k].second),j_ds(loc[3].first,loc[3].second,crane[h].first,crane[h].second)));
                    if(w1 < r+eps && w2< r+eps && w3 <r+eps && w4<r+eps){
                        cout<<"4\n";
                        return 0;
                    }
                }
            }
        }
    }
    cout<<"Impossible\n";

    return 0;
}