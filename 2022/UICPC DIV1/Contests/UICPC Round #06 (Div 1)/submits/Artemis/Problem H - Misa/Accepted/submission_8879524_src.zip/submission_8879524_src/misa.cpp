#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
ll n, m;
bool ir(ll x, ll y) {
    return x >= 0 && x < n && y >= 0 && y < m;
}

int main() {
    cin >> n >> m;
    char bas[n][m];

    for (ll i = 0; i < n; ++i) {
        for (ll j = 0; j < m; ++j) {
            cin >> bas[i][j];
        }
    }

    ll ans = 0;
    ll mx = 0;
    for (ll i = 0; i < n; ++i) {
        for (ll j = 0; j < m; ++j) {
            ll temp = 0;
            for (ll k = -1; k <= 1; ++k) {
                for (ll l = -1; l <= 1; ++l) {
                    if (k == 0 && l == 0)
                        continue;
                    if (ir(i + k, j + l) && bas[i + k][j + l] == 'o') {
                        temp++;
                    }
                }
            }
            if (bas[i][j] == 'o')
                ans += temp;
            else
                mx = max(mx, temp);
        }
    }
    cout << ans / 2 + mx << endl;
}