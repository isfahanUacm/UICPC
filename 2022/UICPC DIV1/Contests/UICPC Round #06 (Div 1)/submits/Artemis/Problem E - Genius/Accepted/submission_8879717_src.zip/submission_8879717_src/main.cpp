#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    int k, t, p, q, xi;
    cin >> k >> t >> p >> q >> xi;
    
    int arr[t + 3];
    arr[0] = xi;
    for (int i = 1; i < t; ++i) {
        arr[i] = (arr[i - 1] * p) % q;
    }

    for (auto& i: arr)
        i %= 4;

    vector<double> prob;

    for (int i = 0; i < t; ++i) {
        double brr[4];
        for (double & j : brr) {
            cin >> j;
        }

        double ans = 0;

        if (arr[i] < 2) {
            double win = brr[arr[i]] / (brr[0] + brr[1]);
            ans += brr[2] / (brr[2] + brr[3]) * win * brr[arr[i]] / (brr[2] + brr[arr[i]]) +
                    brr[3] / (brr[2] + brr[3]) * win * brr[arr[i]] / (brr[3] + brr[arr[i]]);
        }
        else {
            double win = brr[arr[i]] / (brr[2] + brr[3]);
            ans += brr[0] / (brr[0] + brr[1]) * win * brr[arr[i]] / (brr[0] + brr[arr[i]]) +
                   brr[1] / (brr[0] + brr[1]) * win * brr[arr[i]] / (brr[1] + brr[arr[i]]);
        }
        prob.push_back(ans);
    }

    double dp[t + 10];

    memset(dp, 0, sizeof(dp));
    dp[0] = 1;
    for (auto pr: prob) {
        for (int i = t; i >= 1; --i) {
            dp[i] *= (1 - pr);
            dp[i] += dp[i - 1] * pr;
        }
        dp[0] *= (1 - pr);
    }

    double ans = 0;
    for (int i = k; i <= t; ++i) {
        ans += dp[i];
    }
    printf("%.7lf\n", ans);
}