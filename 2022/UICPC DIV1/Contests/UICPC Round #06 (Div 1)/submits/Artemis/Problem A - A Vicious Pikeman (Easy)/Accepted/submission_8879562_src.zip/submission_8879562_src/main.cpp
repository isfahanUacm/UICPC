#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    ll n, t;
    cin >> n >> t;
    ll a, b, c, ti;
    cin >> a >> b >> c >> ti;

    vector<int> vc;
    vc.push_back(ti);

    for (ll i = 1; i < n; ++i) {
        ti = ((a * ti + b) % c) + 1;
        vc.push_back(ti);
    }
    sort(vc.begin(), vc.end());

    ll sum = 0;
    ll del = 0;
    ll cnt = 0;

    for (auto x: vc) {
        if (sum + x > t)
            break;
        sum += x;
        del += sum;
        del %= 1000000007;
        cnt++;
    }

    cout << cnt << ' ' << del % 1000000007 << endl;
}