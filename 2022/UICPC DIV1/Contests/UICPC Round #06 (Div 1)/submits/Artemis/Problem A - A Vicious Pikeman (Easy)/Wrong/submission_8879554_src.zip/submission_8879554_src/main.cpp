#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    ll n, t;
    cin >> n >> t;
    ll a, b, c, ti;
    cin >> a >> b >> c >> ti;

    set<ll> st;
    st.insert(ti);

    for (ll i = 1; i < n; ++i) {
        ti = ((a * ti + b) % c) + 1;
        st.insert(ti);
    }

    ll sum = 0;
    ll del = 0;
    ll cnt = 0;

    for (auto x: st) {
        if (sum + x > t)
            break;
        sum += x;
        del += sum;
        del %= 1000000007;
        cnt++;
    }

    cout << cnt << ' ' << del % 1000000007 << endl;
}