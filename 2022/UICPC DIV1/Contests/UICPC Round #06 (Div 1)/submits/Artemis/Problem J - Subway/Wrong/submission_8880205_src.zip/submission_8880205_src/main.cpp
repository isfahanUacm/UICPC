#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 500;
struct p{
    int x, y;
};

double dist[MAX];
set<pair<ll, ll>> ss;
vector<pair<ll, double>> adj[MAX];
map<pair<int, int>, int> mp;

p h, s;

void dijkstra(int start) {
    dist[start] = 0;
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (dist[v.first] > dist[u] + v.second) {
                ss.erase({dist[v.first], v.first});
                dist[v.first] = dist[u] + v.second;
                ss.insert({dist[v.first], v.first});
            }
        }
    }
}

int ind(p a) {
    if (mp.count({a.x, a.y}) > 0) {
        return mp[{a.x, a.y}];
    }
    mp[{a.x, a.y}] = mp.size();
    return mp[{a.x, a.y}];
}

double c_dist(p a, p b){
    return (sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)));
}

int main() {
    cin >> h.x >> h.y >> s.x >> s.y;
    ind(h);
    ind(s);
    string a;
    while (getline(cin, a)) {
        stringstream sss(a);
        int x, y;
        p prev{};
        bool first = true;
        while (sss >> x >> y) {
            if (x == -1 && y == -1)
                break;

            p temp = {x, y};
            if (!first) {
                adj[ind(temp)].emplace_back(ind(prev), c_dist(temp, prev) / 40000 * 60);
                adj[ind(prev)].emplace_back(ind(temp), c_dist(temp, prev) / 40000 * 60);
            }
            first = false;
            prev = temp;
        }
    }

    for (auto x: mp) {
        for (auto y: mp) {
            adj[x.second].emplace_back(y.second,
                                       c_dist(p{x.first.first, x.first.second}, p{y.first.first, y.first.second}) /
                                       10000 * 60);
            adj[y.second].emplace_back(x.second,
                                       c_dist(p{x.first.first, x.first.second}, p{y.first.first, y.first.second}) /
                                       10000 * 60);
        }
    }

    for (ll i = 0; i < mp.size() + 10; ++i) {
        dist[i] = LONG_LONG_MAX;
    }
    dijkstra(0);

    cout << dist[mp[{s.x, s.y}]] << endl;
}
