#include <bits/stdc++.h>
using namespace std;

int main()
{
    int N, T, A, B, C, t0;
    long solved, penalty;

    cin >> N >> T;
    cin >> A >> B >> C >> t0;

    if (t0 > T)
    {
        cout << 0 << ' ' << 0;
        return 0;
    }

    penalty = t0;
    solved = 1;
    long prevT = t0, newT = 0;

    while (solved < N)
    {
        newT = ((A * prevT + B) % C) + 1;
        penalty += penalty + newT;

        // cout << "prevT:" << (prevT) << '\n';
        // cout << "newT:" << newT << '\n';
        // cout << "penalty:" << penalty << '\n';

        if (penalty > T)
        {
            penalty -= penalty + newT;
            break;
        }

        solved++;
        prevT = newT;
    }

    if (N == solved) penalty -= newT;

    // cout << "solved:" << solved << '\n';
    // cout << "penalty:" << (penalty % 1000000007 ) << '\n';
    cout << solved << ' ' << (penalty % 1000000007);

    return 0;
}