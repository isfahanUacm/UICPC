#include <bits/stdc++.h>
using namespace std;
typedef long long lli;

// int tx[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
// int ty[8] = {0, 1, 1, 1, 0, -1, -1, -1};
vector<pair<int, lli>> adj[50+5];
lli num[50+5];
int indeg[50+5];
bool visited[50+5];

int main(){
    int n, m; cin>>n>>m;
    for (int i = 0; i < n; i++)
    {
        cin>>num[i];
    }
    for (int i = 0; i < m; i++)
    {
        int u, v;
        lli w; cin>>u>>v>>w;
        adj[v].push_back({u, w});
        indeg[u]++;
    }
    priority_queue<pair<int,int>, vector<pair<int,int>> , greater<pair<int,int>>> pq;
    for (int i = 0; i < n; i++)
    {
        pq.push({indeg[i] , i});
    }
    while (!pq.empty())
    {
        auto p = pq.top();
        int cur = p.second;
        pq.pop();
        if(visited[cur]) continue;
        visited[cur] = true;
        
        for(auto px : adj[cur]){
            int u = px.first;
            lli w = px.second;
            num[u] += num[cur]*w;

            indeg[u]--;
            pq.push({indeg[u], u});
        }
    }
    for (int i = 0; i < n; i++)
    {
        cout<<num[i] <<" ";
    }
    
    
}