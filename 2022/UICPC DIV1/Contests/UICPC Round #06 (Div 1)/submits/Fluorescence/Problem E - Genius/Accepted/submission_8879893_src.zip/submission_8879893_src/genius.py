k, t , p, q, x1 = map(int,input().split())
jimmy = []
jimmy.append(x1)
for i in range(t-1):
    temp = jimmy[-1]*p % q
    jimmy.append(temp)
wins = [(i%4) for i in jimmy]
#print(wins)
winners = []
corr = []
for i in range(t):
    w0, w1, w2, w3 = map(int, input().split())
    ab = (w0/(w0+w1))
    ba = (w1/(w0+w1))
    cd = (w2/(w2+w3))
    dc = (w3/(w2+w3))
    ac = (w0/(w0+w2))
    ca = (w2/(w0+w2))
    ad = (w0/(w0+w3))
    da = (w3/(w0+w3))
    bc = (w1/(w1+w2))
    cb = (w2/(w1+w2))
    bd = (w1/(w1+w3))
    db = (w3/(w1+w3))
    a = ab * (cd * ac + dc * ad)
    b = ba * (cd * bc + dc * bd)
    c = cd * (ab * ca + ba * cb)
    d = dc * (ab * da + ba * db)
    winners.append([a,b,c,d])
    #print(a,b,c,d, a+b+c+d)
    corr.append([a,b,c,d][wins[i]])
#print(corr)

dp = [[0 for j in range(t+1)] for i in range(t+1)]
dp[0][0]=1
for i in range(1,t+1):
    winP = corr[i-1]
    #print(winP)
    for j in range(t):
        dp[i][j] = dp[i][j] + dp[i-1][j] * (1-winP)
        dp[i][j+1] = dp[i][j+1] + dp[i-1][j] * winP
#print(dp[t])
#print(dp[t-1])
res = sum(dp[t][k:])
print(res)