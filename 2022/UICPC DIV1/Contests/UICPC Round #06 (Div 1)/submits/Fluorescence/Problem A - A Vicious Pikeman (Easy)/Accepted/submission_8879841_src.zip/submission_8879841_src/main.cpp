#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxn = 1000010;

int main()
{
  ll n, t;
  cin >> n >> t;
  ll A, B, C, t0;
  cin >> A >> B >> C >> t0;
  vector<ll> times(n, 0);
  times[0] = t0;
  for(ll i = 1; i < n; i++)
  {
    times[i] = (A * times[i - 1] + B) % C + 1;
  }
  sort(times.begin(), times.end());
  ll ans = 0;
  ll totalTime = 0;
  ll penalty = 0;
  for(ll i = 0; i < n; i++)
  {
    if(totalTime + times[i] <= t)
    {
      ans = (ans + 1) % mod;
      totalTime = (totalTime + times[i]) % mod;
      penalty = (penalty + totalTime) % mod;
    }
  }
  cout << ans << " " << penalty;
  return 0;
}