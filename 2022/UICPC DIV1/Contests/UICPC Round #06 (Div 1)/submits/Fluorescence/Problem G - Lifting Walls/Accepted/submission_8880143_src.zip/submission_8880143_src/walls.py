import math
def dist(x1,y1, x2,y2):
    return math.sqrt((x1-x2)**2 + (y1-y2)**2)
def smaller(cx,cy,r,x,y):
    return dist(cx, cy, x, y)<=r
l,w,n,r = map(int, input().split())

cranes = []
for i in range(n):
    x,y = map(int, input().split())
    cranes.append([x,y])

res = 5
x1,y1 = -l/2 , 0
x2, y2 = l/2, 0
x3, y3 = 0, -w/2
x4, y4 = 0, w/2
for c1 in range(n):
    crn1 = cranes[c1]
    if11 = smaller(crn1[0], crn1[1], r, x1, y1)
    if12 = smaller(crn1[0], crn1[1], r, x2, y2)
    if13 = smaller(crn1[0], crn1[1], r, x3, y3)
    if14 = smaller(crn1[0], crn1[1], r, x4, y4)
    if (if11 and if12 and if13 and if14):
        res = 1
        break
    for c2 in range(c1,n):
        crn2 = cranes[c2]
        if21 = smaller(crn2[0], crn2[1], r, x1, y1)
        if22 = smaller(crn2[0], crn2[1], r, x2, y2)
        if23 = smaller(crn2[0], crn2[1], r, x3, y3)
        if24 = smaller(crn2[0], crn2[1], r, x4, y4)
        if ((if11 or if21) and (if12 or if22) and (if13 or if23) and (if14 or if24)):
            res = min(res,2)
        for c3 in range(c2,n):
            crn3 = cranes[c3]
            if31 = smaller(crn3[0], crn3[1], r, x1, y1)
            if32 = smaller(crn3[0], crn3[1], r, x2, y2)
            if33 = smaller(crn3[0], crn3[1], r, x3, y3)
            if34 = smaller(crn3[0], crn3[1], r, x4, y4)
            if ((if11 or if21 or if31) and (if12 or if22 or if32) and (if13 or if23 or if33) and (if14 or if24 or if34)):
                res = min(res,3)
            for c4 in range(c3,n):
                crn4 = cranes[c4]
                if41 = smaller(crn4[0], crn4[1], r, x1, y1)
                if42 = smaller(crn4[0], crn4[1], r, x2, y2)
                if43 = smaller(crn4[0], crn4[1], r, x3, y3)
                if44 = smaller(crn4[0], crn4[1], r, x4, y4)
                if ((if11 or if21 or if31 or if41) and (if12 or if22 or if32 or if42) and (if13 or if23 or if33 or if43) and (if14 or if24 or if34 or if44)):
                    res = min(res,4)
if res==5:
    print('Impossible')
else:
    print(res)