#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxn = 1000010;

int main()
{
  ll n;
  cin >> n;
  vector<ll> sample(n, 0);
  vector<vector<ll>> matrix(n, sample);
  for (ll i = 0; i < n; i++)
  {
    for (ll j = 0; j < n; j++)
    {
      cin >> matrix[i][j];
    }
  }
  vector<ll> ans(n, 0);
  for(ll i = 0; i < n; i++)
  {
    for(ll j = 0; j < n; j++)
    {
      if(i != j)
      {
        ans[i] = ans[i] | matrix[i][j];
      }
    }
  }
  for(ll i: ans)
  {
    cout << i << " ";
  }
  return 0;
}