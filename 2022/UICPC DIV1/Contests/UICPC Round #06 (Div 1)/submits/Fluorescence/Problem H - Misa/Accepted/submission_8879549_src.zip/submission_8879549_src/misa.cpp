#include <bits/stdc++.h>
using namespace std;
typedef long long lli;
int r, s;
int tx[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
int ty[8] = {0, 1, 1, 1, 0, -1, -1, -1};
bool grid[50+5][50+5];
bool inrange(int x, int y){
    return (x>=0 && x<r && y>=0 &&y<s) ;
}

int main(){
    cin>>r>>s;
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < s; j++)
        {
            char ch; cin>>ch;
            if(ch == '.') grid[i][j] = false;
            else grid[i][j] = true;
        }
        
    }
    int sum = 0;
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < s; j++)
        {
            if(grid[i][j]){
                for (int q = 0; q < 8; q++)
                {
                    int x = tx[q] + i;
                    int y = ty[q] + j;
                    if(inrange(x, y) && grid[x][y]){
                        sum++;
                    }
                }
                
            }
        }
        
    }
    sum = sum/2;
    int ans = 0;
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < s; j++)
        {
            if(!grid[i][j]){
                int temp =0;
                for (int q = 0; q < 8; q++)
                {
                    int x = tx[q] + i;
                    int y = ty[q] + j;
                    if(inrange(x, y) && grid[x][y]){
                        temp ++;
                    }
                }
                ans = max(ans, temp);
                
            }
        }
        
    }
    cout<<sum+ans;
    
}
