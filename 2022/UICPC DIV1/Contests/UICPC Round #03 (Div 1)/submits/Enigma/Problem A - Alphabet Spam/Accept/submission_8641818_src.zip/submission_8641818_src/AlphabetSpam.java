import java.util.Scanner;

public class AlphabetSpam
{
        public static void main(String[] args)
        {
                String string = new Scanner(System.in).nextLine();
                double countOfWhiteSpaces = 0;
                double countOfLowerCases = 0;
                double countOfUpperCases = 0;
                double countOfSymbols = 0 ;
                double length = string.length();
                char[] StringCharArray = string.toCharArray();
                for (char element : StringCharArray)
                {
                        int ASCII_Code = element;
                        if (ASCII_Code <=122 & ASCII_Code >=97)
                                ++countOfLowerCases;
                        else if (ASCII_Code <=90 & ASCII_Code >=65)
                                ++countOfUpperCases;
                        else if (element == '_')
                                ++countOfWhiteSpaces;
                        else
                                ++countOfSymbols;
                }
                System.out.println((countOfWhiteSpaces/length));
                System.out.println((countOfLowerCases/length));
                System.out.println((countOfUpperCases/length));
                System.out.println((countOfSymbols/length));
        }
}
