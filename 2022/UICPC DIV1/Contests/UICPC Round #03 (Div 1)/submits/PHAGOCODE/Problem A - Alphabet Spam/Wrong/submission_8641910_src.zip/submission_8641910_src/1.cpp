#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    cin >> s;
    int A = 'A';
    int Z = 'Z';
    int a = 'a';
    int z = 'z';
    int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
    for (int i=0; i<s.length(); i++) {
        if (s[i] <= Z && s[i] >= A) c1++;
        else if (s[i] <= z && s[i] >= a) c2++;
        else if (s[i] == '_') c3++;
        else c4++;
    }
    cout << s.length() << endl;
    double r1 = (double)c1/s.length();
    double r2 = (double)c2/s.length();
    double r3 = (double)c3/s.length();
    double r4 = (double)c4/s.length();
    cout << setprecision(7) << r3 << endl << r2 << endl << r1 << endl << r4;


    return 0;
}
