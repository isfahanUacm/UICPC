bbb = 9999
stCost = {'F': 2, 'M': 3}

def upd(field1, field2, maze, time_taken, n, m, k, updated_fields):
    i1, j1 = field1
    i2, j2 = field2
    if not (0 <= i2 < n and 0 <= j2 < m):
        return
    field = maze[i2][j2]
    if field == '#':
        return
    days_taken, stamina_taken = time_taken[i1][j1]
    stamina_to_move = stCost.get(field, 1)
    stamina_taken += stamina_to_move
    if k < stamina_taken:
        days_taken += 1
        stamina_taken = stamina_to_move
    new_time_taken = (days_taken, stamina_taken)
    if new_time_taken < time_taken[i2][j2]:
        time_taken[i2][j2] = new_time_taken
        updated_fields.add((i2, j2))

def main():
    # Read input
    n, m, k = map(int, input().split())
    maze = []
    for i in range(n):
        line = input()
        maze.append(line)

    # Create map of how long it takes to get somewhere
    # Each field has (days_spent, stamina_spent)
    time = []
    for i in range(n):
        time.append([(bbb, bbb) for j in range(m)])

    # Look for the start and mark it as (1, 0), also look for the gold
    updf = set()
    for i in range(n):
        for j in range(m):
            if maze[i][j] == 'S':
                time[i][j] = (1, 0)
                updf.add((i, j))
            elif maze[i][j] == 'G':
                gold_at = (i, j)

    # BFS to propagate time
    while updf:
        i, j = updf.pop()
        upd((i, j), (i + 1, j), maze, time, n, m, k, updf)
        upd((i, j), (i - 1, j), maze, time, n, m, k, updf)
        upd((i, j), (i, j + 1), maze, time, n, m, k, updf)
        upd((i, j), (i, j - 1), maze, time, n, m, k, updf)

    # Print days taken to get to the gold
    i, j = gold_at
    days_taken = time[i][j][0]
    print(-1 if days_taken == bbb else days_taken)

if __name__ == '__main__':
    main()