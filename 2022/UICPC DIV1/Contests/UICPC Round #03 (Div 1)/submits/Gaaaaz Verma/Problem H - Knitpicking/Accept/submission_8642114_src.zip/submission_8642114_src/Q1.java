
import java.util.*;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        String type , lr;
        int num;
        int max = 0;
        Map<String , int[]> map = new HashMap<>();
        for (int i = 0; i < t; i++) {
            type = sc.next();
            lr = sc.next();
            num = sc.nextInt();
            int[] x;
            if (map.containsKey(type)) x = map.get(type);
            else x = new int[3];
            if (lr.equals("left")) x[0] = num;
            else if (lr.equals("right")) x[1] = num;
            else x[2] = num;
            map.put(type, x);
        }
        int any00 = 0, numAny00 = 0;
        boolean imp = true;
        for (String x:map.keySet()) {
            int[] z = map.get(x);
            //System.out.println(Arrays.toString(z));
            if (z[0] > z[1]) max += z[0];
            else max += z[1];
            if (z[0] == 0 && z[1] == 0 && z[2] > any00) any00++;
            if (z[0] == 0 && z[1] == 0 && z[2] > 0) numAny00++;
            if (z[0]*z[1] != 0 || z[2]>0 && (z[2]+z[1] > 1 || z[2]+z[0] > 1)) {
                imp = false;
            }
        }
        max += numAny00;
        max++;
        if (imp) System.out.println("impossible");
        else System.out.println(max);
    }
}