import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int lower = 0 , upper = 0 , space = 0, symbol;
        int n = str.length();
        for (int i = 0; i < n; i++) {
            char x = str.charAt(i);
            if (Character.isLowerCase(x)) lower++;
            if (Character.isUpperCase(x)) upper++;
            if (x == '_') space++;
        }
        symbol = str.length()-(lower+upper+space);
        System.out.printf("%.6f\n",space/(double)n);
        System.out.printf("%.6f\n",lower/(double)n);
        System.out.printf("%.6f\n",upper/(double)n);
        System.out.printf("%.6f\n",symbol/(double)n);
    }
}
