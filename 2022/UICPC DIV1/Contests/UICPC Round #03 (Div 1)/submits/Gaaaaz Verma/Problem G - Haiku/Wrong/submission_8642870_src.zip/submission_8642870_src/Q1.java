
import java.util.*;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < t; i++) list.add(sc.next());
        int s1Num = 0 , s2Num = 0 , s3Num = 0;
        sc.nextLine();
        String[] s1 = sc.nextLine().split(" ");
        String[] s2 = sc.nextLine().split(" ");
        String[] s3 = sc.nextLine().split(" ");
        for (String x:s1) {
            int index = 0;
            StringBuilder z = new StringBuilder(x);
            while (index < z.length()) {
                int f = inedxEnd(list , z.toString());
                if (f < 0) {
                    s1Num = -1;
                    break;
                } else {
                    index += f;
                    s1Num++;
                }
                z.delete(0,index);
                index = 0;
               // System.out.println(z + " " + f);
            }
            if (s1Num < 0) break;
        }
        //System.out.println("num1 "+s1Num);
        if (s1Num == 5) {

            for (String x:s2) {
                int index = 0;
                StringBuilder z = new StringBuilder(x);
                while (index < z.length()) {
                    int f = inedxEnd(list , z.toString());
                    if (f < 0) {
                        s2Num = -1;
                        break;
                    } else {
                        index += f;
                        s2Num++;
                    }
                    z.delete(0,index);
                    index = 0;
                    //System.out.println(z + " " + f);
                    //System.out.println(index + " len : " + z.length() );
                }
                if (s2Num < 0) break;
            }
            //System.out.println("num2 "+s2Num);
            if (s2Num == 7) {

                for (String x:s3) {
                    int index = 0;
                    StringBuilder z = new StringBuilder(x);
                    while (index < z.length()) {
                        int f = inedxEnd(list , z.toString());
                        if (f < 0) {
                            s3Num = -1;
                            break;
                        } else {
                            index += f;
                            s3Num++;
                        }
                        z.delete(0,index);
                        index = 0;
                        //System.out.println(z + " " + f);
                    }
                    if (s3Num < 0) break;
                }
                //System.out.println("num3 "+s3Num);
                if (s3Num == 5) System.out.println("haiku");
                else {
                    //System.out.println("3");
                    System.out.println("come back next year");
                }
            } else {
                //System.out.println("2");
                System.out.println("come back next year");
            }
        } else {
            //System.out.println("1");
            System.out.println("come back next year");
        }
    }
    public static int inedxEnd(ArrayList<String> arr , String str) {
        //System.out.print("func  " + str + "  ");
        int max = 0;
        ArrayList<Integer> b = new ArrayList<>();
        for (String x: arr) {
            if (str.startsWith(x)) {
                //System.out.println(str + " starts with " + x);
                if (x.length() > max) max = x.length();
            }
        }
        //System.out.println( "   End Funck");
        if (max == 0) return -1;
        else return max;
    }
}