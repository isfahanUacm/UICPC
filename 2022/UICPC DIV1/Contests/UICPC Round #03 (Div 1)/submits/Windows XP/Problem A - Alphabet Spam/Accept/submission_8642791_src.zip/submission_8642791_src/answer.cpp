#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
    cout << fixed;
    cout << setprecision(15);

    string s;
    int ws = 0, ll = 0, ul = 0, sy = 0;

    getline(cin, s);

    for (int i = 0; s[i]; i++)
    {
        if(int(s[i]) == 95)
        {
            ws++;
        }
        else if(int(s[i]) > 96 && int(s[i]) < 123)
        {
            ll++;
        }
        else if(int(s[i]) > 64 && int(s[i]) < 91)
        {
            ul++;
        }
        else
        {
            sy++;
        }
    }
    
    int size = s.size();

    cout << double(ws) / size << endl;
    cout << double(ll) / size << endl;
    cout << double(ul) / size << endl;
    cout << double(sy) / size << endl;

    return 0;
}