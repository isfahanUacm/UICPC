//package dataStruct;
import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        Map<String,ArrayList<Integer>> m = new HashMap<>();
        ArrayList<String> s = new ArrayList<>();

        for(int i=0 ; i<n ; ++i)
        {
            String s1 = sc.next();
            String s2 = sc.next();
            int ns = sc.nextInt();

            if(m.containsKey(s1))
            {
                if(s2.equals("right"))
                    m.get(s1).set(0,ns);

                else if(s2.equals("left"))
                    m.get(s1).set(1,ns);

                else
                    m.get(s1).set(2,ns);
            }

            else
            {
                ArrayList<Integer> arr = new ArrayList<>(0);
                arr.add(0);arr.add(0);arr.add(0);

                if(s2.equals("right"))
                    arr.set(0,ns);

                else if(s2.equals("left"))
                    arr.set(1,ns);

                else
                    arr.set(2,ns);

                m.put(s1,arr);
                s.add(s1);
            }
        }

        int result=0,c=0;
        for (String value : s)
        {
            result += Math.max(m.get(value).get(0), m.get(value).get(1));

            if(m.get(value).get(2) == 0)
            {
                if(m.get(value).get(0)==0 || m.get(value).get(1)==0)
                    ++c;
            }

            else
            {
                if(m.get(value).get(0)==0 && m.get(value).get(1)==0)
                    ++result;
            }
        }

        if(c == s.size())
            System.out.println("impossible");

        else if(result == 0)
        {
            int flag = 0;
            for (String value : s)
            {
                if(m.get(value).get(2) > 1)
                {
                    flag = 1;
                    break;
                }
            }

            if(flag == 1)
                System.out.println(2);
            else
                System.out.println("impossible");
        }

        else
            System.out.println(result + 1);
    }
}