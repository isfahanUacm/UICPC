
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
    string str;
    cin>>str;
    float n=str.length();
    double white,low,up,symbols=0;
    for(int i=0;i<n;i++)
     {
         if(str[i]=='_')
         {
             white++;
           
         }
        else if(str[i]>='A' && str[i]<='Z')
         {
             up++;
          
         }
        else if(str[i]>='a' && str[i]<='z')
         {
             low++;
           
         }
         else{
             symbols++;
         }
     }
     
    // cout<<white<<" "<<low<<' '<<up<<" "<<symbols<<endl;
     cout << setprecision(7) << white/n<<endl;
     cout << setprecision(7) << low/n<<endl;
     cout << setprecision(7) << up/n<<endl;
     cout << setprecision(7) << symbols/n<<endl;

    return 0;
}
