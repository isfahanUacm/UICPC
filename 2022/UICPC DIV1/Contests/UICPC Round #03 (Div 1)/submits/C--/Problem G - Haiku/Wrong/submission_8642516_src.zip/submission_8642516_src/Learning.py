def num_of_syllables(word):
    word=word.lower()
    aeiouy='aeiouy'
    s=0
    if word[0] in aeiouy:
        s+=1
    for i in range (1,len(word)):
        if word[i] in aeiouy and word[i-1] not in aeiouy:
            s+=1
    if word[-1]=='e':
        s-=1
    if len(word)>1:
        if word[-1]=='e':
            if word[len(word)-2]=='f' or word[len(word)-2]=='l':
                s+=1
    if s==0:
        s+=1
    return s


list_of_poems=[]
syllables=list()
n=int(input())
for i in range(0,n):
    syllables.append(input())
c=True
for i in range(0,3):
    sent=list(input().split())
    num=0
    for word in sent:
        num+=num_of_syllables(word)
    #print(num,'**')
    if (i==0 or i==2) and num!=5:
        if c:
            c=False
    if i==1 and num!=7:
        if c:
            c=False

if c:
    print('haiku')
else:
    print('come back next year')







