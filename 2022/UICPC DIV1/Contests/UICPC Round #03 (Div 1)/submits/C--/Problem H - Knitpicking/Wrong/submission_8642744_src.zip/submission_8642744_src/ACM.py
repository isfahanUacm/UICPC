n=int(input())
socks=[]
for i in range(0,n):
    socks.append(list(input().split()))
gen=[]
g=False
count=0
for i in range(0,len(socks)):
    if socks[i][1]=='left':
        count+=int(socks[i][2])
        gen.append(socks[i][0])
    if socks[i][1]=='right':
        if socks[i][0] in gen:
            g=True

c=False
for i in range(0,len(socks)):
    if socks[i][1]=='any':
        if socks[i][0] in gen:
            count+=1
            c=True
            break
        elif int(socks[i][2])>=2:
            count+=2
            c=True
            break
if not c and g:
    for i in range(0,len(socks)):
        if socks[i][1]=='right':
            if socks[i][0] in gen:
                count+=1
                c=True
                break
if c:
    print(count)
else:
    print('impossible')




