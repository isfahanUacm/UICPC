string=input()
ch__=string.count('_')
ch_l=0
ch_u=0
for i in string:
    if i.isupper():
        ch_u+=1
    if i.islower():
        ch_l+=1
size=len(string)
ch_s=size-ch__ -ch_l-ch_u
print(ch__/size)
print(ch_l/size)
print(ch_u/size)
print(ch_s/size)


