#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main( )
{
    string inp;
    cin >> inp;
    double ws = 0, lc = 0, uc = 0, sym = 0;
    double length = inp.length();
    for (int i = 0 ; i < length ; i++)
    {
        if (inp[i]=='_')
            ws++;
        else if (islower(inp[i]))
            lc++;
        else if (isupper(inp[i]))
            uc++;
    }
    sym = length - (ws + lc + uc);

//    cout << fixed;

//    cout << setprecision(16);

//    cout <<  << endl <<  << endl <<  << endl <<  << endl;

    printf("%.15f\n%.15f\n%.15f\n%.15f\n",ws/length, lc/length, uc/length, sym/length);

    return 0;
}
