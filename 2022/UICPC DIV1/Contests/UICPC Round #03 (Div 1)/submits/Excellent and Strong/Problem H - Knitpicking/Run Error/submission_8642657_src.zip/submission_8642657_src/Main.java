import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<sucks> mySucks = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            mySucks.add(new sucks(sc.next(), sc.next(), sc.nextInt()));
        }

        boolean pair = false;
        for (int i = 0; i < n; i++) {
            if (doHavePair(mySucks.get(i).name, mySucks, i))
                pair = true;
        }

        if (!pair) {
            System.out.println("impossible");
        } else {
            int min = 0;
            for (int i = 0; i < n; i++) {
                if (mySucks.get(i).type.equals("left") && !leftContainsPair(mySucks.get(i).name, mySucks)) {
                    min += mySucks.get(i).num;
                    mySucks.set(i, null);
                } else if (mySucks.get(i).type.equals("right") && !rightContainsRight(mySucks.get(i).name, mySucks)) {
                    min += mySucks.get(i).num;
                    mySucks.set(i, null);
                }
            }
            int left = 0;
            int right = 0;
            for (int i = 0; i < n; i++) {
                if (mySucks.get(i) != null && mySucks.get(i).type.equals("left")) {
                    left += mySucks.get(i).num;
                } else if (mySucks.get(i) != null && mySucks.get(i).type.equals("right")) {
                    right += mySucks.get(i).num;
                }
            }

            if (left > right) {
                for (int i = 0; i < n; i++) {
                    if (mySucks.get(i) != null && mySucks.get(i).type.equals("left")) {
                        min += mySucks.get(i).num;
                    } else if (mySucks.get(i) != null && mySucks.get(i).type.equals("right")) {
                        min++;
                    } else if (mySucks.get(i) != null && mySucks.get(i).type.equals("any")) {
                        boolean hasPair = false;
                        for (int j = 0; j < n; j++) {
                            if (mySucks.get(j) != null && mySucks.get(i).name.equals(mySucks.get(j)) && i != j) {
                                hasPair = true;
                                break;
                            }
                        }
                        if (!hasPair)
                            min++;
                    }
                }
            } else {
                for (int i = 0; i < n; i++) {
                    if (mySucks.get(i) != null && mySucks.get(i).type.equals("right")) {
                        min += mySucks.get(i).num;
                    } else if (mySucks.get(i) != null && mySucks.get(i).type.equals("left")) {
                        min++;
                    } else if (mySucks.get(i) != null && mySucks.get(i).type.equals("any")) {
                        boolean hasPair = false;
                        for (int j = 0; j < n; j++) {
                            if (mySucks.get(j) != null && mySucks.get(i).name.equals(mySucks.get(j)) && i != j) {
                                hasPair = true;
                                break;
                            }
                        }
                        if (!hasPair)
                            min++;
                    }
                }
            }
            System.out.println(min);
        }
    }

    static boolean doHavePair(String name, ArrayList<sucks> mySucks, int index) {
        for (int i = 0; i < mySucks.size(); i++) {
            if (i != index && mySucks.get(i).name.equals(name))
                return true;
        }
        return false;
    }

    static boolean leftContainsPair(String name, ArrayList<sucks> mySucks) {
        for (int i = 0; i < mySucks.size(); i++) {
            if (mySucks.get(i).name.equals(name) && (mySucks.get(i).type.equals("right") || mySucks.get(i).type.equals("any")))
                return true;
        }
        return false;
    }

    static boolean rightContainsRight(String name, ArrayList<sucks> mySucks) {
        for (int i = 0; i < mySucks.size(); i++) {
            if (mySucks.get(i).name.equals(name) && (mySucks.get(i).type.equals("left") || mySucks.get(i).type.equals("any")))
                return true;
        }
        return false;
    }
}

class sucks {
    String name;
    String type;
    int num;

    public sucks(String name, String type, int num) {
        this.name = name;
        this.type = type;
        this.num = num;
    }
}