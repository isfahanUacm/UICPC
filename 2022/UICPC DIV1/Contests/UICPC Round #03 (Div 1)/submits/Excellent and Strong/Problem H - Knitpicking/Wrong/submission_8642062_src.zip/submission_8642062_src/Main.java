import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        ArrayList<sucks> mySucks = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            mySucks.add(new sucks(sc.next(), sc.next(), sc.nextInt()));
        }
        if (n == 1 && mySucks.get(0).num > 1 && mySucks.get(0).type.equals("any")) {
            System.out.println(2);
        } else {
            boolean havePair = false;
            for (int i = 0; i < n; i++) {
                if (mySucks.get(i).type.equals("any") && mySucks.get(i).num > 1) {
                    havePair = true;
                    break;
                } else if (mySucks.get(i).type.equals("left")) {
                    for (int j = 0; j < n; j++) {
                        if (j!=i && mySucks.get(j).name.equals(mySucks.get(i).name) && (mySucks.get(j).type.equals("right") || mySucks.get(j).type.equals("any"))) {
                            havePair = true;
                            break;
                        }
                    }
                    if (havePair)
                        break;
                } else {
                    for (int j = 0; j < n; j++) {
                        if (j!=i && mySucks.get(j).name.equals(mySucks.get(i).name) && (mySucks.get(j).type.equals("left") || mySucks.get(j).type.equals("any"))) {
                            havePair = true;
                            break;
                        }
                    }
                    if (havePair)
                        break;
                }

            }
            if (havePair) {
                int max = 0;
                for (int j = 0; j < n; j++) {
                    if (mySucks.get(j).type.equals("left") || mySucks.get(j).type.equals("right"))
                        max = Math.max(max, mySucks.get(j).num);
                }
                max += n - 1;
                System.out.println(max);
            } else {
                System.out.println("impossible");
            }
        }
    }


}

class sucks {
    String name;
    String type;
    int num;

    public sucks(String name, String type, int num) {
        this.name = name;
        this.type = type;
        this.num = num;
    }
}