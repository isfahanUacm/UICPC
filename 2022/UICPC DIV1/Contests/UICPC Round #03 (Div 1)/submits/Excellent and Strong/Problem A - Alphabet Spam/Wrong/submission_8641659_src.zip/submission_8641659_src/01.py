s = input()
wS = s.count('_')
upper_count = 0
lower_count = 0
char_count = 0
for x in range(len(s)):
    if s[x].isupper():
        upper_count+=1
    elif s[x].islower():
        lower_count +=1
    else:
        char_count += 1
n = len(s)
print("{0:.16f}".format(float(wS)/n))
print("{0:.16f}".format(float(upper_count)/float(n)))
print("{0:.16f}".format(float(lower_count)/n))
print("{0:.16f}".format(float(char_count)/n))
