s = input()
wS = s.count('_')
upper_count = 0
lower_count = 0
char_count = 0
for x in range(len(s)):
    if s[x].isupper():
        upper_count+=1
    elif s[x].islower():
        lower_count +=1
n = len(s)
print(float(wS)/n)
print(float(lower_count)/float(n))
print(float(upper_count)/n)
print(1 - (float(wS)/n + float(lower_count)/float(n) + float(upper_count)/n))
