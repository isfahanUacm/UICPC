def find(str2):
    for j in range(len(ss)):
        if(ss[j] == str2):
            return 1
    return -1
def cSyll(lll):
    if(len(lll) == 1 and find(lll) == -1):
        return -1
    if find(lll) != -1:
        return 1
    else:
        for i in range(1,len(lll)):
            if find(lll[:-i]) != -1:
                if(cSyll(lll[-i:]) != -1):
                    return 1+cSyll(lll[-i:])
s = int(input())
ss = []
sss = ""
for x in range(s):
    ss.append(input())
    while(x > 0 and len(ss[x - 1]) < len(ss[x])):
        ss[x-1] , ss[x] = ss[x] , ss[x-1]
        x -= 1
for x in range(s):
    sss += ss[x] + " "
q = []
cq = []
for x in range(3):
    q.append(input().split())
    cq.append(0)
for x in range(len(q[0])):
    cq[0] += cSyll(q[0][x])
for x in range(len(q[1])):
    cq[1] += cSyll(q[1][x])
for x in range(len(q[2])):
    cq[2] += cSyll(q[2][x])
if(cq[0] == 5 and cq[1] == 7 and cq[2] == 5):
    print("haiku")
else:
    print("come back next year")
