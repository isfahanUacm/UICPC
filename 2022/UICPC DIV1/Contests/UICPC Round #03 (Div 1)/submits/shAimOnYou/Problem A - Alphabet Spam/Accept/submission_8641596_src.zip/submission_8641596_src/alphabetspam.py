txt = input()
countup = 0
countlower = 0
countwhite = 0
countsymbol = 0

for i in txt:
    if i.islower():
        countlower += 1
    elif i.isupper():
        countup += 1
    elif i == "_":
        countwhite += 1
    else:
        if ord(i) < 65 or ord(i) > 90:
            countsymbol += 1

length = len(txt)
print(countwhite / length)
print(countlower / length)
print(countup / length)
print(countsymbol / length)
