import java.util.Scanner;

public class F {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            int n = sc.nextInt();

            if (n == 0)
                break;

            int can = 100000;
            int usd = 0;

            for (int i = 0; i < n; i++) {
                double d = sc.nextDouble();
                int tmp = usd;
                usd = Math.max(tmp, (int) (0.97 * can / d));
                can = Math.max(can, (int) (0.97 * tmp * d));
            }

            int crr = can / 100;
            int dec = can % 100;

            System.out.printf(dec < 10 ? "%d.0%d\n" : "%d.%d\n", crr, dec);
        }
    }
}