import re


def maxDiff(arr, n):
    diff = arr[1] - arr[0]
    curr_sum = diff
    max_sum = curr_sum

    for i in range(1, n - 1):
        diff = arr[i + 1] - arr[i]

        if (curr_sum > 0):
            curr_sum += diff
        else:
            curr_sum = diff

        if (curr_sum > max_sum):
            max_sum = curr_sum
    return max_sum


while True:
    days = int(input())
    if(days == 0):
        break
    best = 1000
    dayValues = []
    for _ in range(days):
        x = float(input())
        dayValues.append(x)
        if(x < best):
            best = x

    viceVersa = best + maxDiff(dayValues, days)
    value1 = 1000.00 / best
    comission1 = value1 * 0.03
    value2 = (value1-comission1) * viceVersa
    comission2 = value2 * 0.03
    result = value2 - comission2
    if(result <= 1000.00):
        print("1000.00")
    else:
        print(format(round(result, 2), ".2f"))
