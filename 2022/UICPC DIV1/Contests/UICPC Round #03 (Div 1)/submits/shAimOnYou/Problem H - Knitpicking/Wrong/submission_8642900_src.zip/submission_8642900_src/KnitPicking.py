def check(socks):
    for sock in socks:
        if (sock[2] > 1 or (sock[0] != 0 and sock[1] != 0)):
            return True
    else:
        return False


n = int(input())

socks = dict()
index = {'left': 0, 'right': 1, 'any': 2}


for _ in range(n):

    l = input().split()
    type = l[0]
    dir = l[1]
    count = int(l[2])

    lra = socks.get(type, [0, 0, 0])
    lra[index[dir]] += count
    socks[type] = lra


total = 0
values = socks.values()

if(not check(values)):
    print("impossible")
else:
    for lra in values:

        l = lra[0]
        r = lra[1]
        a = lra[2]

        total += max(l, r)

        if a >= 2 and r == 0 and l == 0:
            total += 2
        elif a >= 1 and (l > 0 or r > 0):
            total += 1
        elif a >= 2:
            total += 1

    print(total)
