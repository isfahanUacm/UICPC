n = int(input())
syllables = []
for _ in range(n):
    syllables.append(input())

syllables = sorted(syllables, key=len, reverse=True)

phrase1 = input()
phrase2 = input()
phrase3 = input()

counter1 = 0
counter2 = 0
counter3 = 0

for str in syllables:
    while(str in phrase1):
        counter1 += 1
        phrase1 = phrase1.replace(str, '', 1)
        phrase1 = phrase1.strip()

    while(str in phrase2):
        counter2 += 1
        phrase2 = phrase2.replace(str, '', 1)
        phrase2 = phrase2.strip()

    while(str in phrase3):
        counter3 += 1
        phrase3 = phrase3.replace(str, '', 1)
        phrase3 = phrase3.strip()

if (counter1 == 5 and counter2 == 7 and counter3 == 5 and len(phrase1) == 0 and len(phrase2) == 0 and len(phrase3) == 0):
    print("haiku")
else:
    print("come back next year")
