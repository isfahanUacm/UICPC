st = list(input())
leng = len(st)
white = 0
lower = 0
upper = 0
symb = 0

for i in st:
    if i=='_':
        white+=1
    elif (ord(i)>=33 and ord(i)<=64) or (ord(i)>=91 and ord(i)<=96) or (ord(i)>=123 and ord(i)<=126):
        symb+=1
    elif (ord(i)>=65 and ord(i)<=90):
        upper+=1
    elif (ord(i)>=97 and ord(i)<=122):
        lower+=1

lower=lower/leng
upper=upper/leng
symb = symb/leng
white = white/leng
print(white)
print(lower)
print(upper)
print(symb)