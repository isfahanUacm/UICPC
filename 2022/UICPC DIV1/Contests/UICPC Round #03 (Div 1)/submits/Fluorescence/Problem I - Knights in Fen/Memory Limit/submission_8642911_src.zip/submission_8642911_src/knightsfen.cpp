#include <bits/stdc++.h>
using namespace std;

int mov[8][2] = {{1, -2}, {-1, -2}, {-2, -1}, {2, -1}, {-2, 1}, {-1, 2}, {1, 2}, {2, 1}};
bool ok = false;
bool inrange(int x, int y){
    return x>=0 && y>= 0 && x<5 && y<5;
}

bool final(char arr[5][5]){
    if(arr[0][0] == '1' && arr[0][1] == '1' && arr[0][2] == '1' && arr[0][3] == '1' && arr[0][4] == '1' && arr[1][1] == '1' &&
    arr[1][2] == '1' && arr[1][3] == '1' && arr[1][4] == '1' && arr[2][3] == '1' && arr[2][4] == '1' && arr[3][4] == '1' &&
    arr[2][2] == ' ' && arr[1][0] == '0' && arr[2][0] == '0' && arr[2][1] == '0' && arr[3][0] == '0' && arr[3][1] == '0' &&
    arr[3][2] == '0' && arr[3][3] == '0' && arr[4][0] == '0' && arr[4][1] == '0' && arr[4][2] == '0' && arr[4][3] == '0' &&
    arr[4][4] == '0') return true;
    return false;
}

void bt(int cnt, int cx, int cy, char arr[5][5]){
    if(cnt == 10)
        return;
    if(final(arr)){
        ok = true;
        return;
    }
    for (int i = 0; i < 8; ++i) {
        if(inrange(cx+mov[i][0] , cy+mov[i][1])){
            arr[cx][cy] = arr[cx+mov[i][0]][cy+mov[i][1]];
            arr[cx+mov[i][0]][cy+mov[i][1]] = ' ';
            bt(++cnt, cx+mov[i][0] , cy+mov[i][1], arr);
        }
    }
}

int main(){
    int t;
    cin>>t;
    char arr[5][5];
    string s;
    while (t--){
        ok = false;
        int cx, cy;
        getline(cin, s);
        for (int i = 0; i < 5; ++i) {
            getline(cin, s);
            for (int j = 0; j < 5; ++j) {
                arr[i][j] = s[j];
                if(arr[i][j] == ' ') cx=i, cy=j;
            }
        }
        bt(0, cx, cy, arr);
        if(ok) cout<<"Solvable in 7 move(s).";
        else cout<<"Unsolvable in less than 11 move(s).";
    }
}