import math
while(True):
    n = int(input())
    if n==0:
        break
    dp=[[0,0]]*(n+1)
    dp[0]=[100000,0]
    for i in range(1,n+1):
        rateUS = float(input())
        rateCA = 1/rateUS
        #canadian
        UStoCAD = math.floor(dp[i-1][1]*rateUS*0.97)
        dp[i][0]=max(dp[i-1][0], UStoCAD)
        #us
        CADtoUS = math.floor(dp[i-1][0]*rateCA*0.97)
        dp[i][1]=max(dp[i-1][1], CADtoUS)
    
    print("{:.2f}".format(dp[n][0]/100))