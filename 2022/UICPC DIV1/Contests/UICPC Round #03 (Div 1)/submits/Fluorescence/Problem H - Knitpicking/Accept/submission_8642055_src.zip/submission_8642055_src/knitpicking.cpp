#include <bits/stdc++.h>
using namespace std;

int main(){
    int  n, x;
    cin>>n;
    vector<pair<string, int>> any, left, right;
    set<string> type;
    map<string, int[3]> m;
    int ca = 0, cr = 0, cl = 0;
    string t, v;
    for (int i = 0; i < n; ++i) {
        cin>>t>>v>>x;
        if(v=="any") any.push_back({t, x}), ca+=x;
        if(v=="right") right.push_back({t, x}), cr+=x;
        if(v=="left") left.push_back({t, x}), cl+=x;
        type.insert(t);
    }
    int possible = 0;
    int total = 0;
    for(string s : type){
        bool l = false;
        int ll = 0, rr=0, aa=0;
        for (int i = 0; i < left.size(); ++i) {
            if(left[i].first == s){
                l = true;
                ll += left[i].second;
            }
        }
        bool r = false;
        for (int i = 0; i < right.size(); ++i) {
            if(right[i].first == s) {
                r = true;
                rr += right[i].second;
            }
        }
        bool ta = false, a = false;
        for (int i = 0; i < any.size(); ++i) {
            if(any[i].first == s){
                a = true;
                if(any[i].second >= 2) ta = true;
                aa += any[i].second;
            }
        }
        if((!a && !l && r) || (!a && l && !r) || (!ta && !r && !l)) {
            //possible = false;
            possible++;
        }
        total += max(ll, rr);
        if(ll == 0 && rr == 0 && aa >= 1) total += 1;
    }

    if(possible != type.size()){
        cout<<total+1;
    }
    else cout<<"impossible";
}