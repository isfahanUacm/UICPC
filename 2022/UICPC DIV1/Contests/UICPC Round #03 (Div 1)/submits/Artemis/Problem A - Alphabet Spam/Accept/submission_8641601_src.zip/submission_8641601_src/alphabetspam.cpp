#include<bits/stdc++.h>
using namespace std;
int main(){
    string str;
    int spc=0,lw=0,up=0,syb=0;
    getline(cin,str);
    for(int i=0;i<str.size();i++){
        if(str[i]<=122 && str[i]>=97) lw++;
        else if(str[i]<=90 && str[i]>=65) up++;
        else if(str[i]=='_') spc++;
        else syb++;
    }
     printf("%0.7f",spc*1.0/str.size());
     cout<<endl;
     printf("%0.7f",lw*1.0/str.size());
     cout<<endl;
     printf("%0.7f",up*1.0/str.size());
     cout<<endl;
     printf("%0.7f",syb*1.0/str.size());
    return 0;
}