#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

bool ir(int x, int cap) {
    return x >= 0 && x < cap;
}

set <int>st;
int rows;
vector<int> vc[500];
int cap[5000];
vector<int> visited[500];


vector<pair<int, int>> mj(int i, int j) {
    vector<pair<int, int>> temp;
    if (j != 0) {
        temp.push_back({i, j - 1});
    }
    if (j != vc[i].size() - 1) {
        temp.push_back({i, j + 1});
    }

    if (i > rows / 2) {
        if (i != 0) {
            int nj = j + 1;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});

            nj = j;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});
        }

        if (i != rows - 1) {
            int nj = j - 1;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});

            nj = j;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});
        }
    }
    else if (i < rows / 2) {
        if (i != 0) {
            int nj = j - 1;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});

            nj = j;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});
        }

        if (i != rows - 1) {
            int nj = j + 1;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});

            nj = j;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});
        }
    }
    else {
        if (i != 0) {
            int nj = j - 1;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});

            nj = j;
            if (ir(nj, cap[i - 1]))
                temp.push_back({i - 1, nj});
        }

        if (i != rows - 1) {
            int nj = j - 1;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});

            nj = j;
            if (ir(nj, cap[i + 1]))
                temp.push_back({i + 1, nj});
        }
    }

    return temp;
}

ll ans = 0;

void dfs(int i, int j) {
    visited[i][j] = true;
    vector<pair<int, int>> t = mj(i, j);

    for (auto temp : t) {
        int x = temp.first;
        int y = temp.second;
        if (!visited[x][y]) {
            if (st.count(vc[x][y]) > 0) {
                ans++;
                continue;
            }
            else {
                dfs(x, y);
            }
        }
    }
}


int main() {
    int r, k;
    cin >> r >> k;
    rows = 2 * r - 1;


    for (int i = 0; i < r; ++i) {
        cap[i] = r + i;
    }

    for (int i = 0; i < r; ++i) {
        cap[rows - i - 1] = r + i;
    }

    int ind = 1;
    int row = 0;

    while (row < rows) {
        vc[row].push_back(ind);
        visited[row].push_back(0);
        ind++;
        if (cap[row] == vc[row].size())
            row++;
    }

    for (int i = 0; i < k; ++i) {
        int temp;
        cin >> temp;
        st.insert(temp);
    }


    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < vc[i].size(); ++j) {
            if (i == 0 || i == rows - 1 || j == 0 || j == vc[i].size() - 1) {
                if (st.count(vc[i][j]) == 0 && !visited[i][j])
                    dfs(i, j);
                else if (st.count(vc[i][j]) != 0){
                    if (i == 0 || i == rows - 1) {
                        if (j == 0 || j == vc[i].size() - 1) {
                            ans += 3;
                        }
                        else {
                            ans += 2;
                        }
                    }
                    else if (j == 0 || j == vc[i].size() - 1) {
                        if (i == rows / 2) {
                            ans += 3;
                        }
                        else {
                            ans += 2;
                        }
                    }
                }
            }
        }
    }
    cout << ans << endl;
}