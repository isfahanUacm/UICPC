#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
pair<int, int> mv[] = {
        {1, 2},
        {1, -2},
        {-1, 2},
        {-1, -2},
        {2, 1},
        {2, -1},
        {-2, 1},
        {-2, -1}
};

int arr[5][5];
int test[5][5] = {
        {1,1,1,1,1},
        {2,1,1,1,1},
        {2,2,0,1,1},
        {2,2,2,2,1},
        {2,2,2,2,2}
};

bool ir(int x, int y) {
    return x >= 0 && x < 5 && y >= 0 && y < 5;
}

int ans = INT_MAX;


bool check() {
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if (arr[i][j] != test[i][j])
                return false;
        }
    }
    return true;
}

void dfs(int step, int x, int y, int px, int py) {
    if (check()) {
        ans = min(ans, step);
        return;
    }

    if (step >= 10)
        return;

    for (auto t : mv) {
        int nx = x + t.first;
        int ny = y + t.second;

        if (ir(nx, ny) && (nx != px || ny != py)) {
            swap(arr[x][y], arr[nx][ny]);
            dfs(step + 1, nx, ny, x, y);
            swap(arr[x][y], arr[nx][ny]);
        }
    }
}

int main() {
    int tc;
    cin >> tc;
    getchar();
    while (tc--) {
        ans = INT_MAX;
        int x, y;
        string a;
        for (int i = 0; i < 5; ++i) {
            getline(cin, a);
            for (int j = 0; j < 5; ++j) {
                char ch = a[j];
                if (ch == ' ') {
                    arr[i][j] = 0;
                    x = i;
                    y = j;
                }
                else if (ch == '0') {
                    arr[i][j] = 2;
                }
                else {
                    arr[i][j] = 1;
                }
            }
        }
        dfs(0, x, y, -1, -1);

        if (ans > 10) {
            cout << "Unsolvable in less than 11 move(s)." << endl;
        }
        else {
            cout << "Solvable in " << ans << " move(s)." << endl;
        }
    }

//    int tc;
//    cin >> tc;
//    while (tc--) {
//        int n;
//        cin >> n;
//        int arr[150][10];
//        memset(arr, 0, sizeof(arr));
//
//        for (int i = 0; i < n; ++i) {
//            for (int j = 0; j <= 7; ++j) {
//                cin >> arr[i][j];
//                arr[i][j]--;
//            }
//        }
//
//        int temp[9], tp[9];
//        memset(temp, 0, sizeof(temp));
//
//        for (int i = 0; i < n; ++i) {
//            for (int j = 0; j < 8; ++j) {
//                int mx = 10;
//                for (int k = 0; k < 3; ++k) {
//                    int t = arr[i][j];
//                    t ^= (1 << k);
//                    cout << "asd " << arr[i][j] << ' ' << t;
//                    if (i != n - 1)
//                        t = temp[t];
//
//                    cout << ' ' << t << endl;
//                    for (int l = 0; l < 8; ++l) {
//                        if (arr[i][l] == t) {
//                            mx = min(mx, l);
//                        }
//                    }
//                }
//                cout << arr[i][j] << ' ' << arr[i][mx] << endl;
//                tp[arr[i][j]] = arr[i][mx];
//            }
//            for (int j = 0; j < 8; ++j) {
//                temp[j] = tp[j];
//                cout << temp[j] + 1 << ' ';
//            }
//            cout << endl;
//        }
//        cout << temp[0] << endl;
//
//    }
}