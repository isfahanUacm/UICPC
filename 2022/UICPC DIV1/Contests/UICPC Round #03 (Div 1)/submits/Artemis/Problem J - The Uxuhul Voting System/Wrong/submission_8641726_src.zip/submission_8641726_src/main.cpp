#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        int n;
        cin >> n;
        int arr[10];
        memset(arr, 0, sizeof(arr));
        int now = 0;

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j <= 7; ++j) {
                cin >> arr[j];
                arr[j]--;
            }

            int mx = 10;
            for (int j = 0; j < 3; ++j) {
                int temp = now;
                temp ^= (1 << j);

                for (int k = 0; k <= 7; ++k) {
                    if (arr[k] == temp)
                        mx = min(mx, k);
                }
            }

            now = arr[mx];
//            cout << now << endl;
        }

        for (int i = 2; i >= 0; --i) {
            if (now & (1 << i))
                cout << "Y";
            else
                cout << "N";
        }
        cout << endl;
    }
}