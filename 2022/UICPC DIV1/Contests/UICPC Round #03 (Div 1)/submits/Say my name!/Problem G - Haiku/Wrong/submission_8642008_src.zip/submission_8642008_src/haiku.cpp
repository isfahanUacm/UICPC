#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <cstdio>

using namespace std;

int main()
{
	int nhaja;
	cin >> nhaja;

	string* haja = new string[nhaja];
	for (int i = 0; i < nhaja; i++) cin >> haja[i];

	for (int i = 0; i < nhaja; i++)
	{
		for (int j = 0; j < nhaja - i - 1; j++)
		{
			if (haja[j].length() < haja[j + 1].length())
			{
				string temp = haja[j];
				haja[j] = haja[j + 1];
				haja[j + 1] = temp;
			}
		}
	}

	bool flag = true;

	char temp[3][100 + 1];
	string sen[3];

	for (int k = 0; k < 3; k++)
	{
		if (k == 0) cin.ignore();
		fgets(temp[k], 101, stdin);
		sen[k] = temp[k];
	}




	for (int k = 0; k < 3; k++)
	{

		int ni = 0;

		for (int i = 0; i < nhaja; i++)
		{
			int fi = sen[k].find(haja[i]);

			while (fi >= 0)
			{
				fi = sen[k].find(haja[i]);

				if (fi >= 0 && fi < 105)
				{
					sen[k].replace(fi, haja[i].length(), "");
					ni++;
				}
			}

		}

		if (k == 0 && ni != 5) {
			flag = false;
			break;
		}
		if (k == 1 && ni != 7) 
		{
			flag = false;
			break;
		}
		if (k == 2 && ni != 5)
		{
			flag = false;
			break;
		}

	}

	if (flag) cout << "haiku";
	else cout << "come back next year";
}