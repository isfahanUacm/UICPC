import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        int n=str.length();
        char[]strCh=new char[str.length()];
        for(int i=0;i<n;i++){
            strCh[i]=str.charAt(i);
        }
        int space=0;
        int lowercaseLetters=0;
        int uppercaseLetters=0;
        int symbols=0;
        for(int i=0;i<n;i++){
            if(strCh[i]=='_'){
                space++;
            }else if(strCh[i]>=33 &&strCh[i]<=64 || strCh[i]>=91 &&strCh[i]<=96 || strCh[i]>=123 &&strCh[i]<=126){
                if(strCh[i]!='_'){
                    symbols++;
                }
            }else if(strCh[i]>=65 &&strCh[i]<=90){
                uppercaseLetters++;
            }else if(strCh[i]>=97 &&strCh[i]<=122){
                lowercaseLetters++;
            }
        }
        double spaceA=(double) space/n;
        double lw=(double) lowercaseLetters/n;
        double up=(double) uppercaseLetters/n;
        double sy=(double) symbols/n;
        System.out.println(spaceA);
        System.out.println(lw);
        System.out.println(up);
        System.out.println(sy);
    }
}
