#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

set <string> dic;
string t;
bool dp[1000][1000];
bool visited[1000][1000];

bool check(ll index,ll nosyl)
{

    if (t[index] == ' ' )
        return check(index+1,nosyl);
    if (index == t.size() && nosyl==0)
        return true;
    //    if (nosyl==0 && index != t.size()-1)
    //        return false;
    //    if (index == t.size()-1 && nosyl != 0)
    //        return false;
    if (dp[index][nosyl])
        return true;
    if (visited[index][nosyl])
        return dp[index][nosyl];
    for (ll i=index;i<t.size();i++)
    {
        string sub = t.substr(index,i-index+1);
        if (dic.find(sub) != dic.end())
        {
            if (check(i+1,nosyl-1))
            {
                dp[index][nosyl] = true;
                visited[index][nosyl] = true;
                return dp[index][nosyl];
            }
        }
    }
    visited[index][nosyl] = true;
    return dp[index][nosyl];

}


int main()
{
    ll n;

    cin >> n;
    for(ll i=0;i<n;i++)
    {
        cin >> t;
        dic.insert(t);
    }

    getchar();
    getline(cin,t);
    if (check(0,5))
    {
        //cout << "haiku"<<endl;
        getline(cin,t);
        fill(&dp[0][0],&dp[0][0] + 1000000, false);
        fill(&visited[0][0],&visited[0][0] + 1000000, false);
        if(check(0,7))
        {
            // cout << "haiku"<<endl;
            getline(cin,t);
            fill(&dp[0][0],&dp[0][0] + 1000000, false);
            fill(&visited[0][0],&visited[0][0] + 1000000, false);
            if(check(0,5))
                cout <<  "haiku";
            else
            {
                cout << "come back next year";
            }
        }
        else
        {
            cout << "come back next year";
        }
    }
    else
    {
        cout << "come back next year";
    }


}