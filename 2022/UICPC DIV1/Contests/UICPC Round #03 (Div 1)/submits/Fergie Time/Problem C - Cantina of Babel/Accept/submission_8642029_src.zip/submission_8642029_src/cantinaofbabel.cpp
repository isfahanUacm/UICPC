#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll maxN = 101;
vector<vector<ll>> graph;
vector<vector<ll>> graphRev;
bool visited[maxN];
ll n, m;
ll group;
ll groups[maxN];
ll degreeIn[maxN];
ll degreeOut[maxN];
stack<ll> st1;

void dfs1(ll index)
{
    visited[index] = true;
    for (ll i: graph[index])
    {
        if (!visited[i])
        {
            dfs1(i);
        }
    }
    st1.push(index);
}

void dfs2(ll index)
{
    groups[index] = group;
    visited[index] = true;
    for (ll i: graphRev[index])
    {
        if (!visited[i])
        {
            dfs2(i);
        }
    }
}
vector<string> split(const string& str, char delim)
{
    vector<string> cont;
    stringstream ss(str);
    string token;
    while(getline(ss, token, delim))
        cont.push_back(token);
    return cont;
}

int main()
{

    cin>>n;
    getchar();
    vector<vector<string>> arr(n);
    vector<unordered_set<string>> understand(n);
    unordered_map<string,ll> indexof;
    for(ll i=0;i<n;i++){
        string s;
        getline(cin,s);

        arr[i]=split(s,' ');
        indexof[arr[i][0]]=i;
        for(ll j=1;j<arr[i].size();j++){
            understand[i].insert(arr[i][j]);
        }
    }
    graph=vector<vector<ll>>(n);
    graphRev=vector<vector<ll>>(n);

    for(ll i=0;i<n;i++){
        for(ll j=0;j<n;j++){
            if(i != j){
                if(understand[j].find(arr[i][1]) != understand[j].end()){
                    graph[i].push_back(j);
                    graphRev[j].push_back(i);
                }
            }
        }
    }
    st1=stack<ll>();
    fill(visited, visited + n, false);
    for (ll i = 0; i < n; i++)
    {
        if (!visited[i])
        {
            dfs1(i);
        }
    }
    group = 0;
    fill(visited, visited + n, false);
    fill(groups, groups + n, -1);
    while(st1.size())
    {
        ll i = st1.top();
        st1.pop();
        if (!visited[i])
        {
            dfs2(i);
            group++;
        }
    }
    vector<ll> gropvec(group,0);

    for(ll i=0;i<n;i++){
        gropvec[groups[i]]++;

    }
    cout<<n-(*max_element(gropvec.begin(),gropvec.end()))<<endl;



}
