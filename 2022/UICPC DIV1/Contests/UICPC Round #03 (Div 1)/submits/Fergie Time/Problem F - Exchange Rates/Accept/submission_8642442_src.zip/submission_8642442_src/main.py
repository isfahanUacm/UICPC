from math import floor


n = int(input())
while n != 0:
    a = [float(input()) for _ in range(n)]
    dp = [[0, 0] for _ in range(n + 1)]
    dp[0] = [1000, 0]
    for i in range(1, n + 1):
        dp[i][0] = max(dp[i - 1][0], floor(dp[i - 1][1] * (a[i - 1]) * 0.97 * 100) / 100)
        dp[i][1] = max(floor(dp[i][0] * (1 / a[i - 1]) * 0.97 * 100) / 100, dp[i - 1][1])
    print("{:0.2f}".format(dp[n][0]))
    n = int(input())

