#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    ll n;
    string s;
    cin>>s;
    ll lower=0;
    ll upper=0;
    ll space=0;
    ll sample=0;
    for(ll i=0;i<s.length();i++){
        if(s[i]=='_'){
            space += 1;
        }
        else if(islower(s[i])){
            lower += 1;
        }
        else if(isupper(s[i])){
            upper += 1;
        }
        else{
            sample += 1;
        }
    }
    ll lent=s.length();
    cout<<fixed<<setprecision(10)<<(ld)space/(ld)lent<<endl;
    cout<<fixed<<setprecision(10)<<(ld)lower/(ld)lent<<endl;
    cout<<fixed<<setprecision(10)<<(ld)upper/(ld)lent<<endl;
    cout<<fixed<<setprecision(10)<<(ld)sample/(ld)lent<<endl;
}
