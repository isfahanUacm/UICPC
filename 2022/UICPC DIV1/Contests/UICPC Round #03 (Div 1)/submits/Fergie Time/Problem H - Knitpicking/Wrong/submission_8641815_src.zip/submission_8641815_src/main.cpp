#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl;
const ll maxn = 1000;
const ll mod = 1e9 + 7;

int main()
{
    ll n;
    cin >> n;
    vector<pair<string, pair<string, ll>>> a(n);

    for (ll i = 0; i < n; i++)
    {
        cin >> a[i].first >> a[i].second.first >> a[i].second.second;
    }
    vector<ll> sample(3, 0ll);
    unordered_map<string, vector<ll>> mp;

    for (ll i = 0; i < n; i++)
    {
        if (mp.find(a[i].first) == mp.end())
        {
            mp[a[i].first] = sample;
        }
        unordered_map<string, ll> indexOf = {{"right", 0}, {"left", 1}, {"any", 2}};
        mp[a[i].first][indexOf[a[i].second.first]] += a[i].second.second;
    }
    bool hasAns = false;
    for (auto i : mp)
    {
        if ((i.second[0] && i.second[1]) || (i.second[0] && i.second[2]) || (i.second[1] && i.second[2]))
        {
            hasAns = true;
            break;
        }
    }
    if (!hasAns)
    {
        cout << "impossible";
    }
    else
    {
        ll ans = 0;
        for (auto i : mp)
        {
            if(i.second[0] || i.second[1])
            {
                ans += max(i.second[0], i.second[1]);
            }
            else
            {
                ans += (i.second[2] != 0);
            }
        }
        cout << ans + 1;
    }
    return 0;
}
