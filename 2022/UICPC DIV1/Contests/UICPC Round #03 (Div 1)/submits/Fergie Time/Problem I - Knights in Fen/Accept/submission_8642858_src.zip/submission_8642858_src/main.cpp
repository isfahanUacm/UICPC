#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 20010;

vector<string> goalGrid;
vector<string> grid;

bool isSame(vector<string> &a, vector<string> &b)
{
    for(ll i = 0; i < 5; i++)
    {
        for(ll j = 0; j < 5; j++)
        {
            if(a[i][j] != b[i][j])
            {
                return false;
            }
        }
    }
    return true;
}

vector<pll> dirs = {{-1, -2}, {-2, -1}, {-2, +1}, {-1, +2}, {+1, +2}, {+2, +1}, {+1, -2}, {+2, -1}};
ll answer = LLONG_MAX;

void f(pll pos, ll depth)
{
    if(depth > 10)
    {
        return;
    }
    if(isSame(grid, goalGrid))
    {
        answer = min(answer, depth);
        return;
    }
    for(pll dir: dirs)
    {
        pll dest = {pos.first + dir.first, pos.second + dir.second};
        if(dest.first >= 0 && dest.first < 5 && dest.second >= 0 && dest.second < 5)
        {
            grid[pos.first][pos.second] = grid[dest.first][dest.second];
            grid[dest.first][dest.second] = ' ';
            f(dest, depth + 1);
            grid[dest.first][dest.second] = grid[pos.first][pos.second];
            grid[pos.first][pos.second] = ' ';
        }
    }
}

int main()
{
    goalGrid = vector<string>(5, "     ");
    goalGrid[0] = "11111";
    goalGrid[1] = "01111";
    goalGrid[2] = "00 11";
    goalGrid[3] = "00001";
    goalGrid[4] = "00000";

    ll n;
    cin >> n;
    getchar();
    while(n--)
    {
        answer = LLONG_MAX;
        grid = vector<string>(5, "     ");
        pll pos = {-1, -1};
        for(ll i = 0; i < 5; i++)
        {
            getline(cin, grid[i]);
            if(pos.first == -1 && pos.second == -1)
            {
                auto it = find(grid[i].begin(), grid[i].end(), ' ');
                if(it != grid[i].end())
                {
                    pos = {i, it - grid[i].begin()};
                }
            }
        }
        
        
        f(pos, 0);
        if(answer == LLONG_MAX)
        {
            cout << "Unsolvable in less than 11 move(s)." << endl;
        }
        else
        {
            cout << "Solvable in " << answer << " move(s)." << endl;
        }
    }
    
    return 0;
}