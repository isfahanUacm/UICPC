#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    char a;
    int space = 0, lower = 0, upper = 0, symbol = 0;
    
    while(cin >> a)
    {
        if (a == 32 || a == 95)
            space++;
        else if (a >= 97 && a <= 122)
            lower++;
        else if (a >= 65 && a <= 90)
            upper++;
        else
            symbol++;
    }
    
    int total = space + lower + upper + symbol;
    
    cout << fixed << setprecision(6) << (float)space / total << endl;
    cout << fixed << setprecision(6) << (float)lower / total << endl;
    cout << fixed << setprecision(6) << (float)upper / total << endl;
    cout << fixed << setprecision(6) << (float)symbol / total << endl;

    return 0;
}