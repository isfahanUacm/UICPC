#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n, number, k = 0, k1 = 0;
    long long sum = 0;
    string type1, fit;
    cin >> n;
    string type[1000];
    int num[1000][3] = {0};
    
    for (int i = 0; i < n; i++)
    {
        k = k1;
        cin >> type1 >> fit >> number;
        if (i == 0)
        {
            type[i] = type1;
            if (fit == "any")
                num[i][0] = number;
            else if (fit == "right")
                num[i][1] = number;
            else if (fit == "left")
                num[i][2] = number;
            k1++;
        }
        for (int j = 0; j < k; j++)
        {
            if (type[j] == type1)
            {
                if (fit == "any")
                    num[j][0] = number;
                else if (fit == "right")
                    num[j][1] = number;
                else if (fit == "left")
                    num[j][2] = number;
                break;
            }
            else if (j == k-1)
            {
                type[k] = type1;
                if (fit == "any")
                    num[k][0] = number;
                else if (fit == "right")
                    num[k][1] = number;
                else if (fit == "left")
                    num[k][2] = number;
                k1++;
            }
        }
    }
    k = k1;
        
    for (int i = 0; i < k; i++)
    {
        if (num[i][1] > 0 && num[i][2] > 0)
            sum += 2;
        
        else if (num[i][1] == 0 && num[i][2] == 0 && num[i][0] == 1)
        {
            cout << "impossible" << endl;
            return 0;
        }
            
        else if (num[i][1] == 0 && num[i][2] == 0)
            sum += ceil(float(num[i][0] / 2)) + 1;
        
        else if ((num[i][1] == 0 || num[i][2] == 0) && (num[i][0] == 0 || num[i][0] == 1))
        {
            cout << "impossible" << endl;
            return 0;
        }
        
        else
            sum += ceil(float(num[i][0] / 2)) + 1;
    }
        
        
    cout << sum << endl;
        
        
    return 0;
}