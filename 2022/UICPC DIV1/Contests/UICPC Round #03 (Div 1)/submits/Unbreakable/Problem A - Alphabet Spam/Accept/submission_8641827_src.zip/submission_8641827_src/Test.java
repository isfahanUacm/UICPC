import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int length = s.length();
        double countWhitespace = 0;
        double countLowercase = 0;
        double countUppercase = 0;
        double countSymbols = 0;
        for (int i = 0; i < length; i++) {
            if (isWhitespace(s.charAt(i))) countWhitespace++;
            else if (isLowercase(s.charAt(i))) countLowercase++;
            else if (isUppercase(s.charAt(i))) countUppercase++;
            else if (isSymbols(s.charAt(i))) countSymbols++;
        }
        System.out.printf("%.15f\n", countWhitespace / length);
        System.out.printf("%.15f\n", countLowercase / length);
        System.out.printf("%.15f\n", countUppercase / length);
        System.out.printf("%.15f\n", countSymbols / length);
    }

    static Boolean isWhitespace(Character s) {
        int a = s;
        return a == 95;
    }

    static Boolean isLowercase(Character s) {
        int a = s;
        return a >= 97 && a <= 122;
    }

    static Boolean isUppercase(Character s) {
        int a = s;
        return a >= 65 && a <= 90;
    }

    static Boolean isSymbols(Character s) {
        return !isWhitespace(s) && !isLowercase(s) && !isUppercase(s);
    }
}