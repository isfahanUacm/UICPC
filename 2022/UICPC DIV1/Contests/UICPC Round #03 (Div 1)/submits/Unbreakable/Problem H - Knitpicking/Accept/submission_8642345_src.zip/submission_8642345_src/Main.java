

import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int rep = sc.nextInt();

        HashMap<String, Counts> list = new HashMap<>();
        for (int i = 0; i < rep; i++) {
            String type = sc.next();
            String RLA = sc.next();
            int count = sc.nextInt();

            Counts thisType;

            if (list.containsKey(type)){
                thisType = list.get(type);
            } else{
                thisType = new Counts();
            }

            switch (RLA){
                case "any":
                    thisType.any = count;
                    break;

                case "left":
                    thisType.left = count;
                    break;

                case "right":
                    thisType.right = count;
                    break;
            }

            list.put(type, thisType);
        }




        boolean isPossible = false;
        int ans = 0;


        for (Counts cur : list.values()) {
            if (cur.isPoss()){
                isPossible = true;
                ans += cur.valPos();
            } else {
                ans += cur.valImpos();
            }
        }

        if (isPossible){
            ans++;
            System.out.println(ans);
        } else{
            System.out.println("impossible");
        }

    }
}
class Counts{
    int left = 0;
    int right = 0;
    int any = 0;

    boolean isPoss(){
        if (left == 0 && right == 0 && any == 1){
            return false;
        }

        if (left == 0 && any == 0){
            return false;
        }

        if (right == 0 && any == 0){
            return false;
        }

        return true;
    }

    int valPos(){
        if(left == 0 && right == 0){
            return 1;
        }
        return Math.max(left, right);
    }

    int valImpos(){
        return left + right + any;
    }

}
