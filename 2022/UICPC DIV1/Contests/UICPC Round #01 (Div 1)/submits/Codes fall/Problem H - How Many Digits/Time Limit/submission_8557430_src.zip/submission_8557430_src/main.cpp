#include <iostream>

using namespace std;

int main()
{
    long long int n, fac, counter;
    while( cin >> n )
    {
        fac = 1;
        //cin >> n;
        for( int i = 2; i <= n; i++ )
            fac *= i;
        counter = 0;
        while( fac > 0 )
        {
            counter++;
            fac /= 10;
        }
        cout << counter << endl;
    }

    return 0;
}
