#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;
 
 
int compare(const void* a, const void* b)
{
	const int* x = (int*) a;
	const int* y = (int*) b;

	if (*x > *y)
		return 1;
	else if (*x < *y)
		return -1;

	return 0;
}

int main()
{
    int n, i = 0, z = 0;
    double digits = 0;
    int arr[10000];
    
    while (cin >> n)
        arr[i++] = n;
    
    qsort(arr, i, sizeof(int), compare);
    
    while (arr[z] == 0 || arr[z] == 1)
        arr[z++] = 1;
        
        
    for (int j = 2; j <= 1000000; j++)
    {
        n = arr[z];
        digits += log10(j);
        
        if (n == j)
            arr[z++] = floor(digits) + 1;
    }
    
        
    for (int k = 0; k < i; k++)
    {
        printf("%d", arr[k]);
        printf("\n");
    }

    return 0;
}