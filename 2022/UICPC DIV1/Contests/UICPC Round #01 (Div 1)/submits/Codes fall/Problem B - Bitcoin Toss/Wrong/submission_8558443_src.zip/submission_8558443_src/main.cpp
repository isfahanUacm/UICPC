#include <iostream>
#include <string>

using namespace std;

int main()
{
    int n;
    cin >> n;
    for( int i = 0; i < n; i++ )
    {
        string s;
        cin >> s;
        int length = s.length();
        int* x = new int[length];
        for( int j = 0; j < length; j++ )
            x[j] = 1;
        int counter{};
        for( int j = 0; j < length; j++ )
        {
            if( s[j] == s[j+1] )
                x[counter]++;
            else
                counter++;
        }
        int maxi, indexMax{};
        maxi = x[0];
        for( int j = 1; j < length; j++ )
        {
            if( x[j] > maxi )
            {
                maxi = x[j];
                indexMax = j;
            }
        }
        int sum{};
        for( int j = 0; j < indexMax; j++ )
        {
            sum += x[j];
        }
        int firstCut;
        while( sum > 0 )
        {
            sum -= maxi;
        }
        firstCut = sum + maxi;
        cout << firstCut << ' ' << firstCut-1 << endl;
    }
}
