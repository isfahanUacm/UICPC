#include <iostream>
using namespace std;
int min(int x1,int x2)
{
    if (x1<x2)
    {
        return x1;
    }
    else
    {
        return x2;
    }
}
int main()
{
    int n, h, i, j, a, b, c;
    cin >> n >> h;
    int* x = new int[n];
    int* y = new int[h];
    if (h<=n)
    {
        for (i = 0; i < n; i++)
        {
            cin >> x[i];
            y[i] = 0;
        }
    }
    else
    {
        for (i = 0; i < n; i++)
        {
            cin >> x[i];
            y[i] = 0;
        }
        for (i = n; i < h; i++)
        {
            y[i] = 0;
        }
    }
    for (i = 0; i < n; i++)
    {
        if (i%2==0)
        {
            for (j = 0; j < x[i]; j++)
            {
                y[j]++;
            }
        }
        else
        {
            for (j = h-1; j >= h-x[i]; j--)
            {
                y[j]++;
            }
        }
    }
    for (i = 1; i < h; i++)
    {
        b = min(y[i], y[i - 1]);
    }
    c = 0;
    for (i = 0; i < h; i++)
    {
        if (y[i]==b)
        {
            c++;
        }
    }
    cout << b << " " << c;
}