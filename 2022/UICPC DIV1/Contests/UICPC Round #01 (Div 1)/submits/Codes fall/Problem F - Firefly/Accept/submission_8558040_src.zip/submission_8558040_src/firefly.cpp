#include <iostream>
using namespace std;

int main()
{
    int n, h, i, j, a, b, c;
    cin >> n >> h;
    int x[h] = {};
    int y[h] = {};

    for (i = 0; i < n; i++)
    {
        cin >> a;
        if (i%2==0)
            x[a-1] += 1;
        else
            y[a-1] += 1;
    }
    
    for (i = h-1; i > 0; i--)
    {
        x[i-1] += x[i];
        y[i-1] += y[i];
    }
    
    for (i = 0; i < h; i++)
        x[i] += y[h-i-1];
    
    b = 500001; c = 0;
    for (i = 0; i < h; i++)
    {
        if (x[i]<b)
            b = x[i];
    }
    for (i = 0; i < h; i++)
    {
        if (x[i]==b)
            c++;
    }
    cout << b << " " << c;
    
    return 0;
}



