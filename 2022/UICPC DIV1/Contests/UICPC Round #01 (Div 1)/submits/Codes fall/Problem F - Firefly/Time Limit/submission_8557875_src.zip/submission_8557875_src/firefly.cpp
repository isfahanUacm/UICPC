#include <iostream>
using namespace std;

int main()
{
    int n, h, i, j, a, b, c;
    cin >> n >> h;
    int x[h] = {};

    for (i = 0; i < n; i++)
    {
        cin >> a;
        if (i%2==0)
        {
            for (j = 0; j < a; j++)
            {
                x[j]++;
            }
        }
        else
        {
            for (j = h-1; j >= h-a; j--)
            {
                x[j]++;
            }
        }
    }
    
    b = 500001; c = 0;
    for (i = 0; i < h; i++)
    {
        if (x[i]<b)
            b = x[i];
    }
    for (i = 0; i < h; i++)
    {
        if (x[i]==b)
            c++;
    }
    cout << b << " " << c;
    
    return 0;
}



