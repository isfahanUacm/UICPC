#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    int n, s, k, halatT{};
    int* x = new int[n];
    cin >> n >> s >> k;
    //for( int i = 0; i < pow(s, n); i++ )

    if( k == 0 )
        cout << fixed << setprecision(10) << pow(s, n);
    else
    {
        for( int j = 1; j <= s; j++ )
        {
            for( int p = 1; p <= s; p++ )
            {
                for( int q = 1; q <= s; q++ )
                {
                    x[0] = j;
                    x[1] = p;
                    x[2] = q;
                    int counter;
                    counter = 0;
                    if( x[0] != x[1] )
                        counter++;
                    if( x[0] != x[2] )
                        counter++;
                    if( x[1] != x[2] )
                        counter++;
                    if( counter >= k )
                        halatT++;
                }
            }
        }
        cout << fixed << setprecision(10) << halatT / pow(s, n);
    }
    return 0;
}
