#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;


int fac(int n)
{
    if (n == 0)
        return 1;
        
    if (n == 1)
        return 1;
    
    return n * fac(n-1);
}


int tarkib(int a, int b)
{
    return fac(a) / (fac(b) * fac(a-b));
}


int main()
{
    int n, s, k, x=1;
    cin >> n >> s >> k;
    int z = s;
    if (z == k)
    {
        while (z)
            x *= z--;
    }
    

    else
    {
        x = tarkib(s, k) * pow(k, n);
    }
    
    cout << fixed << setprecision(9) << x / pow(s, n) << endl;

    
    return 0;
}