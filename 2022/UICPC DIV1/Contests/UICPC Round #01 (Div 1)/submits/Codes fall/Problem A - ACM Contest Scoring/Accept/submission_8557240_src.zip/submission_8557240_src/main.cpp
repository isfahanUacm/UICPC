#include <iostream>

using namespace std;

int main()
{
    int time[101];
    char ques[101][6];
    char ans[101][101];
    int counter{}, numberOfProblemsSolved{}, totalTime{};
    while( 1 )
    {
        cin >> time[counter];
        if( time[counter] == -1 )
            break;
        cin >> ques[counter];
        cin >> ans[counter];
        if( ans[counter][0] ==  'r' )
        {
            numberOfProblemsSolved++;
            totalTime += time[counter];
            for( int i = 0; i < counter; i++ )
            {
                if( ques[counter][0] == ques[i][0] )
                {
                    if( ans[i][0] == 'r' )
                    {
                        numberOfProblemsSolved--;
                        totalTime -= time[counter];
                    }
                    else
                        totalTime += 20;
                }
            }
        }
        counter++;
    }

    cout << numberOfProblemsSolved << ' ' << totalTime;
    return 0;
}
