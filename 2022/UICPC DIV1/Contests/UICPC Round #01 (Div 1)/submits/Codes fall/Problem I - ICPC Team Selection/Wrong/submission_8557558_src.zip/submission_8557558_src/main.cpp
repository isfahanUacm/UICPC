#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
    int m, N, sum;
    cin >> m;
    for( int i = 0; i < m; i++ )
    {
        cin >> N;
        sum = 0;
        int* team = new int[3*N];
        for( int j = 0; j < 3*N; j++ )
            cin >> team[j];
        sort( team, team + 3*N );
        for( int j = 1; j < 3*N; j += 3 )
            sum += team[j];
        cout << sum;
        delete []team;
    }
    return 0;
}
