#include <iostream>
using namespace std;



int compare(const void* a, const void* b)
{
	const int* x = (int*) a;
	const int* y = (int*) b;

	if (*x > *y)
		return 1;
	else if (*x < *y)
		return -1;

	return 0;
}


int main()
{
    int t, n, x, sum = 0, z;
    
    cin >> t;
    int arr[300];
    
    
    for (int i = 0; i < t; i++)
    {
        cin >> n;
        x = 3*n;
        sum = 0;
        for (int j = 0; j < x; j++)
            cin >> arr[j];
        qsort(arr, x, sizeof(int), compare);
        
        for (int k = 0; k < n; k++)
        {
            z = (x-2) - (2*k);
            sum += arr[z];
        }
        
        cout << sum << endl;
        
    }

    return 0;
}