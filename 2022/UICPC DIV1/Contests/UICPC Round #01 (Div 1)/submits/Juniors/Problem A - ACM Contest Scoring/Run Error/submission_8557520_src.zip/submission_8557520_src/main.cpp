#include<iostream>
using namespace std;
class team
{
public:

    int minute ;
    string problem ;
    string rrow ;
};
int main(){
 team array[1000] ;

 for(int o=0 ;o<100 ;o++ ){
 cin>>array[o].minute ;
 if(array[o].minute==-1){break ;}
 cin>>array[o].problem ;
 cin>>array[o].rrow ;
 }
 int i= 0 , problem_solved=0  , tot_minute=0 ;
 while (array[i].minute!=-1) {
    if(array[i].rrow=="right"){problem_solved++ ; tot_minute=tot_minute+array[i].minute ;
        int j=0 ;
        while (j<i) {
            if(array[j].problem==array[i].problem){
                tot_minute=tot_minute+20 ;
            }j++;
        }
    }


 i++ ;}
cout<<problem_solved<<" "<<tot_minute ;

}
