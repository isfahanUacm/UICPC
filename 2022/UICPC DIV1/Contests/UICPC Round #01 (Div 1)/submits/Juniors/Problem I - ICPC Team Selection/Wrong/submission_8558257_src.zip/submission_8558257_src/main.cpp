#include<iostream>
#include<cmath>
using namespace std;
int main(){
    int tot  ;double sum =0 , sumf=0 ;int n;
    cin>>tot ;
    for(int i=0 ; i<tot ; i++){
        int  n2 , student_score;
        cin>>n ;
        n2=n*3 ;
        for(int o=0 ;o<n;o++){sum = 0;
        for(int j=0 ;j<3 ;j++){

           cin>>student_score ;
           sum+=student_score ;
        }sum=sum/3 ; sumf=sumf+sum ;
    }
    cout<<round(sumf)<<endl ;
    }

    return 0;
}
