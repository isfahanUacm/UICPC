import java.util.Arrays;
import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n =sc.nextInt() , h=sc.nextInt();
        int[] arr = new int[n];
        int[] brr = new int[h];
        for (int i = 0; i < n; i++) arr[i] = sc.nextInt();
        for (int i = 1; i <= h; i++) {
            for (int j = 1; j <= n ; j++) {
                if (j % 2 == 1 && arr[j-1] >= i) brr[i-1] += 1;
                else if (j % 2 == 0 && h-arr[j-1] < i) brr[i-1] += 1;
            }
        }
        int count = 0;
        Arrays.sort(brr);
        int ans = brr[0];
        for (int i = 0; i < h; i++) {
            if (brr[i] == ans) count++;
            else break;
        }
        System.out.println(ans + " " + count);
    }
}