import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n =sc.nextInt() , h=sc.nextInt() , m;
        int[] brr = new int[h];
        for (int i = 0; i < n; i++) {
            m = sc.nextInt();
            if (i % 2 == 1) {
                for (int j = 0; j < m; j++) {
                    brr[j]++;
                }
            }
            else {
                for (int j = h; j > h-m; j--) {
                    brr[j-1]++;
                }
            }
        }
        int count = 0;
        int ans = brr[0];
        for (int i = 0; i < h; i++) {
            if (ans > brr[i]) {
                ans = brr[i];
                count = 1;
            }
            else if (ans == brr[i]) count++;
        }
        System.out.println(ans + " " + count);
    }
}