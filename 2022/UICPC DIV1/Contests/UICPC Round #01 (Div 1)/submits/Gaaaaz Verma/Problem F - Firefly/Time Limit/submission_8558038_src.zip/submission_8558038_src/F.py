n,h = map(int,input().split())
l = []
le = [0] * h
for i in range(n):
    l.append(int(input()))
for i in range(0,n,2):
    for j in range(l[i]):
        le[j] += 1
for i in range(1,n,2):
    for j in range(h-1,h-l[i]-1,-1):
        le[j] += 1
min = le[0]
ind = 0
for i in le:
    if i < min:
        min = i

for i in le:
    if min == i:
        ind += 1



print(min,ind)