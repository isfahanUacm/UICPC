#include <iostream>
using namespace std;

int main()
{
    int n , h;
    cin>>n>>h;
    int arr[n];
    int brr[h];
    for (int i = 0; i < n; i++) cin>>arr[i];
    for (int i = 0; i < h; i++) brr[i] = 0;
    for (int i = 1; i <= n; i++) {
        if (i % 2 == 1) {
            for (int j = 0; j < arr[i-1]; j++) {
                brr[j]++;
            }
        }
        else {
            for (int j = h; j > h-arr[i-1]; j--) {
                brr[j-1]++;
            }
        }
    }
    int count = 0;
    int ans = brr[0];
    for (int i = 0; i < h; i++) {
        if (ans > brr[i]) {
            ans = brr[i];
            count = 1;
        }
        else if (ans == brr[i]) count++;
    }
    cout<<ans<<" "<<count;
    return 0;
}