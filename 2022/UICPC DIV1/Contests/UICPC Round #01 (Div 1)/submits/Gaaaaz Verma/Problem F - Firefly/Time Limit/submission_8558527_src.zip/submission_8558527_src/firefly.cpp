#include <iostream>
using namespace std;

int main()
{
    int n , h;
    cin>>n>>h;
    int brr[h];
    for (int i = 0; i < h; i++) brr[i] = 0;
    for (int i = 0; i < n; i++){
        int m;
        cin>>m;
        if (i % 2 == 1) {
            for (int j = 0; j < m; j++) {
                brr[j]++;
            }
        }
        else {
            for (int j = h; j > h-m; j--) {
                brr[j-1]++;
            }
        }
    }
    int count = 0;
    int ans = brr[0];
    for (int i = 0; i < h; i++) {
        if (ans > brr[i]) {
            ans = brr[i];
            count = 1;
        }
        else if (ans == brr[i]) count++;
    }
    cout<<ans<<" "<<count;
    return 0;
}