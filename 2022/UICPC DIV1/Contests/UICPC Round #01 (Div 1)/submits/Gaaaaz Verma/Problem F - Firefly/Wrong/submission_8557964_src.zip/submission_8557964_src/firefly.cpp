#include <iostream>
#include "algorithm"
using namespace std;

int main()
{
    int n , h;
    cin>>n>>h;
    int arr[n];
    int brr[h];
    for (int i = 0; i < n; i++) cin>>arr[i];
    for (int i = 1; i <= h; i++) {
        for (int j = 1; j <= n ; j++) {
            if (j % 2 == 1 && arr[j-1] >= i) brr[i-1] += 1;
            else if (j % 2 == 0 && h-arr[j-1] < i) brr[i-1] += 1;
        }
    }
    int count = 0;
    int f = sizeof(arr) / sizeof(arr[0]);
    sort(arr, arr + f);
    int ans = brr[0];
    for (int i = 0; i < h; i++) {
        if (brr[i] == ans) count++;
        else break;
    }
    cout<<ans<<" "<<count;
    return 0;
}