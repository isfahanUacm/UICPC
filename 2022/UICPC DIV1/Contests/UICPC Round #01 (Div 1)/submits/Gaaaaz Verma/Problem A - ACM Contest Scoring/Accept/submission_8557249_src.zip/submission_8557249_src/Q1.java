import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

public class Q1 {
    public static void main(String[] args) {
        Scanner sin = new Scanner(System.in);
        ArrayList<Integer> min = new ArrayList<>();
        ArrayList<String> qs = new ArrayList<>();
        ArrayList<String> checks = new ArrayList<>();
        ArrayList<Integer> rights = new ArrayList<>();
        int k = 0;
        int time = 0;
        int solved = 0;
        while(true){
            int n = sin.nextInt();
            if(n ==-1)
                break;
            else{
                String q = sin.next();
                String check = sin.next();
                min.add(n);
                qs.add(q);
                checks.add(check);
                if(check.equals("right"))
                    rights.add(k);
                
            }
            k++;
        }
        solved = rights.size();
        for (int i = 0; i < rights.size(); i++) {
            String te = qs.get(rights.get(i));
            time += min.get(rights.get(i));
            for (int j = 0; j < rights.get(i); j++) {
                if(qs.get(j).equals(te)){
                    time += 20;
                }
            }
        }
        System.out.println(solved + " " + time);

    }
}
