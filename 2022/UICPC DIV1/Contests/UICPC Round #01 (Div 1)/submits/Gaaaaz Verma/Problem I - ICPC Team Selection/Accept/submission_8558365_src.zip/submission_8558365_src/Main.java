import java.util.Arrays;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int n = sc.nextInt();
            int[] brr = new int[3*n];
            for (int j = 0; j < 3*n; j++) brr[j] = sc.nextInt();
            Arrays.sort(brr);
            int sum = 0 , count = 0;
            for (int j = brr.length-2; j > 0; j-=2) {
                sum += brr[j];
                count++;
                if (count == n) break;
            }
            System.out.println(sum);
        }
    }
}