//package main;

import java.util.*;


class Main {
    public static int middleOfThree(int a, int b, int c) {
        int x = a - b;
        int y = b - c;
        int z = a - c;
        if (x * y > 0)
            return b;
        else if (x * z > 0)
            return c;
        else
            return a;
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int z, sum;
        for (int i = 0; i < n; i++) {
            z = sc.nextInt();
            sum = 0;
            for (int j = 0; j < z; j++)
                sum += middleOfThree(sc.nextInt(), sc.nextInt(), sc.nextInt());
            System.out.println(sum);
        }
    }
}




