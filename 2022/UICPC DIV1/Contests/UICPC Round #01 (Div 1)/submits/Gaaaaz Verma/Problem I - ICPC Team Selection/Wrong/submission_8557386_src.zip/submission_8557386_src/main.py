t = int(input())
for ww in range(t):
    n = int(input())
    l = list(map(int,input().split()))
    l.sort()
    k = 0
    for i in range(n,2*n):
        k += l[i]
    print(k)
