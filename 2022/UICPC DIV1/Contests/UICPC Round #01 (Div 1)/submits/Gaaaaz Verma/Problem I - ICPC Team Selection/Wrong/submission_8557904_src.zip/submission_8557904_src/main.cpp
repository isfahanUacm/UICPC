
#include <bits/stdc++.h>
using namespace std;

int middleOfThree(int a, int b, int c)
{
    int x = a - b;

    int y = b - c;
    int z = a - c;
    if (x * y > 0)
        return b;
    else if (x * z > 0)
        return c;
    else
        return a;
}

// Driver Code
int main()
{
    int n , z, sum,a=0,b=0,c=0;
    cin>>n;

           for (int i = 0; i < n; i++) {
               cin>>z;
               sum = 0;
               for (int j = 0; j < z; j++) {
                   cin>>a;
                   cin>>b;
                   cin>>c;
                   sum += middleOfThree(a, b, c);
               }
               cout <<(sum);
           }

    return 0;
}
