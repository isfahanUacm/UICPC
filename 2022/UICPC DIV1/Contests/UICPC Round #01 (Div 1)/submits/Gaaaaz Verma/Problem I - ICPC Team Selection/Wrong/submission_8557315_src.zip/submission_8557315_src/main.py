t = int(input())
n = int(input())
l = list(map(int,input().split()))
l.sort()
k = 0
for i in range(1,len(l),3):
    k += l[i]
print(k)
