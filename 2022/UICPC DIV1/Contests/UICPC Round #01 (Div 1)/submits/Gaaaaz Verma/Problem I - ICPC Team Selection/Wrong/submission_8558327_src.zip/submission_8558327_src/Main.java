import java.util.Arrays;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int n = sc.nextInt();
            int[] brr = new int[3*n];
            for (int j = 0; j < 3*n; j++) brr[j] = sc.nextInt();
            Arrays.sort(brr);
            int[][] arr = new int[n][3];
            for (int j = 0; j < n; j++) {
                arr[j][0] = brr[j];
                arr[j][2] = brr[3*n-j-1];
                arr[j][1] = brr[n+j];
            }
            int sum = 0;
            for (int j = 0; j < n; j++) {
                sum += arr[j][1];
            }
            System.out.println(sum);
        }
    }
}