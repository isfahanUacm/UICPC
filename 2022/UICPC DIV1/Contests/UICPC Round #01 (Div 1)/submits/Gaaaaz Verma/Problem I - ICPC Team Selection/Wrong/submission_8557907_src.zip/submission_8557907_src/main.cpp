
#include <bits/stdc++.h>
using namespace std;


int middleOfThree(int a, int b, int c)
{
    if (a > b)
    {
        if (b > c)
            return b;
        else if (a > c)
            return c;
        else
            return a;
    }
    else
    {

        if (a > c)
            return a;
        else if (b > c)
            return c;
        else
            return b;
    }
}



int main()
{
    int n , z, sum,a=0,b=0,c=0;
    cin>>n;

           for (int i = 0; i < n; i++) {
               cin>>z;
               sum = 0;
               for (int j = 0; j < z; j++) {
                   cin>>a;
                   cin>>b;
                   cin>>c;
                   sum += middleOfThree(a, b, c);
               }
               cout <<(sum);
           }

    return 0;
}
