import java.util.Arrays;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int[] arr = new int[sc.nextInt()];
            int sum = 0;
            for (int j = 0; j < arr.length; j++) arr[i] = sc.nextInt();
            Arrays.sort(arr);
            for (int j = 1; j < arr.length; j+=3) {
                sum+=arr[j];
            }
            System.out.println(sum);
        }
    }
}