#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int number;
    while (cin>>number) {
        double digits = 1;
        if (number>1) {
            for (int i=2; i<=number; i++)
                digits += log10(i);
        }
        cout<<(int)floor(digits)<<endl;
    }
    return 0;
}