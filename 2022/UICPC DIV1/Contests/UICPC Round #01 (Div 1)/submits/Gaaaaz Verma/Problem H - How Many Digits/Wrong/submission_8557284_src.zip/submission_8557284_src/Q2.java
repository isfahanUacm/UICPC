import java.util.Scanner;
public class Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextInt()) {
            int digits = 1;
            int number = sc.nextInt();
            if (number>=3) {
                for (int i=2; i<=number; i++)
                    digits += Math.log10(i);
            }
            System.out.println((int) Math.floor(digits));
        }

    }
}