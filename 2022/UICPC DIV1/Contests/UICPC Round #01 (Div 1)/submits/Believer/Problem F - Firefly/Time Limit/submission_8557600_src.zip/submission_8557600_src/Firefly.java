import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Firefly {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int h = in.nextInt();
        List<Integer> len = new ArrayList<>();

        for (int i = 0; i <= n-1; i++)
            len.add(in.nextInt());

        int minH = 0, minCrash = -1;

        for (int i = 1; i <= h; i++) {
            int crashTime = 0;
            int j = 1;
            for (Integer ln : len) {
                if (j % 2 != 0) {
                    if (ln >= i)
                        crashTime++;
                } else {
                    if ((h - ln) < i)
                        crashTime++;
                }
                j++;
            }
            if (i == 1 || minCrash > crashTime) {
                minH = 1;
                minCrash = crashTime;
            } else if (minCrash == crashTime) minH++;
        }

        System.out.println("\n" + minCrash + " " + minH);

    }

}
