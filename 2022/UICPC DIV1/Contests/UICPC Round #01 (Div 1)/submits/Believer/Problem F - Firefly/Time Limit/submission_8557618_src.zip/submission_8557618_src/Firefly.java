import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Firefly {
    static int j = 1;

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int h = in.nextInt();
        List<Integer> len = new ArrayList<>();

        for (int i = 0; i <= n - 1; i++)
            len.add(in.nextInt());

        int minH = 0, minCrash = -1;

        for (int i = 1; i <= h; i++) {
            int finalI = i;
            int crashTime = len.stream().filter(integer -> {
                j++;
                return j % 2 != 0 ? integer >= finalI : (h - integer) < finalI;
            }).toArray().length;

            if (i == 1 || minCrash > crashTime) {
                minH = 1;
                minCrash = crashTime;
            } else if (minCrash == crashTime) minH++;
        }

        System.out.println("\n" + minCrash + " " + minH);

    }

}
