import java.util.*;
import java.util.stream.Collectors;

class model {
    int time;
    String test;
    Boolean ans;

    public model(int time, String test, Boolean ans) {
        this.time = time;
        this.test = test;
        this.ans = ans;
    }
}

public class prog {
    static int totalScore = 0;
   static int rghitAns = 0;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        List<model> model = new ArrayList<>();
        List<String> tests = new ArrayList<>();

        while (true) {
            int t = in.nextInt();
            if (t == -1)
                break;
            String s = in.next();
            Boolean ans = Objects.equals(in.next(), "right");
            model.add(new model(t, s, ans));
            tests.add(s);
        }

        Set<String> set = new HashSet<>(tests);
        tests.clear();
        tests.addAll(set);


        tests.forEach(s -> {
            List<model> h = model.stream().filter(model1 -> Objects.equals(model1.test, s)).collect(Collectors.toList());
            int testScore = 0;
            boolean isComplete = false;
            for (model model1 : h) {
                if (model1.ans) {
                    testScore += model1.time;
                    isComplete = true;
                    rghitAns++;
                    break;
                }else testScore += 20;
            }
            if (isComplete) totalScore += testScore;
        });
        System.out.println(rghitAns + " " + totalScore);
    }
}
