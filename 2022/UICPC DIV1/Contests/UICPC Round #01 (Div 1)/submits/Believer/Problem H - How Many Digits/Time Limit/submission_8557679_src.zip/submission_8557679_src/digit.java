import java.util.Scanner;

public class digit {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        cal(in.nextInt());
        while (in.hasNext())
            cal(in.nextInt());
    }

    static void cal(int n) {
        if (n < 0) {
            System.out.println(0);
            return;
        }

        if (n <= 1) {
            System.out.println(1);
            return;
        }

        double digits = 0;
        for (int i = 2; i <= n; i++)
            digits += Math.log10(i);

        System.out.println((int) (Math.floor(digits)) + 1);
    }

}
