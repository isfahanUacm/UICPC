import java.util.Scanner;

public class digit {
    public static double M_E = 2.71828182845904523536;
    public static double M_PI = 3.141592654;
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        cal(in.nextInt());
        while (in.hasNext())
            cal(in.nextInt());
    }

    static void cal(int n) {
        if (n < 0) {
            System.out.println(0);
            return;
        }

        if (n <= 1) {
            System.out.println(1);
            return;
        }

        int x = (int) (n * Math.log10(n / M_E) +
                        Math.log10(2 * M_PI * n) /
                                2.0);


        System.out.println((int) (Math.floor(x)) + 1);
    }

}
