import java.util.Scanner;

public class digit {
    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);
        int n = in.nextInt();

        if (n < 0)
            System.out.println(0);

        if (n <= 1)
            System.out.println(1);

        double digits = 0;
        for (int i=2; i<=n; i++)
            digits += Math.log10(i);

        System.out.println((int)(Math.floor(digits)) + 1);
    }
}
