import java.util.Scanner;

public class ICPC {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        for (int i = 0; i < n; i++) {
            int N = in.nextInt();
            int score = 0;
            for (int j = 0; j < N; j++) {
                int a = in.nextInt();
                int b = in.nextInt();
                int c = in.nextInt();
                score += median(a, b, c);
            }
            System.out.println(score);
        }

    }

    static int median(int a, int b, int c) {
        int x = a - b;
        int y = b - c;
        int z = a - c;
        if (x * y > 0)
            return b;
        else if (x * z > 0)
            return c;
        else
            return a;
    }
}
