import java.util.Scanner;

public class ICPC {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        for (int i = 0; i < n; i++) {
            int N = in.nextInt();
            int score = 0;
            for (int j = 0; j < N; j++) {
                int a = in.nextInt();
                int b = in.nextInt();
                int c = in.nextInt();
                score += median(a, b, c);
            }
            System.out.println(score);
        }

    }

    static int median(int a, int b, int c) {
        return (a > b) ^ (a > c) ? a : (a > b) ^ (b > c) ? c : b;
    }
}
