import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ICPC {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        for (int i = 0; i < n; i++) {
            int N = in.nextInt();
            int score;
            int[] sco = {0, 0, 0};
            for (int j = 0; j < N; j++) {
                sco[0] += in.nextInt();
                sco[1] += in.nextInt();
                sco[2] += in.nextInt();
            }
            score = Arrays.stream(sco).sorted().toArray()[1];
            System.out.println(score);
        }

    }

}
