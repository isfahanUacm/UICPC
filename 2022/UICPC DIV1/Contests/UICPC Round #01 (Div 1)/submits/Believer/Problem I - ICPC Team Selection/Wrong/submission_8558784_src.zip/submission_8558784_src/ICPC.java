import java.util.*;
import java.util.stream.Collectors;

public class ICPC {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        int score = 0;
        for (int i = 0; i < n; i++) {
            int N = in.nextInt();
            score = 0;
            List<Integer> sco = new ArrayList<>();
            for (int j = 0; j < N * 3; j++) {
                sco.add(in.nextInt());
            }
            Collections.sort(sco);
            for (int j = 0; j < N * 2; j++)
                if (j % 2 == 1)
                    score += sco.get(j);
            System.out.println(score);

        }
    }

}
