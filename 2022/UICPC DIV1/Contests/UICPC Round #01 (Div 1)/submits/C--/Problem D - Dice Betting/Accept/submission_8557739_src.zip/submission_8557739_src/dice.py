n,s,k = map(int,input().split())
d = [[0 for xx in range(s+1)] for x in range(n+1)]
d[0][0] = 1

for i in range(1,n+1):
    for j in range(1,s+1):
        pn = (s-(j-1)) / s
        po = (j) / s
        wn = pn * d[i-1][j-1]
        wo = po * d[i-1][j]
        d[i][j] = wn + wo

p = 0
for i in range(k,s+1):
    p += d[n][i]
print(p)