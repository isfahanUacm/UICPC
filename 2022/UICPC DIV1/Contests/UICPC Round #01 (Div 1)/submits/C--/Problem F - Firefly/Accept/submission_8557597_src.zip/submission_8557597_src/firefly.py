n,m = map(int,input().split())
ll = [0 for x in range(m)]
lr = [0 for x in range(m)]

for i in range(n):
    t = int(input())
    if i%2 == 0:
        lr[t-1] += 1
    else:
        ll[m-t] += 1

summ = 0
for i in reversed(range(m)):
    summ += lr[i]
    lr[i] = summ


summ = 0
for i in range(m):
    summ += ll[i]
    ll[i] = summ

best = 99999999999999
count = 0
for i in range(m):
    if ll[i]+lr[i] < best:
        best = ll[i] + lr[i]
        count = 0
    if ll[i]+lr[i] == best:
        count += 1
    
print(best,count)
