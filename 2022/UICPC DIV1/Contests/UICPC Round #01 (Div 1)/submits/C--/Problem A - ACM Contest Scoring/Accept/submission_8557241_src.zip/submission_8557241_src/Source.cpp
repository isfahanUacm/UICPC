#include <iostream>
#include <map>

using namespace std;

int main()
{
	map <char, int> problems;
	int min, score = 0, solved = 0;
	string w_r;
	char p;
	cin >> min;
	while (min != -1) {
		cin >> p;
		cin >> w_r;
		if (w_r == "wrong") {
			if (problems[p] <= 0)
				problems[p] -= 20;
		}
		if (w_r == "right") {
			if (problems[p] <= 0) {
				problems[p] = -problems[p] + min;
				solved++;
				score += problems[p];
			}
		}
		cin >> min;
	}
	cout << solved << " " << score;
	return 0;
}