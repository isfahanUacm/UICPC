#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int counter(vector<int>& books, int& k)
{
	/*int i;
	for (i = books.size() - 2; i >= 0; i--) {
		if (books[i + 1] > books[i]) {
			int temp = books[i];
			books.erase(books.begin() + i);
			books.push_back(temp);
			k++;
			break;
		}
	}
	if (i == -1)
		return k;
	return counter(books, k);*/
	int i;
	for (i = books.size() - 2; i >= 0; i--) {
		if (books[i + 1] > books[i]) {
			int temp = books[i];
			books.erase(books.begin() + i);
			books.push_back(temp);
			k++;
			i = books.size() - 1;
		}
	}
	return k;
}

int main()
{
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		vector<int> s_book;
		for (int i = 0; i < n; i++) {
			int temp;
			cin >> temp;
			s_book.push_back(temp);
		}
		reverse(s_book.begin(), s_book.end());
		int k = 0;
		cout << counter(s_book, k) << endl;
	}
	return 0;
}