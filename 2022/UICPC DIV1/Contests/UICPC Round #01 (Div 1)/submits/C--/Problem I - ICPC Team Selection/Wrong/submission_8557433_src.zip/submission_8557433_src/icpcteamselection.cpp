#include <iostream>

using namespace std;

int f(int a,int b ,int c)
{
    if(a>b && a>c)
    {
        if(b>c)
            return b;
        else
            return c;
    }
    else if(b>c && b>a)
    {
        if(c>a)
            return c;
        else
            return a;
    }
    else if(a>b)
        return a;
    else
        return b;

}

int main()
{
    int number_dataSet , n ;
    cin>>number_dataSet>>n;
    int arr[2*n];
    for(int i = 0 ; i < 3*n ; ++i)
        cin>>arr[i];
    int sum = 0;
    for(int i = 0 ; i < 3*n ; ++i)
    {
     if( (i +1) % 3 == 0)
         sum +=f(arr[i-2],arr[i-1],arr[i]);
    }
    cout<<sum<<endl;
        return 0;
}
