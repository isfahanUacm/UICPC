#include <iostream>
#include<vector>
using namespace std;

int f(int a,int b ,int c)
{
    if(a>b && a>c)
    {
        if(b>c)
            return b;
        else
            return c;
    }
    else if(b>c && b>a)
    {
        if(c>a)
            return c;
        else
            return a;
    }
    else if(a>b)
        return a;
    else
        return b;

}

int main()
{
    int number_dataSet , n ;
    cin>>number_dataSet;
    vector<int>result;
    while (number_dataSet != 0) {

        cin>>n;
        int arr[2*n];
        for(int i = 0 ; i < 3*n ; ++i)
            cin>>arr[i];
        int sum = 0;
        for(int i = 0 ; i < 3*n ; ++i)
        {
         if( (i +1) % 3 == 0)
             sum +=f(arr[i-2],arr[i-1],arr[i]);
        }
        result.push_back(sum);


        number_dataSet--;
    }
    
    for(int i =0 ; i < int(result.size());++i )
        cout<<result[i]<<"";
        return 0;
}
