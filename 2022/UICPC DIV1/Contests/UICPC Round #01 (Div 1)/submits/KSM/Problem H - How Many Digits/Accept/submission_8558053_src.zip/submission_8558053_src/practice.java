
import java.util.Scanner;

public class practice {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        while (sc.hasNextInt()){
            System.out.println(findDigits(sc.nextInt()));
        }
    }
    static long findDigits(int n)
    {
          double M_E = 2.71828182845904523536;
          double M_PI = 3.141592654;

        if (n < 0)
            return 0;
        if (n <= 1)
            return 1;
        double x = (n * Math.log10(n / M_E) +
                Math.log10(2 * M_PI * n) / 2.0);

        return (long)Math.floor(x) + 1;
    }
}
