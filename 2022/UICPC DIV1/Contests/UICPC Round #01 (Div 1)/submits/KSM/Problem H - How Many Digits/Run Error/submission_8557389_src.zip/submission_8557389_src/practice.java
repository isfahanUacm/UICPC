import java.util.Scanner;

public class practice {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        while (sc.hasNextLine()){
            int num=sc.nextInt();
            System.out.println(count_digits(num));
        }
    }
    public static int count_digits(int num){
        if (num < 0){
            return 0;
        }
        if (num <= 1){
            return 1;
        }
        double d = 0;
        for (int i=2; i<=num; i++){
            d += Math.log10(i);
        }
        return (int) (Math.floor(d)+ 1);
    }
}
