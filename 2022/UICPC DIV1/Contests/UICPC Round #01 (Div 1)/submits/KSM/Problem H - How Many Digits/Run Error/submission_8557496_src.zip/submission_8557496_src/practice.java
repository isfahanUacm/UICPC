import java.util.ArrayList;
import java.util.Scanner;

public class practice {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        ArrayList<Double>arrayList=new ArrayList<>();
        for (int i=2; i<=100; i++){
            arrayList.add(Math.log10(i));
        }
        while (sc.hasNextLine()){
            int num=sc.nextInt();
            System.out.println(count_digits(num,arrayList));
        }
    }
    public static int count_digits(int num,ArrayList<Double>arrayList){
        if (num < 0){
            return 0;
        }
        if (num <= 1){
            return 1;
        }
        double d = 0;
        for (int i=2; i<=num; i++){
            d += arrayList.get(i-2);
        }
        return (int) (Math.floor(d)+ 1);
    }
}
