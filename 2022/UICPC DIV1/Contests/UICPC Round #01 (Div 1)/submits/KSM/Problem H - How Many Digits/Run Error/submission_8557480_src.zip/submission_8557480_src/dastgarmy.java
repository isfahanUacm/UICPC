import java.util.*;

public class dastgarmy {
    public static void main(String[] args)
        {

            Scanner sc = new Scanner(System.in);
            int a ;
            double[] w = new double[100000];
            double l10 = Math.log(10);
            w[2] = Math.log(2) / l10;
            int j = 2;
            while (sc.hasNext()) {
                a = sc.nextInt();
                if (a == 1 | a == 0) {
                    System.out.println("1");
                    continue;
                }
                double sum = 0;
                for (int i = 2; i <= j; i++) {
                    sum += w[i] / l10;
                }
                for (int i = j + 1; i <= a; i++) {
                    w[i] = Math.log(i);
                    sum += w[i] / l10;
                    j++;
                }
                sum = Math.ceil(sum);
                System.out.println((int) sum);
            }
        }

    }

