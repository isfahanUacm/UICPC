import java.util.*;

public class dastgarmy {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        double[] arr = new double[1000000];
        for (int i = 2; i <= 1000000; i++) {
            arr[i] = Math.log(i);
        }
        int a;
        while (sc.hasNext()) {
            a = sc.nextInt();
            if (a == 1 | a == 0) {
                System.out.println("1");
                continue;
            }
            double sum = 0;
            for (int i = 2; i <= a; i++) {
                sum += arr[i] / arr[10];
            }
            sum = Math.ceil(sum);
            System.out.println((int) sum);
        }
    }
}

