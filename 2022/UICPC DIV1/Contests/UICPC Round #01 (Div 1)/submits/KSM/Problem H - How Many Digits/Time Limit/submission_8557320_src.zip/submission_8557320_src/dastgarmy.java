import java.util.*;

public class dastgarmy {
    public static void main(String[] args)
        {

            Scanner sc = new Scanner(System.in);
            int a ;
            while (sc.hasNext()) {
                a = sc.nextInt();
                if (a == 1 | a == 0) {
                    System.out.println("1");
                    continue;
                }
                double sum = 0;
                for (int i = 2; i <= a; i++) {
                    sum += (double)Math.log(i) / (double) Math.log(10);
                }
                sum = Math.ceil(sum);
                System.out.println((int) sum);
            }
        }
    }

