import java.util.*;

public class dastgarmy {
    public static void main(String[] args)
        {

            Scanner sc = new Scanner(System.in);
            String a = sc.nextLine();
            boolean[] result = new boolean[24];
            int r2[] = new int[24];
            while (!a.equals("-1")) {
                String[] b;
                b = a.split(" ");
                if (b[2].equals("right")) {
                    result[(int)b[1].charAt(0) - 65] = true;
                    r2[(int)b[1].charAt(0) - 65] += Integer.parseInt(b[0]);
                }
                else {
                    r2[(int)b[1].charAt(0) - 65] += 20;
                }
                a = sc.nextLine();
            }
            int count = 0, ct = 0;
            for (int i = 0; i < 24; i++) {
                if (result[i]) {
                    count++;
                    ct += r2[i];
                }
            }
            System.out.println(count + " " + ct);
        }
    }

