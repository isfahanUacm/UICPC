
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class practice {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int w = 0 ;  w < n; w++)
        {
            int a = sc.nextInt();
            ArrayList<Integer> b = new ArrayList<>();
            for (int i = 0 ; i< a;i++){
                b.add(sc.nextInt());
            }
            System.out.println(sort(b));
        }
    }
    static int sort(ArrayList<Integer> b) {
        int t = b.get(0);
        int count = 0;
        for (int i = 1;i<b.size();i++) {
            if (b.get(i)>=t) {
                t = b.get(i);
            }else{
                b.add(0, b.remove(i));
                count++;
                if(!isSorted(b)){
                    t = b.get(0);
                    i=0;
                }else break;
            }
        }
        return count;
    }
    public static boolean isSorted(ArrayList<Integer> a)
    {
        if (a == null || a.size() <= 1) {
            return true;
        }
        for (int i = 0; i < a.size() - 1; i++)
        {
            if (a.get(i) > a.get(i+1)) {
                return false;
            }
        }
        return true;
    }
}
