import java.util.*;

public class dastgarmy {
    public static void main(String[] args)
        {

            Scanner sc = new Scanner(System.in);
            int n = sc.nextInt();
            int s;
            for (int q = 0; q < n; q++){
                int a = sc.nextInt();
                MaxHeap b = new MaxHeap(3*a);
                for (int i = 0; i < 3*a; i++)
                    b.insert(sc.nextInt());
                s = b.size;
                int sum = 0;
                for (int i = 0 ;i <= b.size / 2; i++) {
                    if ((i + 1) % 2 == 0) {
                        sum += deleteRoot(b.Heap, s);
                        s--;
                    }
                    else
                        deleteRoot(b.Heap, s);
                }
                System.out.println(sum);
            }
        }



    static void heapify(int arr[], int n, int i)
    {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && arr[l] > arr[largest])
            largest = l;

        // If right child is larger than largest so far
        if (r < n && arr[r] > arr[largest])
            largest = r;

        // If largest is not root
        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }

    // Function to delete the root from Heap
    static int deleteRoot(int arr[], int n)
    {
        // Get the last element
        int lastElement = arr[n - 1];
        int t = arr[0];
        // Replace root with first element
        arr[0] = lastElement;

        // Decrease size of heap by 1
        n = n - 1;

        // heapify the root node
        heapify(arr, n, 0);

        // return new size of Heap
        return t;
    }

    /* A utility function to print array of size N */
    static void printArray(int arr[], int n)
    {
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");

        System.out.println();
    }
}

class MaxHeap {
    public int[] Heap;
    public int size;
    private int maxsize;

    // Constructor to initialize an
    // empty max heap with given maximum
    // capacity
    public MaxHeap(int maxsize) {
        // This keyword refers to current instance itself
        this.maxsize = maxsize;
        this.size = 0;
        Heap = new int[this.maxsize];
    }

    // Method 1
    // Returning position of parent
    private int parent(int pos) {
        return (pos - 1) / 2;
    }

    // Method 2
    // Returning left children
    private int leftChild(int pos) {
        return (2 * pos);
    }

    // Method 3
    // Returning left children
    private int rightChild(int pos) {
        return (2 * pos) + 1;
    }

    // Method 4
    // Returning true of given node is leaf
    private boolean isLeaf(int pos) {
        if (pos > (size / 2) && pos <= size) {
            return true;
        }
        return false;
    }

    // Method 5
    // Swapping nodes
    private void swap(int fpos, int spos) {
        int tmp;
        tmp = Heap[fpos];
        Heap[fpos] = Heap[spos];
        Heap[spos] = tmp;
    }

    // Method 6
    // Recursive function to max heapify given subtree
    private void maxHeapify(int pos) {
        if (isLeaf(pos))
            return;

        if (Heap[pos] < Heap[leftChild(pos)]
                || Heap[pos] < Heap[rightChild(pos)]) {

            if (Heap[leftChild(pos)]
                    > Heap[rightChild(pos)]) {
                swap(pos, leftChild(pos));
                maxHeapify(leftChild(pos));
            } else {
                swap(pos, rightChild(pos));
                maxHeapify(rightChild(pos));
            }
        }
    }

    // Method 7
    // Inserts a new element to max heap
    public void insert(int element) {
        Heap[size] = element;

        // Traverse up and fix violated property
        int current = size;
        while (Heap[current] > Heap[parent(current)]) {
            swap(current, parent(current));
            current = parent(current);
        }
        size++;
    }

    // Method 8
    // To display heap
    public void print() {

        for (int i = 0; i < size / 2; i++) {

            System.out.print("Parent Node : " + Heap[i]);

            if (leftChild(i) < size) //if the child is out of the bound of the array
                System.out.print(" Left Child Node: " + Heap[leftChild(i)]);

            if (rightChild(i) < size) //if the right child index must not be out of the index of the array
                System.out.print(" Right Child Node: " + Heap[rightChild(i)]);

            System.out.println(); //for new line

        }

    }

    // Method 9
    // Remove an element from max heap
    public int extractMax() {
        int popped = Heap[1];
        Heap[1] = Heap[size--];
        maxHeapify(1);
        return popped;
    }

}
//            Scanner sc = new Scanner(System.in);
//            int a ;
//            double[] w = new double[1000001];
//            double l10 = Math.log(10);
//            w[2] = Math.log(2) / l10;
//            int j = 2;
//            while (sc.hasNext()) {
//                a = sc.nextInt();
//                if (a == 1 | a == 0) {
//                    System.out.println("1");
//                    continue;
//                }
//                double sum = 0;
//                for (int i = 2; i <= Math.min(j, a); i++) {
//                    sum += w[i] / l10;
//                }
//                for (int i = j + 1; i <= a; i++) {
//                    w[i] = Math.log(i);
//                    sum += w[i] / l10;
//                    j++;
//                }
//                sum = Math.ceil(sum);
//                System.out.println((int) sum);
//            }