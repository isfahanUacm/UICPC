from sys import stdin

def fact(number):
    if number <= 1:
        return 1
    
    answer = 1

    for i in range(1,number+1):
        answer *= i

    return answer

for line in stdin:
    print(len(str(fact(int(line)))))