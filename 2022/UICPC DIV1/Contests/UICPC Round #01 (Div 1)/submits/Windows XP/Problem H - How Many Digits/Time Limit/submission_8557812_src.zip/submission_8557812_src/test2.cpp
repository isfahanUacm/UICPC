#include <bits/stdc++.h>

using namespace std;

int fact_digits(int number)
{
    if (number <= 1)
    {
        return 1;
    }

    double digits = 0;

    for(int i = 2; i <= number; i++)
    {
        digits += log10(i);
    }

    int answer = floor(digits) + 1;
    return answer;
}

int main()
{
    int number;

    while (cin >> number)
    {
        cout << fact_digits(number) << endl;
    }

    return 0;
}