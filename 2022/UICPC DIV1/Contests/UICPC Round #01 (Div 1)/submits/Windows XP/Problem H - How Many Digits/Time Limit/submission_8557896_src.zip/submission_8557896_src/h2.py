from sys import stdin
from math import factorial

for line in stdin:
    print(len(str(factorial(int(line)))))