#include <iostream>
#include <list> 

using namespace std;

class line
{
    public:
    int time;
    string q;
    string rw;

    line()
    {

    }

    line(int time, string q, string rw)
    {
        this->time = time;
        this->q = q;
        this->rw = rw;
    }
};

int main()
{
    list<line> l;

    string temp, temp2;
    int time;
    string q, rw;

    getline(cin, temp);

    while(temp != "-1")
    {
        int i = 0;
        temp2 = "";
        for(i; temp[i] != ' '; i++)
        {
            temp2 += temp[i];
        }

        time = stoi(temp2);

        temp2 = "";

        i++;

        for(i; temp[i] != ' '; i++)
        {
            temp2 += temp[i];
        }

        q = temp2;

        temp2 = "";

        i++;

        for(i; temp[i]; i++)
        {
            temp2 += temp[i];
        }

        rw = temp2;

        line *newline = new line(time, q, rw);

        l.push_back(*newline);

        getline(cin, temp);
    }

    list<line>::iterator itr = l.begin();

    int rights = 0;
    int total_time = 0;

    for(itr; itr != l.end(); itr++)
    {
        if (itr->rw == "right")
        {
            rights++;
            list<line>::iterator itr2 = l.begin();

            int attemps = 0;

            for(itr2; itr2->q != itr->q || itr2->rw == "wrong"; itr2++)
            {
                if(itr2->q == itr->q)
                {
                    attemps++;
                }
            }

            total_time += itr->time + attemps*20;
        }
        
    }

    cout << rights << " " << total_time;

    return 0;
}