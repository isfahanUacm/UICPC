#include <vector>
#include <iostream>
#include <algorithm>

int main() {

	int count;
	std::cin >> count;

	while (count) {

		int teams;
		std::cin >> teams;

		std::vector<int> parv(teams*3);

		for (int& par : parv) {
			std::cin >> par;
		}

		std::sort(parv.rbegin(), parv.rend());

		int sum = 0;

		for (int i = 0; i < teams; i++) {

			sum += parv[i*2 + 1];
		}

		std::cout << sum << std::endl;

		--count;
	}
}