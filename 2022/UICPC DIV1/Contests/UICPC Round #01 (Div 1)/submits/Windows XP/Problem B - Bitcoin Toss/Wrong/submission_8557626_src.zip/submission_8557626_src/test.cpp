#include <iostream>
#include <string>
#include <list>
#include <math.h>
bool find(std::list<std::string>& list, std::string& s)
{
	for (std::string st : list)
	{
		if (st == s)
			return true;
	}

	return false;
}


int main()
{
	int count;
	std::cin >> count;

	while (count)
	{
		std::string s;
		std::cin >> s;

		int check = 1;
		int index = 0;
		int lastCheck = 1;
		int lastIndex = 0;

		while (true)
		{
			if ((s.length() - index) / check < int(pow(check, 2)))
				break;

			std::list<std::string> patterns;

			std::string pattern = "";

			int step = 0;
			int totalSteps = pow(2, check);

			for (int i = index; i < s.length(); ++i)
			{
				if (totalSteps == 0)
				{
					goto done;
				}

				if (step == check)
				{
					if (find(patterns, pattern))
					{
						++index;
						goto out;
					}

					patterns.push_back(pattern);
					pattern = "";
					step = 0;
					--totalSteps;
				}

				pattern += s[i];
				++step;
			}

			if (find(patterns, pattern))
			{
				++index;
				continue;
			}

			patterns.push_back(pattern);
			--totalSteps;
			if (totalSteps != 0)
			{
				++index;
				continue;
			}

		done:

			//for (std::string s : patterns)
			//{
			//	std::cout << s << std::endl;
			//}

			//std::cout << index << std::endl;
			//std::cout << "--------------" << std::endl;

			lastCheck = check;
			lastIndex = index;
			index = 0;

			++check;

		out:;
		}

		std::cout << lastCheck << " " << lastIndex << std::endl;


		--count;
	}
	

	return 0;
}