#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    cout << std::fixed;
    cout << std::setprecision(9);

    int n, s, k, temp_k;

    cin >> n >> s >> k;

    double answer = 0;

    temp_k = k;
    int j = 1;

    while (k <= s && k <= n)
    {
        double temp_ans = 1;

        for (int i = 1; i < k && i < n; i++)
        {
            temp_ans *= double(s-i) / s;
        }

        answer += temp_ans;

        k++;
    }

    cout << answer << endl;

    return 0;
}