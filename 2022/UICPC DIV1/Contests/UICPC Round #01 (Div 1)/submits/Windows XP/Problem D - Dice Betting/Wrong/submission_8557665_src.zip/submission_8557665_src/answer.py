# primary measure is the number of problems that were solved
# the secondary measure is based on a combination of time and panalties
#team's time score is equal to the sum of those submission times that resulted in right answer + 20 min * wrong

