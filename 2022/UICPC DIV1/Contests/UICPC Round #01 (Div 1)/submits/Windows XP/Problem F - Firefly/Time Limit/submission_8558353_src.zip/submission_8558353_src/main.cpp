#include <iostream>



int main () {

    int N_obstacles, H_height, *heights, result, result_count = 0;

    std :: cin >> N_obstacles >> H_height;

    result = N_obstacles + 1;

    heights = new int[N_obstacles];

    for (int i = 0; i < N_obstacles; i++)
        std :: cin >> heights[i];

    int temp_result;
    for (int i = 0; i < H_height; i++) {

        temp_result = 0;

        for (int j = 0; j < N_obstacles; j++) {

            if (j % 2 == 0) {

                if (i >= H_height - heights[j]) temp_result += 1;

            }

            else if (j % 2 == 1) {

                if (i <= heights[j] - 1) temp_result += 1;

            }

        }

        if (temp_result < result) {

            result = temp_result;
            result_count = 1;

        }

        else if (temp_result == result) result_count += 1;

    }

    std :: cout << result << ' ' << result_count;

    return 0;

}
