#include <bits/stdc++.h>

using namespace std;

int main()
{
    int x, y, temp;

    cin >> x >> y;

    int arr[y] = {0};

    for (int i = 0; i < x; i++)
    {
        cin >> temp;
        if (i % 2 == 0)
        {
            for (int j = 0; j < temp; j++)
            {
                arr[j]++;
            }
        }
        else
        {
            int t = y - 1;
            for (int j = 0; j < temp; j++)
            {
                arr[t]++;
                t--;
            }
        }
    }

    int min = x, imin = 0;

    sort(arr, arr + y);

    min = arr[0];
    imin = 1;

    int i = 1;

    while (arr[i] == min)
    {
        imin++;
        i++;
    }

    cout << min << " " << imin << endl;

    return 0;
}