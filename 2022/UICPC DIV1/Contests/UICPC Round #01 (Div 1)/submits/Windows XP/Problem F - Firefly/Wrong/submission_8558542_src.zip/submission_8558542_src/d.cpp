#include <iostream>

using namespace std;

int main()
{
    int x, y, temp;

    cin >> x >> y;

    int arr[y] = {0};

    for (int i = 0; i < x; i++)
    {
        cin >> temp;
        if (i % 2 == 0)
        {
            for (int j = 0; j < temp; j++)
            {
                arr[j]++;
            }
        }
        else
        {
            int t = y-1;
            for (int j = 0; j < temp; j++)
            {
                arr[t]++;
                t--;
            }
        }
    }

    int min = 7, imin = 0;

    for (int i = 0; i < y; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
            imin = 1;
        }
        else if(arr[i] == min)
        {
            imin++;
        }
    }

    cout << min << " " << imin << endl;

    return 0;
}