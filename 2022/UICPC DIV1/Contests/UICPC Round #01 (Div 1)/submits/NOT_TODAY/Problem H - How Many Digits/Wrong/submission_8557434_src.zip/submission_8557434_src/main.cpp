#include<iostream>
using namespace std;

long long int factorial(long long int n)
{
    if(n > 1)
        return n * factorial(n - 1);
    else
        return 1;
}

int main()
{
    long long int n , a ;
    int t = 0 ;
    cin >> n;
    //cout << "Factorial of " << n << " = " << factorial(n) << endl;
    a = factorial(n) ;
    while (a > 0 )
    {
        a /= 10 ;
        t++;
    }
    cout << t << endl;
    return 0;
}
