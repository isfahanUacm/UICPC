
#include <iostream>
#include <iomanip>
using namespace std;
typedef long long ll;
int main()
{
    int n, s, k;
    cin >> n >> s >> k;
    double makhraj = 1;
    int i = n;
    while (i)
    {
        makhraj *= s;
        i--;
    }
    double soorat = 0;
    int j = k;
    while(j <= n) {
        int y = s;
        int soorat1 = 1;
        for (int i = 0; i < j; i++)
            soorat1 *= y--;
        if (j < n)
            for (int i = j; i < n; i++)
            {
                soorat1 *= s;
            }

        j++;
        soorat += soorat1;
    }

  //  cout << soorat << "    " << makhraj << endl;
    cout << setprecision(9)<< soorat / makhraj;

    return 0;
}
