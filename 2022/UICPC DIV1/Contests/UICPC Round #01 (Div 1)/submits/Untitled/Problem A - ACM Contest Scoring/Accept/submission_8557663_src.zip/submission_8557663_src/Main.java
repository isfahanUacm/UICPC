//package dataStruct;
import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int countR = 0 , countT = 0;
        Map<String,Integer> map = new HashMap<>();
        do
        {
            String entry = sc.nextLine();
            String[] split = entry.split("\\s+");

            if(Integer.parseInt(split[0]) == -1)
                break;

            else
            {
                if(map.containsKey(split[1]))
                {
                    int temp;

                    if(split[2].equals("right"))
                        temp = map.get(split[1])+Integer.parseInt(split[0]);
                    else
                        temp = map.get(split[1])+20;

                    map.replace(split[1],temp);
                }

                else
                {
                    if(split[2].equals("right"))
                        map.put(split[1],Integer.parseInt(split[0]));
                    else
                        map.put(split[1], 20);
                }

                if(split[2].equals("right"))
                {
                    ++countR;
                    countT += map.get(split[1]);
                }
            }

        }while(true);

        System.out.println(countR+" "+countT);
    }
}