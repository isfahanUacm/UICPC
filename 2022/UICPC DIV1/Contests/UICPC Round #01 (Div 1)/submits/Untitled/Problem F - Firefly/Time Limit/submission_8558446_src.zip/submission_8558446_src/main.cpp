#include <iostream>
#include <algorithm>
using namespace std;
void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
int partition (int sum[], int low, int high)
{
    int pivot = sum[high];
    int i = (low - 1);
    for (int j = low; j <= high - 1; j++)
    {

        if (sum[j] < pivot)
        {
            i++;
            swap(&sum[i], &sum[j]);
        }
    }
    swap(&sum[i + 1], &sum[high]);
    return (i + 1);
}

void quickSort(int sum[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(sum, low, high);

        quickSort(sum, low, pi - 1);
        quickSort(sum, pi + 1, high);
    }
}
int main() {
    int N ,H;
    cin >> N >> H;
    int T, D;
    int sum[H];
    for (int i=0; i<H; i++)
        sum[i]=0;

    for (int i = 0; i < N; i=i+2) {
        cin >> D;
        for (int j = 0; j<D ; j++) {
            sum[j]++;
        }
        cin >> T;
        for (int j = H-1; j >=H-T ; j--) {
            sum[j]++;
        }
    }
    //sort(sum , sum+H);
    quickSort(sum , 0 , H-1);
    int k=0;
    int s=1;
    for (int i = 1; i < H; ++i) {
        if (sum[i]==sum[0])
            s++;
        else
            i=H;
    }
    cout << sum[0] <<" "<< s <<endl;

    return 0;
}
