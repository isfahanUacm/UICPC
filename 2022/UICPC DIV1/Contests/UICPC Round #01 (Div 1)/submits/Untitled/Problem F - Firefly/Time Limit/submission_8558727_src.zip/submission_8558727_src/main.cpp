#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int N ,H;
    cin >> N >> H;
    int T, D;
    int sum[H];
    for (int i=0; i<H; i++)
        sum[i]=0;

    for (int i = 0; i < N; i=i+2) {
        cin >> D;
        for (int j = 0; j<D ; j++) {
            sum[j]++;
        }
        cin >> T;
        for (int j = H-1; j >=H-T ; j--) {
            sum[j]++;
        }
    }
    sort(sum , sum+H);
    int s=1;
    int low = 0, high = H;
    int mid = 0;
    while (low < high) {
        mid = (high + low)/2;
        if (sum[mid] == sum[0]) {
            while (mid + 1 < H && sum[mid + 1] == sum[0])
                mid++;
            break;
        }
        else if (sum[mid] < sum[0])
            low = mid + 1;
        else
            high = mid;
    }

    while (mid >= 0 && sum[mid] > sum[0])
        mid--;


    cout << sum[0] <<" "<< mid+1 <<endl;
    return 0;
}
