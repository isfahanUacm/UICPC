#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int N ,H;
    cin >> N >> H;
    int T, D;
    int sum[H];
    for (int i=0; i<H; i++)
        sum[i]=0;

    for (int i = 0; i < N; i=i+2) {
        cin >> D;
        for (int j = 0; j<D ; j++) {
            sum[j]++;
        }
        cin >> T;
        for (int j = H-1; j >=H-T ; j--) {
            sum[j]++;
        }
    }
    sort(sum , sum+H);

    int k=0;
    int s=1;
    for (int i = 1; i < H; ++i) {
        if (sum[i]==sum[0])
            s++;
        else
            i=H;
    }
    cout<<sum[0] <<" "<<s<<endl;

    return 0;
}
