#include <iostream>
//#include <string.h>
#include <string>
#include <iomanip> 
#include <algorithm>
#include <cstdlib>
//#include <limits.h>
#include <iterator>
#include <set>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include<bits/stdc++.h>
//#include<ctype.h>
#include <cstdio>
#include <cstring>
#include <cstdlib>
//#include <stdio.h>

using namespace std;
typedef long long L;

int findDigits(int n)
{
    if (n < 0)
        return 0;

    if (n <= 1)
        return 1;
 
    double digits = 0;
    for (int i=2; i<=n; i++)
        digits += log10(i);
 
    return floor(digits) + 1;
}
 
int main()
{
    int n;
	while (cin >> n)
	{
	   cout<<findDigits(n)<<endl;
	}
	
    return 0;
}
