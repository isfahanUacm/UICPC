#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int num , N;
    cin >> num;
    for (int i = 0; i < num; ++i) {
        cin >> N;
        int P[3*N];
        for(int j=0; j<3*N; j++)
            cin >> P[j];

        sort(P , P+3*N);
//        for (int j = 0; j < 3*N; ++j) {
//            cout << P[j]<< " ";
//        }
//        cout << endl;
        int sum = 0;
        for (int j = 3*N-2; j >=N; j=j-2) {
            sum+=P[j];
        }
        cout << sum << endl;
    }

    return 0;
}
