import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class UICPCDive12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            long ans = 0;
            long x = sc.nextInt();
            ArrayList<Long> arr = new ArrayList<>();
            int count = 0;
            for (int j = 0; j < (3 * x); j++) {
                long k = Integer.parseInt(sc.next());
                arr.add(k);
                count += 1;
                if (count == 3) {
                    Collections.sort(arr);
                    ans += arr.get(1);
                    arr.clear();
                    count = 0;
                }
            }
            System.out.println(ans);
        }
    }
}
