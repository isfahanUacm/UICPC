

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int rep = sc.nextInt();

        for (int i = 0; i < rep; i++) {
            int noTeams = sc.nextInt();
            int[] scores = new int[noTeams * 3];

            for (int j = 0; j < noTeams * 3; j++) {
                scores[j] = sc.nextInt();
            }
            Arrays.sort(scores);
            
            int ans = 0;
            int index = scores.length - 2;
            for (int j = 1; j <= noTeams; j++) {
                ans += scores[index];
                index -= 2 ;
            }
            System.out.println(ans);
        }
    }
}
