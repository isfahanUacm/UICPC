import java.util.ArrayList;
import java.util.Scanner;

public class UICPCDive13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.next());
        int h = Integer.parseInt(sc.next());
        long counter = 0;
        long min_counter = counter;
        long level_count = 0;
        ArrayList<Integer> arr1 = new ArrayList<>();
        ArrayList<Integer> arr2 = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int x = sc.nextInt();
            if (i == 0 || i % 2 == 0) {
                arr1.add(x);
            } else {
                arr2.add(x);
            }
        }


        for (int i = 2; i <= (h - 1); i++) {
            counter = 0;
            for (int j = 0; j < arr1.size(); j++) {
                if (arr1.get(j) >= i) {
                    counter += 1;
                }
            }
            for (int j = 0; j < arr2.size(); j++) {
                if (arr2.get(j) >= (h - i + 1)) {
                    counter += 1;
                }
            }
            if (min_counter == 0) {
                min_counter = counter;
            } else {
                if (counter <= min_counter) {
                    min_counter = counter;
                }
            }
        }


        if (min_counter >= (n / 2)) {
            min_counter = (n / 2);
        }

        for (int i = 2; i <= (h - 1); i++) {
            counter = 0;
            for (int j = 0; j < arr1.size(); j++) {
                if (arr1.get(j) >= i) {
                    counter += 1;
                }
            }
            for (int j = 0; j < arr2.size(); j++) {
                if (arr2.get(j) >= (h - i + 1)) {
                    counter += 1;
                }
            }
            if (counter == min_counter) {
                level_count += 1;
            }
        }

        if (min_counter >= (n / 2)) {
            System.out.println(n / 2 + " " + (level_count + 2));
        } else
            System.out.println(min_counter + " " + level_count);

    }
}
