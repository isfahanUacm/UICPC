

import java.util.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
	int len = sc.nextInt();
    int height = sc.nextInt();

    int[] lvls = new int[height];

    boolean upside = true;
        for (int i = 1; i <= len; i++) {
            int obstaclesSize = sc.nextInt();
            if (upside){
                for (int lvlCounter = 0; lvlCounter <= obstaclesSize - 1; lvlCounter++) {
                    lvls[lvlCounter]++;
                }
            } else {
                int compelte =  compelte(obstaclesSize, height);
                for (int lvlCounter = height - 1; lvlCounter >= compelte; lvlCounter--) {
                    lvls[lvlCounter]++;
                }
            }
        upside = !upside;
        }
        int min = len / 2;
        int numOfMin = 0;
        for (int i = 0; i <height; i++) {
            if (lvls[i] < min){
                min = lvls[i];

            } else if (lvls[i] == min)
                numOfMin++;

        }
        System.out.println(min+" "+ numOfMin);
    }
    static int compelte(int size ,int max){
        return max - size;
    }
}

