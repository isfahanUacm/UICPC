

import java.util.ArrayList;

import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {

        ArrayList<Submit> subs = new ArrayList<>();
        ArrayList<String> solved = new ArrayList<>();

        int numOfRights = 0;
        int penalty = 0;
        while (true){
            int time = Integer.parseInt(sc.next());
            if(time == -1) break;
            subs.add(new Submit(time, sc.next(), sc.next()));
        }

        for (int i = subs.size() - 1; i >= 0; i--) {
            if(subs.get(i).result.equals("right")){
                numOfRights++;
                penalty += subs.get(i).time;
                solved.add(subs.get(i).question);

            }else {
                if (solved.contains(subs.get(i).question)){
                    penalty +=20;
                }
            }
        }
        System.out.println(numOfRights + " " + penalty);
    }
}
class Submit{

    public Submit(int time, String question, String result) {
        this.time = time;
        this.question = question;
        this.result = result;
    }
    int time;

    String question;
    String result;
}

