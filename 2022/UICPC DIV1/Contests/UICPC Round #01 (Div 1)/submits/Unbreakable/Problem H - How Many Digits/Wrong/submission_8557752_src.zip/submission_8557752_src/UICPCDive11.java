import java.util.Scanner;

public class UICPCDive11 {

    static long findDigits(long n) {
        if (n < 0)
            return 0;

        if (n <= 1)
            return 1;
        double M_PI = 3.141592;
        double M_E = 2.7182;
        double x = ((n * Math.log10(n / M_E) + Math.log10(2 * M_PI * n) / 2.0)) / (Math.log10(10));
        return (long) (Math.floor(x) + 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inputLine;
        while (sc.hasNextLine()) {
            inputLine = sc.nextLine();
            long n = Long.parseLong(inputLine);
            System.out.println(findDigits(n));
        }

    }

}