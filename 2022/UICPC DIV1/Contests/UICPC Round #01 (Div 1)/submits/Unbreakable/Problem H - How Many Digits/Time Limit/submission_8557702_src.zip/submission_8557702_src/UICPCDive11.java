import java.util.Scanner;

public class UICPCDive11 {

    static int findDigits(long n) {
        if (n < 0)
            return 0;
        if (n <= 1)
            return 1;
        double digits = 0;
        for (int i = 2; i <= n; i++)
            digits += Math.log10(i);

        return (int) (Math.floor(digits)) + 1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inputLine;
        while (sc.hasNextLine()) {
            inputLine = sc.nextLine();
            long n = Long.parseLong(inputLine);
            System.out.println(findDigits(n));
        }

    }

}