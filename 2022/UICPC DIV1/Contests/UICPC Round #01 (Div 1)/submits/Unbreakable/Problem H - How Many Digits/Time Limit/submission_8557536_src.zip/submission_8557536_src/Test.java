import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inputLine;
        while (sc.hasNextLine()) {
            inputLine = sc.nextLine();
            int n = Integer.parseInt(inputLine);
            long factorial = factorial(n);
            int num = countDigit(factorial);
            System.out.println(num);
        }
    }

    static long factorial(int n) {
        if (n == 0) return 1;
        else return (n * factorial(n - 1));
    }

    static int countDigit(long n) {
        int count = 0;
        while (n != 0) {
            n = n / 10;
            ++count;
        }
        return count;
    }
}