import java.util.Scanner;

public class UICPCDive11 {

    static long findDigits(long n) {
        double one = 2.71828182845904523536;
        double two = 3.141592654;
        if (n < 0)
            return 0;
        if (n <= 1)
            return 1;
        double x = (n * Math.log10(n / one) + Math.log10(2 * two * n) / 2.0);
        return (long) Math.floor(x) + 1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inputLine;
        while (sc.hasNextLine()) {
            inputLine = sc.nextLine();
            long n = Long.parseLong(inputLine);
            System.out.println(findDigits(n));
        }
    }
}