#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n, h;
    cin >> n >> h;
    int obs[200000];
    for (int i = 0; i < n; i++)
        cin >> obs[i];
    int min = 20000, mini = 20000;

    for (int i = 0; i < h; i++)
    {
        int temp_obs = 0;
        for (int j = 0; j < n; j++)
        {
            float temp = i + 0.5;
            if (j % 2 == 0)
            {
                if (obs[j] > temp)
                    temp_obs++;
            }
            else
                if (temp > h - obs[j])
                    temp_obs++;
        }
        if (temp_obs < min)
        {
            min = temp_obs;
            mini = i + 1;
        }
    }
    cout << min << " " << mini;
}