#include <bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	char letter;
	map<char, int> penalty;
	map<char, bool> trueorfalse;
	do {
		string worr;
		cin >> t;
		if (t == -1)
			break;
		cin >> letter >> worr;
		if (worr.compare("wrong") == 0)
		{
			penalty[letter] += 20;
			trueorfalse[letter] = false;
		}
		else
		{
			penalty[letter] += t;
			trueorfalse[letter] = true;
		}
	} while (t != -1);
	int sum1 = 0;
	int sum2 = 0;
	for (const auto& kv : trueorfalse) {
		if (kv.second)
		{
			sum1 += 1;
			sum2 += penalty[kv.first];
		}
	}
	cout << sum1 << " " << sum2;
}