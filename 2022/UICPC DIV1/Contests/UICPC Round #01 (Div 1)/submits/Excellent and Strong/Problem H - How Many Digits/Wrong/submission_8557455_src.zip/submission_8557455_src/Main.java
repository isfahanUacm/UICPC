import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()) {
            System.out.println(findDigits(sc.nextInt(), 10));
        }

    }
    
    static long findDigits(int n, int b) {
        // factorial of -ve number
        // doesn't exists
        if (n < 0)
            return 0;

        // base case
        if (n <= 1)
            return 1;
        double M_PI = 3.141592;
        double M_E = 2.7182;

        // Use Kamenetsky formula to calculate
        // the number of digits
        double x = ((n * Math.log10(n / M_E) +
                Math.log10(2 * M_PI * n) /
                        2.0)) / (Math.log10(b));

        return (long) (Math.floor(x) + 1);
    }
}
