import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        do {
            int n = sc.nextInt();
            System.out.println(findDigits(n));
        } while (sc.hasNext());

    }

    static int findDigits(int n) {
        if (n < 0)
            return 0;

        if (n <= 1)
            return 1;

        return (int)Math.floor((Math.log(2*Math.PI*n)/2+n*(Math.log(n)-1))/Math.log(10))+1;
    }
}
