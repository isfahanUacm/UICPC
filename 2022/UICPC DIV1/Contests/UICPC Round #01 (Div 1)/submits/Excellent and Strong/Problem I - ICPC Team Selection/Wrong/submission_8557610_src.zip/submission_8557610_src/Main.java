import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for(int i=0;i<n;i++){
            int N = sc.nextInt();
            int median= 0;
            for(int j=0;j<N;j++){
                int[] arr = new int[3];
                for(int k=0;k<3;k++){
                    arr[k] = sc.nextInt();
                }
                Arrays.sort(arr);
                median += arr[1];
            }
            System.out.println(median);
        }

    }
}
