import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            int N = sc.nextInt();
            int median = 0;
            int[] arr = new int[3 * N];
            for (int j = 0; j < 3 * N; j++) {
                arr[j] = sc.nextInt();
            }
            Arrays.sort(arr);
            for (int j = N; j < 2 * N- N/2; j++) {
                median += arr[j];
            }
            for (int j = 2*N; j < 3 * N- N/2; j++) {
                median += arr[j];
            }
            System.out.println(median);
        }

    }
}
