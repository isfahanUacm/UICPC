#include <bits/stdc++.h>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int h[103];
	vector<int> t;
	for (int i = 0; i < n; i++)
	{
		int sum = 0;
		int l = 0;
		cin >> h[i];
		int temp3[303];
		for (int j = 0; j < h[i] * 3; j++)
			cin >> temp3[j];
		sort(temp3, temp3 + h[i] * 3);
		for (int j = 0; j < h[i] - 1; j++)
			swap(temp3[3 * j + 1], temp3[3 * (j + 1)]);
		for(int k = 0 ; k < h[i]; k++)
			sort(temp3 + k, temp3 + k * 3);
		for (int j = 1; j < h[i] * 3; j+= 3)
		{
			sum += temp3[j];
		}
		//cout << h[i] << " " << sum << "\n\n";
		cout << sum << endl;
	}
}