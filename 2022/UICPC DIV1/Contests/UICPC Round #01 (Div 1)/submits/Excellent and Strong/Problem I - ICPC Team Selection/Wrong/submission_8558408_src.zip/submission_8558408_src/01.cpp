#include <bits/stdc++.h>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int h[103];
	vector<int> t;
	for (int i = 0; i < n; i++)
	{
		int sum = 0;
		cin >> h[i];
		for (int j = 0; j < h[i]; j++)
		{
			int temp[3];
			for(int k = 0 ; k < 3 ; k++)
				cin >> temp[k];
			int n2 = sizeof(temp) / sizeof(temp[1]);
			sort(temp, temp+n2);
			sum += temp[1];
		}
		//cout << h[i] << " " << sum << "\n\n";
		cout << sum << endl;
	}
}