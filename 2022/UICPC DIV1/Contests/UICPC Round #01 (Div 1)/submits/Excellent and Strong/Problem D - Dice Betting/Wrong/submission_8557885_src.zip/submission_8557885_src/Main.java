import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int s = sc.nextInt();
        int k = sc.nextInt();
        double ans = 0.0;
        while (k != s + 1) {
            ans += (fact(n) / (fact(k) * fact(n - k))) * (fact(s) / fact(s - k)) / Math.pow(n, s);
            k++;
        }
        System.out.println(ans);
    }

    static double fact(int n) {
        double fact = 1;
        for (int i = 2; i <= n; i++) {
            fact = fact * i;
        }
        return fact;
    }
}
