#include <bits/stdc++.h>
using namespace std;

int main(){
    vector<double> res;
    res.push_back(1), res.push_back(1);
    //double temp = 0;
    for (int j = 2; j <= 1000000 ; ++j) {
        res.push_back(res[j-1] + log10(j));
    }
    int x;
    while(cin>>x){
        cout<<int(floor(res[x]))<<endl;
    }
}