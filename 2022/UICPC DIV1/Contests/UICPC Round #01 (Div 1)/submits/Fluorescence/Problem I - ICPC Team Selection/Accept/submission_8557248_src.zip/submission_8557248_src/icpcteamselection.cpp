#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
int main(){
    int t; cin>>t;
    while(t--){
        int n; cin>>n;
        int a[300+10];
        for(int i=0; i<3*n; i++){
            cin>>a[i];
        }
        sort(a, a+(3*n));
        int i=n;
        int sum=0;
        while(n--){
            sum += a[i];
            i+=2;
        }
        cout<<sum<<endl;
    }
}