n,h = map(int,input().split())
bot = [0]*(h+1)
top = [0]*(h+1)
for i in range(n//2):
    t = int(input())
    #bot.append(t)
    bot[t]+=1
    t = int(input())
    #top.append(t)
    top[t]+=1
#print(bot)
#print(top)
s_bot = [0]*(h+1)
s_top = [0]*(h+1)
for i in range(h-1,0,-1):
    s_bot[i]=bot[i]+s_bot[i+1]
    s_top[i]=top[i]+s_top[i+1]
s_bot = s_bot[1:]
s_top = s_top[1:]
s_top.reverse()
#print(s_bot)
#print(s_top)
min_res = n+1
min_index = -1
both = [0]*h
for i in range(h):
    both[i]=s_bot[i]+s_top[i]
both.sort()
te=0
mi = both[0]
i=0
while (i<h):
    if both[i]==mi:
        te+=1
    i+=1
#print(both)
print(mi,te)