#include <bits/stdc++.h>
using namespace std;
int n, m;
vector<vector<int>> adj(10005);
vector<vector<int>> undir(10005);
bool vis[10005];
int in_deg[10005], out_deg[10005];


void printCircuit()
{
    unordered_map<int,int> edge_count;
    stack<int> curr_path;
    vector<int> circuit;
    for (int i=0; i<adj.size(); i++)
        edge_count[i] = adj[i].size();

    curr_path.push(0);
    int curr_v = 0;

    while (!curr_path.empty()){
        if (edge_count[curr_v]){
            curr_path.push(curr_v);

            int next_v = adj[curr_v].back();

            edge_count[curr_v]--;
            adj[curr_v].pop_back();

            curr_v = next_v;
        }
        else{
            circuit.push_back(curr_v);
            curr_v = curr_path.top();
            curr_path.pop();
        }
    }

    for (int i=circuit.size()-1; i>=0; i--){
        cout << circuit[i] <<" ";
    }
    cout<<endl;
}


void dfs(int u){
    vis[u] = true;
    for (int v : undir[u]) {
        if(!vis[v])
            dfs(v);
    }
}

int main(){
    while(true){
        cin>>n>>m;
        if(n == 0 && m==0)
            break;
        int u, v;
        fill_n(in_deg, n, 0), fill_n(out_deg, n, 0), fill_n(vis, n, false);
        adj.clear(), adj.resize(10005);
        undir.clear(), undir.resize(10005);
        for (int i = 0; i < m; ++i) {
            cin>>u>>v;
            adj[u].push_back(v);
            undir[u].push_back(v), undir[v].push_back(u);
            in_deg[v]++, out_deg[u]++;
        }

        bool x = false, y = false;
        bool impos = false;
        for (int i = 0; i < n; i++)
        {
            if (out_deg[i] != in_deg[i])
            {
                if (!x && out_deg[i] - in_deg[i] == 1) {
                    x = true;
                }
                else if (!y && in_deg[i] - out_deg[i] == 1) {
                    y = true;
                }
                else {
                    impos = true;
                    break;
                }
            }
        }
        if(!impos){
            dfs(0);
            for (int i = 0; i < n; ++i) {
                if(!vis[i] && (in_deg[i]>0 || out_deg[i]>0)){
                    impos = true;
                    break;
                }
            }
        }
        if(impos){
            cout<<"Impossible\n";
            continue;
        }

        //print tour
        printCircuit();

    }
}