log = []
acc = 0
time = 0
while True:
    line = input()
    if line == '-1':
        break
    log.append(line.split())
for i in range(len(log)):
    mint, name, ver = log[i][0], log[i][1], log[i][2]
    if ver == 'right':
        acc += 1
        w = 0
        for j in range(0, i):
            if name == log[j][1]:
                w += 1
        time += w*20 + int(mint)
print(acc, time)