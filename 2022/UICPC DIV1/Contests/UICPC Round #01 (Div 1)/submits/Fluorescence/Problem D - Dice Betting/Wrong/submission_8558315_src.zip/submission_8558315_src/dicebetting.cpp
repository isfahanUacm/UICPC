#include <bits/stdc++.h>
using namespace std;

long long int factorial(long long int n) 
{
    long long int factorial = 1;
    for (long long int i = 2; i <= n; i++)
        factorial = factorial * i;
    return factorial;
}

long long int comb(long long int n, long long int r)
{
    return factorial(n) / (factorial(r) * factorial(n - r));
}
long double exact_k(long long int n, long long int s, long long int k)
{
    long long int su = 0;
    for (int i = 0; i <= k; i++)
    {
        su+=pow(-1,i)*(comb(k,i))*pow((k-i),n);
    }
    long double res = ((comb(s,k))*su)/(pow(s,n));
    return res;
    
}
int main()
{
    long long int n,s,k;
    cin>>n>>s>>k;
    long double ans = 0;
    for (long long int i = k; i <= s; i++)
    {
        ans += exact_k(n,s,i);
    }
    cout<<setprecision(9)<<ans;
    //int temp; cin>>temp;
}