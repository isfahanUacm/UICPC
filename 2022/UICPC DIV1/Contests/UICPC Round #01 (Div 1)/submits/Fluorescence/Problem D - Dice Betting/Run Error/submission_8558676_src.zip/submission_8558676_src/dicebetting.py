import math as ma

n,s,k = map(int,input().split())
ans = 0
for j in range(k,s+1):
    su = 0
    for i in range(j+1):
        su+=((-1)**i)*(ma.comb(j, i))*((j-i)**n)
    res = ((ma.comb(s, j))*su)/(s**n)
    ans+=res
print(ans)