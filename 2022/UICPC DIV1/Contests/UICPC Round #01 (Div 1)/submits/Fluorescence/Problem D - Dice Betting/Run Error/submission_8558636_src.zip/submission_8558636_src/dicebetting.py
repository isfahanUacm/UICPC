import math as ma
def exactly_k(n,s,k):
    su = 0
    for i in range(k+1):
        #print(math.comb(k, i))
        su+=((-1)**i)*(ma.comb(k, i))*((k-i)**n)
    #print(math.comb(s, k))
    res = ((ma.comb(s, k))*su)/(s**n)
    return res

n,s,k = map(int,input().split())
ans = 0
for i in range(k,s+1):
    ans+=exactly_k(n,s,i)
print(ans)