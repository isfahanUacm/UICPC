def fact(n):
    res = 1
    for i in range(2, n+1):
        res = res * i
    return res

def nCr(n, r):
    return (fact(n) / (fact(r)* fact(n - r)))

n,s,k = map(int,input().split())
ans = 0
for j in range(k,s+1):
    su = 0
    for i in range(j+1):
        #print(math.comb(k, i))
        su+=((-1)**i)*(nCr(j, i))*((j-i)**n)
    #print(math.comb(s, k))
    res = ((nCr(s, j))*su)/(s**n)
    ans+=res
print(ans)