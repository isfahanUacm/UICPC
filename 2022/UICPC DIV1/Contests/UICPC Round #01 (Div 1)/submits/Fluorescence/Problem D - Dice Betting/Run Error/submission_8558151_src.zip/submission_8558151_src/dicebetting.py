import math
n,s,k = map(int,input().split())
def fun(k):
    su = 0
    for i in range(k+1):
        #print(math.comb(k, i))
        su+=((-1)**i)*(math.comb(k, i))*((k-i)**n)
    #print(math.comb(s, k))
    res = ((math.comb(s, k))*su)/(s**n)
    return res
ans = 0
for i in range(k,s+1):
    ans+=fun(i)
print('{0:.9f}'.format(ans))