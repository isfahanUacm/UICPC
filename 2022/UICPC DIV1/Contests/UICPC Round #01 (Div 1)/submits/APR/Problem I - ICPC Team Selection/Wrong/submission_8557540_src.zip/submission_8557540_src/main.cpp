#include <iostream>
using namespace std;


    void bubbleSort(int arr[])
    {
        int n = 3;
        for (int i = 0; i < n-1; i++)
            for (int j = 0; j < n-i-1; j++)
                if (arr[j] > arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
    }


int main( )
{
    int n;
    cin >> n;

    int sums[n];

    for (int i = 0 ; i < n ; i++)
    {
        int n2;

        cin >> n2;

        int list[3*n2];
        for (int j = 0 ; j < 3*n2 ; j++)
            cin >> list[j];
        int sum = 0;
        for (int j = 0 ; j < 3*n2 ; j+=3)
            bubbleSort(list+j);
        for (int j = 1 ; j < 3*n2 ; j+=3)
            sum+=list[j];
        sums[i] = sum;
    }
    for (int i = 0 ; i < n ; i++)
    {
        cout << sums[i] << endl;
    }

    return 0;
}
