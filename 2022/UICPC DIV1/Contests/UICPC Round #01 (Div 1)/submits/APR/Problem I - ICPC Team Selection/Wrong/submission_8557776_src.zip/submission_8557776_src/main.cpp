#include <iostream>
using namespace std;
int main()
{
    float p, mx=0, mids=0, secmx=0;
    int i,j,l,n,e;
    scanf("%d", &l);
    for(i=0; i<l; ++i)
    {
        scanf("%d", &n);
        e=3*n;
        for(j=0; j<e; ++j)
        {
            scanf("%f", &p);
            if(j%3==0){
                mids+=secmx;
                mx=p;
                secmx=0;
            }
            else if(p>mx)
               {
                secmx=mx;
                mx=p;
               }
            else if(p>secmx)
            {
                secmx=p;
            }
        }
    }
    mids+=secmx;
    cout<<mids;
}
