#include <iostream>
using namespace std;


    void bubbleSort(int arr[])
    {
        int n = 3;
        for (int i = 0; i < n-1; i++)
            for (int j = 0; j < n-i-1; j++)
                if (arr[j] > arr[j+1])
                {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
    }


int mid (int i[3])
{
    if (i[0] >= i[1])
    {
        if (i[0] <= i[2])
            return i[0];
        else if (i[1]>=i[2])
            return i[2];
        else
            return i[1];
    }
    else
    {
        if (i[1] <= i[2])
            return i[1];
        else if (i[0]>=i[2])
            return i[0];
        else
            return i[2];
    }
}

int main( )
{
    int n;
    cin >> n;
    for (int i = 0 ; i < n ; i++)
    {
        int n2;

        cin >> n2;

        int list[3*n2];
        for (int j = 0 ; j < 3*n2 ; j++)
            cin >> list[j];
        int sum = 0;
        for (int j = 0 ; j < 3*n2 ; j+=3)
            bubbleSort(list+j);
        for (int j = 1 ; j < 3*n2 ; j+=3)
            sum+=list[j];
        cout << sum;
    }

    return 0;
}
