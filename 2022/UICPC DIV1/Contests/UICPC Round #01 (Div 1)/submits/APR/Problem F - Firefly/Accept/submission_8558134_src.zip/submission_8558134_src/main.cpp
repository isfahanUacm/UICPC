
#include <algorithm>
#include <iostream>
using namespace std;


int main( void )
{
    int n, h;
    cin >> n >> h;
    int gr[n/2];
    int rf[n/2];

    for( int i = 0; i < n/2; i++ )
        cin >> gr[i] >> rf[i];
    n/=2;
    sort( gr, gr+n );
    sort( rf, rf+n );

    int ans = 2*n, ansC = 0;

    for( int y = 0; y < h; ++y ) {
        int hc = n - (int)(lower_bound( gr, gr+n, y+1 )-gr) +n - (int)(lower_bound( rf, rf+n, h-y )-rf);

        if( hc  < ans ) { ans = hc; ansC = 0; }
        if( hc == ans ) ++ansC;
    }

    cout << ans <<" "<< ansC << endl;

    return 0;
}
