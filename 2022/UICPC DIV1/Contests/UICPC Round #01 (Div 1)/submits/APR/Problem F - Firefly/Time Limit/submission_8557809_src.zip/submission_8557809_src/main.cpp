#include <iostream>
using namespace std;

int main( )
{
     int n, h;
     cin >> n >> h;
     int g[n - n/2];
     int r[n/2];
     int ans = n , ansC = 1;
     for (int i = 0 ; i < n/2; i++)
     {
         cin >> g[i] >> r[i];
     }
     if (n%2 == 1)
         cin >> g[n-n/2];

     for(int i = 1 ; i <= h ; i++)
     {
         int hc = 0;
         for(int j = 0 ; j < n/2 ; j++)
         {
             if (g[j] >= i)
                 hc++;
             if (h-r[j] < i)
                 hc++;
         }
         if (n%2==1)
             if(g[n-n/2] > i)
                 hc++;
         if (hc < ans)
         {
             ans = hc;
             ansC = 1;
         }
         else if (hc == ans)
             ansC++;
     }

     cout << ans <<" "<< ansC << endl;



    return 0;
}
