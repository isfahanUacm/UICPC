#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int n;
    double nd;
    while(cin>>n)
    {
        nd=0;
        if(n<=1)
        {
            printf("1\n");
        }
        else{
            nd = ((n * log10(n / M_E) +
                         log10(2 * M_PI * n) /
                         2.0));

            nd= floor(nd) + 1;
            printf("%d\n", (int)nd);
        }
    }
}
