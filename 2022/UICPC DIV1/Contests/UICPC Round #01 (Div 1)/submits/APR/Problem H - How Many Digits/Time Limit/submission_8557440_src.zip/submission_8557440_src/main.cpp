#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int n, i;
    double nd;
    while(cin>>n)
    {

        nd=0;
        if(n<=1)
        {
            printf("1\n");
            continue;
        }
        for(i=2; i<=n; i++)
            nd+= log10(i);
        nd=floor(nd);
        nd++;
        cout<<nd<<"\n";
    }
}
