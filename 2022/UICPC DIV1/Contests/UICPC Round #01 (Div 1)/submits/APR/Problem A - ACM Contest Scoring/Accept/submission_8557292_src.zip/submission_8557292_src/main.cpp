#include <iostream>
using namespace std;
int main()
{
    int t, s, p=0, j, totalscore=0, problemsolved=0;
    char entries[100], c;
    string worr;
    while(1){
        scanf("%d", &s);
        getchar();
        if(s==-1)
            break;
        scanf("%c", &c);
        cin>>worr;
        if(worr=="wrong")
        {
            entries[p]=c;
            p++;
        }
        else
        {
            t=0;
            problemsolved++;
            for(j=p-1; j>=0; j--)
            {
                if(entries[j]==c)
                {
                    t++;
                    entries[j]='a';
                }
            }
            totalscore=totalscore+s+ t*20;
        }
    }
    printf("%d %d", problemsolved, totalscore);
}
