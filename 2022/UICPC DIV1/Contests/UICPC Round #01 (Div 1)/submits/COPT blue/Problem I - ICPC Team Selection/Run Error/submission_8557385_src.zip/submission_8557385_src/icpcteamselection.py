n= int(input())
def inter(l):
    l1 = []
    for i in l:
        l1.append(int(i))
    return l1
for t in range(n):
    
    for i in range(n):
        s = 0
        m = int(input())
        l = input().split(' ')
        l = inter(l)
        for j in range(2):
            index = l.index(max(l))
            del l[index]
        s += (max(l))
        index = l.index(max(l))
        del l[index]
        s += (max(l))
        print(s)