n= int(input())
ans = []
def inter(l):
    l1 = []
    for i in l:
        l1.append(int(i))
    return l1

for i in range(n):
        s = 0
        m = int(input())
        l = input().split(' ')
        l = inter(l)
        l.sort()
        l = l[len(l)-(2*m):]
        l.reverse()
        for i in range(m):
            s+=l[(2*i)+1]
        print(l)
        ans.append(s)
for i in ans:
    print(i,end=' ')
        