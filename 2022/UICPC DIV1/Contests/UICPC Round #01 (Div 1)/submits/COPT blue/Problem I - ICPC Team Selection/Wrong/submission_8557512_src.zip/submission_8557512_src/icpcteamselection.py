n= int(input())
ans = []
def inter(l):
    l1 = []
    for i in l:
        l1.append(int(i))
    return l1

for i in range(n):
        s = 0
        m = int(input())
        l = input().split(' ')
        l = inter(l)
        for j in range(m):
            index = l.index(max(l))
            del l[index]
        for j in range(m):
            s += (max(l))
            index = l.index(max(l))
            del l[index]
        ans.append(s)
for i in ans:
    print(i,end=' ')