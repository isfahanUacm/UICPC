import math
ans = []
contents = []
def dg(n):
    if(n<=1):
        return 1
    sum = 0
    for i in range(2,n+1):
            sum+=math.log(i,10)
    sum = math.ceil(sum)
    return sum
while True:
    try:
        line = input()
        if(line==''):
            break
        line = int(line)
    except EOFError:
        break
    contents.append(line)
for n in contents:
    ans.append(dg(n))
for i in ans:
    print(i)