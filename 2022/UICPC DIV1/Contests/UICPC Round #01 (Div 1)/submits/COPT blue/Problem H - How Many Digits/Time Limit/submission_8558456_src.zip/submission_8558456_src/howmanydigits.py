import math
ans = []
while True:
    try:
        line = input()
        if(line==''):
            break
        if line:
            n = int(line)
            if(n==1 or n==0):
                ans.append(1)
                continue
            som = 0
            for i in range(2,n+1):
                som+=math.log(i,10)
            som = math.ceil(som)
            ans.append(som)
        else:
            break
    except:
        break

for i in ans:
    print(i)
    
