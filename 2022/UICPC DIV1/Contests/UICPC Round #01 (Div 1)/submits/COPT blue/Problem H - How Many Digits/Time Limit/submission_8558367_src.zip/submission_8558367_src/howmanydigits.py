import math
ans = []
contents = []
def dg(n):
    if(n==1 or n==0):
        return 1
    som = 0
    for i in range(2,n+1):
        som+=math.log(i,10)
    som = math.ceil(som)
    return som
while True:
    try:
        line = input()
        if(line==''):
            break
        if line:
            contents.append(int(line))
        else:
            break
    except:
        break
for n in contents:
    ans.append(dg(n))
for i in ans:
    print(i)