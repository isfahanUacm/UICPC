l = []
while True:
    s = input().split(' ')
    if(s==['-1']):
        break
    l.append(s)
right = []
scores = []
score = 0
count = 0
for i in l:
    # print(i)
    if(i[2]=='right'):
        count += 1
        right.append(i[1])
        score += int(i[0])
        scores.append(int(i[0]))
for i in l:
    if(i[2]=='wrong' and i[1] in right):
        index = right.index(i[1])
        if(scores[index]>=int(i[0])):
            # print(i , '*')
            score += 20


print(count , score)