#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

int main()
{
    ll n, h;
    cin >> n >> h;
    vector<ll> start(h, 0);
    vector<ll> end(h, 0);
    for (ll i = 0; i < n; i++)
    {
        ll k;
        cin >> k;
        // odd
        if (i % 2)
        {
            ll p = h - k;
            start[p] ++;
            end[h - 1] ++;
        }
        // even
        else
        {
            start[0] ++;
            end[k - 1] ++;
        }
    }
    ll temp = 0;
    vector<ll> arr(h, 0);
    for(ll i = 0; i < h; i++)
    {
        temp += start[i];
        temp -= ((i > 0)? end[i - 1] : 0);
        arr[i] = temp;
    }
    sort(arr.begin(), arr.end());
    ll s = arr[0];
    ll sum = 0;
    ll index = 1;
    while(s == arr[0])
    {
        sum += 1;
        s = arr[index];
        index ++;

    }

    cout << arr[0] << " " << sum;
    return 0;
}