#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

vector<vector<ld>> dp;
ld s;

ld probfunction(ld x, ld y)
{
    if (x == 0 && y==0)
    {
        dp[x][y] = 1;
        return dp[x][y];
    }
    if (x == 0 || y==0)
    {
        dp[x][y] = 0;
        return dp[x][y];
    }
    if (dp[x][y] != 0)
        return dp[x][y];
    dp[x][y] = (((s-(y-1)) / s) * (probfunction(x-1, y-1))) +  ((y /s) * (probfunction(x-1,y)));
    return dp[x][y];

}

int main()
{
    ld n,k;
    cin >> n >> s >> k;
    vector <ld> sample(s+1,0);
    dp = vector<vector<ld>> (n+1,sample);
    ld total_p = 0;
    dp[0][0] = 1;
    for (ll i=1; i<= n; i++)
        for (ll j=1; j<= s; j++)
        {
         if (i ==0 || j ==0)
             dp[i][j] =0;
         else

         dp[i][j] = (((s-(j-1)) / s) * (dp[i-1][j-1])) +  ((j/s) * (dp[i-1][j]));

        }
    for (ll i = k;i<=s;i++)
    {
        total_p += dp[n][i];
    }

    cout <<fixed << setprecision(9) << total_p;

}
