#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
   ll n;
   cin>>n;
   while(n--){
       ll m;
       cin>>m;
       vector<ll> array(3*m);
       for(ll i=0;i <3*m;i++){
           cin>>array[i];
       }
       sort(array.begin(),array.end());
       ll b=3*m-1;
       ll total_sum=0;
       for(ll j=0;j<m;j++){

           total_sum+=array[b-1];
           b=b-2;
       }
       cout<<total_sum<<endl;

   }
}
