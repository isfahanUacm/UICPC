#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

int main()
{
    vector<ld> digits(1000001, 0);
    digits[0] = 1;
    digits[1] = 1;
    for(ll i = 1; i <= 1000000; i++)
    {
        digits[i] = digits[i - 1] + log10(i);
    }
    ll x;
    while(cin >> x)
    {
        cout << (ll)digits[x] << endl;
    }
    return 0;
}