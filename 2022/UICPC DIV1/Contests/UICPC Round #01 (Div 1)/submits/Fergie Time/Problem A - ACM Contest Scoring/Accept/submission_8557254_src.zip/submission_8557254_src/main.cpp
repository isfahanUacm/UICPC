#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;


int main()
{
    int n;
    string s1, s2;
    n = 9;
    map <string, int> wrong;
    int totalsum = 0;
    int right_ans = 0;
    cin >> n;
    while (n != -1)
    {
        cin >>  s1 >> s2;
        if (s2 == "right")
        {
            right_ans += 1;
            if (wrong.find(s1) != wrong.end())
            {
                int k = wrong[s1];
                totalsum += n + (20*k);
            }
            else
            {
                totalsum += n;
            }
        }
        if (s2 == "wrong")
        {
            if (wrong.find(s1) != wrong.end()){
                wrong[s1] += 1;
            }
            else
            {
                   wrong[s1] = 1;
            }
        }

      cin >> n;
    }

    cout << right_ans << " " << totalsum;
}
