#include <bits/stdc++.h>
using namespace std;

int main()
{
    int ds, n, s;
    cin >> ds;
    for (int i = 0; i < ds; i++)
    {
        cin >> n;
        s = 0;
        int *points = new int[3 * n];

        for (int i = 0; i < 3 * n; i++)
        {
            cin >> points[i];
        }

        sort(points, points + 3 * n);

        for (int i = n; i < n + n; i++)
            s += points[i];

        cout << s << '\n';

        delete[] points;
    }
}