#include <iostream>
#include <bits/stdc++.h>


using namespace std;

int main() {
    int t;
    cin >> t;
    for (int i=0; i<t; i++) {
        int n = 0;
        cin >> n;
        int arr[3*n];
        for (int j=0; j<3*n; j++) cin >> arr[j];

        sort(arr, arr+3*n);
        int s = 0;
        int num = 0;
        for (int i=3*n-2; i>=0; i-=2) {
            s += arr[i];
            num++;
            if (num == n) break;
        }
        cout << s << endl;
    }
    return 0;
}