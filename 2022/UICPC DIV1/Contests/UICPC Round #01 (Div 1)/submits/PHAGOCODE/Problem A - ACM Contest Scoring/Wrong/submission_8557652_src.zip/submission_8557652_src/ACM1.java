import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class ACM1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int x = 0;
        int ans = 0;
        String str = scanner.nextLine();
        ArrayList<String> Eh = new ArrayList<>();
        ArrayList<Integer> Ehs = new ArrayList<>();
        String[] str2 = str.split(" ");
        int h = Integer.parseInt(str2[0]);
        while(h > -1){
            String[] str1 = str.split(" ");
            Eh.add(str1[1]);
            int b = Integer.parseInt(str1[0]);
            Ehs.add(b);
            if(str1[2].equals("right")){
                ans += b;
            }
            str = scanner.nextLine();
            str2 = str.split(" ");
            h = Integer.parseInt(str2[0]);
        }
        HashMap<String,Integer> pro = new HashMap<>();
        for(String s: Eh){
            int y = 0;
            for(String s1:Eh){
                if(s1.equals(s)){
                    y += 1;
                }
            }
            y = y-1;
            pro.put(s,y);
        }
        int t=0;
        for(Integer sd: pro.values()){
            t += sd;
        }
        t = t*20;
        ans += t;
        System.out.println(ans);
    }
}
