#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

int main() {
    int x;
    vector<int> v;
    while(cin>>x)
    {
        v.push_back(x);
    }
    for (int j=0; j<v.size(); j++) {
        double sum = 0;
        for (int i=2; i<=v[j]; i++) {
            sum += log10(i);
        }
        int ans = sum;
        cout << ans+1 << endl;
    }

 
    return 0;
}