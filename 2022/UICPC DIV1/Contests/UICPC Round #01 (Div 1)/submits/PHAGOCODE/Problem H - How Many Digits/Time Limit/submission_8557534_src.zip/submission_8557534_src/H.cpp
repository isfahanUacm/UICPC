#include <iostream>
using namespace std;

int main()
{
    int n;
    long double fact;
    int counter;
    while (true)
    {
        cin >> n;
        if (n == 0)
        {
            cout << 1;
            continue;
        }

        fact = 1;
        counter = 0;

        for (int i = 1; i <= n; i++)
        {
            fact *= i;
            fact /= 10.0;
            counter++;
        }
        // cout << "fact=" << fact << endl;
        // cout << "counter=" << counter << endl;
        while (fact < 1)
        {
            // cout << "here";
            fact *= 10;
            counter--;
        }
        cout << counter + 1;
    }

    return 0;
}