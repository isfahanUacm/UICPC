#include <iostream>
#include <cmath>
using namespace std;

int main() {
    while (1) {
        int num;
        cin >> num;
        double sum = 0;
        for (int i=2; i<=num; i++) {
            sum += log10(i);
        }
        int ans = sum;
        cout << ans+1 << endl;
    }
 
    return 0;
}