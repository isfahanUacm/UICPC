#include <iostream>
#include <cmath>
using namespace std;

long long fact(int x) {
    long long ans = 1;
    for (int i=2; i<=x; i++) {
        ans *= i;
        if (ans%10==0) ans /= 10;
    }
    return ans;
}
int main() {
    while(1) {
        int num;
        cin >> num;
        int number_of_zero =  0, m=1;
        int x = floor(num/pow(5, m++)); 
        while (x) {
            number_of_zero += x;
            x = floor(num/pow(5, m++));
        }
    
        int ans = log10(fact(num));
        cout << ans+number_of_zero+1<< endl;
    }
    return 0;
}