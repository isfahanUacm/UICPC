#include <iostream>
#include <cmath>
using namespace std;

long long fact(int x) {
    long long ans = 1;
    for (int i=2; i<=x; i++) {
        ans *= i;
        if (ans%10==0) ans /= 10;
    }
    return ans;
}
int main() {
    int arr[10000], i=0;
    while(cin >> arr[i]) i++;

    for (int j=0; j<i; j++) {
        int number_of_zero =  0, m=1;
        while (floor(arr[j]/pow(5, m))) {
            number_of_zero += floor(arr[j]/pow(5, m++));
        }
    
        int ans = log10(fact(arr[j]));
        cout << ans+number_of_zero+1<< endl;
    }
    return 0;

    return 0;
}