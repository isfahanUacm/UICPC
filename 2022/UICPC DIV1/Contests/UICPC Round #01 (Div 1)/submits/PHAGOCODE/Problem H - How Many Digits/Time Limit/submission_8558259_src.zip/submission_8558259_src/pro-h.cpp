#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

int main() {
    string x;
    vector<int> v;
    while(getline(cin, x)) {
        int temp = 0;
        for (int i = 0; i < x.length(); i++) {
            temp = temp * 10 + (x[i] - '0');
        }
        v.push_back(temp);
    }
    for (int j=0; j<v.size(); j++) {
        double sum = 0;
        for (int i=2; i<=v[j]; i++) {
            sum += log10(i);
        }
        int ans = sum;
        cout << ans+1 << endl;
    }
    return 0;
}