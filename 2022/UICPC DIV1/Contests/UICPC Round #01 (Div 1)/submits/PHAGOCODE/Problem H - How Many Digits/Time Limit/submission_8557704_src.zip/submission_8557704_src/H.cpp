#include <cmath>
#include <iostream>
using namespace std;

int main()
{
    int n;
    double counter;
    while (true)
    {
        cin >> n;
        if (cin.eof()) break;

        if (n == 0 || n == 1)
        {
            cout << 1 << '\n';
            continue;
        }

        counter = 0;
        for (int i = 2; i <= n; i++)
        {
            counter += log10(i);
        }
        cout << floor(counter) + 1 << '\n';
    }

    return 0;
}