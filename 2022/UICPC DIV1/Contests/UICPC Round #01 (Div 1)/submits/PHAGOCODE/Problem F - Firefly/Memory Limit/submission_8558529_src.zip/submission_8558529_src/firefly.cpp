#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, h;
    cin >> n >> h;
    int arr[h][n];
    for (int i=0; i<h; i++) {
        for (int j=0; j<n; j++) {
            arr[i][j] = 0;
        }
    }
    int ar[n];
    for (int i=0; i<n; i++) {
        cin >> ar[i];
    }
    for (int i=0; i<n; i++) {
        if (i%2 == 0) {
            for(int j=0; j<ar[i]; j++) {
                arr[h-j-1][i] = 1;
            }
        } else {
            for (int j=0; j<ar[i]; j++) {
                arr[j][i] = 1;
            }
        }
    }
    
    // for (int i=0; i<h; i++) {
    //     for (int j=0; j<n; j++) {
    //         cout << arr[i][j];
    //     }
    //     cout << endl;
    // }

    int harr[h],sum;
    for (int i=0; i<h; i++) {
        sum = 0;
        for (int j=0; j<n; j++) {
            sum += arr[i][j];
        }
        harr[i] = sum;
    }
    // for (int i=0; i<h; i++) {
    //     cout << harr[i] << " ";
    // } cout << endl;
    
    int min = harr[0], count = 1;
    for (int i=1; i<h; i++) {
        if (harr[i]<min) {
            min = harr[i];
            count = 0;
        } else if (harr[i] > min) continue;
        count++;
    }
    cout << min << " " << count << endl;
    return 0;
}