#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, h;
    cin >> n >> h;
    int arr[h];
    for (int i=0; i<h; i++) {
        arr[i] = 0;
    }
   
    int x = 0, sign = 1;
    while (x<n) {
        int num;
        cin >> num;
        
        if (sign>0) {
            for (int i=0; i<num; i++) {
                arr[h-i-1] += 1;
            }
        } else {
           for (int i=0; i<num; i++) {
               arr[i] += 1;
           }
        }
        
        sign *= -1;
        x++;
    }

    // for (int i=0; i<h; i++) {
    //     cout << arr[i] << " ";
    // }cout << endl;
    sort(arr, arr+h);
    int min = arr[0], count = 1;
    for (int i=1; i<h; i++) {
        if (arr[i] == min) count++;
        else break;
    }
    // int min = arr[0], count = 1;
    // for (int i=1; i<h; i++) {
    //     if (arr[i]<min) {
    //         min = arr[i];
    //         count = 0;
    //     } else if (arr[i] > min) continue;
    //     count++;
    // }
    cout << min << " " << count << endl;
    return 0;
}