import java.util.HashMap;
import java.util.Scanner;

public class Q1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<String, Integer> wrongs = new HashMap<>();
        int counter = 0;
        int time = 0;

        while (true) {
            String input = sc.nextLine();
            if (input.charAt(0) == '-') {
                break;
            }
            String[] divided = input.split(" ");
            wrongs.putIfAbsent(divided[1], 0);
            if (divided[2].equals("right")) {
                counter++;
                time += (Integer.parseInt(divided[0]) + wrongs.get(divided[1]) * 20);
            } else {
                wrongs.put(divided[1], wrongs.get(divided[1]) + 1);

            }
        }
        System.out.println(counter + " " + time);
    }
}
