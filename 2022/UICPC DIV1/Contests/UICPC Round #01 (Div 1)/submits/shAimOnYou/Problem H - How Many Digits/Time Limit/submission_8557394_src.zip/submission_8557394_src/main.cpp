#include <iostream>
#include <cmath>
using namespace std;

long long factorial(unsigned int n)
{
    if (n == 0)
        return 1;
    return n * factorial(n - 1);
}

int main()
{
    string line;
    while (getline(cin, line))
    {
        int a = stoi(line);
        a=log10(factorial(a))+1;
        cout << a << endl;
    }

    return 0;
}
