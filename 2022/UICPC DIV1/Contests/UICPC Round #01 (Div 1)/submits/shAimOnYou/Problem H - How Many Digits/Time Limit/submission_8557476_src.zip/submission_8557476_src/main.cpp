#include <iostream>
#include <cmath>
using namespace std;
int count_digits(int num){
    if (num < 0){
        return 0;
    }
    if (num <= 1){
        return 1;
    }

    double d = 0;
    for (int i=2; i<=num; i++){
        d += log10(i);
    }
    return floor(d) + 1;
}
int main(){
    string line;
    while (getline(cin, line))
    {
        int a = stoi(line);
        cout<<count_digits(a)<< endl;

    }
    return 0;
}
