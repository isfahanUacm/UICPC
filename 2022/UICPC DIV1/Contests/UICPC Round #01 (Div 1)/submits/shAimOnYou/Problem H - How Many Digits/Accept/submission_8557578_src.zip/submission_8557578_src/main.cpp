#include <iostream>
#include <cmath>
using namespace std;
#define _USE_MATH_DEFINES

long long stirling(int n){
    if(n==1 || n==0) return 1;
    return floor( ((n+0.5)*log(n) - n + 0.5*log(2*M_PI))/log(10) ) + 1;}

int main(){
    string line;
    while (getline(cin, line))
    {
        int a = stoi(line);
        cout<< stirling(a)<< endl;

    }
    return 0;
}
