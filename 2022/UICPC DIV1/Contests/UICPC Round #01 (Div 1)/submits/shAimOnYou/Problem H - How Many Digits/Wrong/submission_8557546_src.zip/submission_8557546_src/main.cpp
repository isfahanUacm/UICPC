#include <iostream>
#include <cmath>
using namespace std;
#define pi 3.14
long long stirling(int n){
    if(n==1 || n==0) return 1;
    return floor( ((n+0.5)*log(n) - n + 0.5*log(2*pi))/log(10) ) + 1;}

int main(){
    string line;
    while (getline(cin, line))
    {
        int a = stoi(line);
        cout<<stirling(a)<< endl;

    }
    return 0;
}
