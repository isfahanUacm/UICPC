#include <bits/stdc++.h>
using namespace std;


int main(){
    int n;
    cin >> n ;

    while (n--) {
        int sum=0;
        vector<int> a;
        int groups;
        cin >> groups;
        for(int i=0;i<3*groups;i++){
            int temp;
            cin >> temp;
           a.push_back(temp);
        }
         sort(a.begin(), a.end(), greater<int>());
         int i=1;
         int count = groups;
         while(count--){
             sum+=a[i];
             i+=2;
         }
         cout << sum << endl;
    }

    return 0;
}
