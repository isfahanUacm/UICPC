#include <bits/stdc++.h>
using namespace std;


int main(){
    int n;
    cin >> n ;

    while (n--) {
                            int sum=0;
        int groups;
        cin >> groups;
        for(int i=0;i<groups;i++){

            int a[3];
            cin >> a[0] >> a[1] >> a[2];

            int n = sizeof(a) / sizeof(a[0]);
            sort(a, a + n, greater<int>());
            sum+=a[1];

        }
            cout<< sum << endl;

    }

    return 0;
}
