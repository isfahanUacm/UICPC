n = int(input())
counter = 1
S = 0
numbers = []
for i in range(n):
    m = int(input())
    for val in input().split():
        if(counter % 3 == 0):
            numbers.remove(max(numbers))
            S += max(numbers)
            numbers.clear
        else:
            numbers.append(int(val))
        counter += 1
    print(S)
