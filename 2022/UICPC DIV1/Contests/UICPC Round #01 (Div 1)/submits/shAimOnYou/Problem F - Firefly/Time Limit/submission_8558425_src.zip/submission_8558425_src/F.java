import java.util.*;

public class F {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Integer> blocks = new ArrayList<>();
        int n = sc.nextInt();
        int m = sc.nextInt();
        int[] attempts = new int[m];
        for(int i=0; i<n; i++){
            blocks.add(sc.nextInt());
        }
        for(int i=0; i<m; i++){
            int count = 0;
            for(int j=0; j< n; j++){
                if(j % 2 == 0){
                    if(i<(m-blocks.get(j))){
                    }else{
                        count++;
                    }
                }else{
                    if(i>=blocks.get(j)){
                    }else{
                        count++;
                    }
                }
            }
            attempts[i] = count;
        }
        Arrays.sort(attempts);
        int min = attempts[0];
        int frequency = 0;
        for(int x: attempts){
            if(x == min){
                frequency++;
            }
        }
        System.out.println(min + " " + frequency);
    }
}
