#include <bits/stdc++.h>
using namespace std;


int main(){
    int obs,height;
    cin >> obs >> height;
    vector<int> heights;
    map<int,int> path;
    for(int i =1;i<=height;i++){
        path[i]=0;
    }

    for (int i =0;i<obs;i++){
        int a;
        cin >> a;
        heights.push_back(a);

    }
    vector<int> even,odd;

    for(int i=1;i<=heights.size();i++){
        if(i%2==1) odd.push_back(heights[i-1]);
        else {
            even.push_back(heights[i-1]);
        }
    }
    for(int i=1;i<=height;i++){
        for(auto x:odd){
            if(i<=x) path[i]++;
        }
        for(auto x : even){
            if(i>height-x)path[i]++;
        }
    }
    int min=99999;
    int count =0;
    int temp;
    for(auto x:path){
        if(x.second<min){
            min=x.second;
        }
    }
    for(auto x:path){
        if(x.second==min){
            count++;
        }
    }
    cout << min << " " << count;

    return 0;
}
