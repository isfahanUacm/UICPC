import java.util.*;

public class F {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int minimum = n;
        int frequencyMin = 1;
        int[] blocks = new int[n];
        for (int i = 0; i < n; i++) {
            blocks[i] = sc.nextInt();
        }
        for (int i = 0; i < m; i++) {
            int count = 0;
            for (int j = 0; j < n; j++) {
                if (j % 2 == 0) {
                    if (!(i < (m - blocks[j]))) count++;
                } else {
                    if (!(i >= blocks[j])) count++;
                }
            }
            if (minimum > count) {
                minimum = count;
                frequencyMin = 1;
            } else if (minimum == count) {
                frequencyMin++;
            }
        }
        System.out.println(minimum + " " + frequencyMin);
    }
}