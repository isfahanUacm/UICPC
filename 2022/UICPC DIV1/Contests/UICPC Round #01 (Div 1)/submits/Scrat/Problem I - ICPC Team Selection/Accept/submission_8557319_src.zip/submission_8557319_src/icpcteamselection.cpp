#include <iostream>
#include <algorithm>
using namespace std;
int dee(int x[],int n){
    sort(x,x+(3*n));
    int sum=0;
    for(int i=0;i<n;i++)
    sum+=x[3*n-2-(2*i)];
    return sum;
}
int main() {
    int m,n;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++) {
        cin >> m; int b[m*3];
        for(int j=0;j<3*m;j++) cin >> b[j];
        a[i]=dee(b, m);
        }
    for(int i=0;i<n;i++) cout << a[i]
        << endl;
    }
