#include <iostream>
#include <queue>
#include <string>
using namespace std;
int s[500001] = {0};
int p[500001] = {0};
int main() {
    int n, m;
    cin >> n 	>>m;
    int a[n];
    for(int i=0;i<n/2;i++)
    {
    	int f,h;
    	cin>>f>>h;
    	s[f] += 1;
    	p[h] += 1;
    }
    int tool[m];
    int cur =0;
    for(int i=m-1;i>=0	;i--) {
    	cur+= p[i+1];
    	tool[i] = cur;
    }
    cur = 0;
    int min = 5000010;
    int ind = 0;
    for(int i=0;i<m;i++) {
    	cur += s[m-i];
    	tool[i] += cur;
    	if(min > tool[i]) {
    		min = tool[i];
    		ind = i;
    	}
    }
    cout<< min<<" "<<ind + 2;
   	 
}