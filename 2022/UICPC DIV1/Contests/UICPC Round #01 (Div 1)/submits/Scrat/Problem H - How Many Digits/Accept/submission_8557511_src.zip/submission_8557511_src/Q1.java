import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Math.floor;
import static java.lang.Math.log10;

public class Q1 {
    static List<Integer> integers = new ArrayList<>();

    public static void init() {
        integers.add(1);
        integers.add(1);
        double a = 0.0;
        for (int i = 2; i <= 1000000; i++) {
            a += log10(i);
            integers.add( (int) (floor(a) + 1));
        }
    }

    public static void main(String[] args) {
        init();
        List<Integer> integerss = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            integerss.add(integers.get(scanner.nextInt()));

        }
        integerss.forEach(System.out::println);
    }

}
