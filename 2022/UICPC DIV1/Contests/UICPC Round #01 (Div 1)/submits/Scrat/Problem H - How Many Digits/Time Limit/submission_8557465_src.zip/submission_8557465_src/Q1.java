import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Math.floor;
import static java.lang.Math.log10;

public class Q1 {
    public static void main(String[] args) {
        List<Integer> integers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            integers.add(q(scanner.nextInt()));

        }
        integers.forEach(System.out::println);
    }

    public static int q(int n) {
        if (n == 0 || n == 1) return 1;
        double a = 0.0;
        for (int i = 2; i <= n; i++) a += log10(i);
        return (int) (floor(a) + 1);
    }

}
