import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Q1 {
    public static void main(String[] args) {
        Map<String, List<Odd>> map = new HashMap<>();
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        while (!line.equals("-1")) {
            String[] strings = line.split(" ");
            map.putIfAbsent(strings[1], new ArrayList<>());
            map.get(strings[1]).add(new Odd(Integer.parseInt(strings[0]), strings[2].equals("right")));
            line = scanner.nextLine();
        }
        AtomicInteger solved = new AtomicInteger();
        AtomicInteger time = new AtomicInteger();
        map.forEach((s, odds) -> {
            int t = 0;
            boolean flag = false;
            for (Odd odd : odds) {
                if (odd.status) {
                    flag = true;
                    t  = odd.time;
                }
            }
            if (flag) {
                time.addAndGet(t + 20 * (odds.size() - 1));
                solved.getAndIncrement();
            }
        });
        System.out.println("" + solved.get() + " " + time.get());
    }
    static class Odd {
        int time;
        boolean status;
        Odd(int time, boolean b) {
            status = b;
            this.time = time;
        }
    }
}
