#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool LoopersC(const pair<int, int>& a, const pair<int, int>& b) {
    return a.second < b.second;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> v(n);
    vector<pair<int, int>> v2;
    for (auto& i : v) cin >> i;
    sort(v.begin(), v.end());
    int a, b;
    cin >> a >> b;
    if (a % 2 == 0)
        a++;
    if (b % 2 == 0)
        b--;
    if (v[0] - a >= 0)
        v2.emplace_back(a, v[0] - a);
    if (b - v[n - 1] >= 0)
        v2.emplace_back(b, b - v[n - 1]);
    for (int i = 0; i < n - 1; i++) {
        int x = ((v[i] + v[i + 1]) / 2);
        if (x >= a && x <= b) {
            if ((x & 1)) {
                v2.emplace_back(x, v[i + 1] - x);
            } else {
                v2.emplace_back(x + 1, v[i + 1] - x - 1);
            }
        }
    }
    cout << max_element(v2.begin(), v2.end(), LoopersC)->first << '\n';
    return 0;
}