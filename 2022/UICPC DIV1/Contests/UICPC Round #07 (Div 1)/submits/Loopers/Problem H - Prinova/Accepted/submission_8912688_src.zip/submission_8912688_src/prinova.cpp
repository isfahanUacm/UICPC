#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long ll;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    ll n, ans, mx = 0;
    cin >> n;
    vector<ll> v(n);
    vector<ll> v2;
    for (auto& i : v) cin >> i;
    sort(v.begin(), v.end());
    ll a, b;
    cin >> a >> b;
    if (a % 2 == 0)
        a++;
    if (b % 2 == 0)
        b--;
    v2.push_back(a);
    v2.push_back(b);
    for (int i = 0; i < n - 1; i++) {
        ll x = (v[i] + v[i + 1]) / 2;
        if ((x & 1)) {
            v2.push_back(x);
        } else {
            v2.push_back(x + 1);
            v2.push_back(x - 1);
        }
    }
    for (const auto& i : v2) {
        if (i >= a && i <= b) {
            ll x = abs(v[0] - i);
            for (int j = 1; j < n; j++) {
                x = min(x, abs(v[j] - i));
            }
            if (x > mx) {
                ans = i;
                mx = x;
            }
        }
    }
    cout << ans << '\n';
    return 0;
}