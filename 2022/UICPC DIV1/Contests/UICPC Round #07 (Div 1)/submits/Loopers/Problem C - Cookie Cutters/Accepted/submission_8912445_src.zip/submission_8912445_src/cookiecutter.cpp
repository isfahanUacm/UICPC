#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<pair<double, double>> v;
    vector<pair<double, double>> v2;
    double x, y;
    for (int i = 0; i < n; i++) {
        cin >> x >> y;
        v.emplace_back(x, y);
    }
    double area = 0;
    int j = n - 1;
    for (int i = 0; i < n; i++) {
        area += (v[i].first + v[j].first) * (v[j].second - v[i].second);
        j = i;
    }
    area = abs(area) / 2;
    double area_;
    cin >> area_;
    double scale = sqrt(area_ / area);
    double a = 0, b = 0;
    for (const auto& i : v) {
        double t1, t2;
        t1 = i.first * scale;
        t2 = i.second * scale;
        v2.emplace_back(t1, t2);
        a = min(a, t1);
        b = min(b, t2);
    }
    for (const auto& i : v2) {
        cout << setprecision(5) << fixed << i.first - a << ' ' << i.second - b << '\n';
    }
    return 0;
}