#include <iostream>
#include <map>
#include <algorithm>
#include <vector>

using namespace std;

bool LoopersC(const pair<string, int>& a, const pair<string, int>& b) {
    return a.second < b.second;
}

int main() {
    int n;
    cin >> n;
    map<string, int> m;
    while (n--) {
        string s, w;
        vector<string> v;
        for (int i = 0; i < 5; i++) {
            cin >> s;
            v.push_back(s);
        }
        sort(v.begin(), v.end());
        for (const auto& i : v)
            w += i;
        m[w]++;
    }
    int ans = 0;
    int mx = max_element(m.begin(), m.end(), LoopersC)->second;
    for (const auto& i : m) {
        if (i.second == mx)
            ans += i.second;
    }
    cout << ans << '\n';
}