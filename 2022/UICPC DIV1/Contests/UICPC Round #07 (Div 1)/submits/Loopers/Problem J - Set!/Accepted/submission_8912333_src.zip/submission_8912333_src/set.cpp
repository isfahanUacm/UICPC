#include <iostream>
#include <vector>

using namespace std;

bool is_set(const string& x, const string& y, const string& z) {
    for (int i = 0; i < 4; i++) {
        if ((x[i] != y[i] || y[i] != z[i]) && (x[i] == y[i] || x[i] == z[i] || y[i] == z[i]))
            return false;
    }
    return true;
}

int main() {
    vector<string> v(12);
    string s;
    bool f = true;
    for (auto& i : v) cin >> i;
    for (int i = 0; i < 12; i++) {
        for (int j = i + 1; j < 12; j++) {
            for (int k = j + 1; k < 12; k++) {
                if (is_set(v[i], v[j], v[k])) {
                    cout << i + 1 << ' ' << j + 1 << ' ' << k + 1 << '\n';
                    f = false;
                }
            }
        }
    }
    if (f) cout << "no sets\n";
    return 0;
}