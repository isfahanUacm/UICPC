import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static int max;
    public static ArrayList<Delivery> pos = new ArrayList<>();
    public static ArrayList<Delivery> neg = new ArrayList<>();

    public static void main(String[] args) {
        int rep = sc.nextInt();
        max = sc.nextInt();
        for (int i = 0; i < rep; i++) {
            new Delivery(sc.nextInt(), sc.nextInt());
        }
        Collections.sort(pos);
        Collections.sort(neg);

        opt(pos);
        opt(neg);

        long ans = cal(pos) + cal(neg);
        System.out.println(ans);
    }
    static void opt(ArrayList<Delivery> list){
        int totalCap = 0;
        for (int i = 0; i < list.size(); i++) {
            totalCap -= list.get(i).giveLetters(totalCap);
            totalCap += list.get(i).cap();
        }
    }

    static long cal(ArrayList<Delivery> list){
        long sum = 0;
        for (int i = 0; i < list.size(); i++) {
            long noGo = (int) Math.ceil(list.get(i).noLetters / (double)max);
            sum += 2 * noGo * list.get(i).loc;
        }
        return sum;
    }
}

class Delivery implements Comparable{
    public Delivery(int loc, int noLetters) {
        if(loc > 0)
            Main.pos.add(this);
        else
            Main.neg.add(this);

        this.loc = Math.abs(loc);
        this.noLetters = noLetters;
    }

    int loc;
    int noLetters;

    int cap(){
        int cap =  Main.max - (noLetters  % Main.max);
        if(cap < Main.max){
            return cap;
        }
        else return 0;
    }

    @Override
    public int compareTo(Object o) {
        return Integer.compare(((Delivery)o).loc, this.loc);
    }

    @Override
    public String toString() {
        return loc + " " + noLetters;
    }

    int giveLetters(int totalCap){
        int remain = noLetters % Main.max;
        int useCap = 0;
        if(remain != 0 && remain <= totalCap){
            this.noLetters -= remain;
            useCap = remain;
        }
        return useCap;
    }
}