import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Dive1_7_3 {
    ;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int n = sc.nextInt();
        ArrayList<P> points = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double x = sc.nextDouble();
            double y = sc.nextDouble();
            P point = new P(x, y);
            points.add(point);
        }
        double newEara = sc.nextDouble();
        double eara = polygonArea(points);
        double s = Math.sqrt(newEara / eara);

        ArrayList<Double> x = new ArrayList<>();
        ArrayList<Double> y = new ArrayList<>();

        for (int i = 0; i < points.size(); i++) {
            x.add(points.get(i).x * s);
            y.add(points.get(i).y * s);
        }
        double minX = Collections.min(x);
        double minY = Collections.min(y);

        for (int i = 0; i < points.size(); i++) {
            System.out.println((x.get(i) - minX) + " " + (y.get(i) - minY));
        }
    }

    public static double polygonArea(ArrayList<P> points) {
        double sum = 0;
        for (int i = 0; i < points.size(); i++) {
            if (i == 0) {
                sum += points.get(i).x * (points.get(i + 1).y - points.get(points.size() - 1).y);
            } else if (i == points.size() - 1) {
                sum += points.get(i).x * (points.get(0).y - points.get(i - 1).y);
            } else {
                sum += points.get(i).x * (points.get(i + 1).y - points.get(i - 1).y);
            }
        }

        double area = 0.5 * Math.abs(sum);
        return area;
    }

}


class P {
    public P(double x, double y) {
        this.x = x;
        this.y = y;
    }

    double x;
    double y;
}