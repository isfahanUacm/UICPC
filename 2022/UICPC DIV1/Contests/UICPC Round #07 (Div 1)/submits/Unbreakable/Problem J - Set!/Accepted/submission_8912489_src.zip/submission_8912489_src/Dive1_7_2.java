import java.util.ArrayList;
import java.util.Scanner;

public class Dive1_7_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> card = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                card.add(sc.next());
            }
        }

        boolean check = false;

        for (int i = 0; i < 12; i++) {
            for (int j = i + 1; j < 12; j++) {
                for (int k = j + 1; k < 12; k++) {
                    boolean is = true;
                    for (int d = 0; d < 4; d++) {
                        if (!((card.get(i).charAt(d) == card.get(j).charAt(d)) && (card.get(j).charAt(d) == card.get(k).charAt(d))) && !((card.get(i).charAt(d) != card.get(j).charAt(d)) && (card.get(i).charAt(d) != card.get(k).charAt(d)) && (card.get(j).charAt(d) != card.get(k).charAt(d)))) {
                            is = false;
                        }
                    }
                    if (is) {
                        System.out.println((i + 1) + " " + (j + 1) + " " + (k + 1));
                        check = true;
                    }
                }
            }
        }
        if (!check) {
            System.out.println("no sets");
        }

    }
}
