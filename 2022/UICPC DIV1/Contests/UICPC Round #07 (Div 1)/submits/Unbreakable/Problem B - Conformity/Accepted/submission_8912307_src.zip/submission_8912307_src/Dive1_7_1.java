import java.util.*;

public class Dive1_7_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), max = 0, ans = 0;
        HashMap<ArrayList<Integer>, Integer> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            ArrayList<Integer> course = new ArrayList<>();
            for (int j = 0; j < 5; j++) {
                course.add(sc.nextInt());
            }
            Collections.sort(course);

            if (map.containsKey(course)) {
                map.put(course, map.get(course) + 1);
            } else {
                map.put(course, 1);
            }

            if (map.get(course) > max) {
                max = map.get(course);
            }
        }

        for (Map.Entry<ArrayList<Integer>, Integer> entry : map.entrySet()) {
            if (entry.getValue() == max) {
                ans += entry.getValue();
            }
        }

        System.out.println(ans);

    }
}