#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int n, w, h, l;
char mp[10][10];
pair<int, int> hh;

struct s {
    pair<int, int> p[4];

    bool operator < (s const &a) {
        return true;
    }
};

ll ans = INT_MAX;
ll dp[10][10][10][10][10][10][10][10];

// 0 1 2 3
// u d l r

bool ir(int x, int y) {
    return x >= 0 && x < h && y >= 0 && y < w;
}

pair<int, int> next_place(pair<int, int> place, int mv) {
    if (mv == 0) {
        int ny = place.second;
        while (ir(place.first, ny - 1) && (mp[place.first][ny - 1] == '.' || mp[place.first][ny - 1] == 'X'))
            ny--;
        return {place.first, ny};
    }

    if (mv == 1) {
        int ny = place.second;
        while (ir(place.first, ny + 1) && (mp[place.first][ny + 1] == '.' || mp[place.first][ny + 1] == 'X'))
            ny++;
        return {place.first, ny};
    }

    if (mv == 2) {
        int nx = place.first;
        while (ir(nx - 1, place.second) && (mp[nx - 1][place.second] == '.' || mp[nx - 1][place.second] == 'X'))
            nx--;
        return {nx, place.second};
    }

    if (mv == 3) {
        int nx = place.first;
        while (ir(nx + 1, place.second) && (mp[nx + 1][place.second] == '.' || mp[nx + 1][place.second] == 'X'))
            nx++;
        return {nx, place.second};
    }
}

void pc(s current) {
    for (int i = 0; i < n; ++i) {
        cout << current.p[i].first << ' ' << current.p[i].second << endl;
    }
    cout << "______________________" << endl;
}

void dfs(ll step, s current) {
    int x1 = (n >= 1) ? current.p[0].first : 0;
    int x2 = (n >= 2) ? current.p[1].first : 0;
    int x3 = (n >= 3) ? current.p[2].first : 0;
    int x4 = (n >= 4) ? current.p[3].first : 0;

    int y1 = (n >= 1) ? current.p[0].second : 0;
    int y2 = (n >= 2) ? current.p[1].second : 0;
    int y3 = (n >= 3) ? current.p[2].second : 0;
    int y4 = (n >= 4) ? current.p[3].second : 0;

    if (dp[x1][y1][x2][y2][x3][y3][x4][y4] != -1 && dp[x1][y1][x2][y2][x3][y3][x4][y4] <= step)
        return;

    if (step > l)
        return;

    for (int i = 0; i < n; ++i) {
        pair<int, int> ith_current = current.p[i];

        for (int j = 0; j <= 3; ++j) {
            pair<int, int> ith_moved = next_place(ith_current, j);
            if (ith_current == ith_moved)
                continue;

            current.p[i] = ith_moved;
            swap(mp[ith_current.first][ith_current.second], mp[ith_moved.first][ith_moved.second]);

            if (current.p[0] == hh) {
                ans = min(ans, step);
            }
            else {
                dfs(step + 1, current);
            }

            swap(mp[ith_current.first][ith_current.second], mp[ith_moved.first][ith_moved.second]);
        }
        current.p[i] = ith_current;
    }
    dp[x1][y1][x2][y2][x3][y3][x4][y4] = step;
}


int main() {
    memset(dp, -1, sizeof(dp));
    cin >> n >> w >> h >> l;
    s current;

    for (int i = 0; i < h; ++i) {
        for (int j = 0; j < w; ++j) {
            cin >> mp[i][j];

            if (isdigit(mp[i][j])) {
                current.p[mp[i][j] - '1'] = {i, j};
            }

            if (mp[i][j] == 'X') {
                mp[i][j] = '.';
                hh = {i, j};
            }
        }
    }

    dfs(1,  current);
    if (ans == INT_MAX)
        cout << "NO SOLUTION" << endl;
    else
        cout << ans << endl;
}


//pair<int, int> next_place(pair<int, int> place, int mv) {
//    if (mv == 0) {
//        int ny = place.second;
//        while (ir(place.first, ny - 1) && (mp[place.first][ny - 1] == '.' || mp[place.first][ny - 1] == 'X'))
//            ny--;
//        return {place.first, ny};
//    }
//
//    if (mv == 1) {
//        int ny = place.second;
//        while (ir(place.first, ny + 1) && (mp[place.first][ny + 1] == '.' || mp[place.first][ny + 1] == 'X'))
//            ny++;
//        return {place.first, ny};
//    }
//
//    if (mv == 2) {
//        int nx = place.first;
//        while (ir(nx - 1, place.second) && (mp[nx - 1][place.second] == '.' || mp[nx - 1][place.second] == 'X'))
//            nx--;
//        return {nx, place.second};
//    }
//
//    if (mv == 3) {
//        int nx = place.first;
//        while (ir(nx + 1, place.second) && (mp[nx + 1][place.second] == '.' || mp[nx + 1][place.second] == 'X'))
//            nx++;
//        return {nx, place.second};
//    }
//}
