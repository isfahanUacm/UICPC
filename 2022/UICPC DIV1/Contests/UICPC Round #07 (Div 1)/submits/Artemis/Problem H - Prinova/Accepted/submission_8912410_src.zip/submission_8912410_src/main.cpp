#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

bool valid(ll x, ll a, ll b, ll l, ll r) {
    return x % 2 == 1 && x >= a && x <= b && x >= l && x <= r;
}

pair<ll, ll> calc(ll a, ll b, ll l, ll r) {
    if (l == r && l % 2 == 0)
        return {-1, INT_MIN};

    if (a == b && a % 2 == 0)
        return {-1, INT_MIN};

    if (l > b || (l == b && b % 2 == 0) || r < a || (r == a && a % 2 == 0))
        return {-1, INT_MIN};

    ll ans = INT_MIN;
    ll ah = -1;
    ll mid = (a + b) / 2;


    for (int i = -1; i <= 1; ++i) {
        if (valid((mid + i), a, b, l, r)) {
            ll temp = min(abs(a - (mid + i)), abs(b - (mid + i)));
            if (ans < temp) {
                ans = temp;
                ah = mid + i;
            }
        }

        if (valid((r + i), a, b, l, r)) {
            ll temp = min(abs(a - (r + i)), abs(b - (r + i)));
            if (ans < temp) {
                ans = temp;
                ah = r + i;
            }
        }

        if (valid((l + i), a, b, l, r)) {
            ll temp = min(abs(a - (l + i)), abs(b - (l + i)));
            if (ans < temp) {
                ans = temp;
                ah = l + i;
            }
        }
    }
    return {ans, ah};
}

int main() {
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    sort(arr, arr + n);

    int l, r;
    cin >> l >> r;

    ll ans = INT_MIN;
    ll ah = -1;

    for (int i = 0; i <= 1; ++i) {
        int nl = l + i;
        if (nl % 2 == 1) {
            int dist = INT_MAX;
            for (int j = 0; j < n; ++j) {
                dist = min(dist, abs(arr[j] - nl));
            }
            if (ans < dist) {
                ans = dist;
                ah = nl;
            }
        }

        int nr = r - i;
        if (nr % 2 == 1) {
            int dist = INT_MAX;
            for (int j = 0; j < n; ++j) {
                dist = min(dist, abs(arr[j] - nr));
            }
            if (ans < dist) {
                ans = dist;
                ah = nr;
            }
        }
    }

    for (int i = 0; i < n - 1; ++i) {
        auto temp = calc(arr[i], arr[i + 1], l, r);
        if (temp.second == -1)
            continue;
        if (ans < temp.first) {
            ans = temp.first;
            ah = temp.second;
        }
    }

    cout << ah << endl;
}
