#include<bits/stdc++.h>
using namespace std;
int n;
double polygonArea(double X[], double Y[])
{
    double area=0.0;
    int j=n-1;
    for (int i=0;i<n;i++){
        area+=(X[j]+X[i])*(Y[j]-Y[i]);
        j=i;  
    }
    return abs(area/2.0);
}
int main(){
    cin>>n;
    double x[n],y[n],desire,add,min_x=0,min_y=0;
    for(int i=0;i<n;i++) cin>>x[i]>>y[i];
    double area=polygonArea(x,y);
    cin>>desire;
    add=desire/area;
    add=sqrt(add);
    for(int i=0;i<n;i++){
        x[i]*=add;
        y[i]*=add;
        min_x=min(min_x,x[i]);
        min_y=min(min_y,y[i]);
    }
    for(int i=0;i<n;i++){
        x[i]-=min_x;
        y[i]-=min_y;
    }
    for(int i=0;i<n;i++)   printf("%.7f %.7f\n",x[i],y[i]);

    return 0;
}