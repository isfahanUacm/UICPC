#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


int main() {
    int n;
    cin >> n;
    map<string, int> mp;

    for (int i = 0; i < n; ++i) {
        string arr[5];
        for (auto & j : arr) {
            cin >> j;
        }
        sort(arr, arr + 5);
        string a = arr[0] + arr[1] + arr[2] + arr[3] + arr[4];
        mp[a]++;
    }

    int mx = 1;
    for (const auto& x : mp) {
        mx = max(mx, x.second);
    }

    int ans = 0;
    for (const auto& x : mp) {
        if (x.second == mx)
            ans += x.second;
    }

    cout << ans << endl;
}
