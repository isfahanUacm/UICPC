#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int n, k;
ll ans = 0;
set<pair<int, int>> fb;
bitset<10> visited;

void BF(int p, int c) {
    if (c == n && fb.count({p, 0}) == 0) {
        ans++;
        return;
    }

    for (int i = 1; i < n; ++i) {
        if (fb.count({p, i}) > 0)
            continue;
        if (visited[i])
            continue;
        if (i == p)
            continue;

        visited[i] = true;
        BF(i, c + 1);
        visited[i] = false;
    }
}

int main() {
    int tc;
    cin >> tc;
    for (int j = 1; j <= tc; ++j) {

        cin >> n >> k;

        for (int i = 0; i < k; ++i) {
            int u, v;
            cin >> u >> v;
            u--;
            v--;
            fb.emplace(u, v);
            fb.emplace(v, u);
        }
        visited[0] = true;
        BF(0, 1);
        cout << "Case #" << j << ": " << (ans / 2) % 9901 << endl;

        fb.clear();
        visited.reset();
        ans = 0;
    }
}
