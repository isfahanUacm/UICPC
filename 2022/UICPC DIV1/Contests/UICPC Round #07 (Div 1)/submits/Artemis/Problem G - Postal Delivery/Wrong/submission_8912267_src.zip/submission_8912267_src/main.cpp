#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


int main() {
    ll n, k;
    cin >> n >> k;
    vector<pair<ll, ll>> pos, neg;

    for (ll i = 0; i < n; ++i) {
        ll t1, t2;
        cin >> t1 >> t2;
        if (t1 < 0)
            neg.emplace_back(t1, t2);
        else
            pos.emplace_back(t1, t2);
    }

    ll dist = 0;
    while (!pos.empty()) {
        ll c = k;
        dist += pos.back().first * 2;
        while (!pos.empty() && c != 0) {
            ll mi = min(c, pos.back().second);
            c -= mi;
            pos.back().second -= mi;

            if (pos.back().second == 0)
                pos.pop_back();
        }
    }


    while (!neg.empty()) {
        ll c = k;
        dist += abs(neg.back().first * 2);
        while (!neg.empty() && c != 0) {
            ll mi = min(c, neg.back().second);
            c -= mi;
            neg.back().second -= mi;

            if (neg.back().second == 0)
                neg.pop_back();
        }
    }

    cout << dist << endl;
}
