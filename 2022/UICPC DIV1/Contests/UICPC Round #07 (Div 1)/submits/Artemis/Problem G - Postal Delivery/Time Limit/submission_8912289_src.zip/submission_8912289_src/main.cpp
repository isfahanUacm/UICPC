#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


int main() {
    ll n, k;
    cin >> n >> k;
    vector<pair<ll, ll>> pos, neg;

    for (ll i = 0; i < n; ++i) {
        ll t1, t2;
        cin >> t1 >> t2;
        if (t1 < 0)
            neg.emplace_back(t1, t2);
        else
            pos.emplace_back(t1, t2);
    }

    sort(neg.begin(), neg.end(), greater<>());
    sort(pos.begin(), pos.end());


    ll dist = 0;
    while (!pos.empty()) {
        ll c = k;
        dist += pos.back().first * 2;
        for (int i = pos.size() - 1; i >= 0 && c != 0; --i) {
            ll mi = min(c, pos[i].second);
            c -= mi;
            pos[i].second -= mi;
        }

        vector<pair<ll, ll>> nvc;
        for (auto x : pos) {
            if (x.second != 0)
                nvc.emplace_back(x);
            pos = nvc;
        }
    }


    while (!neg.empty()) {
        ll c = k;
        dist += abs(neg.back().first * 2);
        for (int i = neg.size() - 1; i >= 0 && c != 0; --i) {
            ll mi = min(c, neg[i].second);
            c -= mi;
            neg[i].second -= mi;
        }

        vector<pair<ll, ll>> nvc;
        for (auto x : neg) {
            if (x.second != 0)
                nvc.emplace_back(x);
            neg = nvc;
        }
    }

    cout << dist << endl;
}
