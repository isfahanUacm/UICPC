N, K = map(int,input().split())
seats = [[[-1,-1] for i in range(N+1)] for j in range(K+2)]
#print(seats)
inp = list(map(int,input().split()))
num = inp[0]
firstList = []
for step in range(num):
    p = inp[step+1]
    s = inp[step+1+num]
    firstList.append([p,s])
    '''for i in range(N+1):
        seats[j][i]=max(seats[j][i],seats[j-1][i])'''
firstList.sort()
#print(firstList)
for ticket in firstList:
    for i in range(N+1):
        if i+s<=N:
            if (p*s)>seats[1][i+s][0]:
                seats[1][i+s] = [p*s,p]
        else:
            ss = N-i
            if (p*ss)>seats[1][i+ss][0]:
                seats[1][i+ss] = [p*ss,p]
                
for j in range(2,K+2):
    inp = list(map(int,input().split()))
    num = inp[0]
    for step in range(num):
        p = inp[step+1]
        s = inp[step+1+num]
        '''for i in range(N+1):
            seats[j][i]=max(seats[j][i],seats[j-1][i])'''
        for i in range(N+1):
            if i+s<=N:
                if seats[j-1][i][0]!=-1 and (seats[j-1][i][0]+(p*s))>(seats[j][i+s][0]):
                    seats[j][i+s][0]=seats[j-1][i][0]+(p*s)
                    seats[j][i+s][1]=seats[j-1][i][1]
            else:
                ss = N-i
                if seats[j-1][i][0]!=-1 and (seats[j-1][i][0]+(p*ss))>(seats[j][i+ss][0]):
                    seats[j][i+ss][0]=seats[j-1][i][0]+(p*ss)
                    seats[j][i+ss][1]=seats[j-1][i][1]
maP = -1
maPf = -1
for i in range(N,-1,-1):
    if seats[K+1][i][0]>maP:
        maP = seats[K+1][i][0]
        maPf = seats[K+1][i][1]
print(maP)
print(maPf)