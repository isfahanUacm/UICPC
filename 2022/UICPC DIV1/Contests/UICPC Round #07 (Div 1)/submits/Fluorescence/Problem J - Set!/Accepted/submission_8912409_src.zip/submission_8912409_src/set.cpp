#include <bits/stdc++.h>
using namespace std;
vector<string> arr;
int ans[560+5][3+5];

int compare(char a, char b, char c){
    if(a==b && b==c) return 0;
    if(a!=b && a!=c && b!=c) return 1;
    return 2;
}
int compare2 ( const void *pa,const void *pb)
{
    int *a = (int*)pa;
    int *b = (int*)pb;
    if(a[0] == b[0]){
        if(a[1] == b[1]){
            return a[2] - b[2];
        }
        return a[1] - b[1];
    }
    else
        return a[0] - b[0];
}
int main(){
    for (int i = 0; i < 12; i++)
    {
        string s; cin>>s;
        arr.push_back(s); //id zero base
    }
    
    int indx=0;
    for (int i = 0; i < 12; i++)
    {
        for (int x = i+1; x < 12; x++)
        {
            for (int p = x+1; p < 12; p++)
            {
                bool flag = true;
                for(int w=0; w<4; w++){
                    if(compare(arr[i][w], arr[x][w], arr[p][w]) == 2){
                        flag = false;
                        break;
                    }
                }
                if(flag){
                    ans[indx][0] = i+1;
                    ans[indx][1] = x+1;
                    ans[indx][2] = p+1;
                    indx++;
                }
            }
            
            
        }
        
    }
    
    if(indx==0){
        cout<<"no sets";
        return 0;
    }
    
    
    qsort(ans, indx, sizeof ans[0] ,compare2);

    for (int i = 0; i < indx; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout<<ans[i][j] << " ";
        }
        cout<<endl;
    }
    
}