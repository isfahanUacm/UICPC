def one2one (s1,s2,n):
    check = ['?' for i in range(26)]
    totalN = 0
    for i in range(n):
        ch1 = s1[i]
        if ch1=='?': continue
        ch2 = s2[i]
        idx = ord(ch1)-ord('a')
        if check[idx]=='?': 
            check[idx]=ch2
            totalN+=1
        elif check[idx]==ch2:
            continue
        else:
            return False,check
    if totalN==25:
        for i in range(26):
            if chr(i+ord('a')) not in check:
                theChr = chr(i+ord('a'))
            if check[i]=='?':
                theIdx = i
        check[theIdx]=theChr
    return True,check

for _T in range(int(input())):
    nEn = int(input())
    lEn = []
    for i in range(nEn):
        s = input()
        lEn.append(s)
    dec = input()
    lenDec = len(dec)
    check = []
    trueEns = []
    fFlag = False
    for en in lEn:
        lenEn = len(en)
        if lenEn!=lenDec: 
            continue
        flag, check = one2one(dec, en, lenDec)
        if not(flag): 
            continue
        flag, check = one2one(en, dec, lenDec)
        if not(flag): 
            continue
        else:
            fFlag=True
            trueEns.append(en)
    if not(fFlag):
        print("IMPOSSIBLE")
        msg=input()
        continue
    fEn = list(trueEns[0])
    for i in range(1,len(trueEns)):
        en = list(trueEns[i])
        for ich in range(len(en)):
            if fEn[ich]!=en[ich]: 
                fEn[ich]='?'
    finalEn = ''.join(fEn)
    flag,check = one2one(fEn, dec, lenDec)
    res = ""
    msg=input()
    for ch in msg:
        idx = ord(ch)-ord('a')
        res += check[idx]
    print(res)