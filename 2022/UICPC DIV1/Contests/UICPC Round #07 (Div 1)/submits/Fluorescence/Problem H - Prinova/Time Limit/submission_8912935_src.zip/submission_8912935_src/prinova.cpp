#include <bits/stdc++.h>
using namespace std;
int p[100+5];

int main(){
    int n; cin>>n;
    for (int i = 0; i < n; i++)
    {
        cin>>p[i];
    }
    int a, b; cin>>a>>b;
    
    sort(p, p+n);
    if(a%2 == 0) a++;
    if(b%2 == 0) b--;

    int ans ;
    int func = -1;
    for (int x = a; x <= b; x+=2)
    {
        int y = lower_bound(p, p+n , x) - p;
        int func1 = INT_MAX, func2 = INT_MAX;
        if(y==n){
            ans = b;
            break;
        }
        if(y != n){
           func1 = abs(p[y]-x); 
        }
        if(y != 0){
            func2 = abs(p[y-1]-x);
        }

        if(min(func1, func2) > func){
            func = min(func1, func2);
            ans = x;
        }

    }
    cout<<ans;
    
    
}