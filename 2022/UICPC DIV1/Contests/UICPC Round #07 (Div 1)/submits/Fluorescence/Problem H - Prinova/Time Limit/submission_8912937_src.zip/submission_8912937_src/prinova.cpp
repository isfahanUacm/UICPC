#include <bits/stdc++.h>
using namespace std;
int p[100+5];

int main()
{
    int maaxi = 1000000009;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n; cin>>n;
    for (int i = 0; i < n; i++)
    {
        cin>>p[i];
    }
    int a, b; cin>>a>>b;
    
    sort(p, p+n);
    if(a%2 == 0) a++;

    int ans ;
    int func = -1;
    for (int x = a; x <= b; x+=2)
    {
        int y = lower_bound(p, p+n , x) - p;
        int func1 = maaxi, func2 = maaxi;
        if(y != n){
           func1 = abs(p[y]-x); 
        }
        if(y){
            func2 = abs(p[y-1]-x);
        }
        int mi = min(func1, func2);
        if(mi > func)
        {
            func = mi;
            ans = x;
        }

    }
    cout<<ans;
    
    
}