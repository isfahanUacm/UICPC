#include <bits/stdc++.h>
using namespace std;
int n, a, b, p[100+5];
int solve(int x){
    int ans = INT_MAX;
    for (int i = 0; i < n; i++)
    {
        ans = min(ans,
                abs(x-p[i]));
    }
    return ans;
    
}
int main(){
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        cin>>p[i];
    }
    cin>>a>>b;

    int f = a, 
        l = b,
        final = -1;

    while (f < l)
    {

        int mid = (f+l)/2 + 1;
        int ans = solve(mid);
        if(ans >= final){
            final = ans;
            f = mid;
        }
        else{
            l = mid-1;
        }

    }
    int ans = -1;
    int f2 = f;
    if(f%2 == 0){
        
        if(f-1 >= a && f-1 <= b){
            ans = solve(f-1);
            f2 = f-1;
        }
        if(f+1 >= a && f+1 <= b){
            if(solve(f+1) > ans){
                f2= f+1;
            }
        }

    }
    cout<<f2;
}