#include <bits/stdc++.h>
using namespace std;
bool adj[10+5][10+5];
int n;
int Count;

void solve(int mask, int pre){
    if(mask == (1<<n)-1){
        if(adj[pre][0]){
            Count++;
        }
        return;
    }
    for (int i = 0; i < n; i++)
    {
        if(i != pre && adj[pre][i] && !(mask&(1<<i))){
            solve(mask|(1<<i) , i);
        }
    }
    
}

int main(){
    int tc; cin>>tc;
    for(int TC=1; TC<=tc; TC++)
    {
        int k;
        cin>>n>>k;
        memset(adj, true, sizeof adj);
        while (k--)
        {
            int x, y; cin>>x>>y;
            x--, y--;
            adj[y][x] = adj[x][y] = false;
        }
        Count = 0;
        solve(1, 0);
        cout<<"Case #"<<TC<<": "<<(Count/2)%9901<<endl;
    }
    
}