#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

int main () {
   map<set<int>, int> mp;
   set<set<int>> qu;
   int n, x;
   cin>>n;
   int mx = 1;
   for (int i = 0; i < n; i++){
      set<int> s;
      for (int j = 0; j < 5; j++){
         cin>>x;
         s.insert(x);
      }
      qu.insert(s);
      if (mp.count(s)) mx = max(mx, ++mp[s]);
      else mp[s] = 1;
   }
   int cnt = 0, sum = 0, res;
   for(auto q:qu){
      if(mp[q] == mx) {
         cnt++;
         sum += mp[q];
         res = mp[q];
      }
   }
   if (cnt== 1) cout<<res<<endl;
   else cout<<sum<<endl;
}