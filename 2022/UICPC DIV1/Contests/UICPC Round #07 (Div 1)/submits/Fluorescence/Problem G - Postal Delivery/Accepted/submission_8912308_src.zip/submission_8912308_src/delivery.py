import math
N, K = map(int,input().split())
stationsPos = []
stationsNeg = []
numNeg = 0
numPos = 0
for i in range(N):
    dist, cap = map(int,input().split())
    if dist<0:
        stationsNeg.append([-1*dist,cap])
        numNeg+=1
    else:
        stationsPos.append([dist,cap])
        numPos+=1

stationsNeg.sort()
stationsNeg.reverse()
stationsPos.sort()
stationsPos.reverse()

totalDist = 0

i =0
remain = 0

while(i<numNeg):
    if (stationsNeg[i][1]<0):
        i+=1
        continue
    totalDist += math.ceil(stationsNeg[i][1]/K)*(stationsNeg[i][0]*2)
    remain = K - stationsNeg[i][1]%K
    if remain==K: remain=0
    j = i+1
    while(j<numNeg and remain>0):
        if remain>stationsNeg[j][1]:
            remain-=stationsNeg[j][1]
            stationsNeg[j][1]=0
            j+=1
        else:
            stationsNeg[j][1]-=remain
            remain=0
    i = j

i =0
remain = 0

while(i<numPos):
    if (stationsPos[i][1]<0):
        i+=1
        continue
    totalDist += math.ceil(stationsPos[i][1]/K)*(stationsPos[i][0]*2)
    remain = K - stationsPos[i][1]%K
    if remain==K: remain=0
    j = i+1
    while(j<numPos and remain>0):
        if remain>stationsPos[j][1]:
            remain-=stationsPos[j][1]
            stationsPos[j][1]=0
            j+=1
        else:
            stationsPos[j][1]-=remain
            remain=0
    i = j

print(totalDist)