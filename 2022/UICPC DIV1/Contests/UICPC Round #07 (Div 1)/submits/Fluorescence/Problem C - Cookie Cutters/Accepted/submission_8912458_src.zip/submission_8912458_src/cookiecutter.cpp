#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;

int main(){
    int c, a;
    vector<pair<double, double>> v;
    cin>>c;
    double x, y;
    for (int i = 0; i < c; ++i) {
        cin>>x>>y;
        v.push_back({x, y});
    }
    v.push_back(v[0]);
    cin>>a;

    double area = 0;
    for (int i = 0; i < c; ++i) {
        area += ((v[i].second + v[i+1].second)/2)*(v[i+1].first - v[i].first);
    }

    area = abs(area);
    double k = sqrt(a/area);
    v.pop_back();
    double minx = 1000, miny = 1000;
    for (int i = 0; i < c; ++i) {
        v[i].second *= k;
        v[i].first *= k;
        minx = min(minx, v[i].first);
        miny = min(miny, v[i].second);
    }
    for (int i = 0; i < c; ++i) {
        v[i].first -= minx;
        v[i].second -= miny;
    }
    for (int i = 0; i < c; ++i) {
        cout<<fixed<<setprecision(11)<<v[i].first<<" "<<v[i].second<<endl;
    }
}