from collections import Counter


def last_nonzero(lst):
    for i, value in enumerate(reversed(lst)):
        if value != 0:
            return (len(lst)-i-1), value
    return -1, None


n = int(input())

freq = [0] * (n + 1)
courses = Counter()
for i in range(n):
    line = sorted(list(map(int, input().split())))
    hash_key = tuple(line)

    courses[hash_key] += 1
    freq[courses[hash_key]] += 1
    freq[courses[hash_key]-1] -= 1

last = last_nonzero(freq)
print(last[0]*last[1])
