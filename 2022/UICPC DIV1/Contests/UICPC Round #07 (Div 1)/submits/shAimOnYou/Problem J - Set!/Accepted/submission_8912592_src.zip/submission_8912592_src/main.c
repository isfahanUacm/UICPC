#include <stdio.h>

int check(const char *s1, const char *s2, const char *s3)
{
    for (int x = 0; x < 4; x++)
    {
        if (!(s1[x] == s2[x] && s2[x] == s3[x]) && !(s1[x] != s2[x] && s1[x] != s3[x] && s2[x] != s3[x]))
            return 0;
    }
    return 1;
}

int main()
{
    char sets[12][5];
    for (int i = 0; i < 12; i++)
        scanf("%s", sets[i]);
    int found = 0;
    for (int i = 0; i < 12; i++)
    {
        for (int j = i + 1; j < 12; j++)
        {
            for (int k = j + 1; k < 12; k++)
            {
                if (check(sets[i], sets[j], sets[k]))
                {
                    printf("%d %d %d\n", i + 1, j + 1, k + 1);
                    found = 1;
                }
            }
        }
    }
    if (!found)
        printf("no sets\n");
    return 0;
}