#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mo = 1e9+7;
const ll mx = 1e5+10;
ll c[mx][55];
void bc(){
    for(ll i=0;i<mx;i++){
        for(ll j=0;j<=min(i,55LL);j++){
            if(i==0 || j==i){
                c[i][j] = 1;
            }
            else{
                c[i][j] = (c[i-1][j-1] + c[i-1][j])%mo;
            }
        }
    }
}
int main(){
    bc();
    ll n,k;
    cin >> n >> k;
    vector<ll> num(n);
    for(ll i=0;i<n;i++) cin >> num[i];
    sort(num.begin(),num.end());
    ll ans =0;
    for(ll i=0;i<n;i++){
        //cout<<c[i][k-1]<<endl;
        ans = (ans + c[i][k-1]*num[i])%mo;
    }
    cout<<ans<<endl;
}