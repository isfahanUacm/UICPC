#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    while(cin>>n && n!=0){
            int cnt[n],parent[n],children[n],v,child,x,ans=0,take;
            queue<int>leaf;
            for(int i=0;i<n;i++) {
                parent[i]=-1;
                children[i]=0;
            }

            for(int k=0;k<n;k++){
                cin>>v>>cnt[v-1]>>child;
                for(int i=0;i<child;i++){
                    cin>>x;
                    parent[x-1]=v-1;
                    children[v-1]++;
                }
            }
        for(int i=0;i<n;i++)
            if(children[i]==0) leaf.push(i);

    while(leaf.size()!=0){
        int tmp=leaf.front();
        leaf.pop();
        if(parent[tmp]!=-1){
            take=parent[tmp];
            children[take]--;
            if(!children[take]) leaf.push(take);
            cnt[tmp]--;
            cnt[take]+=cnt[tmp];
            ans+=abs(cnt[tmp]);
        }
     }
     cout<<ans<<endl;
    }
    return 0;
}