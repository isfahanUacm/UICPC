#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
    ll n,c;
    cin>>n>>c;
    ll arr[n];
    for(ll i=0;i<n;i++) cin>>arr[i];
    ll mx=0;
    for(ll i=0;i<n;i++){
       ll sum=0,cnt=0;
        for(ll j=i;j<n;j++){
            if(sum+arr[j]<=c) sum+=arr[j],cnt++;
        }
        mx=max(mx,cnt);
    }
    cout<<mx<<endl;
    return 0;
}