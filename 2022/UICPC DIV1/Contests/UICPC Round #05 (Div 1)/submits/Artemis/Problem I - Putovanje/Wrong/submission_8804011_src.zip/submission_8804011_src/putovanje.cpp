#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
    ll n,c;
    cin>>n>>c;
    ll arr[n];
    for(ll i=0;i<n;i++) cin>>arr[i];
    ll mx=-1;
    for(ll i=0;i<n;i++){
       ll sum=0,cnt=0;
        for(ll j=i;j<n;j++){
            sum+=arr[j];
            if(sum<=c) cnt++;
        }
        mx=max(mx,cnt);
    }
    cout<<mx<<endl;
    return 0;
}