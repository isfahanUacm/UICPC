#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
const ll mx = 110;
ll db[mx];
ll p[mx];
bool visited[mx];
ll adj[mx][mx];
ll ans=0;
map<string, ll> id;
void bfs(){
   queue<ll> q;
   q.push(0);
   visited[0] = true;
   db[0] = 0;
   while(!q.empty()){
       ll u = q.front();
       q.pop();
       for(ll v=0;v<=n;v++){
           if(adj[u][v]){
               if(visited[v]==false){
                   ans+=adj[u][v];
                   visited[v] = true;
                   q.push(v);
                   db[v]=db[u]+1;
               }
               else if(visited[v]==true && adj[u][v]<adj[p[v]][v] && db[v]==db[u]+1){
                   ans+=adj[u][v] - adj[p[v]][v];
                   visited[v] = true;
                   q.push(v);
                   db[v]=db[u]+1;
                   p[v] = u;
               }
           }
       }
   }

}
int main(){

    cin >> n >> m;

    for(ll i=1;i<=n;i++){
        string in;
        cin >> in;
        id[in] = i;
    }
    id["English"] = 0;
    for(ll i=0;i<m;i++){
        string u,v;
        ll c;
        cin >> u >> v >> c;
        adj[id[u]][id[v]] = c;
        adj[id[v]][id[u]] = c;
    }

    bfs();
    for(ll i=0;i<=n;i++){
        if(visited[i]==false){
            cout<<"Impossible"<<endl;
            return 0;
        }
    }
    cout<<ans<<endl;
    return 0;
}