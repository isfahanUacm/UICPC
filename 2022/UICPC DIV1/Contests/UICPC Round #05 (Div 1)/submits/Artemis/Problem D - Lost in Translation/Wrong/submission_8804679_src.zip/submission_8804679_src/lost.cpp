#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
const ll mx = 110;
ll db[mx];
ll dist[mx];
ll p[mx];
bool visited[mx];
vector<pair<ll,ll>> adj[mx];
set<pair<ll,pair<ll,ll>>> pq;
map<string, ll> id;
void bfs(){
    queue<ll> q;
    q.push(0);
    visited[0] = 1;
    db[0] = 0;
    p[0] = 0;
    while(!q.empty()){
        ll u = q.front();
        q.pop();
        for(auto v:adj[u]){
            if(visited[v.first]==false){
                q.push(v.first);
                visited[v.first]=true;
                db[v.first] = db[u]+1;
            }
        }
    }

}
void dijkstra(){
    //set<pair<ll,pair<ll,ll>>> pq;
    pq.insert({0,{0,0}});
    dist[0]=0;
	 while(pq.size()){
	 	pair<ll,ll> u = pq.begin()->second;
		pq.erase(pq.begin());
        for(auto v:adj[u.first]){
            if(db[v.first]==u.second+1){
                if((dist[v.first]==-1)||(dist[u.first]+v.second<=dist[v.first])){
                    pq.erase({dist[v.first],{v.first,db[v.first]}});
                    dist[v.first] = dist[u.first] + v.second;
                    p[v.first] = u.first;
                    pq.insert({dist[v.first],{v.first,db[v.first]}});
                }
            }
        }
	}
}

int main(){

    cin >> n >> m;

    for(ll i=1;i<=n;i++){
        string in;
        cin >> in;
        id[in] = i;
    }
    id["English"] = 0;
    for(ll i=0;i<m;i++){
        string u,v;
        ll c;
        cin >> u >> v >> c;
        adj[id[u]].push_back({id[v],c});
        adj[id[v]].push_back({id[u],c});
    }
    for(ll i=0;i<mx;i++){
        dist[i] = -1;
    }
    bfs();
    dijkstra();
    ll ans=0;
    for(ll i=1;i<=n;i++){
        if(dist[i]== -1){
            cout<<"Impossible"<<endl;
            return 0;
        }
        ans+=(dist[i]-dist[p[i]]);
    }
    cout<<ans<<endl;
    return 0;
}