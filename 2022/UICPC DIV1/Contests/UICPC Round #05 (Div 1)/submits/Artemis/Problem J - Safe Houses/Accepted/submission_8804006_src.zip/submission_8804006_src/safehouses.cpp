#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll ans = 0;
char bs[110][110];
vector<pair<ll,ll>> sp;
vector<pair<ll,ll>> hs;
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    for(ll i=0;i<n;i++){
        for(ll j=0;j<n;j++){
            cin >> bs[i][j];
            if(bs[i][j]=='S'){
                sp.push_back({i,j});
            }
            else if(bs[i][j]=='H'){
                hs.push_back({i,j});
            }
        }
    }
    ll ans = -1;
    for(auto s:sp){
        ll m = INT_MAX;
        for(auto h:hs){
            m = min(m,(abs(s.first-h.first)+abs(s.second-h.second)));
        }
        ans = max(ans,m);
    }
    cout<<ans<<endl;
    return 0;
}