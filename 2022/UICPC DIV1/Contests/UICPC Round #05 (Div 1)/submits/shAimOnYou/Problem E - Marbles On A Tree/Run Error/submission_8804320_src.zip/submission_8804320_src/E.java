import java.util.LinkedList;
import java.util.Scanner;

public class E {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            int n = sc.nextInt();

            if (n == 0)
                break;

            int sz = 10000;
            int[] p = new int[sz];
            int[] deg = new int[sz];
            int[] ok = new int[sz];

            for (int i = 0; i < n; i++) {
                int v = sc.nextInt(), m = sc.nextInt(), d = sc.nextInt();
                ok[v] = m;
                deg[v] = d;
                for (int j = 0; j < d; j++)
                    p[sc.nextInt()] = v;
            }

            LinkedList<Integer> link = new LinkedList<>();

            for (int i = 1; i <= n; i++)
                if (deg[i] == 0)
                    link.push(i);

            int res = 0;

            while (!link.isEmpty()) {
                int head = link.pop();

                if (p[head] == 0)
                    break;

                if (ok[head] != 1) {
                    res += Math.abs(ok[head] - 1);
                    ok[p[head]] += ok[head] - 1;
                    ok[head] = 1;
                }

                deg[p[head]]--;

                if (deg[p[head]] == 0)
                    link.push(p[head]);
            }

            System.out.println(res);
        }
    }
}


