import java.util.Scanner;

public class F {
    static int r, c;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        r = sc.nextInt();
        c = sc.nextInt();
        int[][] a = new int[r][c];

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                a[i][j] = sc.nextInt();
            }
        }
        int min = Integer.MAX_VALUE;
        for (int i = 0; i < r; i++) {
            int res = minPathSum(a, i);
            if(res != 0)
                min = Math.min(min, res);
        }
        System.out.println(min);
    }

    static int minPathSum(int[][] a, int s) {
        int min = 0;
        int i = s, j = 0;

        boolean[][] seen = new boolean[r][c];

        while (j != c - 1) {
            int dm = Integer.MAX_VALUE, di = 0, dj = 0;
            if (i - 1 >= 0 && a[i - 1][j] < dm && !seen[i - 1][j]) {
                if (a[i - 1][j] < dm) {
                    dm = a[i - 1][j];
                    di = i - 1;
                    dj = j;
                }

            }
            if (j + 1 < c && a[i][j + 1] < dm && !seen[i][j + 1]) {
                if (a[i][j + 1] < dm) {
                    dm = a[i][j + 1];
                    di = i;
                    dj = j + 1;
                }
            }
            if (i + 1 < r && a[i + 1][j] < dm && !seen[i + 1][j]) {
                if (a[i + 1][j] < dm) {
                    dm = a[i + 1][j];
                    di = i + 1;
                    dj = j;
                }
            }
            if (j - 1 >= 0 && a[i][j - 1] < dm && !seen[i][j - 1]) {
                if (a[i][j - 1] < dm) {
                    dm = a[i][j - 1];
                    di = i;
                    dj = j - 1;
                }
            }
            if(dm == Integer.MAX_VALUE)
                return 0;
            min = Math.max(dm , min);
            i = di;
            j = dj;
            seen[i][j] = true;
//            System.out.println(di + " " + dj);
        }

        return min;
    }
}
