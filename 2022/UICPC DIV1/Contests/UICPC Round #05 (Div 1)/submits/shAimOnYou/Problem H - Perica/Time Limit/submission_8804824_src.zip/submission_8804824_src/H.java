import java.util.*;

public class H {
    static int max = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();

        Integer[] a = new Integer[n];

        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        max = Collections.max(Arrays.asList(a));

        System.out.println(sump(a, n, k));

    }


    static int K;

    public static int sump(Integer arr[], int n, int k) {
        K = k;

        ArrayList<ArrayList<Integer>> res = new ArrayList<>();

        subset(arr, res, new ArrayList<>(), 0);

        return findsum(res);
    }


    static void subset(Integer arr[], ArrayList<ArrayList<Integer>> res, ArrayList<Integer> a, int p) {

        if (a.size() == K) {
            res.add(new ArrayList<>(a));
            return;
        }

        for (int i = p; i < arr.length; i++) {
            a.add(arr[i]);

            subset(arr, res, a, i + 1);

            a.remove(a.size() - 1);
        }
    }

    private static int findsum(ArrayList<ArrayList<Integer>> res) {

        int sum = 0;
        int mod = 1000000007;
        for (ArrayList<Integer> tempList : res) {
            sum += Collections.max(tempList) % mod;
        }

        return sum % mod;
    }
}
