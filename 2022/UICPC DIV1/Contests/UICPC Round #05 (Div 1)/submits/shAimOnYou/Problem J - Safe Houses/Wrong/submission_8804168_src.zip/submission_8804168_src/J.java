import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class J {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        char[][] a = new char[n][];

        for (int i = 0; i < n; i++) {
            a[i] = sc.useDelimiter("\n").next().toCharArray();
        }

        System.out.println(count(a, n));
    }

    static int count(char a[][], int n) {

        ArrayList<Point> s = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] == 'S')
                    s.add(new Point(i, j));
            }
        }
        int res = 0;
        HashSet<Point> ss = new HashSet<>();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] == 'H') {
                    int min = 0, mi, mj;
                    Point ms = null;
                    for (Point p : s) {
                        int d = p.man(i, j);
                        if (min < d) {
                            min = d;
                            ms = p;
                        }
                    }
                    if (ss.contains(ms))
                        res = Math.min(res, min);
                    else {
                        res = Math.max(res, min);
                        ss.add(ms);
                    }
                }
            }
        }
        return res;
    }
}

class Point {
    int x, y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    int man(int x, int y) {
        return Math.abs(this.x - x) + Math.abs(this.y - y);
    }
}
