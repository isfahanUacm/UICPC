import java.util.Arrays;
import java.util.Scanner;

public class I {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int c = sc.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println(max(arr, n, c));
    }

    static int max(int[] arr, int n, int c) {
        Arrays.sort(arr);
        int sum = 0, count = 0;

        for (int i = 0; i < n; i++) {
            if (sum + arr[i] <= c) {
                sum += arr[i];
                count++;
            }
            if (sum == c)
                break;
        }

        return count;
    }
}
