import java.util.Arrays;
import java.util.Scanner;

public class I {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int c = sc.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        System.out.println(max(arr, n, c));
    }

    static int max(int[] a, int n, int k) {
        int max = 0;
        for (int i = 0; i < n; i++) {
            int count = 0, sum = 0;
            for (int j = i; j < n; j++) {
                if (sum + a[j] <= k) {
                    sum += a[j];
                    count++;
                } else
                    break;
            }
            max = Math.max(max, count);
        }
        return max;
    }
}
