import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int c = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < arr.length; i++) arr[i] = sc.nextInt();

        Integer[] arrMax = new Integer[n];
        for (int i = 0; i < arr.length; i++) {
            int count = 0;
            int amount = 0;
            for (int j = i; j < arr.length; j++) {
                if (arr[j] + amount <= c) {
                    count++;
                    amount += arr[j];
                }
            }
            arrMax[i] = count;
        }

        int max = Collections.max(Arrays.asList(arrMax));
        System.out.println(max);
    }

}
