import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Dive1_5_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        char[][] arr = new char[n][n];
        ArrayList<Integer> dS1 = new ArrayList<>();
        ArrayList<Integer> dS2 = new ArrayList<>();

        ArrayList<Integer> dH1 = new ArrayList<>();
        ArrayList<Integer> dH2 = new ArrayList<>();

        sc.nextLine();
        for (int i = 0; i < n; i++) {
            String s = sc.nextLine();
            for (int j = 0; j < s.length(); j++) {
                arr[i][j] = s.charAt(j);
                if (s.charAt(j) == 'S') {
                    dS1.add(i);
                    dS2.add(j);
                } else if (s.charAt(j) == 'H') {
                    dH1.add(i);
                    dH2.add(j);
                }
            }
        }

        ArrayList<Integer> max = new ArrayList<>();
        for (int i = 0; i < dS1.size(); i++) {
            int min = Integer.MAX_VALUE;
            int ans;
            for (int j = 0; j < dH1.size(); j++) {
                ans = (Math.abs(dS1.get(i) - dH1.get(j)) + Math.abs(dS2.get(i) - dH2.get(j)));
                if (ans < min) {
                    min = ans;
                }
            }
            max.add(min);
        }

        System.out.println(Collections.max(max));


    }
}