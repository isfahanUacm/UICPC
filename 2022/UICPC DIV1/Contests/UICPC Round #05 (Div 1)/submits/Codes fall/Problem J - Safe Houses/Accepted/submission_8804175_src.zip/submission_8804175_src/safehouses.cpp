#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;
    int numspy{}, numho{};
    int *sx = new int[n*n];
    int *sy = new int[n*n];
    int *hx = new int[n*n];
    int *hy = new int[n*n];
    char **x = new char*[n];
    for( int i = 0; i < n; i++ )
        x[i] = new char[n];
    for( int i = 0; i < n; i++ )
    {
        for( int j = 0; j < n; j++ )
        {
            cin >> x[i][j];
            if( x[i][j] == 'S' )
            {
                sx[numspy] = i;
                sy[numspy] = j;
                numspy++;
            }
            if( x[i][j] == 'H' )
            {
                hx[numho] = i;
                hy[numho] = j;
                numho++;
            }
        }
    }
    
    int maxd{};
    int mind = 1000000;
    for( int i = 0; i < numspy; ++i )
    {
        mind = 1000000;
        for( int j = 0; j < numho; ++j )
        {
            int tmp, tmp1;
            tmp = sx[i] - hx[j];
            if( tmp < 0 )
                tmp *= -1;
            tmp1 = sy[i] - hy[j];
            if( tmp1 < 0 )
                tmp1 *= -1;
            tmp = tmp + tmp1;
            if( tmp < mind )
                mind = tmp;
        }
        if (mind > maxd)
            maxd = mind;
    }
    cout << maxd;

    return 0;
}