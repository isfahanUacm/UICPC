#include <iostream>
using namespace std;

long long sum = 0;
string paget[1000];
bool pagets[1000] = {};
int pagenu[3000];
    

void counter(int i)
{
    if (pagets[i])
    {
        if (paget[i] == "favourably")
            sum++;
    }
    
    else
    {
        counter(pagenu[i*3]);
        counter(pagenu[i*3+1]);
        counter(pagenu[i*3+2]);
    }
}


int main()
{
    int t, s, b, c, x;
    string a;
    
    cin >> t;
    
    for (int i = 0; i < t; i++)
    {
        cin >> s;
        for (int j = 0; j < s; j++)
        {
            cin >> x;
            cin >> a;
            
            
            if (a[0] == 102 || a[0] == 99)
            {
                pagets[x] = 1;
                paget[x] = a;
            }
            
            else
            {
                cin >> b >> c;
                pagenu[3*x] = atoi(a.c_str());
                pagenu[3*x+1] = b;
                pagenu[3*x+2] = c;
            }
        }
        
        counter(1);
        cout << sum << endl;
        sum = 0;
    }

    return 0;
}