#include <iostream>
using namespace std;

int main()
{
    int n, c, sum = 0, max = 0, counter = 0;
    int arr[1000];
    cin >> n >> c;
    
    for (int i = 0; i < n; i++)
        cin >> arr[i];
    
    for (int i = 0; i < n; i++)
    {
        sum = 0;
        counter = 0;
        for (int j = i; j < n; j++)
        {
            counter++;
            sum += arr[j];
            if (counter > max && sum <= c)
                max = counter;
            if (sum > c)
                break;
        }
    }
    
    cout << max << endl;

    return 0;
}
