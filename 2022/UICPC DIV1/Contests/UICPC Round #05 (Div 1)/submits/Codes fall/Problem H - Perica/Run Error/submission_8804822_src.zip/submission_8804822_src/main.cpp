#include <iostream>

// C++ program to sort an array
#include <algorithm>
using namespace std;

int fact( int n )
{
    int f=n;
    for( int i = 1; i < n; i++ )
    {
        f *= i;
    }
    return f;
}
int tarkib( int r , int k )
{
    int t;
    t = fact( k ) / ( fact( r ) * fact( k - r ) );
    return t;
}

int main()
{

    int n, k;
    cin >> n >> k;
    int *x = new int[n];
    for( int i = 0; i < n; i++ )
        cin >> x[i];

    sort( x , x + n );  int *y = new int[n];
    int w = n-1;
    for( int i =0; i<n; i++ )
    {
          y[i] = x[w];
        w--;
    }


    int kol{}, ala= k-1, al = n-1, sum{}, tmp{};
    int u = tarkib( k , n );
    int g;

    while( kol < u )
    {
        int r = tarkib( ala , al);
        for( int i = 0 ;i < r; i++ )
        {
            sum += y[tmp];
            kol++;
            if( kol >= u )
                break;
        }
         if( kol >= u )
                break;

        al--;
        tmp++;


    }
    cout << sum + y[tmp];

    return 0;
}
