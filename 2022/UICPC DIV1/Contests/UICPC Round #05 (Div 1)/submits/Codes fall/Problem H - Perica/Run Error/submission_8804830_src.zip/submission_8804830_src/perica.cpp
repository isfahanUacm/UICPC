#include <iostream>
using namespace std;


int compare(const void* a, const void* b)
{
	const int* x = (int*) a;
	const int* y = (int*) b;

	if (*x > *y)
		return 1;
	else if (*x < *y)
		return -1;

	return 0;
}


int fac(int n)
{
    if (n < 0)
        return 0;
    if (n == 0 || n == 1)
        return 1;
    return (n * fac(n-1));
}


int comb(int a, int b)
{
    if (a > b)
        return 0;
        
    if (a == b)
        return 1;
    
    return (fac(b) / (fac(a) * fac(b-a)));
}


int main()
{
    int n, k;
    long long plus = 0;
    int arr[100000] = {2000000000};
    cin >> n >> k;
    
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    
    qsort(arr,n ,sizeof(int), compare);
    
    for (int i = n-1; i >= 0; i--)
    {
        if (i >= k-1)
            plus += (arr[i] * comb(k-1, i));
    }
    
    cout << plus << endl;
    
    return 0;
}