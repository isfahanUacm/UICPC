result = []


def backtrack(nums, start, curr_set):

    result.append(list(curr_set))

    for i in range(start, len(nums)):


        if (i > start and nums[i] == nums[i - 1]):
            continue


        curr_set.append(nums[i])


        backtrack(nums, i + 1, curr_set)


        curr_set.pop()



def AllSubsets(nums):

    curr_set = []

    nums.sort()

    backtrack(nums, 0, curr_set)




if __name__=='__main__':
    n,c=input().split()
    main = list(map(int, input().split()))
    arr=[]
    res=[]
    max=0
    AllSubsets(main)
    for num in result:
        arr=num
        size=len(arr)
        if(sum(arr)==int(c) and size>max):
            res=arr
            max=size

    print(max)