import java.util.Scanner;

public class Dive1_4_H {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String[] s2 = s.split(" ");
        long B = Long.parseLong(s2[0]);
        long Br = Long.parseLong(s2[1]);
        long Bs = Long.parseLong(s2[2]);
        long A = Long.parseLong(s2[3]);
        long As = Long.parseLong(s2[4]);

        long bobMony = (Br - B) * Bs;
        long alisMony = 0;
        long count = 0;
        while (true) {
            count += 1;
            alisMony += As;
            if (alisMony > bobMony) {
                System.out.println(A + count);
                break;
            }
        }
    }
}
