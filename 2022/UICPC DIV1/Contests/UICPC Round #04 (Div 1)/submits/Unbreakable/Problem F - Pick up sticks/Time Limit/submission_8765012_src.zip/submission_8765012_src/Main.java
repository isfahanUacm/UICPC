

import java.util.HashMap;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static HashMap<String, Wood> list = new HashMap<>();

    public static void main(String[] args) {
        sc.nextInt();
        int rep = sc.nextInt();
        Wood cur = new Wood();

        for (int i = 0; i < rep; i++) {
            String topName = sc.next();
            String bottomName = sc.next();

            Wood top;
            Wood bottom;

            if (list.containsKey(topName)){
                top = list.get(topName);
            } else{
                top = new Wood(topName);
            }

            if (list.containsKey(bottomName)){
                bottom = list.get(bottomName);
            } else{
                bottom = new Wood(bottomName);
            }

            top.bottom = bottom;
            bottom.top = top;

            if (i == 0){
                cur = top;
            }
        }

        //find top

        while (cur.top != null){
            cur = cur.top;
        }

        //trace
        while(cur != null){
            System.out.println(cur.name);
            cur = cur.bottom;
        }
    }
}

class Wood{
    public Wood(String name) {
        this.name = name;
        top = null;
        bottom = null;
        Main.list.put(name, this);
    }

    public Wood() {
    }

    String name;
    Wood top;
    Wood bottom;
}