import java.util.Scanner;

public class Dive1_4_I {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String s = sc.nextLine();
            long sum = 0;
            String[] arr = s.split(" ");
            for (int i = 0; i < arr.length; i++) {
                sum += Long.parseLong(arr[i]);
            }

            for (int i = 0; i < arr.length; i++) {
                long x = Long.parseLong(arr[i]);
                if (x == sum - x) {
                    System.out.println(x);
                    break;
                }
            }

        }
    }
}
