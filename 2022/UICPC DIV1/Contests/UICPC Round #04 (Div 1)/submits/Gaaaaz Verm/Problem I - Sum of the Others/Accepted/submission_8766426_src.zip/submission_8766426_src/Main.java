//package main;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(scanner.hasNext()){
            int sum = 0;
            String a = scanner.nextLine();
            String[] aa = a.split(" ");
            for (int i=0;i< aa.length;i++)
                sum+= Integer.parseInt(aa[i]);
            System.out.println(sum/2);
        }
    }
}

