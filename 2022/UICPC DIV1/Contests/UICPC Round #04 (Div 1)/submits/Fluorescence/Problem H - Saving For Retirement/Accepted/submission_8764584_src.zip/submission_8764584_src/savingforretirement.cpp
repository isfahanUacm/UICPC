#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;

int main(){
    int b, br, bs, a, as;
    cin>>b>>br>>bs>>a>>as;
    int k = (br - b)*bs;
    int y = 1;
    while(y*as <= k){
        y++;
    }
    cout<<a+y;
}