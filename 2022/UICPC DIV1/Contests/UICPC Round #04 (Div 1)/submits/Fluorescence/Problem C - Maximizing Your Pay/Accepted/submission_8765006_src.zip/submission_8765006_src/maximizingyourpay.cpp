#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
int ans;
int n,m;
bool adj[10+5][10+5];

void solve(int mask, int size, int cur){
    if(adj[cur][0]){
        ans = max(ans, size);
    }
    for(int i=1; i<n; i++){
        if((adj[cur][i]) && i != cur && (mask & 1<<i)==0){
            solve(mask|(1<<i), size+1, i);
        }
    }
}
int main(){
    while(true){
        cin>>n;
        if(n==0) break;
        cin>>m;

        ans = 1;
        for (int i = 0; i < 15; i++)
        {
            for (int j = 0; j < 15; j++)
            {
                adj[i][j] = false;
            }
            
        }
        
        for (int i = 0; i < m; i++)
        {
            int x, y; cin>>x>>y;
            adj[x][y] = adj[y][x] = true;
        }
        for (int i = 1; i < n; i++)
        {
            if(adj[0][i]){
                solve((1|1<<i), 2, i);
            }
            if(ans == n) break;
        }
        cout<<ans<<endl;
    }
}