#include <bits/stdc++.h>
using namespace std;
int dp[2021];
#define maxIn  777777777
int main()
{
   fill_n(dp, 2021,maxIn);
   dp[0] = 0;
   int n; cin>>n;
   int points,red,blue,gray;
   int cityPopulation,winVotes,remainVotes;
   int allPoints=0;
   for (int i = 0; i < n; i++)
   {
      cin>>points>>red>>blue>>gray;
      allPoints+=points;
      cityPopulation=red+blue+gray;
      winVotes=int((cityPopulation/2) + 1);
      remainVotes = winVotes-red;
      if (remainVotes < 0) {remainVotes = 0;}
      if (remainVotes > gray) {continue;}

      for (int j = allPoints; j >= points; j--) 
      {
        dp[j] = min(dp[j], dp[j - points] + remainVotes);
      }
   }
    int res = maxIn;
    int pointsToWin = int((allPoints/2) + 1);
    for (int j = pointsToWin; j <= allPoints; j++) {res = min(res,dp[j]);}
    if (res!=maxIn) {cout<<res;}
    else {cout<<"impossible";}
}