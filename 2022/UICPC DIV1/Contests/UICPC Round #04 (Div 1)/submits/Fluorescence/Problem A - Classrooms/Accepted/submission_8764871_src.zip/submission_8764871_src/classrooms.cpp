#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};

int main(){
    int n, k; cin>>n>>k;
    vector<pair<int, int>> a;
    for (int i = 0; i < n; i++)
    {
        int x, y; cin>>x>>y;
        a.push_back({y, x});
    }
    //Comp compfunc;
    sort(a.begin(), a.end());
        
    multiset<int> clas;
    for (int i = 0; i < k; i++)
    {
        clas.insert(1);
    }

    int count = 0;
    for (int i = 0; i < a.size(); i++)
    {
        int f = a[i].second;
        int l = a[i].first;
        auto it = clas.upper_bound(f);
        //not found
        if(it == clas.begin()){
            continue;
        }
        it = prev(it);
        //cout<<*it<<endl;
        clas.erase(it);
        clas.insert(l+1);
        count++;
    }
    cout<<count;
}