for _T in range(int(input())):
    goalPrice = int(input())
    maxCent = 10000
    dp = []
    for _i in range(maxCent+1):
        dp.append([0,0])
    dp[0][0]=1
    numberOfCoins = int(input())
    coins=[]
    for _coin in range(numberOfCoins):
        coins.append(int(input()))
    coins.sort()
    for coin in coins:
        for state in range(maxCent+1):
            if dp[state][0] and state+coin<=maxCent:
                if dp[state+coin][0]:
                    dp[state+coin][1] = min(dp[state+coin][1],dp[state][1]+1)
                else:
                    dp[state+coin][0] = 1
                    dp[state+coin][1] = dp[state][1]+1
    step = goalPrice
    while(step<=maxCent):
        if dp[step][0]:
            print(step,dp[step][1])
            break
        step+=1