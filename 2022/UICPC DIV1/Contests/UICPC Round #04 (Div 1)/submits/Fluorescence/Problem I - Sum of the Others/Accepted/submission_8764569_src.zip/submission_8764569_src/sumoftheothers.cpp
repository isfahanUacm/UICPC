#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};

vector<string> split(string str, char delimiter) { 
  vector<string> internal; 
  stringstream ss(str); // Turn the string into a stream. 
  string tok; 
 
  while(getline(ss, tok, delimiter)) { 
    internal.push_back(tok); 
  } 
 
  return internal; 
}

int main(){
    string line;
    while(getline(cin, line))
    {
        vector<string> a;
        a = split(line, ' ');
        vector<int> b(30+5);
        int i=0;
        int sum = 0;
        for(auto x : a){
            b[i] = 1;
            string sub = "";
            if(x[0] == '-'){
                b[i] *= -1;
                sub = x.substr(1, x.size()-1);
            }
            else{
                sub = x;
                //cout<<sub<<endl;
            }
            b[i] *= stoi(sub);
            sum += b[i];
            i++;
        }
        for(int k=0; k<b.size(); k++){
            if(sum - b[k] == b[k]){
                cout<<b[k]<<endl;
                break;
            }
        }
    }
}