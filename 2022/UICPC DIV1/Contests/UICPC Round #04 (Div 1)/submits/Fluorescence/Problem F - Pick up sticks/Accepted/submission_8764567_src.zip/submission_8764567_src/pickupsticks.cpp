#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
int n, m, a, b;
vector<vector<int>> adj(1000005);
vector<int> topo_sort;
int in[1000005];
queue<int> q;
int main(){
    cin>>n>>m;

    for (int i = 0; i < m; i++){
        cin>>a>>b; a--, b--;
        adj[a].push_back(b);
        //adj[b].push_back(a);
        in[b]++; //in[b]++;
    }

    for (int i = 0; i < n; i++){
        if(in[i] == 0)
            q.push(i);
    }

    int cnt = 0;
    while(!q.empty()){
        int u = q.front();
        topo_sort.push_back(u);
        q.pop();
        cnt++;

        for(int v : adj[u]){
            in[v]--;
            if(in[v] == 0){
                q.push(v);
            }
        }
    }

    if(cnt != n) cout<<"IMPOSSIBLE";
    else{
        for (int i = 0; i < topo_sort.size(); i++)
        {
            cout<<topo_sort[i]+1<<endl;
        }

    }
}