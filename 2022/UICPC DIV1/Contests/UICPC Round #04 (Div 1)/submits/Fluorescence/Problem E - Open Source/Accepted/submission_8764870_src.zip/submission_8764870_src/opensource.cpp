#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
bool stringcase(string s){
    if (s[0]>=97 && s[0]<=122) return false;
    return true;
}
bool cmp(pair<string, int> a, pair<string, int> b){
    if(a.second == b.second) return a.first < b.first;
    return a.second > b.second;
}

bool studant[10005];
map<string, int> stu_m;
map<string, set<int>> prj_stu;
map<int, string> stu_prj;
set<string> prj;
vector<pair<string, int>> res;
int main(){
    string s;
    int ind = 1;
    string curprj;
    while(getline(cin, s)){
        if(s=="0") break;
        if(s=="1"){
            //print and clears every thing
            for(auto p : prj){
                if(prj_stu.count(p) == 0) res.push_back({p, 0});
                else res.push_back({p, prj_stu[p].size()});
            }
            sort(res.begin(), res.end(), cmp);
            for(auto r : res){
                cout<<r.first<<" "<<r.second<<endl;
            }
            //clear
            ind = 1;
            fill_n(studant, 10005, false);
            stu_m.clear(), prj_stu.clear(), stu_prj.clear(), prj.clear(), res.clear();
            continue;
        }

        if(stringcase(s)){
            prj.insert(s);
            curprj = s;
        }
        else{
            if(stu_m.count(s) == 0){
                stu_m[s] = ind++;
            }
            if(studant[stu_m[s]]){
                //not here
                if(stu_prj[stu_m[s]] != curprj){
                    //delete
                    prj_stu[stu_prj[stu_m[s]]].erase(stu_m[s]);
                }
            }
            else{
                prj_stu[curprj].insert(stu_m[s]);
                stu_prj[stu_m[s]] = curprj;
                studant[stu_m[s]] = true;
            }
        }
    }
}