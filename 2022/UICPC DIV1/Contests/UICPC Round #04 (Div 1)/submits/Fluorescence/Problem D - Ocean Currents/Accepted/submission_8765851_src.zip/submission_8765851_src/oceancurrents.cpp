#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef long double lld;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
int grid[1000+5][1000+5];
int dist[1000+5][1000+5];
int n, m;
int x, y, z, w;
bool boudry(int i, int j){
    return i>=0 && i<n && j>=0 && j<m;
}
int dx[8] = {-1, -1 , 0, 1, 1, 1, 0, -1};
int dy[8] = {0, 1, 1 , 1, 0, -1, -1, -1};
priority_queue<pair<int, pair<int, int>>,
vector<pair<int, pair<int, int>>>, greater<pair<int, pair<int, int>>>> q;

void bfs(){
    while(!q.empty()){
        int cost = q.top().first;
        int x = q.top().second.first;
        int y = q.top().second.second;
        q.pop();
        
        if(dist[x][y] < cost) continue;

        for(int i=0; i<8; i++){
            int temp = 1;
            if(i == grid[x][y]) temp = 0;
            int x2 = x+dx[i];
            int y2 = y+dy[i];
            if(boudry(x2, y2)){
                if(dist[x2][y2] > cost+temp){
                    dist[x2][y2] = cost+temp;
                    q.push({dist[x2][y2], {x2, y2}});  
                }
            }
        }
    }
}
int main(){
    cin>>n>>m;
    for (int i = 0; i < n; i++)
    {
        for (int k = 0; k < m; k++)
        {
            char ch; cin>>ch;
            grid[i][k] = ch - '0';
        }
        
    }
    int t; cin>>t;
    while(t--){
        cin>>x>>y>>z>>w;
        x--, y--, z--, w--;
        for (int i = 0; i < 1000+5; i++)
        {
            for (int k = 0; k < 1000+5; k++)
            {
                dist[i][k] = INT_MAX;
            }
        }
        //visited[x][y] = true;
        dist[x][y] = 0;
        q.push({0, {x, y}});
        bfs();
        cout<< dist[z][w] << endl;
    }
    
}