#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
int d, s;

bool judge(double mid){
    return mid * cosh(d/(2*mid)) > mid + s;
}
double calc(double mid){
    return fabs(mid * cosh(d/(2*mid)) - mid - s);
}
int main(){

    cin>>d>>s;
    double lo = 0, hi = 100000000, mi;
    while(fabs(hi - lo) > 1e-9){
        mi = (lo+hi)/2;
        if(calc(mi) < 1e-9) break;
        if(judge(mi)) lo = mi;
        else hi = mi;
    }
    cout<<fixed<<setprecision(9)<<2*mi* sinh(d/(2*mi))<<endl;
}