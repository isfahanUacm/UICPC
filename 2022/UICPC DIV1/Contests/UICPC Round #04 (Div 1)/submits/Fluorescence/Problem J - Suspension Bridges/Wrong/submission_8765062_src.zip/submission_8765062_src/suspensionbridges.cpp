#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
int d, s;

bool judge(double mid){
    return mid * cosh(d/(2*mid)) >= mid + s;
}
int main(){

    cin>>d>>s;
    double lo = 0, hi = 100000, mi;
    while(fabs(hi - lo) > 1e-9){
        mi = (lo+hi)/2;
        if(judge(mi)) lo = mi;
        else hi = mi;
    }
    cout<<fixed<<setprecision(9)<<2*lo* sinh(d/(2*lo))<<endl;
}