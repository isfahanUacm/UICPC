import java.util.ArrayList;
import java.util.Scanner;

public class F {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        Stick[] map = new Stick[n + 1];
        for (int i = 1; i <= n; i++) {
            map[i] = new Stick(i);
        }
        boolean poss = true;
        int last = 0;
        for (int i = 0; i < m; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            Stick sa = map[a];
            Stick sb = map[b];
            if (sa.below != null || sb.top != null) {
                poss = false;
            }
            sa.below = sb;
            sb.top = sa;
            last = a;
        }

        if (!poss) {
            System.out.println("IMPOSSIBLE.");
            System.exit(0);
        }

        Stick top = map[last];
        int count = 0;
        ArrayList<Integer> res = new ArrayList<>();

        try {
            while (top.top != null) {
                top = top.top;
                count++;
                if (top == top.top || count > 1000000) {
                    poss = false;
                    break;
                }
            }
            while (top != null) {
                res.add(top.a);
                top = top.below;
            }
            if (res.size() != n)
                poss = false;

            if (!poss)
                System.out.println("IMPOSSIBLE.");
            else
                for (int a : res) System.out.println(a);
        } catch (StackOverflowError ex) {
            System.out.println("IMPOSSIBLE.");
        }
    }
}

class Stick {
    int a;
    Stick below;
    Stick top;

    @Override
    public String toString() {
        return "Stick{" +
                "a=" + a +
                ", below=" + below +
                '}';
    }

    public Stick(int a) {
        this.a = a;
    }
}