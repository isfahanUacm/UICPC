import java.util.HashMap;
import java.util.Scanner;

public class F {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();

        HashMap<Integer, Stick> map = new HashMap<>();
        for (int i = 0; i < m; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            map.putIfAbsent(a, new Stick(a));
            map.putIfAbsent(b, new Stick(b));
            Stick sa = map.get(a);
            Stick sb = map.get(b);
            sa.below = sb;
            sb.top = sa;
        }
        Stick top = map.get(1);

        try {


            while (top.top != null) {
                top = top.top;
            }
            top.toString();
            while (top != null) {
                System.out.println(top.a);
                top = top.below;
            }
        } catch (StackOverflowError ex) {
            System.out.println("IMPOSSIBLE");
        }
    }
}

class Stick {
    int a;
    Stick below;
    Stick top;

    @Override
    public String toString() {
        return "Stick{" +
                "a=" + a +
                ", below=" + below +
                '}';
    }

    public Stick(int a) {
        this.a = a;
    }
}