import java.util.Scanner;

public class F {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();

        int N = 1000001;
        int[] res = new int[N], top = new int[N], below = new int[N], num = new int[N], depth = new int[N];

        int k = 1;
        for (int i = 1; i <= m; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            depth[b]++;
            num[i] = b;
            below[i] = top[a];
            top[a] = k++;
        }

        int last = 1;
        for (int i = 1; i <= n; i++) {
            if (depth[i] == 0)
                res[last++] = i;
        }
        for (int i = 1; i < last; i++) {
            for (int j = top[res[i]]; j > 0; j = below[j]) {
                if (depth[num[j]]-- == 1)
                    res[last++] = num[j];
            }
        }
        if (last - 1 == n) {
            for (int i = 1; i <= n; i++) {
                System.out.println(res[i]);
            }
        }
        else {
            System.out.println("IMPOSSIBLE");
        }
    }
}