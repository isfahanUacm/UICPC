import java.util.HashMap;
import java.util.Scanner;

public class F {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        Stick[] map = new Stick[n+1];
        for (int i = 1; i <= n; i++) {
            map[i] = new Stick(i);
        }

        int last = 0;
        for (int i = 0; i < m; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            Stick sa = map[a];
            Stick sb = map[b];
            sa.below = sb;
            sb.top = sa;
            last = a;
        }
        Stick top = map[last];
        int count = 0;
        try {
            while (top.top != null) {
                top = top.top;
                count++;
                if(top == top.top || count > 1000000)
                    throw new StackOverflowError();
            }
            top.toString();
            while (top != null) {
                System.out.println(top.a);
                top = top.below;
            }
        } catch (StackOverflowError ex) {
            System.out.println("IMPOSSIBLE");
        }
    }
}

class Stick {
    int a;
    Stick below;
    Stick top;

    @Override
    public String toString() {
        return "Stick{" +
                "a=" + a +
                ", below=" + below +
                '}';
    }

    public Stick(int a) {
        this.a = a;
    }
}