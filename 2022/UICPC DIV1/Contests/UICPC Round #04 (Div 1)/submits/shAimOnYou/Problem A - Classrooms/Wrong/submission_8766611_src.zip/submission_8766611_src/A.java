import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        ArrayList<Activity> acts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            acts.add(new Activity(sc.nextInt(), sc.nextInt()));
        }
        Collections.sort(acts);
        int count = 0;
        for (int i = 0; i < n; i++) {
            Activity cur = acts.get(i);
            if (cur.done) continue;
            int maxClass = k;
            for (int j = i + 1; j < n; j++) {
                Activity next = acts.get(j);
                if (cur.fi < next.si && !next.done && maxClass != 0) {
                    next.done = true;
                    maxClass--;
                }
            }
            count++;
        }
        System.out.println(count);
    }
}

class Activity implements Comparable<Activity> {
    int si, fi;
    boolean done;

    public Activity(int si, int fi) {
        this.si = si;
        this.fi = fi;
    }

    public int compareTo(Activity o) {
        return si - o.si;
    }
}
