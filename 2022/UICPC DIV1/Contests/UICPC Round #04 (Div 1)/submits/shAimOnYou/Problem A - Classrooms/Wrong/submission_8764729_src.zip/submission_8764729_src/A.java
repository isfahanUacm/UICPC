import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.TreeSet;

public class A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        ArrayList<Activity> acts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            acts.add(new Activity(sc.nextInt(), sc.nextInt()));
        }
        Collections.sort(acts);
        TreeSet<Integer> set = new TreeSet<>();
        int count = 0;
        for (int i = 0; i < n; i++) {
            int nc = next(set, -acts.get(i).si);
            if (nc == 0) {
                if (set.size() < k) {
                    set.add(-acts.get(i).fi - 1);
                    count++;
                }
                continue;
            }
            set.remove(nc);
            set.add(-acts.get(i).fi - 1);
            count++;
        }
        System.out.println(count);
    }

    static int next(TreeSet<Integer> set, int key) {
        for (int k : set) {
            if (k >= key) return k;
        }
        return 0;
    }
}

class Activity implements Comparable<Activity> {
    int si, fi;

    public Activity(int si, int fi) {
        this.si = si;
        this.fi = fi;
    }

    public int compareTo(Activity o) {
        return (fi == o.fi) ? si - o.si : fi - o.fi;
    }
}


