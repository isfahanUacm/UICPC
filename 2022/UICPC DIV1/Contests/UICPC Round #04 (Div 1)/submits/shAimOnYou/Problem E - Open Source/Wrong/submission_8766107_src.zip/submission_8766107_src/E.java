import java.util.*;

public class E {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Proj> set = new ArrayList<>();
        ArrayList<String> input = new ArrayList<>();
        HashMap<String, String> map = new HashMap();
        HashSet<String> ban = new HashSet<>();

        String projN = "";
        while (true) {
            String line = sc.nextLine();
            if (line.equals("0")) break;
            input.add(line);
            char ch = line.charAt(0);
            if (ch >= 'A' && ch <= 'Z') {
                projN = line;
            } else if (ch >= 'a' && ch <= 'z') {
                String sp = map.get(line);
                if (sp != null && !sp.equals(projN)) {
                    ban.add(line);
                }
                map.put(line, projN);
            }
        }

        Proj proj = null;
        for (String line : input) {
            char ch = line.charAt(0);
            if (ch >= 'A' && ch <= 'Z') {
                proj = new Proj(line);
                set.add(proj);
            } else if (ch >= 'a' && ch <= 'z' && !ban.contains(line)) {
                proj.stu.add(line);
            }
        }
        Collections.sort(set);
        for (Proj p : set) {
            System.out.println(p.name + " " + p.stu.size());
        }
    }
}

class Proj implements Comparable<Proj> {
    String name;
    HashSet<String> stu = new HashSet<>();

    public Proj(String name) {
        this.name = name;
    }


    @Override
    public int compareTo(Proj o) {
        if (stu.size() != o.stu.size())
            return o.stu.size() - stu.size();
        return name.compareTo(o.name);
    }
}
