while True:
    x = input()
    if not x:
        break
    nums = list(map(int, x.split()))
    sum = 0
    for i in nums:
        sum += i

    for i in nums:
        if (sum - i == i):
            print(i)
            break
