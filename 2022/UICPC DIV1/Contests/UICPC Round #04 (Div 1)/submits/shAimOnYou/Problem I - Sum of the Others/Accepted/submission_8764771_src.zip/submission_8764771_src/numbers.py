while True:
    try:
        x = input()
        nums = list(map(int, x.split()))
        sum = 0
        for i in nums:
            sum += i

        for i in nums:
            if (sum - i == i):
                print(i)
                break

    except (EOFError, ValueError):
        break
