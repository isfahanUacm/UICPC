#include <iostream>
#include <vector>
#include <sstream>

typedef long long ll;

using namespace std;

int main() {
    string s;
    vector<vector<int>> v(201);
    int a = 0;
    while (getline(cin, s)) {
        istringstream ss(s);
        int x;
        while (ss >> x)
            v[a].push_back(x);
        a++;
    }
    for (auto& i : v) {
        for (int j = 0; j < i.size(); j++) {
            ll z = 0;
            for (int k = 0; k < i.size(); k++) {
                if (j != k)
                    z += i[k];
            }
            if (z == i[j]) {
                cout << z << '\n';
                break;
            }
        }
    }
    return 0;
}
