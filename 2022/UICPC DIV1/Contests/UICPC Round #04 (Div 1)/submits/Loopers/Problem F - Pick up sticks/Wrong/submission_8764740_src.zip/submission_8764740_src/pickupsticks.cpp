#include <iostream>
#include <vector>
#include <stack>

using namespace std;

bool IMPOSSIBLE = false;

stack<int> s;

void Loopers(int i, const vector<int> adj[], vector<bool>& vis) {
    vis[i] = true;
    for (const auto& i : adj[i]) {
        if (!vis[i]) {
            vis[i];
            Loopers(i, adj, vis);
            s.push(i);
        } else {
            IMPOSSIBLE = true;
            return;
        }
    }
}

int main() {
    int n, m, a, b;
    cin >> n >> m;
    vector<int> adj[n + 1];
    vector<bool> vis(n + 1);
    for (int i = 0; i < m; i++) {
        cin >> a >> b;
        adj[a].push_back(b);
    }
    for (int i = 1; i <= n; i++) {
        if (!vis[i] && !IMPOSSIBLE) {
            Loopers(i, adj, vis);
            s.push(i);
        }
    }
    if (IMPOSSIBLE)
        cout << "IMPOSSIBLE\n";
    while (!s.empty()) {
        cout << s.top() << '\n';
        s.pop();
    }
}
