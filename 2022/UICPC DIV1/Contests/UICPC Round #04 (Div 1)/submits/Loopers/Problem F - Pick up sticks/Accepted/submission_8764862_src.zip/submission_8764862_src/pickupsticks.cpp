#include <iostream>
#include <vector>
#include <stack>

using namespace std;

stack<int> s;

void Loopers(int i, const vector<int> adj[], vector<bool>& vis) {
    vis[i] = true;
    for (const auto& j : adj[i]) {
        if (!vis[j]) {
            vis[j];
            Loopers(j, adj, vis);
        }
    }
    s.push(i);
}

int main() {
    int n, m, a, b;
    cin >> n >> m;
    vector<int> adj[n + 1];
    vector<bool> vis(n + 1);
    for (int i = 0; i < m; i++) {
        cin >> a >> b;
        adj[a].push_back(b);
    }
    for (int i = 1; i <= n; i++) {
        if (!vis[i]) {
            Loopers(i, adj, vis);
        }
    }
    vector<int> v(n + 1);
    int i = 1;
    stack<int> s2 = s;
    while (!s.empty()) {
        v[s.top()] = i;
        s.pop();
        i++;
    }
    bool IMPOSSIBLE = false;
    for (int i = 1; i <= n; i++) {
        for (auto j : adj[i]) {
            if (v[i] > v[j]) {
                IMPOSSIBLE = true;
                break;
            }
        }
    }
    if (IMPOSSIBLE)
        cout << "IMPOSSIBLE\n";
    else {
        while (!s2.empty()) {
            cout << s2.top() << '\n';
            s2.pop();
        }
    }
}
