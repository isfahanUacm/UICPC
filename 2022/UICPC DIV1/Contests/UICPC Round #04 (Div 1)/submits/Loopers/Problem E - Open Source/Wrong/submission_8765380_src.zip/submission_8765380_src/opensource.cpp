#include <iostream>
#include <map>
#include <algorithm>
#include <cctype>
#include <vector>
#include <set>

using namespace std;

map<string, string> m;
map<string, int> m2;
set<string> st;

bool LoopersC(pair<string, int>& x, pair<string, int>& y) {
    if (x.second == y.second)
        return x.first < y.first;
    return x.second > y.second;
}

int main() {
    string s;
    getline(cin, s);
    while (s != "0") {
        m.clear();
        m2.clear();
        st.clear();
        while (s != "1") {
            while (isupper(s[0])) {
                string s2;
                getline(cin, s2);
                int c = 0;
                while (islower(s2[0])) {
                    c++;
                    if (m.find(s2) != m.end()) {
                        if (m[s2] != s) {
                            m2[m[s2]] -= 1;
                            st.insert(s2);
                            m.erase(s2);
                        }
                    } else if (st.find(s2) == st.end()) {
                        m[s2] = s;
                        m2[s] += 1;
                    }
                    getline(cin, s2);
                }
                if (!c)
                    m2[s] = 0;
                s = s2;
            }
        }
        vector<pair<string, int>> v;
        for (auto& i : m2) {
            v.push_back({i.first, i.second});
        }
        sort(v.begin(), v.end(), LoopersC);
        for (const auto& i : v) {
            cout << i.first << ' ' << i.second << '\n';
        }
        getline(cin, s);
    }
    return 0;
}
