#include <iostream>

using namespace std;

int main() {
    int B, Br, Bs, A, As;
    cin >> B >> Br >> Bs >> A >> As;
    int x = (Br - B) * Bs;
    int y = 0;
    int z = 0;
    while (y <= x) {
        y += As;
        z++;
    }
    cout << z + A << '\n';
    return 0;
}
