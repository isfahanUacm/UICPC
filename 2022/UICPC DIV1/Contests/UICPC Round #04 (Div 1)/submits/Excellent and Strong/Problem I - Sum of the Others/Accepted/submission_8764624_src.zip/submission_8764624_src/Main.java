import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext()) {
            String input = sc.nextLine();
            String[] num = input.split(" ");
            int[] myNum = new int[num.length];
            for (int j = 0; j < num.length; j++) {
                myNum[j] = Integer.parseInt(num[j]);
            }
            for (int j = 0; j < myNum.length; j++) {
                int plus = 0;
                for (int k = 0; k < myNum.length; k++) {
                    if (k != j)
                        plus += myNum[k];
                }
                if (myNum[j] == plus) {
                    System.out.println(plus);
                    break;
                }
            }
        }
    }
}