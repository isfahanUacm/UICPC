import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        for (int i = 0; i < t; i++) {
            int money = sc.nextInt();
            int n = sc.nextInt();
            ArrayList<Integer> holeMoney = new ArrayList<>();
            for (int j = 0; j < n; j++) {
                holeMoney.add(sc.nextInt());
            }
            quickSort(holeMoney, 0, holeMoney.size() - 1);
//            int plus = 0;
//            int coins = 0;
//            for (Integer integer : holeMoney) {
//                plus += integer;
//                coins++;
//                if (plus >= money)
//                    break;
//            }
            int index = holeMoney.size();
            for (int j = holeMoney.size() - 1; j >= 0; j--) {
                if (holeMoney.get(j) <= money) {
                    index = j;
                    break;
                }
            }
            int newPlus = holeMoney.get(index);
            int newCoins = 1;
            for (int j = 0; j < index; j++) {
                if (newPlus >= money)
                    break;
                newPlus += holeMoney.get(j);
                newCoins++;
            }
            System.out.println(newPlus + " " + newCoins);
        }
    }

    static void swap(ArrayList<Integer> arr, int i, int j) {
        int temp = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, temp);
    }

    static int partition(ArrayList<Integer> arr, int low, int high) {

        int pivot = arr.get(high);
        int i = (low - 1);

        for (int j = low; j <= high - 1; j++) {

            if (arr.get(j) < pivot) {

                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return (i + 1);
    }

    static void quickSort(ArrayList<Integer> arr, int low, int high) {
        if (low < high) {

            int pi = partition(arr, low, high);

            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }
}