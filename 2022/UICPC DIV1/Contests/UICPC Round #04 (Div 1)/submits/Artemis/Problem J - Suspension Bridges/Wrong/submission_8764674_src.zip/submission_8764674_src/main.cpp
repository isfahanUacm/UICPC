#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
double_t eps = 0.0000001;

int main() {
    double_t d, s;
    cin >> d >> s;

    double_t mi = 0.000000001, ma = 10000000;

    while (abs(ma - mi) >= eps) {
        double_t mid = (ma + mi) / 2;
        double_t ans = mid * cosh(d / (2 * mid)) - mid;

        if (ans < s) {
            ma = mid;
        }
        else {
            mi = mid;
        }
    }

    double ans = 2 * mi * sinh(d / (2 * mi));
    printf("%.8f\n", ans);
}