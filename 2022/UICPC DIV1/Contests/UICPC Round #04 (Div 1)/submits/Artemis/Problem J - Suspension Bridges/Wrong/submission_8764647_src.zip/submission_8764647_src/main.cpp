#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
double eps = 0.000001;

int main() {
    double d, s;
    cin >> d >> s;

    double mi = 0.00000001, ma = 10000000;

    while (ma - mi >= eps) {
        double mid = (ma + mi) / 2;
        double ans = mid * cosh(d / (2 * mid)) - mid;

        if (ans < s) {
            ma = mid;
        }
        else {
            mi = mid;
        }
    }

    double ans = 2 * mi * sinh(d / (2 * mi));
    printf("%f\n", ans);
}