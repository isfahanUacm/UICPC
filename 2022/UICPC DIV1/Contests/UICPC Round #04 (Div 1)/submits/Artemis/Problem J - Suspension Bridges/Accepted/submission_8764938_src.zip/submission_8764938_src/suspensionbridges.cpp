#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
double_t eps = 1e-9;
double_t d, s;
double_t calc(double_t a){
    return a*cosh(d/(2*a))-a;
}
int main() {
    
    cin >> d >> s;

    double_t mi = 1e-12, ma = 1e12;
    double_t mid = (mi+ma)/2;
    while(ma-mi>eps){
        mid = (mi+ma)/2;
        double_t ans = calc(mid);
        if(fabs(ans - s)<eps && fabs(calc(mid+eps)-s)>eps){
            break;
        }
        if(ans > s){
            mi = mid;
        }
        else{
            ma = mid;
        }
    }
    double_t ans = 2 * mid * sinh(d / (2 * mid))+eps;
    printf("%.8f\n", ans);
}