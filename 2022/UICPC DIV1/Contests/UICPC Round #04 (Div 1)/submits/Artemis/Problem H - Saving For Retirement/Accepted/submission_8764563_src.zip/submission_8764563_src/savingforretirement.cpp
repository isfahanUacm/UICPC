#include<bits/stdc++.h>
using namespace std;
int main(){
    int b,br,bs,a,ar,cnt=0;
    cin>>b>>br>>bs>>a>>ar;
    cnt+=(br-b)*bs;
    int sum=cnt/ar;
    if(sum*ar>cnt) cout<<sum+a<<endl;
    else cout<<sum+a+1<<endl;
    return 0;
}