#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


int main() {
    ll n;
    cin >> n;

    vector<pair<ll, ll>> kn;

    ll wc = 0, wf = 0;
    ll total = 0;
    for (ll i = 0; i < n; ++i) {
        ll d, c, f, u;
        cin >> d >> c >> f >> u;
        ll cnt = 0;
        total += d;

        if (u == c - f) {
            kn.emplace_back(d, 1);
            continue;
        }

        if (c > f) {
            ll z = min(c - f, u);
            f += z;
            u -= z;
        }

        else if (c < f) {
            ll z = min(f - c, u);
            cnt += z;
            c += z;
            u -= z;
        }

        if (u == 0) {
            if (c > f) {
                wc += d;
                total -= d;
            }
            else {
                wf += f;
                total -= f;
            }
        }
        else {
            if (u % 2 == 0) {
                cnt += (u / 2) + 1;
                kn.emplace_back(d, cnt);
            } else {
                cnt += ((u + 1) / 2);
                kn.emplace_back(d, cnt);
            }
        }
    }

    ll dp[2050];
    for (auto& x: dp)
        x = LONG_LONG_MAX / 3;

    dp[0] = 0;

    for (auto x : kn) {
        ll val = x.first;
        ll price = x.second;
        for (ll i = 2050 - 1; i >= val; --i) {
            if (dp[i - val] == LONG_LONG_MAX / 3)
                continue;

            dp[i] = min(dp[i], dp[i - val] + price);
        }
    }

    ll mi = LONG_LONG_MAX / 3;
    for (ll i = 0; i < 2050; ++i) {
        if (dp[i] == 0 && i != 0)
            continue;
        ll tc = wc + i;
        ll tf = wf + (total - i);

        if (tc > tf) {
            mi = min(mi, dp[i]);
        }
    }

    if (mi == LONG_LONG_MAX / 3) {
        cout << "impossible" << endl;
    }
    else {
        cout << mi << endl;
    }
}



