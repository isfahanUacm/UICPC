#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 1e3+10;
ll r,c,n,k,ans=0;
ll dist[mx][mx];
char bas[mx][mx];
pair<ll,ll> mov[8] = {{-1,0},{-1,1},{0,1},{1,1},{1,0},{1,-1},{0,-1},{-1,-1}};
set<pair<ll,pair<ll,ll>>> pq;
bool inr(ll x,ll y){
    return x>=0 && x<r && y>=0 && y<c;
}
void dijkstra(ll rs, ll cs, ll rd,ll cd){
    pq.insert({0,{rs,cs}});
    dist[rs][cs]=0;
	 while(pq.size()){
	 	pair<ll,ll> u = pq.begin()->second;
		pq.erase(pq.begin());
        for(ll i=0;i<8;i++){
            ll x = u.first+mov[i].first;
            ll y = u.second+mov[i].second;
            if(inr(x,y)){
                if(i==(bas[u.first][u.second]-'0')){
                    if(dist[u.first][u.second]<dist[x][y]){
                        pq.erase({dist[x][y],{x,y}});
                        dist[x][y]=dist[u.first][u.second];
                        pq.insert({dist[x][y],{x,y}});
                    }
                }
                else{
                    if(dist[u.first][u.second]+1<dist[x][y]){
                        pq.erase({dist[x][y],{x,y}});
                        dist[x][y]=dist[u.first][u.second]+1;
                        pq.insert({dist[x][y],{x,y}});
                    }
                }

            }
	 	}
	}
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin >> r >> c;
    for(ll i=0;i<r;i++){
        for(ll j=0;j<c;j++){
            cin >> bas[i][j];
        }
    }
    cin >> n;
    for(ll t=0;t<n;t++){
        //cout<<pq.size()<<endl;
        for(ll i=0;i<r;i++){
            for(ll j=0;j<c;j++){
                dist[i][j] = LONG_LONG_MAX/2;
                //pq.insert({dist[i][j],{i,j}});
            }
        }
        ll rs, cs, rd,cd;
        cin >> rs >> cs >> rd >> cd;
        rs--;cs--;rd--;cd--;
        dijkstra(rs,cs,rd,cd);
        cout<<dist[rd][cd]<<endl;
    }
    return 0;
}