#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

bool cmp(const pair<int, string>& a, const pair<int, string>& b) {
    if (a.first == b.first) {
        return a.second < b.second;
    }
    return a.first > b.first;
}

int main() {
    string l;

    bool done = false;

    while (true) {
        set<string> all;
        set<string> to_remove;
        map<string, vector<string>> mp;
        set<string> current;
        string m;
        while (true) {

            getline(cin, l);
            if (l == "0") {
                done = true;
                break;
            }
            if (l == "1") {
                break;
            }

            if (isupper(l[0])) {
                m = l;
                mp[m];
                current.clear();
            }
            else {
                if (current.count(l) == 0) {
                    mp[m].push_back(l);
                    if (all.count(l) > 0) {
                        to_remove.insert(l);
                    }
                    all.insert(l);
                }
                current.insert(l);
            }
        }
        vector<pair<int, string>> temp;
        for (const auto& x: mp) {
            int cnt = 0;
            for (const auto& t: x.second) {
                if (to_remove.count(t) == 0)
                    cnt++;
            }

            temp.emplace_back(cnt, x.first);
        }

        sort(temp.begin(), temp.end(), cmp);

        for (const auto& x: temp) {
            cout << x.second << ' ' << x.first << endl;
        }

        if (done)
            break;
    }
}

