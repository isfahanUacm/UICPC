#include <bits/stdc++.h>
typedef long long ll;
using namespace std;


int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        int p;
        cin >> p;
        int n;
        cin >> n;
        int arr[n];
        for (int i = 0; i < n; ++i) {
            cin >> arr[i];
        }

        int dp[20005];
        memset(dp, -1, sizeof(dp));
        dp[0] = 0;

        for (int i = 0; i < n; ++i) {
            for (int j = 20004; j >= arr[i]; --j) {
                if (dp[j - arr[i]] == -1)
                    continue;

                if (dp[j] == -1)
                    dp[j] = dp[j - arr[i]] + 1;
                else
                    dp[j] = min(dp[j], dp[j - arr[i]] + 1);
            }
        }

        for (int i = p; i < 20005; ++i) {
            if (dp[i] != -1) {
                cout << i << ' ' << dp[i] << endl;
                break;
            }
        }
    }
}