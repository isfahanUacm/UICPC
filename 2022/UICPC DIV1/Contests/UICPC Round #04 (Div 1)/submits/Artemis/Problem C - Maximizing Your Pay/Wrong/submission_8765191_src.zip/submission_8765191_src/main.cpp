#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 20;
ll dist[MAX][3000];
set<pair<ll, pair<ll, ll>>> ss;
// dist - to - mask
vector<ll> adj[MAX];

void dijkstra(int start) {
    dist[start][0] = 0;
    ss.insert({0, {start, 0}});
    while (!ss.empty()) {
        ll u = ss.begin()->second.first;
        ll mask = ss.begin()->second.second;
//        cout << u << ' ' << mask << ' ' << ss.size() << endl;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (v == u)
                continue;
            if (mask & (1 << v))
                continue;

            ll nmask = mask | (1 << v);

            if (dist[v][nmask] > dist[u][mask] + 1) {
                ss.erase({dist[v][nmask], {v, nmask}});
                dist[v][nmask] = dist[u][mask] + 1;
                ss.insert({dist[v][nmask], {v, nmask}});
            }
        }
    }
}

int main() {
    ll n, m;
    while (cin >> n && n != 0) {
        cin >> m;
        ss.clear();
        for (auto& x : adj)
            x.clear();
        for (ll i = 0; i < n; ++i) {
            for (int j = 0; j < 3000; ++j) {
                dist[i][j] = INT_MAX;
            }
        }
        for (ll i = 0; i < m; ++i) {
            ll a, b;
            cin >> a >> b;
            adj[a].emplace_back(b);
            adj[b].emplace_back(a);
        }
        dijkstra(0);
        ll ans = 0;
        for (int i = 0; i < 3000; ++i) {
            ll x = dist[0][i];
            if (x >= INT_MAX)
                continue;
            if (i & 1)
                ans = max(ans, x);
        }

        cout << ans << endl;
    }
}
