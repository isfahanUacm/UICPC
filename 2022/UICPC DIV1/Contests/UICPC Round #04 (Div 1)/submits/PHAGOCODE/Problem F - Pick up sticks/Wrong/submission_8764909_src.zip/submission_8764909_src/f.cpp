#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, m, a, b;
    cin >> n >> m;
    int sticks[n] = {};
    bool placed;
    for (int i = 0; i < m; i++)
    {
        cin >> a >> b;
        placed = false;

        if (i == 0)
        {
            sticks[0] = a;
            sticks[1] = b;
            continue;
        }

        for (int j = 0; j < n; j++)
        {
            if (sticks[j] == a)
            {
                if (sticks[j + 1] == 0)
                {
                    sticks[j + 1] = b;
                    placed = true;
                    break;
                }

                for (int k = j + 3; k < n; k++)
                    if (sticks[k] == 0)
                    {
                        for (int l = k - 1; l >= j + 1; l--)
                            sticks[l + 1] = sticks[l];
                        sticks[j + 1] = b;
                        placed = true;
                        break;
                    }
            }

            if (placed) break;

            if (sticks[j] == b)
                for (int k = j + 2; k < n; k++)
                    if (sticks[k] == 0)
                    {
                        for (int l = k - 1; l >= j; l--)
                            sticks[l + 1] = sticks[l];
                        sticks[j] = a;
                        placed = true;
                        break;
                    }
        }

        if (placed) continue;

        for (int j = 0; j < n - 1; j++)
            if (sticks[j] == 0 && sticks[j + 1] == 0)
            {
                sticks[j] = a;
                sticks[j + 1] = b;
                break;
            }

        // cout << "------\n";
        // for (int j = 0; j < n; j++)
        //     cout << j << ": " << sticks[j] << '\n';
    }

    for (int i = 0; i < n; i++)
        cout << sticks[i] << '\n';
    return 0;
}