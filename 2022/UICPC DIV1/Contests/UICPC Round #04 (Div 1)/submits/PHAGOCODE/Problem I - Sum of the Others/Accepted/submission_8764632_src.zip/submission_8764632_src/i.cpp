#include <bits/stdc++.h>
using namespace std;

int main()
{
    string line;
    vector<int> numbers;
    int sum;
    for (int i = 0; i < 200; i++)
    {
        getline(cin, line);
        istringstream is(line);
        int number;
        sum = 0;

        while (is >> number)
        {
            numbers.push_back(number);
            sum += number;
        }

        for (size_t j = 0; j < numbers.size(); j++)
            if (numbers.at(j) == sum - numbers.at(j)) {
                cout << numbers.at(j) << '\n';
                break;
            }
            
    }
    return 0;
}