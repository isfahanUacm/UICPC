#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxn = 1000010;

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        ll goal;
        cin >> goal;
        ll n;
        cin >> n;
        vector<ll> c(n);
        for(ll i = 0; i < n; i++)
        {
            cin >> c[i];
        }
        vector<ll> dp(maxn, -1);
        dp[0] = 0;
        for(ll i = 0; i < n; i++)
        {
            for(ll p = goal - 1; p >= 0; p--)
            {
                if(dp[p] != -1)
                {
                    if(p + c[i] <= maxn)
                    {
                        if(dp[p + c[i]] == -1)
                        {
                            dp[p + c[i]] = dp[p] + 1;
                        }
                        else
                        {
                            dp[p + c[i]] = min(dp[p + c[i]], dp[p] + 1);
                        }
                    }
                }
            }
        }
        ll index = goal;
        while(dp[index] == -1)
        {
            index++;
        }
        cout << index << " " << dp[index] << endl;
    }
    return 0;
}