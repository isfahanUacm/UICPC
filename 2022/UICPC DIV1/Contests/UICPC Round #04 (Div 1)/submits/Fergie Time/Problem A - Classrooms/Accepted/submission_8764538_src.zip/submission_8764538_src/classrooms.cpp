#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    ll k,n;
    cin>>n>>k;
    vector<pll> scheduled(n);
    ll x,y;
    for(ll i=0; i<n; i++){
        cin>>x>>y;
        scheduled[i]={y,x};
    }
    sort(scheduled.begin(),scheduled.end());
    multiset<ll> scheduledans;
    ll ans=0;
    for(ll i=0;i<n;i++){
        pll temp=scheduled[i];
        auto upper_bound=scheduledans.lower_bound(temp.second);
        if(upper_bound == scheduledans.begin()){
                if(scheduledans.size()<k){
                    scheduledans.insert(temp.first);
                    ans++;
                }
        }
        else {
            --upper_bound;
            scheduledans.erase(upper_bound);
            scheduledans.insert(temp.first);
            ans++;
        }

    }
    cout<<ans<<endl;
}