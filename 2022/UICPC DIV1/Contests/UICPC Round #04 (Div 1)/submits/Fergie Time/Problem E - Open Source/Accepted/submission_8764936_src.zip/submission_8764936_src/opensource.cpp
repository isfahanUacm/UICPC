#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
bool cmp(pair<ll,string> x,pair<ll,string> y){
    if(x.first > y.first){
        return true;
    }
    else if(x.first==y.first){
        if(x.second<y.second){
            return true;
        }
    }
    return false;
}
bool isUpper(string& s) {
    return std::all_of(s.begin(), s.end(), [](char c){ return isupper(c) || c == ' '; });
}
int main()
{
   string s;
   map<string,ll> project;
   vector<pair<ll,string>> p;
   map<string,set<string>> studentp;
   string currentupper;
   while(true){
       getline(cin,s);
       if(s=="0"){
           break;
       }
       if(s=="1"){
           for(auto i: studentp){
               if(i.second.size()==1){
                   if(project.find(*(i.second.begin())) != project.end())
                        project[*(i.second.begin())]+=1;

               }
           }
           for(auto i: project){
               p.push_back({i.second,i.first});
//               cout<<i.first<<" "<<i.second<<"###";
           }
           sort(p.begin(),p.end(),cmp);
           for(pair<ll,string> i:p){
               cout<<i.second<<" "<<i.first<<endl;
           }
           project= map<string,ll>();
           p=vector<pair<ll,string>>();
           studentp=map<string,set<string>>();
       }
       if(isUpper(s)){
          currentupper=s;
          project[currentupper]=0;

       }
       else{
           studentp[s].insert(currentupper);
       }
   }
}
