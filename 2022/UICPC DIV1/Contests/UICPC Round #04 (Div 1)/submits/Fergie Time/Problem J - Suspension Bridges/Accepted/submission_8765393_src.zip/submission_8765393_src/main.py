import math

d, s = map(int, input().split())

def f(a):
    return a + s - a * math.cosh(d / (2 * a))

l = 0
r = 10 ** 9

while 0.000000001 < r - l:
    mid = (l + r) / 2
    temp = f(mid)
    if temp > 0:
        r = mid
    else:
        l = mid

mid = (l + r) / 2
print("{:.9f}".format(2 * mid * math.sinh(d / (2 * mid))))
