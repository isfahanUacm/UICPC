#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    ll b,br,bs,a,as;
    cin>>b>>br>>bs>>a>>as;
    ll ans=0;
    ans=(((br-b)*bs)/as)+1;

    cout<<(a+ans)<<endl;
}
