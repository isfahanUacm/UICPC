#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxn = 10;

ll n, m;
vector<vector<ll>> graph;
vector<bool> visited;
stack<ll> ans;

void dfs(ll index)
{
    visited[index] = true;
    for (ll i: graph[index])
    {
        if (!visited[i])
        {
            dfs(i);
        }
    }
    ans.push(index + 1);
}

int main()
{
    cin >> n >> m;
    graph = vector<vector<ll>>(n);
    vector<ll> degreeIn(n, 0);
    for (ll i = 0; i < m; i++)
    {
        ll a, b;
        cin >> a >> b;
        a--;
        b--;
        graph[a].push_back(b);
        degreeIn[b]++;
    }
    ans = stack<ll>();
    visited = vector<bool>(n, false);
    bool flag = true;
    
    for(ll i = 0; i < n; i++)
    {
        if(!visited[i] && degreeIn[i] == 0)
        {
            dfs(i);
        }
    }

    if (ans.size() == n)
    {
        while(ans.size())
        {
            cout << ans.top() << endl;
            ans.pop();
        }
    }
    else
    {
        cout << "IMPOSSIBLE" << endl;
    }
    return 0;
}