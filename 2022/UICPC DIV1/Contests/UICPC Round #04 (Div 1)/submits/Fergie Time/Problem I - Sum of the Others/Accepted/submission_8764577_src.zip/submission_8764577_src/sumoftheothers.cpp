#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<ll> readLine(string s)
{
    vector<ll> q;

    stringstream ss(s);
    string qs;
    while (getline(ss, qs, ' '))
    {
        q.push_back(stoll(qs));
    }
    return q;
}
int main()
{
    string s;
    while(getline(cin,s)){
        vector<ll> arr;
        arr=readLine(s);
        ll sum=accumulate(arr.begin(),arr.end(),0ll);
        for(ll i=0;i<arr.size();i++){
            if(sum-arr[i]==arr[i]){
                cout<<arr[i]<<endl;
                break;
            }

        }
    }
}
