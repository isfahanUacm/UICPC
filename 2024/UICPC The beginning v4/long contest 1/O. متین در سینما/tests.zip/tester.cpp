//be name khoda

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
using namespace std;

int F(char c)
{
	if(c=='t')
		return 2;
	if(c=='n')
		return 1;
	return 0;
}

int main(int argc, char const *argv[])
{
	ifstream tin(argv[1]);    /* This stream reads from test's input file   */
	ifstream tout(argv[2]);   /* This stream reads from test's output file  */
	ifstream uout(argv[3]);   /* This stream reads from user's output file  */
	int n,m,sn,nn,tn;
	string s[2100],s2[2100];
	tin>>n>>m;
	for(int i=0;i<n;i++)
		tin>>s[i];
	tin>>sn>>nn>>tn;
	uout>>s2[0];
	for(int i=0;i<s2[0].size();i++)
		if(s2[0][i]!='#' && s2[0][i]!='s' && s2[0][i]!='n' && s2[0][i]!='t')
		{
			string st;
			tout>>st;
			if(st==s2[0])
				return 0;
			return 1;
		}
	for(int i=1;i<n;i++)
		uout>>s2[i];
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
		{
			if(s[i][j]!='#' && s2[i][j]=='#')
				return 1;
			if(s[i][j]=='#' && s2[i][j]!='#')
			{
				if(s2[i][j]=='t')
					tn--;
				else if(s2[i][j]=='n')
					nn--;
				else
					sn--;
			}
			if(s2[i][j]!='#' && s2[i][j]!='s' && s2[i][j]!='n' && s2[i][j]!='t')
				return 1;
			if(nn<0 || sn<0 || tn<0)
				return 1;
		}
	for(int i=0;i<m;i++)
	{
		char last='#';
		for(int j=0;j<n;j++)
			if(s[j][i]!='#')
			{
				if(last!='#' && F(s[j][i])>F(last))
					return 1;
				last=s[j][i];
			}
	}
	return 0;
}