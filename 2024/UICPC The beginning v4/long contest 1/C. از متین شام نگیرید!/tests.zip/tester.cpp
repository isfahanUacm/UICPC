/*
 * tester.cpp
 * Output case insensitive
 */

#include <iostream>
#include <fstream>
#include <string>
#include<bits/stdc++.h>

using namespace std;
int main(int argc, char const *argv[])
{

	ifstream test_in(argv[1]);    /* This stream reads from test's input file   */
	ifstream test_out(argv[2]);   /* This stream reads from test's output file  */
	ifstream user_out(argv[3]);   /* This stream reads from user's output file  */

	/* Your code here */
	/* If user's output is correct, return 0, otherwise return 1       */

	string test_out_lower;
	test_out >> test_out_lower;
	transform(test_out_lower.begin(), test_out_lower.end(), test_out_lower.begin(), ::tolower);

	string user_out_lower;
	user_out >> user_out_lower;
	transform(user_out_lower.begin(), user_out_lower.end(), user_out_lower.begin(), ::tolower);

	if (user_out_lower == test_out_lower)
		return 0;
	else
		return 1;
}
