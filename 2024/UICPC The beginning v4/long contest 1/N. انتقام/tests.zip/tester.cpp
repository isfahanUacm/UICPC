#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int num[200];

int main(int argc, char const *argv[])
{
	ifstream test_in(argv[1]);    /* This stream reads from test's input file   */
	ifstream test_out(argv[2]);   /* This stream reads from test's output file  */
	ifstream user_out(argv[3]);   /* This stream reads from user's output file  */
 
	/* Your code here */
	/* If user's output is correct, return 0, otherwise return 1       */
	string input, output, user_output;
	test_in >> input;
	test_out >> output;
	user_out >> user_output;

	if (output == "NO") {
		if (user_output == "NO") return 0;
		else return 1;
	}

	int n = int(input.length());
	
	if (int(user_output.length()) != n) return 1;

	string rev_user_output = user_output;
	reverse(rev_user_output.begin(), rev_user_output.end());
 	if (user_output != rev_user_output) return 1;

	for (int i = 0; i < n; i++) num[input[i]-'A']++;
	for (int i = 0; i < n; i++) num[user_output[i]-'A']--;
	for (int i = 0; i < 26; i++) if (num[i]) return 1;
	return 0;
}
