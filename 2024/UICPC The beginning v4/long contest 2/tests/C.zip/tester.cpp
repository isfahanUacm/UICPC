#include <bits/stdc++.h>

using namespace std;

int main(int argc, char const *argv[]) 
{
	ifstream test_in(argv[1]);
	ifstream test_out(argv[2]);
	ifstream user_out(argv[3]);

	long double a;
	test_out >> a;

	long double b;
	user_out >> b;

	if (abs(a - b) > (long double)0.001)
		return 1;

	return 0;
}
