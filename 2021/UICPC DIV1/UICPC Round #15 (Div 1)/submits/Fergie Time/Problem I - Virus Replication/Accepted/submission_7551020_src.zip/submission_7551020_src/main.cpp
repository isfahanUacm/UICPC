#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;

int main()
{
    string a, b;
    cin >> a >> b;
    ll i,j;
    for(i=0; i<min(a.length(),b.length()); i++)
    {
        if(a[i] != b[i])
            break;
    }

    for(j=0; j<min(a.length(),b.length()); j++)
    {
        if(a[a.length()-j-1] != b[b.length()-j-1])
            break;
    }

//     watch(i);
//     watch(j);

    j = (ll)b.length()-j-1;
    ll ans = (ll)b.length() - (ll)a.length();
    ans = max(ans, j-i+1);
    cout << max(ans , 0ll);
}

