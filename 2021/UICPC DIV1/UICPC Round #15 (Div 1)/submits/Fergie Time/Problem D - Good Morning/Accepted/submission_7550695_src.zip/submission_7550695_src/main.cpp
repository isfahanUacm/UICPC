#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

map<char, pll> coor = {
        {'1', {0, 0}},
        {'2', {0, 1}},
        {'3', {0, 2}},
        {'4', {1, 0}},
        {'5', {1, 1}},
        {'6', {1, 2}},
        {'7', {2, 0}},
        {'8', {2, 1}},
        {'9', {2, 2}},
        {'0', {3, 1}}
};
bool canType(string s)
{
    for(ll i = 1; i < s.length(); i++)
    {
        if(!((coor[s[i - 1]].first <= coor[s[i]].first) && (coor[s[i - 1]].second <= coor[s[i]].second)))
        {
            return false;
        }
    }
    return true;
};
int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        string k;
        cin >> k;
        ll num = stoi(k);
        for(ll i = 0; i < 200; i++)
        {
            if(canType(to_string(num - i)))
            {
                cout << num - i << endl;
                break;
            }
            if(canType(to_string(num + i)))
            {
                cout << num + i << endl;
                break;
            }
        }
    }
    return 0;
}