#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
bool dp[2000][1500];
int sp[2000][1500];

map<int, string> id;
int arr[10];
int price[10];
int n;

int main() {
    double tm, a;
    int money;
    int alc;
    cin >> tm >> a >> n;
    money = tm * 100;
    alc = a * 60;

    for (int i = 0; i < n; ++i) {
        string t;
        int c;
        string p;
        double mm;
        cin >> t >> c >> p >> mm;
        id[i] = t;
        if (p == "1/1") {
            arr[i] = c * 60;
        }
        else if (p == "1/2") {
            arr[i] = c * 30;
        }
        else {
            arr[i] = c * 20;
        }
        price[i] = mm * 100;
    }

    memset(dp, 0, sizeof(dp));
    dp[0][0] = true;
    for (int i = 0; i < 1100; ++i) {
        for (int j = 0; j < 1400; ++j) {
            for (int k = 0; k < n; ++k) {
                if (price[k] <= i && arr[k] <= j && dp[i - price[k]][j - arr[k]]) {
                    dp[i][j] = true;
                    sp[i][j] = k;
                }
            }
        }
    }
    if (dp[money][alc]) {
        map<int, int> mp;
        while (money != 0 && alc != 0) {
            mp[sp[money][alc]]++;
            money -= price[sp[money][alc]];
            alc -= arr[sp[money][alc]];
        }
        for (auto x : mp) {
            cout << id[x.first] << ' ' << x.second << endl;
        }
    }
    else {
        cout << "IMPOSSIBLE" << endl;
    }
}

