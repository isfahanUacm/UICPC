
list = {
  "1": ["0","1","2","3","4","5","6","7","8","9"],
  "2": ["0","2","3","5","6","8","9"],
  "3": ["3","6","9"],
  "4": ["0","4","5","6","7","8","9"],
  "5": ["0","5","6","8","9"],
  "6": ["6","9"],
  "7": ["0","7","8","9"],
  "8": ["0","8","9"],
  "9": ["9"],
  "0": ["0"]
}

def can_make(number):
  canMake = True;

  for index in range(len(number) - 1):
    if not number[index + 1] in list[number[index]]:
      canMake = False
      break

  return canMake

num = int(input())

for _ in range(num):
  number = int(input())
  valueAddedOrSubmissed = 1

  while True:
    if can_make(str(number)):
      print(number)
      break
    else:
      if can_make(str(number + valueAddedOrSubmissed)):
        print(number + valueAddedOrSubmissed)
        break
      elif can_make(str(number - valueAddedOrSubmissed)):
        print(number - valueAddedOrSubmissed)
        break
      else:
        valueAddedOrSubmissed += 1