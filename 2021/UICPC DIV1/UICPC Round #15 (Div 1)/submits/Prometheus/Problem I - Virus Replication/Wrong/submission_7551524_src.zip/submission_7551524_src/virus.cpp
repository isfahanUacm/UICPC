#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

int main(){
    string s1,s2;
    cin >> s1 >> s2;

    int count = 0;
    int minimum = min(s1.length(), s2.length());

    for (int i = 0; i < minimum; i++) {
        if (s1[i] == s2[i]) {
            count++;
            continue;
        }
        break;
    }

    for (int i = 1; i <= minimum - count; i++) {
        if ( s1[s1.length() - i] == s2[s2.length() - i] ) {
            count++;
            continue;
        }
        break;
    }

    if (count >= s2.length())
        count = s2.length();

    cout << s2.length() - count << endl;
}