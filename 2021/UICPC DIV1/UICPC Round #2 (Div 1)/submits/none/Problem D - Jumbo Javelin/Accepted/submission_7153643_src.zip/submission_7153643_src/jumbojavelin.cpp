#include <iostream>
using namespace std;

int main()
{
    int n, i, sum= 0;
    cin>> n;
    int * x= new int [n];
    for (i=0; i<n; i++)
    {
        cin>> x[i];
        sum += x[i];
    }
    cout<< sum- n+ 1<< endl;
    return 0;
}