#include <iostream>
using namespace std;

int main()
{
    int n, i, max= -1;
    cin>> n;
    int * x= new int [n];
    for (i=0; i<n; i++)
    {
        cin>> x[i];
        if (x[i] > max)
            max= x[i];
    }
    cout<< max<< endl;
    return 0;
}