#include<bits/stdc++.h>
using namespace std;
#define M 1000000+100

vector<long long> prime;

void gharbal(){
    bool flag[M];
    memset(flag,1,sizeof(flag));

    for (int i=2;i<M;i++)
        if (flag[i]){
            prime.push_back(i);
            for (int j=1;j*i<M;j++)
                flag[i*j]=false;
        }
}

long long solve(long long n){
    vector<pair<int,int>> ans;
    for (int i=0;prime[i]<=sqrt(n);i++){
        long long tmp=0;
        while (n%prime[i]==0){
            tmp++;
            n/=prime[i];
        }
        ans.push_back(pair<long long,long long>(prime[i],tmp));
    }
    long long answer=1;
    for (int i=0;i<ans.size();i++)
        if (ans[i].second!=0)
            answer*=pow(ans[i].second,ans[i].first);
    return answer;

}

int main()
{
    gharbal();
    long long n;
    while (cin>>n)
        cout<<n<<" "<<solve(n)<<endl;

    return 0;
}
