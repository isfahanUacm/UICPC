#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
 	ll n,m;
 	while(true){
 		ll ans=0;
 		cin >> n >> m;
 		if(n==0&&m==0)break;
 		std::vector<ll> jack(n);
 		for(ll i=0;i<n;i++){
 			cin >> jack[i];
 		}
 		for(ll i=0;i<m;i++){
 			ll in;
 			cin >> in;
 			if(binary_search(jack.begin(),jack.end(),in))ans++;
 			
 		}
 		cout<<ans<<endl;

 	}
	return 0;
}