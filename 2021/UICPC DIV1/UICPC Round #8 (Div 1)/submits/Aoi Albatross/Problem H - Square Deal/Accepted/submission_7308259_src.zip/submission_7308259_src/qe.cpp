#include<bits/stdc++.h>
using namespace std;

bool con1(int a,int b,int c,int d,int e,int f){
    if (a==c && a==e)
        if (b+d+f==a)
            return true;
    if (a==c && a==f)
        if (b+d+e==a)
            return true;
    if (a==d && a==e)
        if (b+c+f==a)
            return true;
    if (a==d && a==f)
        if (b+c+e==a)
            return true;

    if (b==c && b==e)
        if (a+d+f==b)
            return true;
    if (b==c && b==f)
        if (a+d+e==b)
            return true;
    if (b==d && b==e)
        if (a+c+f==b)
            return true;
    if (b==d && b==f)
        if (a+c+e==b)
            return true;

    return false;
}

bool con2(int a,int b,int c,int d,int e,int f){
    if (a==c){
        if ((b+d==e && e==f+a) || (b+d==f && f==e+a))
            return true;
    }else if (a==d){
        if ((b+c==e && e==f+a) || (b+c==f && f==e+a))
            return true;
    }else if (b==c){
        if ((a+d==e && e==f+b) || (a+d==f && f==e+b))
            return true;
    }else if (b==d){
        if ((a+c==e && e==f+b) || (a+c==f && f==e+b))
            return true;
    }
    return false;
}

int main()
{
    int a,b,c,d,e,f;
    cin>>a>>b;
    cin>>c>>d;
    cin>>e>>f;

    if (con1(a,b,c,d,e,f))
        cout<<"YES"<<endl;
    else if (con2(a,b,c,d,e,f))
        cout<<"YES"<<endl;
    else if (con2(a,b,e,f,c,d))
        cout<<"YES"<<endl;
    else if (con2(e,f,c,d,a,b))
        cout<<"YES"<<endl;
    else cout<<"NO"<<endl;

    return 0;
}
