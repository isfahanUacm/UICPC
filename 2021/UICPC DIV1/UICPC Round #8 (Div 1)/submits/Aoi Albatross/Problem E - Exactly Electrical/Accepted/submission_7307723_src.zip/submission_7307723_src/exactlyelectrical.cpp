#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll a,b,c,d,f;
	cin >> a >> b >> c >> d >> f;
	ll n = abs(a-c)+abs(b-d);
	cout<<((n%2)==(f%2)&&f>=n ? "Y":"N")<<endl;
	return 0;
}