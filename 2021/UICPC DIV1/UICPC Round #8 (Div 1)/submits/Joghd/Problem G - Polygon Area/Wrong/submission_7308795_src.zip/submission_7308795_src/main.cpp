#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
struct answer {
    string a;
    float area;
};
int wsat(float x1,float y1,float x2,float y2,float x,float y) {
    if((x1-x2) == 0) {
        if(y2>y1) {
            if(x>x1)
                return 1;
            else
                return 0;
        }
        if(x<x1)
            return 1;
        else
            return 0;

    }
    if((y1-y2) == 0) {
        if(x2>x1) {
            if(y<y1)
                return 1;
            else
                return 0;
        }
        if(y>y1)
            return 1;
        else
            return 0;

    }
    float a = (y1-y2)/(x1-x2);
    float b = y1 - a*x1;
    float yp= a*x + b;
    if(yp>y) {
        if(x1>x2) {
            return 0;
        }
        else {
            return 1;
        }
    }
    else {
        if(x1>x2) {
            return 1;
        }
        else {
            return 0;
        }
    }

}
answer que(int n) {
    answer ans;
    ans.area=0.0;
    float x[n], y[n];
    for(int i=0;i<n;i++)
        cin >> x[i] >> y[i];
    int j = n - 1;
    for (int i = 0; i < n; i++) {
            ans.area += (x[j] + x[i]) * (y[j] - y[i]);
            j = i;
    }
    ans.area /= 2.0;
    if(ans.area < 0)
        ans.area = -ans.area;
    ans.a = "CCW";
    int c = wsat(x[0],y[0],x[1],y[1],x[2],y[2]);
    for(int i=3;i<n;i++)  {
        if(wsat(x[i-2],y[i-2],x[i-1],y[i-1],x[i],y[i]) != c)
             ans.a = "CW";
    }
    if(wsat(x[n-2],y[n-2],x[n-1],y[n-1],x[0],y[0]) != c)
         ans.a = "CW";
    if(wsat(x[n-1],y[n-1],x[0],y[0],x[1],y[1]) != c)
         ans.a = "CW";

    return ans;
}
int main() {
    int n;
    cin >> n;
    answer b[100];
    int i=0;
    while (n) {
        b[i]=que(n);
        i++;
        cin >> n;
    }
    for(int j=0;j<i;j++) {
        cout << b[j].a << " " ;
        cout << fixed;
       cout << setprecision(1);

        cout << b[j].area << endl;

}

}
