#include <iostream>
#include <string>
int qq(int a,int b) {
    if(a-b >0)
        return a-b;
    return b-a;
}
using namespace std;

int main() {
    int x1, y1, x2, y2, d;
    cin >> x1 >>y1 >>x2 >>y2 >> d;
    int a = qq(x1,x2) + qq(y1,y2);
    if(a>d || (d-a)%2==1)
        cout << "N";
    else
        cout << "Y";

}
