#include <iostream>
using namespace std;

int main ()
{
    int x1, x2, y1, y2, t;
    cin>> x1>> y1>> x2>> y2;
    cin>> t;
    int d= 0;
    d= t- (abs(x2- x1)+ abs(y2- y1));
    if (d >= 0)
    {
        if (d % 2)
            cout<< "N"<< endl;
        else
            cout<< "Y"<< endl;
    }
    else
        cout<< "N"<< endl;
    return 0;
}
