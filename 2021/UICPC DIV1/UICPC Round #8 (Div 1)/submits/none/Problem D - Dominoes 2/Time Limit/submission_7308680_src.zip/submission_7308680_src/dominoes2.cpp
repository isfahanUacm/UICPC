#include <iostream>
#include <unordered_map>
using namespace std;

int main()
{
    int n , m,l,x;
    cin>>n;
    while (n--) {
        unordered_map<int, int> umap;

        cin >> x >> m >> l;
        for (int i = 0; i < m; ++i) {
            int a,b;
            cin>>a>>b;
            umap[a]=b;

        }
        int hand[l];
        for (int i = 0; i < l; ++i) {
            cin>>hand[i];
        }
        int count =0;
        for (int i = 0; i < l; ++i) {
            count++;
            int s=hand[i];
            while (umap.count(s) > 0) {
                    for (auto e : umap) {
                        if (s == e.first) {
                            count++;
                            s = e.second;

                        }
                    }
                if (s == hand[i])
                    break;
                }

        }
        cout<<count<<endl;

    }
}