#include <iostream>
#include <unordered_map>
using namespace std;

int find(unordered_map<int , int> umap ,  int s ,int count)
{
    if (umap.count(s) > 0) {
        for (auto e : umap) {
            if (s == e.first) {
                count++;
                find(umap, e.second, count);
                return count;

            }
        }
    }
    return count;
}
int main()
{
    int n , m,l,x;
    cin>>n;
    while (n--) {
        unordered_map<int, int> umap;

        cin >> x >> m >> l;
        for (int i = 0; i < m; ++i) {
            int a,b;
            cin>>a>>b;
            umap[a]=b;

        }
        int hand[l];
        for (int i = 0; i < l; ++i) {
            cin>>hand[i];
        }
        int count =0;
        for (int i = 0; i < l; ++i) {
            count++;
            count = find(umap  , hand[i] , count);
        }
        cout<<count<<endl;

    }
}