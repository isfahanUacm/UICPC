#include <bits/stdc++.h>
using namespace std;
bool flag = false;
void ff(int a[3][2],int w,int h,int d){
    if (a[d][0] == h && (a[d][1]+w) == h) flag = true;
    else if (a[d][1] == h && (a[d][0]+w) == h) flag = true;
    else if (a[d][0] == w && (a[d][1]+h) == w) flag = true;
    else if (a[d][1] == h && (a[d][0]+h) == w) flag = true;
}

void f(int a[3][2],int b , int c){
    int h,d;
    if (b==0 && c==1) d =2;
    else if (b==0 && c==2) d =1;
    else if (b==1 && c==2) d =0;
    for (int i = 0 ; i < 2 ; ++i){
        for (int j = 0 ; j < 2 ;++j){
            if (a[b][i]==a[c][j]){
                if (i == 0 && j == 0) h = a[b][1]+a[c][1];
                else if (i == 1 && j == 0) h = a[b][0]+a[c][1];
                else if (i == 0 && j == 1) h = a[b][1]+a[c][0];
                else if (i == 1 && j == 1) h = a[b][0]+a[c][0];
                ff(a,(a[b][i]),h,d);
            }
        }
    }
}

int main()
{
    int i , j , k;
    int a[3][2];
    for (i = 0 ; i < 3 ;++i)
        cin >> a[i][0] >> a[i][1];
    for (i = 0 ; i < 2 ;++i)
        for (j = i+1 ; j < 3 ;++j)
            f(a,i,j);
    if (flag) cout <<"YES";
    else cout <<"NO";
}
