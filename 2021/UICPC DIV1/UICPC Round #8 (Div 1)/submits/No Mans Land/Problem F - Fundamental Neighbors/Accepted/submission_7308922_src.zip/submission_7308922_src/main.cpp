#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    while(cin >> n)
    {
        cout << n << " ";
        int cnt = 0, Neighbor = 1;
        while((n & 1) == 0)
        {
            cnt++;
            n >>= 1;
        }
        if(cnt > 0)
            Neighbor *= pow(cnt , 2);
        for(int i = 3; i <= sqrt(n); i++)
        {
            cnt = 0;
            while(n % i == 0)
            {
                n /= i;
                cnt++;
            }
            if(cnt != 0)
                Neighbor *= pow(cnt, i);
        }
        cout << Neighbor << endl;
    }
}
