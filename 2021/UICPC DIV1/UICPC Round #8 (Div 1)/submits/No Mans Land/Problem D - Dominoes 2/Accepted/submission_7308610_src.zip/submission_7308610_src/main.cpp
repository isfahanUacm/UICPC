#include <bits/stdc++.h>
using namespace std;

bool isfallen[10001];
map <int , vector<int>> a;
int cnt = 0;

void f(int b)
{
    if(a.find(b) != a.end())
    {
        if(!isfallen[b])
        {
            isfallen[b] = true;
            cnt++;
            for(int i = 0; i < a[b].size(); i++)
            {
                if(!isfallen[a[b][i]])
                {
                    f(a[b][i]);
                }
            }
        }
    }
    else
        if(!isfallen[b])
        {
            isfallen[b] = true;
            cnt++;
        }
}

int main()
{
    int m, n, l, t;
    cin >> t;
    while(t--)
    {
        cin >> n >> m >> l;

        a.clear();
        fill(isfallen, isfallen +10001, 0);
        int b, c;

        for(int i = 0; i < m; i++)
        {
            cin >> b >> c;
            a[b].push_back(c);
        }
        cnt = 0;

        for(int i = 0; i < l; i++)
        {
            cin >> b;
            f(b);
        }

        cout << cnt << endl;

    }
}
