#include <iostream>
#include <queue>
#include <string>
using namespace std;

void count(int *x,string s) {
    int num = 0;
    char athom = 'A';
    for(int i=0;i<s.size();i++) {
        if(s[i]>='A' && s[i]<='Z' ) {
            x[athom-'A'] += num;
            if(num == 0 && i != 0)
                x[athom-'A']++;
            athom = s[i];
            num = 0;
        }
        else {
            num *= 10;
            num += s[i]-'0';
        }
    }
    x[athom-'A'] += num;
    if(num == 0)
        x[athom-'A']++;
}


int main() {
    int athomin[26] = {0}, athomout[26] = {0}, n;
    string input,output;
    cin >> input >> n >> output;
    count(athomin,input);
    count(athomout,output);
    int min = 2147483647;
    for(int i=0;i<26;i++) {
        if(athomout[i]==0)
            continue;
        if(n*athomin[i]/athomout[i] < min)
            min = n*athomin[i]/athomout[i];
    }
    cout << min;
}
