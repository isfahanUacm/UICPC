for t in range(int(input())):
    ma = 0
    n = input()
    for i in range(1, len(n)+1):
        x = int(n[0:i])
        #print(bin(x))
        ma = max(ma, bin(x).count('1'))
    print(ma)
    

