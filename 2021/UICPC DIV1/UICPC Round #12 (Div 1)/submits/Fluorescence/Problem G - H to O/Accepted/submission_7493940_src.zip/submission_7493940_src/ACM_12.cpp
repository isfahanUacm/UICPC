#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

int main()
{
	string s ,s2;
	int num;
	cin >> s >> num >> s2;

	map<char, int> m1, m2;
	map<char, int> count;

	for (int i = 0; i < s.size(); i++) {
		if (s[i] >= 48 && s[i] <= 57) {
			continue;
		}
		auto it = m1.find(s[i]);
		if (it == m1.end()) {
			m1[s[i]] = 1;
			if (i == s.size() - 1)
				break;
			int j = i + 1;
			if (s[i + 1] >= 48 && s[i + 1] <= 57) {
				string c = "";
				while (s[j] >= 48 && s[j] <= 57) {
					c += s[j];
					j++;
				}
				int c2 = stoi(c);
				m1[s[i]] = c2;
			}
		}
		else {
			m1[s[i]] ++;
			int j = i + 1;
			if (s[i + 1] >= 48 && s[i + 1] <= 57) {
				string c = "";
				while (s[j] >= 48 && s[j] <= 57){
					c += s[j];
					j++;
				}
				int c2 = stoi(c);
				m1[s[i]] += c2 - 1;
			}
		}
	}
	for (auto it = m1.begin(); it != m1.end(); it++) {
		it->second *= num;
	}

	for (int i = 0; i < s2.size(); i++) {
		if (s2[i] >= 48 && s2[i] <= 57) {
			continue;
		}
		auto it = m2.find(s2[i]);
		if (it == m2.end()) {
			count[s2[i]] = 1;
			m2[s2[i]] = 1;
			if (i == s2.size() - 1)
				break;
			int j = i + 1;
			if (s2[i + 1] >= 48 && s2[i + 1] <= 57) {
				string c = "";
				while (s2[j] >= 48 && s2[j] <= 57) {
					c += s2[j];
					j++;
				}
				int c2 = stoi(c);
				m2[s2[i]] = c2;
			}
		}
		else {
			m2[s2[i]] ++;
			int j = i + 1;
			if (s2[i + 1] >= 48 && s2[i + 1] <= 57) {
				string c = "";
				while (s2[j] >= 48 && s2[j] <= 57) {
					c += s2[j];
					j++;
				}
				int c2 = stoi(c);
				m2[s2[i]] += c2 - 1;
			}
		}
	}

	int ans=INT_MAX;
	bool flag = 1;
	for (int i = 0; i < s2.size(); i++) {
		if (s2[i] >= 48 && s2[i] <= 57) {
			continue;
		}
		char c = s2[i];
		auto it = m1.find(c);
		if (it == m1.end()) {
			flag = 0;
			break;
		}
		count[c] = m1[c] / m2[c];
		ans = min(ans, count[c]);
	}
	if (flag) {
		cout << ans;
		
	}
	else
		cout << 0;
}