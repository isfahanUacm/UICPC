#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

int main() {
    lli n, h, l, x, a, b;
    bool visit[10005];
    queue<pair<int, int>> q;
    vector<vector<int>> adj(10005);
    vector<pair<int,int>> res;
    vector<int> f_res;
    cin>>n>>h>>l;
    fill_n(visit, n, false);

    for (int i = 0; i < h; i++)
    {
        cin>>x;
        visit[x] = true;
        q.push({0, x});
    }

    for (int i = 0; i < l; i++)
    {
        cin>>a>>b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    pair<int, int> u;
    int hi, ind, m_hi = 0;
    while(!q.empty()){
        u = q.front();
        q.pop();
        hi = u.first;
        ind = u.second;

        if (m_hi <= hi) {
            m_hi = hi;
            res.push_back({hi, ind});
        }

        for (auto v: adj[ind]){
            if (!visit[v]){
                q.push({hi+1, v});
                visit[v] = true;
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        //cout<<i<<" "<<visit[i]<<endl;
        if (!visit[i]) {res.push_back({INT_MAX, i});
        m_hi = INT_MAX;
        }
    }
    

    for(auto r: res){
        if(r.first >= m_hi) f_res.push_back(r.second);
    }

    sort(f_res.begin(), f_res.end());

    cout<<f_res[0]<<endl;

}