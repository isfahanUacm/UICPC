#include <iostream>
#include <climits>
using  namespace std;
int main() {
    string s , s1 , p;
    long long int n , j ,min = INT_MAX ,t;
    cin >> s >> n >> p;
    long long int arr[26];
    long long int arr1[26];
    for (int i = 0 ; i < 26 ; i++)
        arr[i] = 0 , arr1[i] = 0;
    for (int i = 0 ; i < s.length() ; ++i){
        j = i;
        s1.clear();
        while (int(s[i+1])<65 && (i+1)<s.length()) {
            s1+=s[i+1];
            i++;
        }
        if (s1.empty()) s1 += '1';
        arr[int(s[j])-65] += stoll(s1);
    }
    for (int i = 0 ; i < 26 ; i++)
        arr[i] *= n;
    for (int i = 0 ; i < p.length() ; ++i){
        j = i;
        s1.clear();
        while (int(p[i+1])<65 && (i+1)<p.length()) {
            s1+=p[i+1];
            i++;
        }
        if (s1.empty()) s1 += '1';
        arr1[int(p[j])-65] += stoll(s1);
    }
    for (int i = 0 ; i < 26 ; i++){
        if (arr1[i]==0) continue;
        t = arr[i]/arr1[i];
        if (t < min) min = t;
    }
    cout << min;
    return 0;
}
