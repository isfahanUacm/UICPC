#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

string arr[] = {"draw", "player one wins", "player two wins"};

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        int h, w, n;
        cin >> w >> h >> n;

        int total1 = 0;
        int total2 = 0;
        int mp1[h][w];
        int mp2[h][w];

        for (int i = 0; i < h; ++i) {
            for (int j = 0; j < w; ++j) {
                char ch;
                cin >> ch;
                if (ch == '_') {
                    mp1[i][j] = 0;
                }
                else {
                    mp1[i][j] = 1;
                    total1++;
                }
            }
        }

        for (int i = 0; i < h; ++i) {
            for (int j = 0; j < w; ++j) {
                char ch;
                cin >> ch;
                if (ch == '_') {
                    mp2[i][j] = 0;
                }
                else {
                    mp2[i][j] = 1;
                    total2++;
                }
            }
        }

        int turn = 0;
        int totalTurn = 0;
        bool flag = false;
        int won = 0;
        for (int i = 0; i < n; ++i) {
            int x, y;
            cin >> y >> x;
            x = h - x - 1;
            if (turn == 0) {
                if (mp2[x][y] == 1) {
                    mp2[x][y] = 0;
                    total2--;
                    if (total2 == 0) {
                        totalTurn++;
                        turn ^= 1;
                    }
                }
                else {
                    totalTurn++;
                    turn ^= 1;
                }
            }
            else if (turn == 1) {
                if (mp1[x][y] == 1) {
                    mp1[x][y] = 0;
                    total1--;
                    if (total1 == 0) {
                        totalTurn++;
                        turn ^= 1;
                    }
                }
                else {
                    totalTurn++;
                    turn ^= 1;
                }
            }
            if (!flag) {
                if (totalTurn % 2 == 0 && total1 == 0 && total2 != 0) {
                    won = 2;
                    flag = true;
                } else if (totalTurn % 2 == 0 && total1 != 0 && total2 == 0) {
                    won = 1;
                    flag = true;
                } else if (totalTurn % 2 == 0 && total1 == 0 && total2 == 0) {
                    won = 0;
                    flag = true;
                }
            }
        }
        if (flag) {
            cout << arr[won] << endl;
        }
        else {
            cout << arr[0] << endl;
        }
    }
}