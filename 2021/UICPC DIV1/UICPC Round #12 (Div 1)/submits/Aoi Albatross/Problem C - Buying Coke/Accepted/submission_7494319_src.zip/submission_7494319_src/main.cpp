#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ll;

int main(){
    int tc;
    cin >> tc;
    while (tc--) {

        int s, n1, n5, n10;
        int ss, nn1, nn5, nn10;

        cin >> ss >> nn1 >> nn5 >> nn10;
        ll mm = INT_MAX;

        for (int i = 0; i <= min(nn10, min(nn1 / 3, ss)); ++i) {
            ll ans = 0;
            s = ss;
            n1 = nn1;
            n5 = nn5;
            n10 = nn10;

            n1 -= i * 3;
            n10 -= i;
            n5 += i;
            s -= i;
            ans += i * 4;

            int q = min(n10, s);
            n10 -= q;
            n1 += q * 2;
            s -= q;
            ans += q;

            int mi = INT_MAX;
            for (int i = 0; i <= min(n5 / 2, s); ++i) {
                int sh = s;
                int n1h = n1;
                int n5h = n5;
                int ah = 0;
                ah += i * 2;
                sh -= i;
                n1h += 2 * i;
                n5h -= 2 * i;

                q = min(n1h / 3, min(n5h, sh));
                sh -= q;
                n1h -= q * 3;
                n5h -= q;
                ah += q * 4;

                q = min(n1h / 8, sh);
                sh -= q;
                n1h -= q * 8;
                ah += q * 8;

                if (sh == 0)
                    mi = min(mi, ah);
            }
            mm = min(mm, ans + mi);
        }
        cout << mm << endl;
    }
}