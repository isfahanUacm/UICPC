#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 1e4 + 10;
ll dist[MAX];
ll cnt[MAX];
ll parent[MAX];
set<pair<ll, ll>> ss;
vector<pair<ll, ll>> adj[MAX];
ll s, t;

void dijkstra(int start) {
    cnt[start] = 1;
    dist[start] = 0;
    parent[start] = 0;
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (dist[v.first] > dist[u] + v.second) {
                cnt[v.first] = cnt[u];
                ss.erase({dist[v.first], v.first});
                dist[v.first] = dist[u] + v.second;
                ss.insert({dist[v.first], v.first});
                parent[v.first] = u;
            }
            else if (dist[v.first] == dist[u] + v.second) {
                cnt[v.first] += cnt[u];
            }
        }
    }
}

void print(int end) {
    stack<ll> stc;
    ll ind = end;
    do {
        stc.push(ind);
        ind = parent[ind];
    } while (parent[ind] != ind);
    stc.push(ind);
    while (!stc.empty()) {
        cout << stc.top() + 1 << ' ';
        stc.pop();
    }
    cout << endl;
}

int main() {
    ll n, m;
    cin >> n >> m;
    for (ll i = 0; i < n; ++i) {
        dist[i] = LONG_LONG_MAX;
    }
    for (ll i = 0; i < m; ++i) {
        ll a, b, w;
        cin >> a >> b >> w;
        adj[a].emplace_back(b, w);
    }
    cin >> s >> t;
    dijkstra(s);

    if (dist[t] == LONG_LONG_MAX) {
        cout << 0 << endl;
    }
    else {
        cout << cnt[t] << endl;
    }
}