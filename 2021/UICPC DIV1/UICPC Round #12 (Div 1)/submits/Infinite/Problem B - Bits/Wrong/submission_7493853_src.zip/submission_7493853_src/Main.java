import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	static int a[];
	static double dp[][];
	static int n, k;

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		for (int i = 0 ; i < n ; i ++){
			int x = s.nextInt();
			String bin = Integer.toBinaryString(x);

			int cnt = 0 ;
			for (int k = 0 ; k < bin.length() ;k ++) {
				if (bin.charAt(k) == '1') cnt ++;
			}
			System.out.println(cnt);
		}

	}

}
