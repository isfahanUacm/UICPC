import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	static int a[];
	static double dp[][];
	static int n, k;

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		for (int i = 0 ; i < n ; i ++){
			String x = s.next();
			int max = Integer.MIN_VALUE , cnt = 0;
			for (int j = 0 ; j < x.length() ; j ++){
				cnt = 0;
				int c = x.charAt(j)-48;
				String bin = Integer.toBinaryString(c);
				for (int k = 0 ; k < bin.length() ;k ++) {
					if (bin.charAt(k) == '1') cnt ++;
				}
				if (cnt > max ) max = cnt;
			}
			int g = Integer.parseInt(x);
			String bin = Integer.toBinaryString(g);
			cnt = 0 ;
			for (int k = 0 ; k < bin.length() ;k ++) {
				if (bin.charAt(k) == '1') cnt ++;
			}
			if (cnt > max ) max = cnt;
			System.out.println(max);

		}

	}

}
