#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

bool shot(vector<string> &mp, ll x, ll y, ll n, ll m)
{
    if (mp[x][y] == '#')
    {
        mp[x][y] = '_';
        return true;
        //        if(x - 1 >= 0)
        //        {
        //            shot(mp, x - 1, y, n, m);
        //        }
        //        if(y - 1 >= 0)
        //        {
        //            shot(mp, x, y - 1, n, m);
        //        }
        //        if(x + 1 < n)
        //        {
        //            shot(mp, x + 1, y, n, m);
        //        }
        //        if(y + 1 < m)
        //        {
        //            shot(mp, x, y + 1, n, m);
        //        }
    }
    return false;
}

bool finished(vector<string> &mp, ll n, ll m)
{
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            if (mp[i][j] == '#')
            {
                return false;
            }
        }
    }
    return true;
}

int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        ll w, h, turns;
        cin >> w >> h >> turns;
        vector<string> map1(h);
        vector<string> map2(h);
        for (ll i = 0; i < h; i++)
        {
            cin >> map1[i];
        }
        for (ll i = 0; i < h; i++)
        {
            cin >> map2[i];
        }
        vector<pll > orders(turns, {0, 0});
        for (ll i = 0; i < turns; i++)
        {
            cin >> orders[i].first >> orders[i].second;
        }

        char player = '1';
        bool win1 = false;
        bool win2 = false;
        for (ll i = 0; i < turns; i++)
        {
            ll x, y;
            x = orders[i].first;
            y = orders[i].second;
            //            watch(player);
            y = h - 1 - y;
            if (player == '1')
            {
                bool hit = shot(map2, y, x, h, w);
                if (win2)
                {
                    if (finished(map2, h, w))
                    {
                        win1 = true;
                        break;
                    }
                    if(!hit)
                    {
                        break;
                    }
                }
                else if (finished(map2, h, w))
                {
                    win1 = true;
                    player = '2';
                    continue;
                }
                if(!hit)
                {
                    player = '2';
                }
            }
            else if (player == '2')
            {
                bool hit = shot(map1, y, x, h, w);
                if (win1)
                {
                    if (finished(map1, h, w))
                    {
                        win2 = true;
                    }
                    if(!hit)
                    {
                        break;
                    }
                }
                else if (finished(map1, h, w))
                {
                    win2 = true;
                    player = '1';
                    break;
                }
                if(!hit)
                {
                    player = '1';
                }
            }
        }
        //        watch(win1);
        //        watch(win2);
        //        for (ll i = 0; i < h; i++)
        //        {
        //            cout << map1[i] << endl;
        //        }
        //        for (ll i = 0; i < h; i++)
        //        {
        //            cout << map2[i] << endl;
        //        }
        //        cout << endl;
        if((win1 && win2) || (!win1 && !win2))
        {
            cout << "draw" << endl;
        }
        else
        {
            if(win1)
            {
                cout << "player one wins" << endl;
            }
            else if(win2)
            {
                cout << "player two wins" << endl;
            }
        }

    }
    return 0;
}