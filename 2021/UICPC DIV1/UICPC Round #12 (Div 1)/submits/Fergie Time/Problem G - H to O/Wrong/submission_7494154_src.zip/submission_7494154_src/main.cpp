#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


int main()
{
   int alpha1 [26];
   int alpha2 [26];
   for (int i=0;i<26;i++)
   {
       alpha1[i]=0;
       alpha2[i]=0;
   }
   string a;
   cin>>a;
   int n;
   cin>>n;
   string b;
   cin>>b;
   int k=0;
   int num=0;
   char counter = 0;
 //  cout<<a[0]-65;
   while(k < a.length())
   {

        if (0 > a[k]-65 ||  a[k]-65>=32 )
        {
            num *= 10;
            num += a[k] -48;
            counter ++;
            //cout <<num<<endl;
            if(k == a.length()-1)
            {
                alpha1[(a[k - (counter)]-65)] += num;
            }
        }
        else
        {
                 if (counter != 0)
                 {
                     alpha1[(a[k - (counter + 1)]-65)] += num;

                 }
                 else
                 {
                   if(k== a.length()-1 )
                       alpha1[a[k]-65] += 1;


                 }
                 if(k<a.length()-1 && 0 <= a[k+1]-65 && a[k+1]-65 < 32)
                    alpha1[(a[k]-65)] += 1;
                 counter = 0;
                 num = 0;
        }
        k+= 1;

   }

   for (int i=0;i<26;i++)
   {
       alpha1[i] *= n;
   }
   k =0;
   num = 0;
   counter = 0;
   while(k < b.length())
   {

       if (0 > b[k]-65 ||  b[k]-65>=32 )
       {
           num *= 10;
           num += b[k] -48;
           counter ++;
           if(k == b.length()-1)
           {
               alpha2[(b[k - (counter)]-65)] += num;
           }
       }
       else
       {
                if (counter != 0)
                {
                    alpha2[(b[k - (counter + 1)]-65)] += num;

                }
                else
                {
                    if(k==b.length()-1 )
                        alpha2[b[k]-65] += 1;

                }
                if(k<b.length()-1 && 0 <= b[k+1]-65 && b[k+1]-65 < 32)
                  alpha2[(b[k]-65)] += 1;
                counter = 0;
                num =0;
       }
       k+= 1;

   }
   int  min = INT_MAX;
   int devide;
   k=0;

   for (int i=0;i<26;i++)
   {
       if (alpha2[i] != 0)
       {
       devide = alpha1[i] / alpha2[i];
       if (devide < min)
           min = devide;
       }

   }
   cout<<min<<endl;


}
