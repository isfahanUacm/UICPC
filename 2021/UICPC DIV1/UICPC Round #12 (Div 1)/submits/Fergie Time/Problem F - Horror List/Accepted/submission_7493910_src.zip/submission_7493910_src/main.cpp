#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

int main()
{
    ll n, h, l;
    cin >> n >> h >> l;
    set<ll> hset;
    for(ll i = 0; i < h; i++)
    {
        ll x;
        cin >> x;
        hset.insert(x);
    }
    map<ll, set<ll>> mp;
    for(ll i = 0; i < l; i++)
    {
        ll a, b;
        cin >> a >> b;
        if(mp.find(a) == mp.end())
        {
            mp[a] = set<ll>();
        }
        mp[a].insert(b);

        if(mp.find(b) == mp.end())
        {
            mp[b] = set<ll>();
        }
        mp[b].insert(a);
    }
    vector<ll> values(n, LLONG_MAX);
    vector<bool> visited(n, false);
    for(ll i: hset)
    {
        values[i] = 0;
    }

    queue<ll> q;
    for(ll i: hset)
    {
        visited[i] = true;
        q.push(i);
    }
    while(q.size())
    {
        ll current = q.front();
        q.pop();
        for(ll i: mp[current])
        {
            if(!visited[i])
            {
                visited[current] = true;
                values[i] = min(values[i], values[current] + 1);
                q.push(i);
            }
        }
    }
    cout << max_element(values.begin(), values.end()) - values.begin();
    return 0;
}
