#include<bits/stdc++.h>
using namespace std;
#define M 1000000007

long long dp[305][305][305];
long long solve(int i,int w,int h){
    if ((i==h && w==0) || (w<=0 && i!=h)) return 1;
    if (i==h && w!=0) return 0;
    if (dp[i][w][h]!=-1) return dp[i][w][h];

    long long ans=0,ans1=0,ans2=0;
    for (int j=0;j<w;j++){
        ans1=solve(i+1,j,h);
        ans2=solve(i,w-j-1,h);

        ans+=(ans1*ans2)%M;
    }
    return dp[i][w][h]=ans%M;
}

int main()
{
    int h,ww;
    cin>>h>>ww;
    memset(dp,-1,sizeof(dp));
    cout<<(solve(1,ww-1,h)-solve(1,ww-1,h-1)+M)%M<<endl;

    return 0;
}
