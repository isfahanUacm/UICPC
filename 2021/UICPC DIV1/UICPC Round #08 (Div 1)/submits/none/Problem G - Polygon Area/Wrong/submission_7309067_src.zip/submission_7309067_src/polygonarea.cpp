#include <bits/stdc++.h>
using namespace std;

double polygon_Area(double *x, double *y, int n)
{
    double area= 0.0;

    int j= n- 1;
    for (int i=0; i<n; i++)
    {
        area += (x[j]+ x[i])* (y[j]- y[i]);
        j= i;
    }
    return abs(area/ 2.0);
}

int main()
{
    int n;
    while (true)
    {
        cin>> n;
        if (n == 0)
            break;
        else
        {
            double * x= new double [n+ 1];
            double * y= new double [n+ 1];
            for (int i=0; i<n; i++)
                cin>> x[i]>> y[i];
            x[n]= x[0];
            y[n]= y[0];
            if (x[1] > x[0])
                cout<< "CCW"<< " ";
            else
                cout<< "CW"<< " ";
            cout << polygon_Area(x, y, n+ 1)<< endl;
        }
    }
}