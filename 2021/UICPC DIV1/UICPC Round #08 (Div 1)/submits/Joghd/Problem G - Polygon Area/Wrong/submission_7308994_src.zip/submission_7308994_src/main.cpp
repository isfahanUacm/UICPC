#include <iostream>
#include <string>
#include <iomanip>
#include <math.h>
using namespace std;
#define PI 3.14159265
struct answer {
    string a;
    float area;
};
float zav(float x1,float y1,float x2,float y2,float x,float y) {
    float a1, a2;
    if(x1!=x && y1!=y) {
        a1 = atan2((y1-y),(x1-x))*180/PI;
    }
    else if(x1!=x) {
        if(y1>y)
            a1=0;
        else
            a1=180;
    }
    else if(x1>x)
        a1 = 90;
    else
        a1 = -90;


    if(x2!=x && y2!=y) {

        a2 = atan2((y2-y),(x2-x))*180/PI;
    }
    else if(x2!=x) {
        if(y2>y)
            a2=0;
        else
            a2=180;
    }
    else if(x2>x)
        a2 = 90;
    else
        a2 = -90;
   a1 = abs(a1-a2);
   if(a1 > 180)
       a1 = 360 - a1;
   return a1;
}
answer que(int n) {
    answer ans;
    ans.area=0.0;
    float x[n], y[n];
    for(int i=0;i<n;i++)
        cin >> x[i] >> y[i];
    int j = n - 1;
    for (int i = 0; i < n; i++) {
            ans.area += (x[j] + x[i]) * (y[j] - y[i]);
            j = i;
    }
    ans.area /= 2.0;
    if(ans.area < 0)
        ans.area = -ans.area;


    float s = 0.0;
    for(int i=1;i<n-1;i++)
        s+= zav(x[i-1],y[i-1],x[i+1],y[i+1],x[i],y[i]);
    s+= zav(x[n-1],y[n-1],x[1],y[1],x[0],y[0]);
    s+= zav(x[0],y[0],x[n-2],y[n-2],x[n-1],y[n-1]);
    ans.a= "CCW";
    if(abs(s - (180*(n-2)))>0.000001)
        ans.a= "CW";
    return ans;
}

int main() {
    int n;
    cin >> n;
    answer b[100];
    int i=0;
    while (n) {
        b[i]=que(n);
        i++;
        cin >> n;
    }
    for(int j=0;j<i;j++) {
        cout << b[j].a << " " ;
        cout << fixed;
       cout << setprecision(1);

        cout << b[j].area << endl;
    }
    return 0;
}
