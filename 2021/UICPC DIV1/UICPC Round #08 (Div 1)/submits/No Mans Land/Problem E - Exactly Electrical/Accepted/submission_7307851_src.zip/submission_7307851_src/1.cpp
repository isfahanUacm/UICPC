#include <iostream>
using namespace std;
int main()
{
   int a , b , c ,d , m;
   cin >> a >> b >> c >> d >> m;
   if (((abs(a-c)+abs(b-d))<m && ((abs(abs(a-c)+abs(b-d)-m)))%2==0) || (abs(a-c)+abs(b-d)==m)) cout << "Y";
   else cout << "N";
}

