#include <bits/stdc++.h>
using namespace std;

int reduce(string a) {
    if (a.empty())
        return 0;

    int l = 0;
    int r = INT_MAX;

    string rep;
    string rem_f, rem_l;

    for (int i = 0; i < a.length(); ++i) {
        for (int j = 1; j + i <= a.length(); ++j) {
            int ind = 0;
            string ans;
            bool possible = true;
            for (int k = i + j; k < a.length(); ++k) {
                ans += a[k];
                if (possible && a[k] == a[i + ind])
                    ind++;
                else {
                    possible = false;
                }
                if (ind == j) {
                    ind = 0;
                    for (int m = 0; m < j; ++m) {
                        ans.pop_back();
                    }
                }
            }

            if (i + ans.size() + j <= l + r) {
                l = j;
                rep = a.substr(i, j);
                r = ans.size() + i;
                rem_f = a.substr(0, i);
                rem_l = ans;
            }
        }
    }

    unsigned int c = (a.length() - rem_l.length() - rem_f.length()) / rep.length();
    if (c == 1) {
        return a.length();
    }
    else if (c * rep.length() == a.length()) {
        return reduce(rep);
    }
    else {
        return reduce(rem_l) + reduce(rem_f) + reduce(rep);
    }
}

int main() {
    string a;
    cin >> a;
    cout << reduce(a) << endl;
}