#include <bits/stdc++.h>
using namespace std ;

int n , m ;
vector<double> num,dp;
vector<vector<int> > g;
vector<bool> vis ;

double dfs(int i){
    if (vis[i] == true) return dp[i] ;
    vis[i] = true ;

    double ans = num[i] ;
    for (int j=0 ; j<g[i].size() ; j++){
        double tmp = dfs(g[i][j]) ;
        ans = max (ans , max (num[i] + tmp/2 , tmp)) ;
    } 
    
    return dp[i] = ans ;
}

int main(){
    cin >> n >> m;
    
    num.resize(n);
    vis.resize(n,false);
    dp.resize(n) ;
    g.resize(n) ;

    for (int i=0 ; i<n ; i++)
        cin >> num[i] ;

    for (int i=0 ; i<m ; i++){
        int a,b ;
        cin >> a >> b ;
        g[a].push_back(b) ;
    }

    printf("%.6lf\n" , dfs(0)) ; 

    return 0;
}