#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    if(n == 0){
        cout<<0<<' '<<0<<endl;
        return 0;
    }
    if(n == 1){
        cout<<0<<' '<<1<<endl;
        return 0;
    }
    if(n == 3){
        cout<<1<<' '<<2<<endl;
        return 0;
    }
    int dif;
    bool check = false;
    for (int i = 0; i < n; i++)
    {
        if(check) break;
        for(int d = 0; d <= sqrt(n); d++){
            if((d*d)+(2*d*i) == n){
                cout<<i<<' '<<i+d<<endl;
                check = true;
                break;
            }
        }
    }
    if(!check){
        cout<<"impossible\n";
    }
}