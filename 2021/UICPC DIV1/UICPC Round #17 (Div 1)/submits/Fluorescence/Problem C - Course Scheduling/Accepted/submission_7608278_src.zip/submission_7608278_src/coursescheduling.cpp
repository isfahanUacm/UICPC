#include <bits/stdc++.h>
using namespace std;
int n;
map<string, set<string>> cts;
set<string> crs;
int main(){
    cin>>n;
    string a, b, c;
    for (int i = 0; i < n; ++i) {
        cin>>a>>b>>c;
        cts[c].insert(a+b);
        crs.insert(c);
    }

    for(string c: crs){
        cout<<c<<" "<<cts[c].size()<<endl;
    }


}