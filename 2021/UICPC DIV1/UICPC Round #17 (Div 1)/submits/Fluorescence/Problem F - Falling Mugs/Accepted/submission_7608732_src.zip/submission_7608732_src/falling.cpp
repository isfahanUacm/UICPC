#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){

    ll n;
    cin>>n;
    bool found = false;
    ll a, b;

    for (ll y = 0; y <= n; ++y) {
        ll l = 0;
        ll h = y;
        ll x;

        //binary search bezan x = mid

        while(h > l+1){
            //cout<<x<<endl;
            //cout<<h<<" "<<l<<endl;
            x = (h+l)/2;
            if(y*y - x*x < n) h = x-1;
            else if (y*y - x*x >= n) l = x;
            /*else {//y2-x2 == n
                found = true;
                b = y;
                a = x;
                break;
            }*/
        }
        if(y*y - l*l == n){
            found = true;
            b = y;
            //a = x;
            a = l;
            break;
        }
        //if (found) break;
    }

    if(found) cout<<a<<" "<<b;
    else cout<<"impossible";

}