	#include <bits/stdc++.h>
	using namespace std;
	typedef long long int lli;
	// std::cout << std::setprecision(3) << std::fixed << doubllle;
	typedef unsigned long long int ulli;
	// sort(arr, arr + n, greater<int>());
	//c = ::tolower(c);
	//for (int i = 0; i < s.size(); i++) {
	//s[i] = tolower(s[i]);
	//multiset<lli, greater<lli>> mset;


	//there is at most one road between
	//any two locations, and no road starts and ends at the same location.
	int n, m;
	lli item[100 + 5];
	lli allitem[100 + 5];
	vector<vector<pair<lli, lli>>>adj(100 + 5);
	lli dis[100 + 5];

	void dijk() {
		fill_n(dis, 100 + 5, LONG_MAX);
		fill_n(allitem, 100 + 5, 0);
		dis[1] = 0;
		set<pair<lli, pair<lli , lli>>> pq;
		allitem[1] = item[1];
		pq.insert({ 0, {1, item[1]} });

		while (!pq.empty()) {
			lli dist = pq.begin()->first;
			lli cur = pq.begin()->second.first;
			lli ite = pq.begin()->second.second;
			pq.erase(pq.begin());
			for (auto it : adj[cur]) {
				lli child = it.first;
				lli w = it.second;
				if (dist + w < dis[child]) {
					pq.erase({ dis[child], {child, allitem[child]} });
					dis[child] = dist + w;
					allitem[child] = item[child] + ite;
					pq.insert({ dis[child], {child, allitem[child]} });
				}
				else if (dist + w == dis[child]) {
					pq.erase({ dis[child], {child, allitem[child]} });
					allitem[child] = max(allitem[child], item[child] + ite);
					pq.insert({ dis[child], {child, allitem[child]} });
				}
			}
		}
	}

	int main() {
		cin >> n;
		for (int i = 1; i <= n; i++) {
			cin >> item[i];
		}
		cin >> m;
		for (int i = 0; i < m; i++) {
			lli a, b, d;
			cin >> a >> b >> d;
			adj[a].push_back({b, d});
			adj[b].push_back({ a,d });
		}
		dijk();
		if (dis[n] == LONG_MAX) cout << "impossible";
		else {
			cout << dis[n] << " " << allitem[n];
		}
	}