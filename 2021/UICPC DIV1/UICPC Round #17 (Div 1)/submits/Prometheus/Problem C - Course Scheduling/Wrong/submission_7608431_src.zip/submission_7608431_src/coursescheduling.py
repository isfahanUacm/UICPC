n = int(input())
course = {}



for i in range(n):
    all = list(input().split(" "))

    if all[2] not in course:
        course[all[2]]=[]

    word = all[0] + all[1]
    # print(word)
    course[all[2]].append(word)

for k,v in course.items():
    course[k] = list(dict.fromkeys(v))

for k, v in course.items():
    print(k, len(v))


# print(course)
