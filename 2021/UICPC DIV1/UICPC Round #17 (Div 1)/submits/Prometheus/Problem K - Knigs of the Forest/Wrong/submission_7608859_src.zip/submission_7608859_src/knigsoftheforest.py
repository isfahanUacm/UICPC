def main():
    k, n = [int(x) for x in input().split(" ")]
    karl_year, karl_strength = [int(x) for x in input().split(" ")]
    years = {karl_year: []}
    years[karl_year].append(karl_strength)

    for _ in range(n + k - 2):
        year, strength = [int(x) for x in input().split(" ")]

        if year not in years:
            years[year] = []

        years[year].append(strength)

    flag = False

    survive_list = []
    for k in sorted(years.keys()):
        years[k] += survive_list
        if karl_year == k:
            if karl_strength>=max(years[k]):
                print(k)
                flag = True
                break
            else:
                if karl_year == max(years):
                    break
            list_year = list(years)
            karl_year = list_year[list_year.index(k+1)]
    else:
        years[k].remove(max(years[k]))
        print(years[k])
        survive_list = years[k]


    # print(years)
    if not flag:
        print('unknown')


if __name__ == '__main__':
    main()

