#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

struct Cmp
{
    bool operator()(pll a, pll b) const
    {
        return a.second < b.second;
    }
};

struct CmpMultiset
{
    bool operator()(pair<pll, ll> a, pair<pll, ll> b) const
    {
        if(a.first.first == b.first.first)
        {
            return a.first.second > b.first.second;
        }
        return a.first < b.first;
    }
};


ll n;

vector<ll> t;
vector<set<pair<ll, ll>>> graph;


pll dijkstra(ll src)
{
    vector<pll> dist(n, {LLONG_MAX, LLONG_MAX});
    vector<bool> visited(n, false);

    dist[src] = {0, t[0]};

    multiset<pair<pll, ll>, CmpMultiset> pq;

    pq.insert({{0, t[0]}, src});

    while(!pq.empty())
    {
        ll current = pq.begin()->second;
        pq.erase(pq.begin());
        if(visited[current])
        {
            continue;
        }
        visited[current] = true;

        for (pll i: graph[current])
        {
            ll currentDist = dist[current].first;
            ll currentItems = dist[current].second;

            ll nextIndex = i.first;

            if (currentDist + i.second < dist[nextIndex].first ||
                ((currentDist + i.second == dist[nextIndex].first) &&
                (currentItems + t[i.first] >= dist[nextIndex].second))
               )
            {
                dist[nextIndex].first  = dist[current].first + i.second;
                dist[nextIndex].second = dist[current].second + t[nextIndex];

                pq.insert({dist[nextIndex], nextIndex});
            }
        }
    }
    return dist[n - 1];
}

int main()
{
    cin >> n;
    t = vector<ll>(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> t[i];
    }
    ll m;
    cin >> m;
    set<pll> sample;
    graph = vector<set<pll>>(n, sample);
    for(ll i = 0; i < m; i++)
    {
        ll a, b, d;
        cin >> a >> b >> d;
        a--;
        b--;
        graph[a].insert({b, d});
        graph[b].insert({a, d});
    }
    pll ans = dijkstra(0);
    if(ans.first == LLONG_MAX)
    {
        cout << "impossible";
    }
    else
    {
        cout << ans.first << " " << ans.second;
    }
    return 0;
}