#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

int main()
{
    ll d;
    cin >> d;
    bool hasAns = false;
    for(ll i = 0; i <= d; i++)
    {
        ll n1 = i;
        ll n2 = sqrt(n1 * n1 + d);
        if(n2 * n2 - n1 * n1 == d)
        {
            cout << n1 << " " << n2 << endl;
            hasAns = true;
            break;
        }
    }
    if(!hasAns)
    {
        cout << "impossible";
    }
    return 0;
}