#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main ()
{
    ll D, M;
    cin >> D >> M;
    vector<vector<string>> v = {
        {"Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"},
        {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"},
        {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"},
        {"Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday"},
        {"Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"},
        {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"},
        {"Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday"},
        {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"},
        {"Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday"},
        {"Thursday", "Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"},
        {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"},
        {"Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "Monday"}
    };
    cout << v[M - 1][D % 7 - 1];
    return 0;
}
