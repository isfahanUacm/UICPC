

#include <iostream>
#include <string>
using namespace std;


 void c2048(int* row, bool jahat)
{
	 for (int i = 1; i < 4; i++)
	 {
		 if (0 == row[i - 1])
		 {
			 row[i - 1] = row[i];
			 row[i] = 0;
		 }
	 }
	 for (int i = 1; i < 4; i++)
	 {
		 if (0 == row[i - 1])
		 {
			 row[i - 1] = row[i];
			 row[i] = 0;
		 }
	 }
	if (jahat)
	{
		for (int i = 1; i < 4; i++)
		{
			if (row[i] == row[i - 1])
			{
				row[i - 1] = row[i - 1] + row[i];
				row[i] = 0;
		    }
		}
		for (int i = 1; i < 4; i++)
		{
			if (0 == row[i - 1])
			{
				row[i - 1] = row[i];
				row[i] = 0;
			}
		}
		for (int i = 1; i < 4; i++)
		{
			if (0 == row[i - 1])
			{
				row[i - 1] = row[i];
				row[i] = 0;
			}
		}
	}
	else
	{
		for (int i = 2; i >=0; i--)
		{
			if (row[i] == row[i + 1])
			{
				row[i + 1] = row[i + 1] + row[i];
				row[i] = 0;
			}
		}
		for (int i = 2; i >= 0; i--)
		{
			if (0 == row[i + 1])
			{
				row[i + 1] = row[i];
				row[i] = 0;
			}
		}
		for (int i = 2; i >= 0; i--)
		{
			if (0 == row[i + 1])
			{
				row[i + 1] = row[i];
				row[i] = 0;
			}
		}
	}
}
 void print(int jad[4][4])
 {
	 for (int i = 0; i < 4; i++)
	 {
		 for (int j = 0; j < 4; j++)
		 {
			 cout << jad[i][j];
			 if (j != 3)
				 cout << " ";
		 }
		 cout << endl;
	 }
 }
 int main()
 {
	 int jad[4][4];
	 for (int i = 0; i < 4; i++)
	 {
		 for (int j = 0; j < 4; j++)
		 {
			 cin >> jad[i][j];
		 }
	 }
	 int m; cin >> m;
	 if (m == 0)
	 {
		 for (int i = 0; i < 4; i++)
			 c2048(jad[i], true);
	 }
	 else if (m == 2)
	 {
		 for (int i = 0; i < 4; i++)
			 c2048(jad[i], false);
	 }
	 else if (m == 1)
	 {
		 for (int i = 0; i < 4; i++)
		 {
			 int row[4] = { jad[0][i], jad[1][i], jad[2][i] ,jad[3][i] };
			 c2048(row, true);
			 jad[0][i] = row[0];
			 jad[1][i] = row[1];
			 jad[2][i] = row[2];
			 jad[3][i] = row[3];
		 }
	 }
	 else if (m == 3)
	 {
		 for (int i = 0; i < 4; i++)
		 {
			 int row[4] = { jad[0][i], jad[1][i], jad[2][i] ,jad[3][i] };
			 c2048(row, false);
			 jad[0][i] = row[0];
			 jad[1][i] = row[1];
			 jad[2][i] = row[2];
			 jad[3][i] = row[3];
		 }
	 }
	 print(jad);
 }
