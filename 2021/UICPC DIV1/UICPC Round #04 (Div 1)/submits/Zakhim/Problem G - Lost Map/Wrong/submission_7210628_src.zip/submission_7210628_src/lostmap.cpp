#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    int x=0,y=0;
    cin>>n;
    int a[n][n];
    bool visited[n];
    bool alo=true;
    for (int i = 0; i <n-1 ; ++i) {
        int mini=INT_MAX;
        for (int k = 0; k <n ; ++k) {
            if (visited[k] || alo) {
                alo= false;
                for (int j = 0; j < n; ++j) {
                    if (k == j)
                        continue;
                    if (!visited[k] || !visited[j]) {
                        if (mini > a[k][j]) {
                            mini = a[k][j];
                            x = k;
                            y = j;
                        }
                    }
                }
            }
        }
        cout<<x+1<<" "<<y+1<<endl;
        visited[x]= true;
        visited[y]= true;
    }
}