#include <iostream>
#include <math.h>
using namespace std;

int main() {
    int n,c;
    cin >> n >> c;
    c= pow(10,c);
    int f = n%c;
    int a = n-f;
    int b = a+c;
    if(a==n)
        cout << n;
    else if((n-a)<(b-n))
        cout << a;
    else
        cout << b;
}