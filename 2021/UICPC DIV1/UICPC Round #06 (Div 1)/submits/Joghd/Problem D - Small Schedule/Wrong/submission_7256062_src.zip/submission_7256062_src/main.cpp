#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main() {
    int q, n ,n1,nq;
    cin >> q >> n >>n1 >> nq;
    int a2 = nq%n;
    int a3 = n-a2;
    int a4 = a3*q;
    int a5 = n1-a4;
    int max = (nq-a2)/n;
    max++;
    max*=q;
    if(a5<=0) {
        cout << max;
    }
    else {
        int a6=a5%n;
        cout << 1+max+(a5-a6)/n;
    }


}
