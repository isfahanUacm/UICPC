#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
int main()
{
	lli q, m, s, l, time = 0;
	cin >> q >> m >> s >> l;
	bool flag = 0;
	
	while (l >= m)
	{
		time += q;
		l -= m;
	}

	if (l) {
		time += q;
		for (auto j = 0; j < q; j++) {
			for (auto i = l + 1; i <= m; i++)
			{
				if (s) {
					s--;
				}
				else
					break;
			}
		}
	}

	if (s == 0)
		cout << time;
	else {
		while (s > 0)
		{
			for (auto i = 0; i < m; i++)
			{
				if (s) {
					s--;
				}
				else
					flag = true;
			}
			time++;
			if (flag)
				break;
		}
		cout << time;
	}
}