#include <bits/stdc++.h>
using namespace std;

int main()
{
	long long int c, k, b = 1;
	cin >> c >> k;
	for (auto i = 0; i < k; i++)
		b = b * 10;
	//cout << b <<endl;
	if (c < b)
		cout << b;
	else if (b == 1)
		cout << c;
	else {
		long long int rem = c % b;
		if (rem < b / 2)
		{
			long long int x = c - rem;
			cout << x;

		}
		else if (rem >= b / 2) {
			long long int x = c + (b-rem);
			cout << x;
		}
	}
}