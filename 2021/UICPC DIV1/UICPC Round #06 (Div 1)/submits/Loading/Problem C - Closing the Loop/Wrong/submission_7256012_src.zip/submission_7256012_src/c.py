for i in range(int(input())):
    n = int(input())
    li = list(map(str, input().split()))
    #print(li)
    liR = []
    cR = 0
    sR=0
    liB = []
    cB= 0
    sB=0
    for j in range(n):
        temp = list(li[j])
        ln = len(temp)
        theStrNum = ''
        for m in range(ln-1):
            theStrNum += temp[m]
        if temp[-1] == 'R':
            liR.append(int(theStrNum))
            cR+=1
            sR+=int(theStrNum)
        else:
            liB.append(int(theStrNum))
            cB+=1
            sB+=int(theStrNum)
    #print(liR)
    #print(liB)
    theS = 0
    theC = 0
    if cR == 0:
        #print(f"Case #{i+1}: {0}")
        continue
    if cB == 0:
        #print(f"Case #{i+1}: {0}")
        continue

    if cR < cB:
        theS+=sR
        #print(theS)
        liB.sort(reverse = True)
        #print(liB)
        tempS=0
        for z in range(cR):
            tempS+=liB[z]
        #print(tempS)
        theS+=tempS
        theC = 2 * cR
        theS -= theC

    elif cB < cR:
        theS+=sB
        #print(theS)
        liR.sort(reverse = True)
        #print(liR)
        tempS=0
        for z in range(cB):
            tempS+=liR[z]
        #print(tempS)
        theS+=tempS
        theC = 2 * cB
        theS -= theC

    else:
        theS = sB + sR - (cR + cB)
    
    print(f"Case #{i+1}: {theS}")

            

