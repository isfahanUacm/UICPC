k, m, n = map(int, input().split())
step = m + n
r = k%step
#p = k//n
if r < m:
    print("Barb")
else:
    print("Alex")
'''else:
    if r < m:
        print("Alex")
    else:
        print("Barb")'''