#include <bits/stdc++.h>
using namespace std;
typedef long long ll;



int main(){
	ll k,n,m;
	cin >> k >> n >> m;
	cout<<(k%(n+m) < n  ? "Barb":"Alex" )<<endl;
	return 0;
}