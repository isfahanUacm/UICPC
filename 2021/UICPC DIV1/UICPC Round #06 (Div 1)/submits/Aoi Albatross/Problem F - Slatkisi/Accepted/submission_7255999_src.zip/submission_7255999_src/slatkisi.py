c,k = map(int,input().split())
print(round(c/(10**k))*(10**k))