#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
	ll q,m,s,l;
	cin >> q >> m >> s >> l;
	ll ans=0;
	ans = l/m*q;
	l%=m;
	if(l>0){
		ans+=q;
		s-=((m-l)*q);
	}
	if(s>0){
		ans+=(s/m+(s%m ? 1:0));
	}
	cout<<ans<<endl;
	return 0;
}