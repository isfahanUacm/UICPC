k, m, n = map(int, input().split(" "))

if m > k:
    print("Barb")
elif n >= k:
    print("Alex")
else:
    remainder = k % n
    divider = k // n
    if divider % 2 == 0:
        if m <= remainder <= n:
            print("Alex")
        else:
            print("Barb")
    else:
        if m <= remainder <= n:
            print("Barb")
        else:
            print("Alex")
