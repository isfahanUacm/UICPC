#include <bits/stdc++.h>
using namespace std;

int main()
{
    long long int q, m, s, l, cnt = 0, rest;
    cin >> q >> m >> s >> l;
    long long int remain =0;
    if((l%m) != 0)
        remain = 1;
    cnt += ((l/m + remain)*q);
    rest = m - (l%m);
    while(rest > 0 && rest < m && s > 0)
    {
        s -= q;
        rest--;
    }
    if(s > 0)
    {
        cnt += s/m;
        if((s % m) != 0)
            cnt++;
    }
    cout << cnt << endl;
}
