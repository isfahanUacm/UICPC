#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t , n;
    string s,s1;
    cin >> t;
    for (int i = 1 ; i <= t ;i++){
        cin >> n;
        int r=0,b=0,c=0;
        int ar[n] , ab[n];
        for (int j = 0 ; j < n ; ++j){
            cin >> s;
            s1.clear();
            for (int j = 0 ; j < s.length()-1 ; j++)
                s1+=s[j];
            if (s[s.length()-1]=='R'){
                ar[r] = stoi(s1);
                r++;
            }else{
                ab[b] = stoi(s1);
                b++;
            }
        }
        if (r==0 || b==0){
            cout << "Case #"<<i<<": " << 0<<endl;
            continue;
        }else{
            sort(ab,ab+b);
            sort(ar,ar+r);
            reverse(ab,ab+b);
            reverse(ar,ar+r);
            if (r<=b){
                for (int j = 0 ; j < r ; ++j){
                    c+=ar[j];
                    c+=ab[j];
                }
                c-=(r*2);
            }else{
                for (int j = 0 ; j < b ; ++j){
                    c+=ar[j];
                    c+=ab[j];
                }
                c-=(b*2);
            }
        }
        cout << "Case #"<<i<<": " << c <<endl;
    }
    return 0;
}
