n,m = map(int, input().split())

can = [0]*n
col = [0]*m
for i in range(n):
    can[i] = int(input())
for i in range(m):
    col[i] = int(input())

waste = 0
for j in col:
    temp = min([ z for z in can if z >= j], key=lambda x:abs(x-j))
    waste += temp - j

print(waste)

