n, m = map(int, input().split())

cans = []
colors = []

for i in range(n):
    cans.append(int(input()))

for i in range(m):
    colors.append(int(input()))

cans.sort()

s = 0
for i in colors:
    for j in cans:
        if j > i:
            s += j
            break

print(s - sum(colors))
