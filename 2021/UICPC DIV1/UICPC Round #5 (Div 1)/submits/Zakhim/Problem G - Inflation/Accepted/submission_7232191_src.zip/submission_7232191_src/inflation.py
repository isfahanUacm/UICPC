n = (int(input()))
main = list(map(int, input().split()))

main.sort()
iss = True
minn = 1
for i in range(len(main)):
    if main[i] > i + 1:
        iss = False
        break
    if main[i] / (i + 1) < minn:
        minn = main[i] / (i + 1)

if iss:
    if minn != 0:
        print(minn)
    else:
        print(0)
else:
    print("impossible")
