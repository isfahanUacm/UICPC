from itertools import combinations


def check(l, r):
    return list(combinations(l, r))


n = int(input())
l = list(map(int, input().split()))

s = 0
for i in range(1, 4):
    ll = check(l, i)
    for j in ll:
        x = 0
        for k in j:
            x += k
        if x < 200:
            s -= x

s += sum(l) * (2 ** (n - 1))

print(int(s))
