import math
from itertools import combinations


def check(l, r):
    return list(combinations(l, r))


def check2(n, m):
    return math.factorial(n) / (math.factorial(m) * math.factorial(n - m))


n = int(input())
l = list(map(int, input().split()))

s = 0
for i in range(1, 4):
    ll = check(l, i)
    for j in ll:
        x = 0
        for k in j:
            x += k
        if x >= 200:
            s += x

ss = sum(l)

for i in range(4, len(l) + 1):
    x = check2(len(l), i)
    x *= i
    x /= len(l)
    s += x * ss

print(int(s))
