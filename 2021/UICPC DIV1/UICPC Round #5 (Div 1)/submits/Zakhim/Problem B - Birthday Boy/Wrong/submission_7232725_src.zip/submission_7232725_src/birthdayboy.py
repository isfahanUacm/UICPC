n = int(input())


def chech(mm):
    s = 0
    if mm > 11:
        s += 30
    if mm > 10:
        s += 31
    if mm > 9:
        s += 30
    if mm > 8:
        s += 31
    if mm > 7:
        s += 31
    if mm > 6:
        s += 30
    if mm > 5:
        s += 31
    if mm > 4:
        s += 30
    if mm > 3:
        s += 31
    if mm > 2:
        s += 28
    if mm > 1:
        s += 31

    return s


def chech2(n):
    c = 1
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 28:
        n -= 28
        c += 1
    else:
        return c, n
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 30:
        n -= 30
        c += 1
    else:
        return c, n
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 30:
        n -= 30
        c += 1
    else:
        return c, n
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 30:
        n -= 30
        c += 1
    else:
        return c, n
    if n > 31:
        n -= 31
        c += 1
    else:
        return c, n
    if n > 30:
        n -= 30
        c += 1
    else:
        return c, n
    return c, n


births = []
birthsdiff = []
if n == 1:
    a, b = map(str, input().split())
    mm = int(b[0:2])
    dd = int(b[3:])
    a = mm
    b = dd - 1

else:

    for i in range(n):
        a, b = map(str, input().split())
        mm = int(b[0:2])
        dd = int(b[3:])
        births.append(chech(mm) + dd)

    births.sort()

    for i in range(1, len(births)):
        birthsdiff.append([births[i], births[i] - births[i - 1]])

    birthsdiff.append([births[0], births[0] + (365 - births[-1])])

    for i in range(len(birthsdiff) - 1):
        for j in range(0, len(birthsdiff) - i - 1):
            if birthsdiff[j][1] < birthsdiff[j + 1][1]:
                birthsdiff[j][1], birthsdiff[j + 1][1] = birthsdiff[j + 1][1], birthsdiff[j][1]
                birthsdiff[j][0], birthsdiff[j + 1][0] = birthsdiff[j + 1][0], birthsdiff[j][0]

    if birthsdiff[0][1] == birthsdiff[1][1]:
        x = birthsdiff[1][1]
        i = 0
        m = 1000
        ii = 0
        while birthsdiff[i][1] == x:
            if birthsdiff[i][0] == 301:
                i += 1
            else:
                if birthsdiff[i][0] < 300:
                    birthsdiff[i][0] += 365
                if birthsdiff[i][0] - 300 < m:
                    m = birthsdiff[i][0] - 300
                    ii = i
                i += 1
        if birthsdiff[ii][0] > 365:
            birthsdiff[ii][0] -= 365
        ll = birthsdiff[ii][0] - 1
    else:
        ll = birthsdiff[0][0] - 1

    a, b = chech2(ll)

if b == 0:
    if a == 1:
        a = 12
        b = 31
    elif a == 2:
        a -= 1
        b = 31
    elif a == 3:
        a -= 1
        b = 28
    elif a == 4:
        a -= 1
        b = 31
    elif a == 5:
        a -= 1
        b = 30
    elif a == 6:
        a -= 1
        b = 31
    elif a == 7:
        a -= 1
        b = 30
    elif a == 8:
        a -= 1
        b = 31
    elif a == 9:
        a -= 1
        b = 31
    elif a == 10:
        a -= 1
        b = 30
    elif a == 11:
        a -= 1
        b = 31
    elif a == 12:
        a -= 1
        b = 30


m = ''
d = ''
if a < 10:
    m += '0'
    m += str(a)
else:
    m = str(a)
if b < 10:
    d += '0'
    d += str(b)
else:
    d = str(b)

print(f"{m}-{d}")
