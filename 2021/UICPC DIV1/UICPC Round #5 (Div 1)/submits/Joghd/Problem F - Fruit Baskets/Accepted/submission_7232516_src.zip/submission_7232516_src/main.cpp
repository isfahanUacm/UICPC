
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int main ( void )
{
    int n;
    cin >> n;
    int x[n];
    for(int i=0;i<n;i++)
        cin >>x[i];
    long long final=0;
    for(int i=0;i<n;i++)
        final+=x[i];
    final*=pow(2,n-1);
    sort(x,x+n);
    for(int i=0;x[i]<200 && i< n;i++)
        final-=x[i];
    for(int i=0;x[i]<150 && i< n;i++) {
        for(int j=0;j<i;j++) {
            int t=x[i]+x[j];
            if(t<200)
                final-=t;
        }
    }
    for(int i=0;x[i]<100 && i< n;i++) {
        for(int j=0;j<i;j++) {
            for(int k=0;k<j;k++) {
                int t = x[i]+x[j]+x[k];
                if(t<200)
                    final-=t;
            }
        }
    }
    cout << final;
}

