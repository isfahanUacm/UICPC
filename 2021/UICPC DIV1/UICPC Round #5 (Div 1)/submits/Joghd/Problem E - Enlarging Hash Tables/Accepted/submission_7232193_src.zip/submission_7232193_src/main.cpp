#include <iostream>
#include <math.h>
#include <queue>
using namespace std;
bool isprime(int n) {
    int t = sqrt(n);
    if(n!=2 && n%2==0)
        return 0;
    for(int i=3;i<=t;i+=2) {
        if(n%i==0)
            return 0;
    }
    return 1;

}
int fine(int n) {
    n = 2*n+1;
    while(isprime(n)==0)
        n++;
    return n;
}
struct ans {
    int nu;
    int nn;
};

int main() {
    queue<ans> x;
    int n;
    cin >> n;
    while(n) {
        ans a;
        a.nn=n;
        a.nu=fine(n);
        x.push(a);
        cin >> n;
    }
    while (x.size()) {
        cout << x.front().nu << " ";
        if(isprime(x.front().nn)==0)
            cout << "("<< x.front().nn <<" is not prime)";
        cout << endl;
        x.pop();
    }

}
