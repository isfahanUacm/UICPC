#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;

int main() {
    int n,m;
    cin >> n >> m;
    double st[n];
    double jo[m];
    int za[n];
    for(int i=0;i<n;i++)
        za[i]=0;
    for(int i=0;i<n;i++)
        cin >> st[i];
    for(int i=0;i<m;i++)
        cin >> jo[i];
    sort(st,st+n);
    sort(jo,jo+m);
    double ans = 0;
    int j=0;
    for(int i=0;i<m;i++) {
l:       if(st[j]<jo[i]) {
            j++;
            goto l;
        }
        ans+= st[j]-jo[i];

    }
    cout << ans;




}
