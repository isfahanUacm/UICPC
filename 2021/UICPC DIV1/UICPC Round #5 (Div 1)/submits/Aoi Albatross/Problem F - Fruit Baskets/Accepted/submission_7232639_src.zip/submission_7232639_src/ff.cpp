#include <bits/stdc++.h>
using namespace std;
#define ll long long

ll n,num[50];
pair<ll,ll> dp[50][300];

pair<ll,ll> solve(ll i,ll val){
    if (i>=n) return pair<ll,ll>(1,0);
    if (dp[i][val].first!=-1) return dp[i][val];

    ll tmp=val-num[i];
    if (tmp<0) tmp=0;

    ll ans=0,counter=0;
    for (ll j=i+1;j<=n;j++){
        if (solve(j,tmp).second>=tmp){
            counter+=solve(j,tmp).first;
            ans+=solve(j,tmp).second+solve(j,tmp).first*num[i];
        }
    }
   // cout<<i<<" "<<val<<" "<<counter<<" "<<ans<<endl;
    return dp[i][val]=pair<ll,ll>(counter,ans);
}

int main()
{
    cin>>n;
    for (ll i=0;i<n;i++)
        cin>>num[i];
    sort(num,num+n,greater<>());
    memset(dp,-1,sizeof(dp));
    ll ans=0;
    for (ll i=0;i<n;i++)
        ans+=solve(i,200).second;
    cout<<ans<<endl;
    return 0;
}
