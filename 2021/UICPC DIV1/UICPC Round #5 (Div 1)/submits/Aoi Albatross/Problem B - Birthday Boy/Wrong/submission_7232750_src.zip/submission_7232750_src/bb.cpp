#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
using namespace std;
int date[]={31,28,31,30,31,30,31,31,30,31,30,31};
vector<pair<int,int> > p,d;
int index(pair<int,int> tmp){
    for (int i=0;i<366;i++)
        if (tmp==p[i]) return i;
}
int main()
{
    for (int i=0;i<12;i++){
        for (int j=0;j<date[i];j++){
            pair<int,int> tmp;
            tmp.first=i+1;
            tmp.second=j+1;
            p.push_back(tmp);
        }
    }

    int n;
    string s;
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>s;
        pair<int,int> tmp;
        cin>>tmp.first;
        cin.ignore();
        cin>>tmp.second;
        d.push_back(tmp);
    }
    int m=0;
    pair<int,int> ans;
    sort(d.begin(),d.end());
    for (int i=0;i<d.size()-1;i++){
        if (m<index(d[i+1])-index(d[i])){
            m=index(d[i+1])-index(d[i]);
            ans=d[i+1];
        }
    }
    if (m<(365-index(d[d.size()-1])+index(d[0]))){
        m=(365-index(d[d.size()-1])+index(d[0]));
        ans=d[0];
    }
    if (ans.second==1){
        ans.first--;
        if (ans.first==0) ans.first=12;
        ans.second=date[ans.first-1];
    }
    if (ans.first<10) cout<<0;
    cout<<ans.first<<"-";
    if (ans.second<10) cout<<0;
    cout<<ans.second-1<<endl;
    return 0;
}
