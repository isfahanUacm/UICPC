#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n;
	cin >> n;
	std::vector<ll> gas(n);
	for(ll i=0;i<n;i++)cin >> gas[i];
	sort(gas.begin(),gas.end());
	ll j=1;
	double jm=1.0;
	for(ll i=0;i<n;i++){
		if(gas[i]>j){
			cout<<"impossible"<<endl;
			return 0;
		}
		if(jm>=gas[i]/double(j)){
			
			jm=gas[i]/double(j);
		}
		j++;
	}
	printf("%0.6f\n",jm);
	return 0;
}