l = []
for i in range(4):
    ll = list(map(int, input().split()))
    l.append(ll)

x = int(input())
if x == 0:
    for i in range(4):
        if l[i][0] == l[i][1]:
            l[i][0] *= 2
            l[i][1] = 0
            if l[i][2] == l[i][3]:
                l[i][2] *= 2
                l[i][3] = 0
        elif l[i][0] == l[i][2] and l[i][1] == 0:
            l[i][0] *= 2
            l[i][2] = 0
        elif l[i][0] == l[i][3] and l[i][1] == 0 and l[i][2] == 0:
            l[i][0] *= 2
            l[i][3] = 0
        elif l[i][1] == l[i][2]:
            l[i][1] *= 2
            l[i][2] = 0
        elif l[i][1] == l[i][3] and l[i][2] == 0:
            l[i][1] *= 2
            l[i][3] = 0
        elif l[i][2] == l[i][3]:
            l[i][2] *= 2
            l[i][3] = 0
        for j in range(1, 4):
            m = j
            while l[i][m - 1] == 0:
                m -= 1
                if m == 0:
                    break
            if m != j:
                l[i][m] = l[i][j]
                l[i][j] = 0

if x == 2:
    for i in range(4):
        if l[i][3] == l[i][2]:
            l[i][3] *= 2
            l[i][2] = 0
            if l[i][1] == l[i][0]:
                l[i][1] *= 2
                l[i][0] = 0
        elif l[i][3] == l[i][1] and l[i][2] == 0:
            l[i][3] *= 2
            l[i][1] = 0
        elif l[i][3] == l[i][0] and l[i][1] == 0 and l[i][2] == 0:
            l[i][3] *= 2
            l[i][0] = 0
        elif l[i][2] == l[i][1]:
            l[i][2] *= 2
            l[i][1] = 0
        elif l[i][2] == l[i][0] and l[i][1] == 0:
            l[i][2] *= 2
            l[i][0] = 0
        elif l[i][0] == l[i][1]:
            l[i][1] *= 2
            l[i][0] = 0
        for j in range(2, -1, -1):
            m = j
            while l[i][m + 1] == 0:
                m += 1
                if m > 2:
                    break
            if m != j:
                l[i][m] = l[i][j]
                l[i][j] = 0

if x == 1:
    for i in range(4):
        if l[0][i] == l[1][i]:
            l[0][i] *= 2
            l[1][i] = 0
            if l[2][i] == l[3][i]:
                l[2][i] *= 2
                l[3][i] = 0
        elif l[0][i] == l[2][i] and l[1][i] == 0:
            l[0][i] *= 2
            l[2][i] = 0
        elif l[0][i] == l[3][i] and l[1][i] == 0 and l[2][i] == 0:
            l[0][i] *= 2
            l[3][i] = 0
        elif l[1][i] == l[2][i]:
            l[1][i] *= 2
            l[2][i] = 0
        elif l[1][i] == l[3][i] and l[2][i] == 0:
            l[1][i] *= 2
            l[3][i] = 0
        elif l[2][i] == l[3][i]:
            l[2][i] *= 2
            l[3][i] = 0
        for j in range(1, 4):
            m = j
            while l[m - 1][i] == 0:
                m -= 1
                if m == 0:
                    break
            if m != j:
                l[m][i] = l[j][i]
                l[j][i] = 0

if x == 3:
    for i in range(4):
        if l[3][i] == l[2][i]:
            l[3][i] *= 2
            l[2][i] = 0
            if l[1][i] == l[0][i]:
                l[1][i] *= 2
                l[0][i] = 0
        elif l[3][i] == l[1][i] and l[2][i] == 0:
            l[3][i] *= 2
            l[1][i] = 0
        elif l[3][i] == l[0][i] and l[1][i] == 0 and l[2][i] == 0:
            l[3][i] *= 2
            l[0][i] = 0
        elif l[2][i] == l[1][i]:
            l[2][i] *= 2
            l[1][i] = 0
        elif l[2][i] == l[0][i] and l[1][i] == 0:
            l[2][i] *= 2
            l[0][i] = 0
        elif l[0][i] == l[1][i]:
            l[1][i] *= 2
            l[0][i] = 0
        for j in range(2, -1, -1):
            m = j
            while l[m + 1][i] == 0:
                m += 1
                if m > 2:
                    break
            if m != j:
                l[m][i] = l[j][i]
                l[j][i] = 0

for i in range(4):
    for j in range(4):
        print(l[i][j], end=' ')
    print()
