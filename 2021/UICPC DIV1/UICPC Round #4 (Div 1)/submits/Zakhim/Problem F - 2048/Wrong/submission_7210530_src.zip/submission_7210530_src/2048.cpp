#include <bits/stdc++.h>
#define ull unsigned long long
int arr[4][4];
using namespace std;
int main(){
    for (int i = 0; i < 4; i++)  for (int j = 0; j < 4; j++) cin>>arr[i][j];
    int mode;cin>>mode;
    if(mode == 0){
        for (int i = 0; i < 4; i++) {
            int pos = -1, cnt = 0;
            for (int j = 0; j < 4; j++) {
                if (arr[i][j] == 0) {
                    cnt++;
                    if (cnt == 1) pos = j;
                }
                else if (arr[i][j] != 0 && pos != -1) {
                    arr[i][pos] = arr[i][j];
                    arr[i][j] = 0;
                    pos = j;
                    cnt = 0;
                }
                for (int j = 0; j < 3; j++) {
                if (arr[i][j] != 0 && arr[i][j] == arr[i][j + 1]) {
                    // arr[i][j] *= 2;
                    arr[i][j] = arr[i][j] * 2;
                    for (int k = j + 1; k < 3; k++) {
                        arr[i][k] = arr[i][k + 1];
                        }
                    arr[i][3] = 0;
                    }
                }
            }
        }
    }
    else if(mode==1){
        for (int j = 0; j < 4; j++) {
		int pos = -1, cnt = 0;
		for (int i = 0; i < 4; i++) {
			if (arr[i][j] == 0) {
				cnt++;
				if (cnt == 1) pos = i;
			}
			else if (arr[i][j] != 0 && pos != -1) {
				arr[pos][j] = arr[i][j];
				arr[i][j] = 0;
				pos = i;
				cnt = 0;
			}
		}
		for (int i = 0; i < 3; i++) {
			if (arr[i][j] != 0 && arr[i][j] == arr[i + 1][j]) {
				arr[i][j] *= 2;
				for (int k = i + 1; k < 3; k++) {
					arr[k][j] = arr[k + 1][j];
				    }
				arr[3][j] = 0;
			    }
		    }

   	    }
    }
    else if(mode == 2){
        for (int i = 0; i < 4; i++) {
		int pos = -1, cnt = 0;
		for (int j = 3; j > -1; j--) {
			if (arr[i][j] == 0) {
				cnt++;
				if (cnt == 1) pos = j;
			}
			else if (arr[i][j] != 0 && pos != -1) {
				arr[i][pos] = arr[i][j];
				arr[i][j] = 0;
				pos = j;
				cnt = 0;
			}
		}
		for (int j = 3; j > 0; j--) {
			if (arr[i][j] != 0 && arr[i][j] == arr[i][j - 1]) {
				arr[i][j] = arr[i][j] * 2;
				for (int k = j - 1; k > 0; k--) {
					arr[i][k] = arr[i][k - 1];
				    }
				arr[i][0] = 0;
			    }
		    }

   	    }
    }
    else{
        for (int j = 0; j < 4; j++) {
        int pos = -1, cnt = 0;
        for (int i = 3; i > -1; i--) {
            if (arr[i][j] == 0) {
                cnt++;
                if (cnt == 1) pos = i;
            }
            else if (arr[i][j] != 0 && pos != -1) {
                arr[pos][j] = arr[i][j];
                arr[i][j] = 0;
                pos = i;
                cnt = 0;
            }
        }
        for (int i = 3; i > 0; i--) {
            if (arr[i][j] != 0 && arr[i][j] == arr[i - 1][j]) {
                arr[i][j] = arr[i][j] * 2;
                for (int k = i - 1; k > 0; k--) {
                    arr[k][j] = arr[k - 1][j];
                }
                arr[0][j] = 0;
                }
            }

        }
    }
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<arr[i][4]<<endl;
    }
    
}