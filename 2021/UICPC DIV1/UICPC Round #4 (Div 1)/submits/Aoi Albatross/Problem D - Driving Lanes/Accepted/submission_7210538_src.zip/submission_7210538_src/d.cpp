#include <iostream>
#include <string.h>

using namespace std;
#define M 10000000+100
#define INF 1000000000000
long long n,m,k,r,l[M],s[M],c[M],dp[300][300];

long long solve(long long i,long long start){
    if (i==n){
        if ((start-1)*k>l[i]) return INF;
        return l[i]+(start-1)*r;
    }
    if (dp[i][start]!=-1)
        return dp[i][start];

    long long ans=INF;
    for (long long j=start-1;j>=1 && (start-j)*k<=l[i];j--){
        long long tmp=l[i]+(start-j)*r+(s[i]+c[i]*j)+solve(i+1,j);
        ans=min(ans,tmp);
    }
    for (long long j=start;j<=m && (j-start)*k<=l[i];j++){
        long long tmp=l[i]+(j-start)*r+(s[i]+c[i]*j)+solve(i+1,j);
        ans=min(ans,tmp);
    }
    return dp[i][start]=ans;
}

int main()
{
    cin>>n>>m;
    cin>>k>>r;
    for (int i=1;i<=n;i++)
        cin>>l[i];
    for (int i=1;i<n;i++)
        cin>>s[i]>>c[i];
    memset(dp,-1,sizeof(dp));
    cout<<solve(1,1)<<endl;

    return 0;
}
