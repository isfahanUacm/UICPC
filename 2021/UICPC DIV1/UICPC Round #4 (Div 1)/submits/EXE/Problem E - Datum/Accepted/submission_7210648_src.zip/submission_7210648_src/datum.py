day,index = map(int,input().split())

dic1 = {
    1 : 0,
    2 : 31,
    3 : 59,
    4 : 90,
    5 : 120,
    6 : 151,
    7 : 181,
    8 : 212,
    9 : 243,
    10: 273,
    11: 304,
    12: 334,
}

list1 = ["Thursday","Friday", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday"]

sum = day + dic1[index]
sum = sum%7
sum = sum -1
print(list1[sum])


