#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);

int N;


int main()
{
	cin >> N;
	int* a = new int[N];
	for (int i = 0; i < N; i++) {
		cin >> a[i];
	}
	int ma = 2006;
	bool bo[2005];
	fill_n(bo, 2005, 0);
	bo[0] = 1;

	int best = ma-1000;
	bool flag = 0;

	for (int i = 0; i < N; i++) {
		for (int j = 2004; j >=0 ; j--) {
			if (bo[j]) {
				if (j + a[i] < ma) {
					bo[j + a[i]] = true;
					if (j + a[i] == 1000) {
						flag = 1;
						break;
					}
					else if (j + a[i] > 1000) {
						ma = j + a[i];
					}
				}
			}
		}
		if (flag)
			break;
	}
	if (flag)
		cout << 1000;
	else {
		int i = 1;
		while (true) {
			if (bo[1000 + i]) {
				cout << 1000 + i;
				break;
			}
			if (bo[1000 - i]) {
				cout << 1000 - i;
				break;
			}
			i++;
		}
	}
}
