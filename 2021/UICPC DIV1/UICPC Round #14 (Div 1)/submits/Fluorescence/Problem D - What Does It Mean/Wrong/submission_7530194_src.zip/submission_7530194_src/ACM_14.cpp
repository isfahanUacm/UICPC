#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);

lli N;
string W;
map<string, lli> dic;
lli dp[35][35];

bool exist(lli len, lli from)
{
	string s = W.substr(from, len);
	auto it = dic.find(s);
	if (it == dic.end())
	{
		return 0;
	}
	return 1;
}
lli s2(lli size, lli from) {
	string sub = W.substr(from, size);
	if (dp[size][from] != -1)
		return dp[size][from];
	if (exist(size, from)) {
		return dp[size][from] = dic[sub];
	}
	return dp[size][from] = 0;
}
lli solve(lli size, lli from) {
	string sub = W.substr(from, size);
	if (dp[size][from] != -1) {
		return dp[size][from];
	}
	if (size == 1) {
		if (exist(size, from)) {
			return dp[size][from] = dic[sub];
		}
		return dp[size][from] = 0;
	}
	dp[size][from] = 0;
	for (int i = 1; i < size; i++)
	{
		dp[size][from] += s2(i, from) * solve(size - i, i + from);
	}
	if (exist(size, from))
	{
		dp[size][from] += dic[sub];
	}
	return dp[size][from];

}

int main()
{
	cin >> N >> W;
	string s;
	lli e;

	for (int i = 0; i <= 34; i++){
		for (int j = 0; j <= 34; j++){
			dp[i][j] = -1;
		}
	}
	for (int i = 0; i < N; i++) {
		cin >> s;
		cin >> e;
		dic[s] = e;
	}

	cout << solve(W.size(), 0);
}
