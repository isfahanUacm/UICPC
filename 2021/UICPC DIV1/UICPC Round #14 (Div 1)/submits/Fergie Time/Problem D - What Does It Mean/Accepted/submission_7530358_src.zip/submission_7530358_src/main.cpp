#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;

bool endsWith(string s, string x)
{
    if (s.size() >= x.size())
    {
        return s.substr(s.size() - x.size(), x.size()) == x;
    }
    return false;
}

int main()
{
    ll n;
    string s;
    cin >> n >> s;
    vector<ll> dp(s.size(), 0);
    map<string, ll> dict;
    for (ll i = 0; i < n; i++)
    {
        string word;
        cin >> word;
        ll meanings;
        cin >> meanings;
        dict[word] = meanings;
    }
    for (ll i = 0; i < s.size(); i++)
    {
        ll tempDP = 0;
        for (pair<string, ll> j: dict)
        {
            if (endsWith(s.substr(0, i + 1), j.first))
            {

                ll currentValue = (((i >= j.first.size())? dp[i - j.first.size()] : 1) * j.second) % mod;
                tempDP = (tempDP + currentValue) % mod;
            }
        }
        dp[i] = max(dp[i], tempDP);
    }
    cout << dp[s.size() - 1];
    return 0;
}