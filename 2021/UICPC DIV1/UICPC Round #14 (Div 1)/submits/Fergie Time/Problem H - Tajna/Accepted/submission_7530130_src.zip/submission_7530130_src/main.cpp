#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;

pll findmult(int n){
    int x , y;
    pll number;
    x = sqrt(n);
    while(true)
    {
        if(n % x == 0)
        {
            y = n / x;
            if(x < y)
                return number = {x , y};
            else
            {
                return number = {y , x};
            }

        }
        x -- ;

    }

}


int main()
{
    string s;
    cin >> s;
    pll number;
    number = findmult(s.size());
    int pointerf = 0;
    int pointers = 0;
    int counter = 0;
    while(pointerf < number.first){
         pointers = 0;
         counter = 0;
        while(counter < number.second)
        {
            cout << s[pointerf + pointers];
            pointers += number.first;
            counter += 1;
        }
        pointerf += 1;
    }
}
