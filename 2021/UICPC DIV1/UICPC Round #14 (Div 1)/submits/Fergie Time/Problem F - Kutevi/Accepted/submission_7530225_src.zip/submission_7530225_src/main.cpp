#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
int main()
{
    ll n, k;
    cin >> n >> k;
    set<ll> angles;
    vector<ll> has(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> has[i];
    }
    vector<ll> need(k);
    set<ll> needSet;
    for(ll i = 0; i < k; i++)
    {
        cin >> need[i];
        needSet.insert(need[i]);
    }

    angles.insert(0);
    needSet.erase(0);
    for(ll i: has)
    {
        angles.insert(i);
        needSet.erase(i);
    }
    ll last_size = 1;
    for(ll time = 0; time < 360; time++)
    {
        set<ll> newOnes;
        for(ll i: angles)
        {
            for(ll j: angles)
            {
                newOnes.insert((i + j) % 360);
                needSet.erase((i + j) % 360);
                newOnes.insert(abs(i - j) % 360);
                needSet.erase(abs(i - j) % 360);

            }
        }
        for(ll i: newOnes)
        {
            angles.insert(i);
        }
        if(angles.size() == last_size)
        {
            break;
        }
        if(needSet.empty())
        {
            break;
        }
        last_size = angles.size();
    }
    for(ll i: need)
    {
        cout << ((needSet.find(i) == needSet.end())? "YES\n" : "NO\n");
    }
    return 0;
}