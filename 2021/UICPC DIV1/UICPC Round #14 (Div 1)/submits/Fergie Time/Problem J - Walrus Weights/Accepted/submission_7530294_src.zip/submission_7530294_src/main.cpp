#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
vector<ll> arr;

ll weight(ll maxWeight){
    ll **w = new ll*[arr.size()];
    for(ll i = 0; i < arr.size(); i++) {
        w[i] = new ll[maxWeight];
    }
    if(arr.size() == 1){
        return arr[0];
    }
    else{
        for(ll i = 0; i < arr.size(); i++){
            for(ll j = 0; j<maxWeight; j++){
                if(j == 0){
                    w[i][j]=0;
                }
                else if((arr[i] <= j ) && i == 0 ){
                    w[i][j] = arr[i];
                }
                else if((arr[i] > j) && i==0) {
                    w[i][j]=0;
                }
                else {
                    if((j-arr[i])>0)
                    {
                       w[i][j] = max(w[i-1][j],arr[i]+w[i-1][j-arr[i]]);
                    }
                    else{
                        w[i][j] = w[i-1][j];
                    }

                }
            }
        }
//        for(ll i=0;i<arr.size();i++)
//        {
//            for(ll j=0;j<maxWeight;j++)
//            {
//                cout<<w[i][j]<<" ";
//            }
//            cout<<endl;
//        }
        ll maximum=w[arr.size()-1][maxWeight-1];
        ll sizearr=arr.size() -1;
        for(ll i = maxWeight-2; i>0; i--){
//            cout<<w[sizearr][i]<<" ";
            ll x=abs(maximum - 1000);
            ll y=abs(w[sizearr][i] - 1000);
            if( x > y ){
                maximum = w[sizearr][i];
//                cout<<maximum<<" ";
            }



        }
        return maximum;
    }

}

int main()
{
    ll n,item;
    cin>>n;
    arr= vector<ll> ();
    for(ll i = 0; i < n; i++){
        cin>>item;
        arr.push_back(item);
    }
    ll maxWeight = 1000 + *min_element(begin(arr), end(arr));
    ll ans= weight(maxWeight);
    cout<<ans<<endl;


}
