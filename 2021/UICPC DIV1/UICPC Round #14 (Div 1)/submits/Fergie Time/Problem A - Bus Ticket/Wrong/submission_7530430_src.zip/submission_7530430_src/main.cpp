#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;

int main()
{
    ll s, p, m, n;
    cin >> s >> p >> m >> n;
    vector<ll> trip(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> trip[i];
    }
    vector<ll> dp(n, 0);
    dp[0] = s;
    ll lastCovered = 0;
    for(ll i = 1; i < n; i++)
    {
        while(trip[i] - trip[lastCovered] > m)
        {
            lastCovered++;
        }
        dp[i] = min(dp[i - 1] + s, dp[lastCovered - 1] + p);
    }
    cout << dp[n - 1];
    return 0;
}