#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
vector<string> mapp;
ll n, m;
vector<vector<bool>> visited;

bool isSea(ll x, ll y)
{
    if(mapp[x][y] == '2')
    {
        return true;
    }
    visited[x][y] = true;
    if(mapp[x][y] == '0')
    {
        if(x == 0 || x == n - 1 || y == 0 || y == m - 1)
        {
            return true;
        }
        if(x - 1 >= 0 && !visited[x - 1][y] && isSea(x - 1, y))
        {
            return true;
        }
        if(x + 1 < n && !visited[x + 1][y] && isSea(x + 1, y))
        {
            return true;
        }
        if(y - 1 >= 0 && !visited[x][y - 1] && isSea(x, y - 1))
        {
            return true;
        }
        if(y + 1 < m && !visited[x][y + 1] && isSea(x, y + 1))
        {
            return true;
        }
    }
    return false;
}
void fillSea(ll x, ll y)
{
    if(mapp[x][y] == '0')
    {
        mapp[x][y] = '2';
        if(x - 1 >= 0)
        {
            fillSea(x - 1, y);
        }
        if(x + 1 < n)
        {
            fillSea(x + 1, y);
        }
        if(y - 1 >= 0)
        {
            fillSea(x, y - 1);
        }
        if(y + 1 < m)
        {
            fillSea(x, y + 1);
        }
    }
}
int main()
{
    cin >> n >> m;
    mapp = vector<string>(n);
    vector<bool> sample(m, false);
    visited = vector<vector<bool>> (n, sample);
    for(ll i = 0; i < n; i++)
    {
        cin >> mapp[i];
    }
    for(ll i = 0; i < n; i++)
    {
        for(ll j = 0; j < m; j++)
        {
//                visited = vector<vector<bool>> (n, sample);
                if(isSea(i, j))
                {
                    fillSea(i, j);
                }
        }
    }
//    for(ll i = 0; i < n; i++)
//    {
//        for(ll j = 0; j < m; j++)
//        {
//            cout << mapp[i][j] << " ";
//        }
//        cout << endl;
//    }
    ll ans = 0;
    for(ll i = 0; i < n; i++)
    {
        for(ll j = 0; j < m; j++)
        {
            if(mapp[i][j] == '1')
            {
                if(i == 0     || mapp[i - 1][j] == '2')
                {
                    ans++;
                }
                if(i == n - 1 || mapp[i + 1][j] == '2')
                {
                    ans++;
                }
                if(j == 0     || mapp[i][j - 1] == '2')
                {
                    ans++;
                }
                if(j == m - 1 || mapp[i][j + 1] == '2')
                {
                    ans++;
                }
            }
        }
    }
    cout << ans;
    return 0;
}