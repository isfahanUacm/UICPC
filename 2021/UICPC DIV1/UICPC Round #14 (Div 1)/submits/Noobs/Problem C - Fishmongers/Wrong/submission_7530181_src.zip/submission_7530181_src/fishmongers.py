n, m = map(int, input().split())
kg = list(map(int, input().split()))

d = dict()
for i in range(m):
    fish_num, money = map(int, input().split())
    if money in d:
        d[money] += fish_num
    else:
        d[money] = fish_num

max_money = 0
kg.sort(reverse=True)
sort_dic = sorted(d.items(), reverse=True)
i = 0
for f, mo in sort_dic:
    while mo > 0:
        if i >= len(kg):
            print(max_money)
            break
        max_money += kg[i] * f
        mo -= 1
        i += 1
