#include <bits/stdc++.h>
using namespace std ;

int n,k , num;
int nn[10] ;
int visited[360];

bool dfs(int tmp){
    visited[tmp] = true;
    for (int i=0 ; i<n ; i++) {
        int index = (tmp + nn[i]) % 360;
        int sIndex = (tmp - nn[i] + 360) % 360;
        if (!visited[index]) {
            dfs(index);
        }
        if (!visited[sIndex]) {
            dfs(sIndex);
        }
    }
    return false;
}


int main(){
    cin >> n >> k;
    for (int i=0 ; i<n ; i++)
        cin >> nn[i] ;

    dfs(0);
    for (int i=0 ; i<k ; i++){
        cin >> num;
        if (visited[num]) {
            cout << "YES" << endl;
        }
        else {
            cout << "NO" << endl;
        }
    }

    return 0;
}