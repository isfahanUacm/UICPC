#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ll c, p;
    cin >> c >> p;
    ll val[p];
    queue<ll> stc[p];
    for (ll i = 0; i < p; ++i) {
        ll t;
        cin >> t;
        val[i] = t;

        for (ll j = 0; j < c; ++j) {
            cin >> t;
            stc[i].push(t);
        }
    }

    bool dead[c + 10];
    ll mg[c + 10];
    memset(dead, 0, sizeof(dead));
    memset(mg, 0, sizeof(mg));
    set<pair<ll, ll>> st;
    for (ll i = 1; i <= c; ++i) {
        st.insert({0, i});
    }

    for (ll i = 0; i < c; ++i) {
        for (ll j = 0; j < p; ++j) {
            bool flag = i == 0;
            while (!stc[j].empty() && dead[stc[j].front()]) {
                flag = true;
                ll x = stc[j].front();
                mg[x] -= val[x - 1];
                stc[j].pop();
            }
            if(flag && !stc[j].empty()) {
                st.erase({mg[stc[j].front()], stc[j].front()});
                mg[stc[j].front()] += val[stc[j].front() - 1];
                st.insert({mg[stc[j].front()], stc[j].front()});
            }
        }
        ll x = st.begin()->second;
        dead[x] = true;
        if (i != c - 1 && !st.empty()) {
            st.erase(st.begin());
        }
    }
    cout << st.begin()->second << endl;
}

