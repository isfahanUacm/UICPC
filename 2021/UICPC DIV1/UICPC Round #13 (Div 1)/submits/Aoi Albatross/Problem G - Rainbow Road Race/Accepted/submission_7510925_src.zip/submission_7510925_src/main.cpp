#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 7 * 7 * 7 + 10;
ll dist[MAX][128];
set<pair<ll, pair<ll, ll>>> ss;
vector<pair<ll, pair<ll, ll>>> adj[MAX];

map<char, int> mp = {
        {'R', 0},
        {'O', 1},
        {'Y', 2},
        {'G', 3},
        {'B', 4},
        {'I', 5},
        {'V', 6}
};

void dijkstra(int start) {
    dist[start][0] = 0;
    ss.insert({0, {start, 0}});
    while (!ss.empty()) {
        ll u = ss.begin()->second.first;
        ll cond = ss.begin()->second.second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            ll mask = cond | (1 << v.second.second);
            if (dist[v.first][mask] > dist[u][cond] + v.second.first) {
                ss.erase({dist[v.first][mask], {v.first, mask}});
                dist[v.first][mask] = dist[u][cond] + v.second.first;
                ss.insert({dist[v.first][mask], {v.first, mask}});
            }
        }
    }
}

int main() {
    ll n, m;
    cin >> n >> m;
    for (ll i = 0; i < n; ++i) {
        for (int j = 0; j < 128; ++j) {
            dist[i][j] = INT_MAX;
        }
    }
    for (ll i = 0; i < m; ++i) {
        ll w, a, b;
        cin >> a >> b >> w;
        char ch;
        cin >> ch;
        a--;b--;
        adj[a].push_back({b, {w, mp[ch]}});
        adj[b].push_back({a, {w, mp[ch]}});
    }
    dijkstra(0);
    cout << dist[0][127] << endl;
}