#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;


using namespace std;


int main()
{
    ll r,c;
    cin>>r>>c;
    char ** map = new char *[r];
    int ** visited = new int *[r];
    for(int i=0;i<r;i++)
    {
         map[i] = new char[c];
         visited[i] = new int[c];
    }
    for(int i=0;i<r;i++)
        for(int j=0;j<c;j++)
        {
           cin>>map[i][j];
           visited[i][j] = 0;
        }

    int i=0,j = 0;
    char dir;
    int flag = 0;
    int counter = 0;
    while(true)
    {
        dir = map[i][j];
        if (visited [i][j] == 1)
        {
            flag = 2;
            break;
        }
        else
        {
            visited[i][j] = 1;
        }

        if(dir == 'N')
          {
           if (i-1 <= -1)
           {
               flag = 1;
               break;
           }

               else
               {
                   i -= 1;

               }

        }
        else if(dir == 'S')
          {
           if (i+1 >= r)
           {
                 flag = 1;
                  break;
           }
               else
               {
                   i += 1;
               }

        }
        else if(dir == 'W')
          {
           if (j-1 <=  -1)
           {
                 flag = 1;
                   break;
           }
               else
               {
                   j -= 1;
               }

        }
        else if(dir == 'E')
          {
           if (j+1 >= c)
           {
                   flag = 1;
                    break;
           }
               else
               {
                   j += 1;
               }

        }
        else if(dir == 'T')
          {

              flag = 0;
              break;
          }
        counter += 1;
    }

    switch (flag) {

     case 0:
        cout<<counter;
        break;
      case 1:
        cout<<"Out";
        break;
      case 2:
        cout<<"Lost";
        break;

    }






}
