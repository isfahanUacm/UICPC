#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;

int main()
{
    map<char, ll> colorBitmask {{'R', 1}, {'O', 2}, {'Y', 4}, {'G', 8}, {'B', 16}, {'I', 32}, {'V', 64}};
    ll n, m;
    cin >> n >> m;
    vector<pair<ll, pair<ll, ll>>> sample;
    vector<vector<pair<ll, pair<ll, ll>>>> graph(n, sample);
    //                 {dest, {weight, colorBitmask}}
    ll l1, l2, d;
    char c;
    for(ll i = 0; i < m; i++)
    {
        cin >> l1 >> l2 >> d >> c;
        l1--;
        l2--;
        graph[l1].push_back({l2, {d, colorBitmask[c]}});
        graph[l2].push_back({l1, {d, colorBitmask[c]}});
    }
    vector<ll> sampleVec(128, LLONG_MAX);
    vector<vector<ll>> dp(n, sampleVec);
    set<pair<ll, pair<ll, ll>>> q;
    //     {distance, {color, index}}
    q.insert({0, {0, 0}});
    dp[0][0] = 0;
    // pair<ll, pair<ll, ll>>

    while(q.size())
    {
        pair<ll, pair<ll, ll>> current = *(q.begin());
        //     {distance, {color, index}}
        ll currentDist = current.first;
        ll currentColor = current.second.first;
        ll currentIndex = current.second.second;

        q.erase(q.begin());
        //      GRAPH:     {dest, {weight, colorBitmask}}
        for (ll i = 0; i < graph[currentIndex].size(); i++)
        {
            ll edgeDest = graph[currentIndex][i].first;
            ll edgeWeight = graph[currentIndex][i].second.first;
            ll edgeColor = graph[currentIndex][i].second.second;

            ll nextDist = currentDist + edgeWeight;
            ll nextColor = currentColor | edgeColor;
            ll nextIndex = edgeDest;
            if(nextDist < dp[nextIndex][nextColor])
            {
                q.erase({dp[nextIndex][nextColor], {nextColor, nextIndex}});
                dp[nextIndex][nextColor] = nextDist;
                q.insert({dp[nextIndex][nextColor], {nextColor, nextIndex}});
            }
        }
    }
    cout << dp[0][127];
    return 0;
}