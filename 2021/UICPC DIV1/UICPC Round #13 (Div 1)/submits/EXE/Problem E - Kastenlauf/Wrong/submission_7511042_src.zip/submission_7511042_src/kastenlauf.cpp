#include <bits/stdc++.h>

using namespace std;

int findMeters(vector<int> a, vector<int> b)
{
  return abs(a[1] - b[1]) + abs(a[0] - b[0]);
}

int main()
{

  int numberOfTests;
  cin >> numberOfTests;

  for (int index = 0; index < numberOfTests; index++)
  {

    int numberOfStores;
    cin >> numberOfStores;

    vector<vector<int>> stops;

    for (int i = 0; i < numberOfStores + 2; i++)
    {
      vector<int> stop;
      int firstCo;
      int secondCo;
      cin >> firstCo >> secondCo;
      stop.push_back(firstCo);
      stop.push_back(secondCo);
      stops.push_back(stop);
    }

    for (int i = 1; i < numberOfStores + 1; i++)
    {
      int min = findMeters(stops[0], stops[i]);
      int minIndex = i;

      for (int j = i + 1; j < numberOfStores + 1; j++)
      {
        if (findMeters(stops[0], stops[j]) < min)
        {
          minIndex = j;
          min = findMeters(stops[0], stops[j]);
        }
      }

      int temp = stops[i][0];
      stops[i][0] = stops[minIndex][0];
      stops[minIndex][0] = temp;

      temp = stops[i][1];
      stops[i][1] = stops[minIndex][1];
      stops[minIndex][1] = temp;
    }

    int max = findMeters(stops[0], stops[numberOfStores + 1]);
    
    if (max <= 20 * 50) {
      cout << "happy" << endl;
      continue;
    }

    for (int i = 1; i < stops.size() - 1; i++)
    {
      if (findMeters(stops[i], stops[0]) > max) {
        vector<vector<int>>::iterator it;
        it = stops.begin() + i;
        stops.erase(it);
      }
    }

    for (int i = 0; i < numberOfStores + 1; i++)
    {
      if (findMeters(stops[i], stops[i + 1]) > 20 * 50)
      {
        cout << "sad" << endl;
        break;
      }

      if (i == numberOfStores)
      {
        cout << "happy" << endl;
      }
    }
  }

  return 0;
}