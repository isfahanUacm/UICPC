#include <iostream>
#include <math.h>
#include <string>
#include <vector>

using namespace std;


struct node{
    bool empty = true;
    char dir ;

};

int main(){
    int R,C;
    cin>>R>>C;
    node ** mat = new node*[R];

    for(int i=0;i<R;i++)
        mat[i] = new node[C];

    for(int i=0;i<R;i++){
        string nn;
        cin>>nn;
        for(int j=0;j<C;j++){
            mat[i][j].dir = nn[j];
        }
    }

    int x=0,y = 0;
    int count = 0;
     while(1){
         if(x>=R || y>=C){
             cout<<"Out";
             break;
         }
         if(!mat[x][y].empty){
             cout<<"Lost"<<endl;
             break;
         }
         if(mat[x][y].dir == 'N'){
             mat[x][y].empty=false;
             count++;
             x-=1;
         }
         else if(mat[x][y].dir == 'S'){
             mat[x][y].empty=false;
             count++;
             x+=1;
         }
         else if(mat[x][y].dir == 'W'){
             mat[x][y].empty=false;
             count++;
             y-=1;
         }
         else if(mat[x][y].dir == 'E'){
             mat[x][y].empty=false;
             count++;
             y+=1;
         }
         else if(mat[x][y].dir == 'T'){
             cout<<count<<endl;
             break;
         }


     }


}
