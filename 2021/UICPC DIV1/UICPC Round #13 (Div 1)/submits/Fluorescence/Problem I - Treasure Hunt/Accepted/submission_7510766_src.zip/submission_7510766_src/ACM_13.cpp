#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());

int r, c;
bool inr(int i, int j) {
    return (i >= 0) && (i < r) && (j >= 0) && (j < c);
}

int main()
{
   
    cin >> r >> c;
    pair<int, int> t;
    char** map = new char*[r];
    bool** vi = new bool* [r];
    for (int i = 0; i < r; i++) {
        map[i] = new char[c];
        vi[i] = new bool[c];
        for (int j = 0; j < c; j++) {
            cin >> map[i][j];
            vi[i][j] = 0;
            if (map[i][j] == 'T')
                t = { i, j };
        }
    }

   
    int x = 0, y = 0, count = 0;
    bool t1 = 0, o1 = 0, ou = 0;;
    
    while (true) {
        if (!inr(x, y)){
            o1 = 1;
            break;
        }
        if (vi[x][y]) {
            ou = 1;
            break;
        }
        if (x == t.first && y == t.second) {
            t1 = 1;
            break;
        }
        
        if (map[x][y] == 'N') {
            
            vi[x][y] = 1;
            x--;
        }
        else if (map[x][y] == 'S') {
            
            vi[x][y] = 1;
            x++;
        }
        else if (map[x][y] == 'W') {
            
            vi[x][y] = 1;
            y--;
        }
        else if (map[x][y] == 'E') {
            
            vi[x][y] = 1;
            y++;
        }
        count++;
    }

    if (t1)
        cout << count;
    else if (o1)
        cout << "Out";
    else if (ou) {
        cout << "Lost";
    }

}
