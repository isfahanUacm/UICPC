#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());

pair<lli, lli> s, e;
bool vi[105];
map<lli, pair<lli, lli>> Map;
lli n;

lli dis(pair<lli, lli> p1, pair<lli, lli> p2) {
	return abs(p2.first - p1.first) + abs(p2.second - p1.second);
}

bool solve() {
	bool find=0;
	lli cur = 0;//s
	set<pair<lli, lli>> set;
	set.insert({cur, cur});
	while (!set.empty()) {
		cur = set.begin()->first;
		vi[cur] = 1;
		set.erase({cur, cur});
		for (lli i = 1; i < n + 2; i++) {
			if (!vi[i] && (dis(Map[cur], Map[i]) <= 1000)) {
				if (i == n + 1) {
					find = 1;
					break;
				}
				set.insert({i, i});
			}
		}
		if (find)
			break;
	}
	return find;
}

int main()
{
	int t;
	cin >> t;
	while (t--) {
		Map.clear();
		cin >> n;
		fill_n(vi, 105, 0);
		cin >> s.first >> s.second;
		Map[0] = s;
		pair<lli, lli> p;
		for (lli i = 1; i <= n; i++) {
			cin >> p.first >> p.second;
			Map[i] = p;
		}
		cin >> e.first >> e.second;
		Map[n + 1] = e;
		if (solve())
			cout << "happy";
		else cout << "sad";
		cout << endl;
	}
}