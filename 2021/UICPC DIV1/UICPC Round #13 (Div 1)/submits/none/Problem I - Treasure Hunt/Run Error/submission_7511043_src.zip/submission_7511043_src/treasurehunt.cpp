#include <bits/stdc++.h>
using namespace std;

void find_new_curr (string * x, int i, int j, int & new_i, int & new_j)
{
    if (x[i][j] == 'N')
    {
        new_i= i- 1;
        new_j= j;
    }
    else if (x[i][j] == 'S')
    {
        new_i= i+ 1;
        new_j= j;
    }
    else if (x[i][j] == 'W')
    {
        new_i= i;
        new_j= j- 1;
    }
    else if (x[i][j] == 'E')
    {
        new_i= i;
        new_j= j+ 1;
    }
    else if (x[i][j] == 'T')
    {
        new_i= i;
        new_j= j;
    }
}

int main()
{
    int R, C, i, count= 0;
    cin>> R>> C;

    string * x= new string [R];
    for (i=0; i<R; i++)
        cin>> x[i];

    bool ** b= new bool * [R];
    for (i=0; i<R; i++)
        b[i]= new bool [C];
    for (i=0; i<R; i++)
        for (int j=0; j<C; j++)
            b[i][j]= false;

    int new_i=0, new_j=0;
    while (true)
    {
        b[new_i][new_j]= true;
        find_new_curr (x, new_i, new_j, new_i, new_j);
        count ++;
        if (new_i >= R || new_j >= C)
        {
            cout<< "Out"<< endl;
            break;
        }
        else if (b[new_i][new_j] == true)
        {
            cout<< "Lost"<< endl;
            break;
        }
        else if (new_i >= R || new_j >= C)
        {
            cout<< "Out"<< endl;
            break;
        }
        else if (x[new_i][new_j] == 'T')
        {
            cout<< count<< endl;
            break;
        }
    }

    return 0;
}
