#include <bits/stdc++.h>
using namespace std;
int MAX = 2 * (1e5);
int momayez = 6;
int main()
{
    int n;
    cin >> n;
    float a[n], min = MAX;
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    sort(a , a+n);
    for(int i = 0; i < n; i++)
    {
        if(a[i] > (i +1))
        {
            cout << "impossible" << endl;
            return 0;
        }
        else
        {
            if(min > (a[i]/(i +1)))
            {
                min = a[i]/(i +1);
            }
        }
    }
    cout<<fixed;
    cout.precision(momayez);
    cout << min << endl;
    return 0;
}
