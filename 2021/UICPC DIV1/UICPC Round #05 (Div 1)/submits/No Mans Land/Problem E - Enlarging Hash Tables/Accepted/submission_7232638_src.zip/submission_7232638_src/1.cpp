#include <bits/stdc++.h>
using namespace std;
bool prime(long long int n)
{
    if (n == 1)
        return false;
    else if (n == 2 || n == 3)
        return true;
    else if (n % 2 == 0 || n % 3 == 0)
        return false;
    for (long long int i=5; i*i<= n; i+=6)
        if (n%i == 0 || n%(i + 2) == 0)
            return false;
    return true;
}
int main()
{
    long long int n,z;
    cin >> n;
    while (n) {
        bool f1 = false;
        if (prime(n)) f1 = true;
        z = 2*n+1;
        while (!prime(z)) {
            z++;
        }
        if (!f1) cout << z <<" ("<<n<<" is not prime)"<<endl;
        else cout << z<<endl;
        cin >> n;
    }
}
