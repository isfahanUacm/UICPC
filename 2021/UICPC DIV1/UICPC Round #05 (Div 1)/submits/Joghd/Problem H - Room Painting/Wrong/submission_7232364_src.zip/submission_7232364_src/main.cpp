#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;

int main() {
    int n,m;
    cin >> n >> m;
    double st[n];
    double jo[m];
    for(int i=0;i<n;i++)
        cin >> st[i];
    for(int i=0;i<m;i++)
        cin >> jo[i];
    sort(st,st+n);
    sort(jo,jo+m);
    double ans = 0;
    int j=0;
    for(int i=0;i<m;i++) {
       if(st[j]<jo[i]) {
            j++;
            if(j==n)
                break;
            i--;
            continue;
        }
        ans+= st[j]-jo[i];

    }
    int aa = ans*1000000;
    ans = aa / 1000000.0;

    cout << ans;




}
