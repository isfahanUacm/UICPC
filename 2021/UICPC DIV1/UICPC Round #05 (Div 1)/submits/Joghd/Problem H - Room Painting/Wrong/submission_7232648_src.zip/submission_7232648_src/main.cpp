#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;
int main() {
    int n,m;
    cin >> n >> m;
    double st[n];
    double jo[m];

    double ans=0;
    for(int i=0;i<n;i++)
        cin >> st[i];
    for(int i=0;i<m;i++)
        cin >> jo[i];
     sort(st,st+n);
    for(int i=0;i<m;i++) {
        for(int j=0;j<n;j++) {
            if(jo[i]<=st[j]) {
                ans+=st[j]-jo[i];
                break;
            }
        }

    }
    if(ans==0) {
        return 0;
    }
    cout << ans;




}
