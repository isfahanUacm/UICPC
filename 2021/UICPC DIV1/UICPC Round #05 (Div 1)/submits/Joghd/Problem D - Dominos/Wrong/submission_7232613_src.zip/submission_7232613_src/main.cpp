
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int que() {
    int n, m;
    cin >> n >> m;
    int x[n];
    for(int i=0;i<n;i++)
        x[i]=1;
    int a,b;
    for(int i=0;i<m;i++) {
        cin >> a >> b;
        if(b-a==1)
            x[a]=0;
    }
    int ans=0;
    for(int i=0;i<n;i++)
        ans+=x[i];
    return ans;

}
int main ( void )
{
    int n;
    cin >> n;
    int ans[n];
    for(int i=0;i<n;i++)
        ans[i]=que();
    for(int i=0;i<n;i++)
        cout << ans[i] << endl;
}
