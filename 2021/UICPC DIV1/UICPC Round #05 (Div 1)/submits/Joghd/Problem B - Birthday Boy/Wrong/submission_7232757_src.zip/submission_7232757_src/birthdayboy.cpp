
#include <iostream>
#include <algorithm>
#include<string.h>
#include <sstream>

using namespace std;

string digitformat(int kl)
{
	string ss = "";
	int lengthOfMonth[] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
	if (kl < 1000)
	{
		int u = kl / 100;
		if (u == 1 && kl % 100 == 1)
		{
			u = 12;
			ss = "12-31";			
		}
		else if (kl % 100 == 1)
		{
			u--;
			ss = ss + "0" + to_string(u);
			ss += "-" + to_string(lengthOfMonth[u-1]);
		}
		else
		{
			ss = ss + "0" + to_string(u);
			ss += "-" + to_string((kl % 100)-1);
		}
	}
	else
	{
		int u = kl / 100;
		if (kl % 100 == 1)
		{
			u--;
			if(u>9)
			ss = ss + to_string(u);
			else
				ss = ss + "0" + to_string(u);
			ss += "-" + to_string(lengthOfMonth[u - 1]);
		}
		else
		{
			ss = ss + to_string(u);
			ss += "-" + to_string((kl % 100) - 1);
		}
	}
	return ss;
}
int main()
{
	int n; cin >> n;
	int *date=  new int[n];

	for (int i = 0; i < n * 2; i++)
	{
		string m; cin >> m;

		if (i % 2 == 1)
		{	
		string mon = m.substr(0, m.find('-'));
		string day = m.substr(m.find('-')+1, m.length() - 1);
		stringstream convert(mon);
		int mo = 0;
		convert >> mo;
		stringstream convert2(day);
		int d = 0;
		convert2 >> d;
		date[i/2] = mo * 100 + d;
	    }
	}
	sort(date, date + n);
	int j = 0;
	int min = -1;
	for (int i = 0; i < n-1; i++)
	{
		if (min < date[i + 1] - date[i])
			min = date[i + 1] - date[i];
		j = i+1;
	}
	int k = 1231 - date[n - 1] + date[0];
	if (k > min)
	{
		cout<< digitformat(date[j]);
	}
	else
	{
		cout << digitformat(date[0]);
	}
}
