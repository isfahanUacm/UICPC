import math


def check_prime(n):
    if n < 10:
        for i in range(2, n):
            if n % i == 0:
                return False
    else:
        for i in range(2, math.ceil(math.sqrt(n)) + 5):
            if n % i == 0:
                return False
    return True


n = -1

while True:
    n = int(input())
    if n == 0:
        break
    m = 0
    if check_prime(n):
        m = 2 * n + 1
        while not check_prime(m):
            m += 1
        print(m)
    else:
        m = 2 * n + 1
        while not check_prime(m):
            m += 1
        x = f"{m} ({n} is not prime)"
        print(x)
