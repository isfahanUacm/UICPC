#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n,m;
	cin >> n >> m;
	ll ans=0;
	std::vector<ll> buy(m);
	multiset<ll> can;
	for(ll i=0;i<n;i++){
		ll c;
		cin >> c;
		can.insert(c);
	}
	for(ll i=0;i<m;i++)cin >> buy[i];
	sort(buy.begin(),buy.end());
	for(auto i:buy){
		ans+=(*can.lower_bound(i)-i);
	}
	cout<<ans<<endl;
}