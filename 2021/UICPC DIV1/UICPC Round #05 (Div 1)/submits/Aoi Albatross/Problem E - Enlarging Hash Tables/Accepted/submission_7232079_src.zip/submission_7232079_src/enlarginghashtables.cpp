#include <bits/stdc++.h>
using namespace std;
typedef long long ll;



bool is_prime(ll num){
	for(ll i=2;i<=sqrt(num);i++){
		if(num%i==0)return false;
	}
	return true;
}
int main(){
	ll n;
	while(true){
		cin >> n;
		if(n==0)break;
		for(ll i=2*n+1;;i++){
			if(is_prime(i)){
				cout<<i;
				if(!is_prime(n)){
					cout << " (" << n << " is not prime)";
				}
				cout<<endl;
				break;
			}

		}
	}
	return 0;
}