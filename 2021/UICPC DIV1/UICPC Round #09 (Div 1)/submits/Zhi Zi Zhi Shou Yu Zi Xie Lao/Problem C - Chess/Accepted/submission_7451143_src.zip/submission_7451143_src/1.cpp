#include <iostream>
using  namespace std;
int main() {
    int t,a1,b1,a2,b2,m,x,a3,b3;
    char a,b;
    string s;
    cin >> t;
    while (t--){
        s.clear();
        m = 0;
        cin >> a >> b1 >> b >> b2;
        a1 = int(a)-64 , a2 = int(b)-64;
        a3 = a2 , b3 = b2;
        if ((a1+b1)%2 != (a2+b2)%2)
            cout << "Impossible" <<endl;
        else{
            if ((a1+b1)%2==1){
                s+=char(a1+64);
                s+=char(b1+48);
                if ((a1+b1)!=9) {
                    m++;
                    x = abs(9 - (a1 + b1));
                    if ((a1 + b1) > 9)
                        a1 -= x / 2, b1 -= x / 2;
                    else if ((a1 + b1) < 9)
                        a1 += x / 2, b1 += x / 2;
                    s += char(a1 + 64);
                    s += char(b1 + 48);
                }
                if ((a2+b2)!=9) {
                    x = abs(9 - (a2 + b2));
                    if ((a2 + b2) > 9)
                        a2 -= x / 2, b2 -= x / 2;
                    else if ((a2 + b2) < 9)
                        a2 += x / 2, b2 += x / 2;
                }
                if (a1!=a2 || b1!=b2){
                    m++;
                    s += char(a2 + 64);
                    s += char(b2 + 48);
                }
                if (a3!=a2 || b3!=b2){
                    m++;
                    s += char(a3 + 64);
                    s += char(b3 + 48);
                }
            }
            else{
                a1 = 9-a1,a2 = 9-a2,a3 = 9-a3;
                s+=char(9-a1+64);
                s+=char(b1+48);
                if ((a1+b1)!=9) {
                    m++;
                    x = abs(9 - (a1 + b1));
                    if ((a1 + b1) > 9)
                        a1 -= x / 2, b1 -= x / 2;
                    else if ((a1 + b1) < 9)
                        a1 += x / 2, b1 += x / 2;
                    s += char(9-a1 + 64);
                    s += char(b1 + 48);
                }
                if ((a2+b2)!=9) {
                    x = abs(9 - (a2 + b2));
                    if ((a2 + b2) > 9)
                        a2 -= x / 2, b2 -= x / 2;
                    else if ((a2 + b2) < 9)
                        a2 += x / 2, b2 += x / 2;
                }
                if (a1!=a2 || b1!=b2){
                    m++;
                    s += char(9-a2 + 64);
                    s += char(b2 + 48);
                }
                if (a3!=a2 || b3!=b2){
                    m++;
                    s += char(9-a3 + 64);
                    s += char(b3 + 48);
                }
            }
            cout << m<<" ";
            for (int i = 0 ; i < s.size();i++)
                cout << s[i]<<" ";
            cout << endl;
        }
    }
    return 0;
}