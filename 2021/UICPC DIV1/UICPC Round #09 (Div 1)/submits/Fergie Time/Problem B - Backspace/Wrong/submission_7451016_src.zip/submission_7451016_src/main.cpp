#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}


int main()
{
    string input,output;
    cin>>input;
    ll i,j=0;
    i=input.length()-1;
    while(i>=0)
    {
        if(input[i]=='<')
        {
            j++;
            i--;
            while(input[i]=='<')
            {
               j++;
               i--;

            }
            i=i-(j);
            j=0;
        }
        else{
           output.push_back(input[i]);

            i--;
        }
    }
    int n=output.length();

     string rev;
     for(int i=n-1;i>=0;i--)
       rev.push_back(output[i]);

     cout<<rev<<endl;



}
