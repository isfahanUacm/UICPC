#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

void watchstack(stack<ll> s)
{
    while (s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        char charAx, charBx;
        pll a, b;

        cin >> charAx >> a.second;
        cin >> charBx >> b.second;

        a.first = charAx - 'A';
        b.first = charBx - 'A';

        a.second--;
        b.second--;

        if(((a.first % 2) == (a.second % 2)) != ((b.first % 2) == (b.second % 2)))
        {
            cout << "Impossible" << endl;
        }
        else
        {
            if(a.first == b.first && a.second == b.second)
            {
                cout << 0 << " " << (char)('A' + a.first) << " " << (a.second + 1) << endl;
            }
            else
            {
                ll c1 = a.second - a.first;
                ll c2 = a.second + a.first;
                ll c3 = b.second - b.first;
                ll c4 = b.second + b.first;

                if(c1 == c3 || c2 == c4)
                {
                    cout << 1 << " " << (char)('A' + a.first) << " " << (a.second + 1) << " ";
                    cout << (char)('A' + b.first) << " " << (b.second + 1) << endl;
                }
                else
                {
                    pll p1, p2;

                    p1.first = (c4 - c1) / 2;
                    p1.second = p1.first + c1;

                    p2.first = (c2 - c3) / 2;
                    p2.second = p2.first + c3;

                    if(p1.first < 8 && p1.first >= 0 && p1.second < 8 && p1.second >= 0)
                    {
                        cout << 2 << " " << (char)('A' + a.first) << " " << (a.second + 1) << " ";
                        cout << (char)('A' + p1.first) << " " << (p1.second + 1) << " ";
                        cout << (char)('A' + b.first) << " " << (b.second + 1) << endl;
                    }
                    else if(p2.first < 8 && p2.first >= 0 && p2.second < 8 && p2.second >= 0)
                    {
                        cout << 2 << " " << (char)('A' + a.first) << " " << (a.second + 1) << " ";
                        cout << (char)('A' + p2.first) << " " << (p2.second + 1) << " ";
                        cout << (char)('A' + b.first) << " " << (b.second + 1) << endl;
                    }
                    else
                    {
                        cout << "Impossible" << endl;
                    }
                }
            }
        }


    }
    return 0;
}
