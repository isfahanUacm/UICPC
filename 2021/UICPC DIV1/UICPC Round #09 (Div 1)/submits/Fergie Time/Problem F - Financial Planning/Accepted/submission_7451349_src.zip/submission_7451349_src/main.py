n, m = map(int, input().split())
p = [0 for _ in range(n)]
c = [0 for _ in range(n)]

for i in range(n):
    p[i], c[i] = map(int, input().split())

payoff = [((c[i] // p[i]), i) for i in range(n)]

payoff.sort()

sood = 0
borrow = 0
day = payoff[0][0]
currentIndex = 0
while True:
    if sood * day - borrow >= m:
        break
    while currentIndex < len(payoff) and payoff[currentIndex][0] == day:
        borrow += c[payoff[currentIndex][1]]
        sood += p[payoff[currentIndex][1]]
        currentIndex += 1

    day += 1
print(day)
