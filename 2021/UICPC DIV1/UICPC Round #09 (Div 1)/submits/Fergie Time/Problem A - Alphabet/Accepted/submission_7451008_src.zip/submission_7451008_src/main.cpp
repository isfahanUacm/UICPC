#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

void watchstack(stack<ll> s)
{
    while (s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main()
{
    string s;
    cin >> s;
    ll** dp = new ll*[27];
    for(ll i = 0; i < 27; i++)
    {
        dp[i] = new ll[s.length() + 1];
    }
    for(ll i = 0; i < 27; i++)
    {
        for(ll j = 0; j < s.length() + 1; j++)
        {
            dp[i][j] = 0;
        }
    }

    for(ll i = 1; i < 27; i++)
    {
        for(ll j = 1; j < s.length() + 1; j++)
        {
            if((char)(i - 1 + 97) == s[j - 1])
            {
                dp[i][j] = 1 + dp[i - 1][j - 1];
            }
            else
            {
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }
    cout << 26 - dp[26][s.length()] << endl;
    return 0;
}
