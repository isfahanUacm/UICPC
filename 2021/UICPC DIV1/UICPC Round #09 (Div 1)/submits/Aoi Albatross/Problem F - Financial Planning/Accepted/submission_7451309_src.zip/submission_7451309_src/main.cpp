#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;
typedef long long ll;

struct p {
    ll d = 0;
    ll s = 0;
    ll e = 0;
};

bool cmp (p a, p b) {
    return a.d < b.d;
}

int main() {
    vector<p> vc;
    ll n, m;
    cin >> n >> m;
    for (ll i = 0; i < n; ++i) {
        ll a, b;
        cin >> a >> b;
        p temp;
        ll d = ceil(double(b) / a);
        temp.d = d;
        temp.s = a;
        temp.e = (a*d) - b;
        vc.push_back(temp);
    }
    sort(vc.begin(), vc.end(), cmp);
    ll z = 0;
    ll ans = 0;
    ll lastday = 0;
    for (ll i = 0; i < vc.size(); i++) {
        p t = vc[i];

        ans += (t.d - lastday) * z;
        ans += t.e;
        z += t.s;
        if (ans - m >= 0) {
            cout << t.d << endl;
            return 0;
        }

        if (i != vc.size() - 1) {
            ll dist = vc[i + 1].d - t.d - 1;
            if (dist * z + ans - m >= 0) {
                cout << (ll)(t.d + ceil((-ans + m) / double(z))) << endl;
                return 0;
            }
        }

        lastday = t.d;
    }

    cout << (ll)(vc[vc.size() - 1].d + ceil((-ans + m) / double(z))) << endl;
}