#include <iostream>
#include <stack>
using namespace std;



int main()
{
    stack<char> st;
    char input;
    string s;
    cin >> s;
    for(int i=0;i<s.size();i++) {
        input = s[i];
        if(input != '<')
            st.push(input);
        else if(st.size())
            st.pop();
    }
    stack<char> s2;
    while(st.size()) {
        s2.push(st.top());
        st.pop();
    }
    while(s2.size()) {
        cout << s2.top();
        s2.pop();
    }




}
