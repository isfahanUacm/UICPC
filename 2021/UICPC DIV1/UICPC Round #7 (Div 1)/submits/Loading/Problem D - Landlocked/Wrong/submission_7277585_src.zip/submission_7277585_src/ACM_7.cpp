#include<bits/stdc++.h>
#include<map>
using namespace std;
typedef long long lli;
map<char, int> Map;
vector<char> charcter;
int main()
{
    int n, m;
    cin >> n >> m;
        
    while (n--)
    {
        string s;
        cin >> s;
        vector<int> w;
        for (int i = 0; i < m; i++)
        {
            if (s[i] == 'W')
                w.push_back(i);
            else
            {
                auto it = Map.find(s[i]);
                if (it == Map.end())
                {
                    Map[s[i]] = INT_MAX;
                    charcter.push_back(s[i]);
                }
            }
        }
        for (int i = 0; i < m; i++)
        {
            int nearest = Map[s[i]];
            if (s[i] != 'W' && Map[s[i]] == 0)
                continue;
            else if (s[i] != 'W')
            {
                int d = 0;
                bool flag = 0;
                for (auto it : w)
                {
                    d = abs(i - it);
                    if (d < nearest)
                    {
                        nearest = d;
                        Map[s[i]] = nearest;
                        flag = 1;
                    }
                }  
                if (flag)
                    Map[s[i]]--;
            }
        }
    }
    int size = charcter.size();
    sort(charcter.begin(), charcter.end());

    for (int i = 0; i < size; i++)
    {
        cout << charcter[i] << " " << Map[charcter[i]] << endl;
    }
}

