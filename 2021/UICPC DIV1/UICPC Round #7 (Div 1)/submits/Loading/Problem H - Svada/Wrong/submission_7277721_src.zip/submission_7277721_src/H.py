tot = int(input())
n = int(input())
a =[]
for i in range(n):
    o,p = map(int, input().split())
    a.append([o,p])
m = int(input())
b =[]
for i in range(m):
    o,p = map(int, input().split())
    b.append([o,p])

l = 1
r = 1000000000
while(r>=l):
    x = l + (r - l) // 2
    #print("T",x)
    aa = 0
    for i in range(n):
        tr = (x - a[i][0])-1 
        if tr < 0:
            break
        elif tr == 0:
            aa +=1
            break
        else:
            aa +=1
            aa += tr // a[i][1]
    
    bb = 0
    for j in range(m):
        tr = ((tot-x-1) - b[i][0])
        if tr < 0:
            break
        elif tr == 0:
            bb +=1
            break
        else:
            bb +=1
            bb += tr // b[i][1]

    te = aa - bb
    if te == 0:
        print(x)
        exit()
    elif te > 0:
        r = x - 1
    else:
        l =  x + 1