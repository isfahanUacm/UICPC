def happy(flag,dp, t, temp):
    #print(t)
    #print(temp)
    #print(flag)
    if (dp[t]==-1):
        #print("WTF1")
        for tt in temp:
            dp[tt] = -1
        temp.clear()
        #flag = -1
        return False

    elif (dp[t] == 1):
        #print("WTF")
        for tt in temp:
            dp[tt] = 1
        temp.clear()
        #flag = 1
        return True
    
    elif t in temp:
        #print("WTF3")
        for tt in temp:
            dp[tt] = -1
        temp.clear()
        #flag = -1
        return False

    else:
        temp.append(t)
        s = 0
        ch = list(str(t))
        for c in ch:
            r = int(c) ** 2
            s+=r
        return happy(flag,dp,s,temp)

def isPrime(n) :
    if (n <= 1) :
        return False
    if (n <= 3) :
        return True
    if (n % 2 == 0 or n % 3 == 0) :
        return False
    i = 5
    while(i * i <= n) :
        if (n % i == 0 or n % (i + 2) == 0) :
            return False
        i = i + 6
    return True

n = int(input())
dp = [0]*10004
dp[0], dp[10], dp[100], dp[1000], dp[10000] = 1,1,1,1,1
temp = []
for i in range(n):
    #print(i)
    ii, t = map(int,input().split())
    flag= 0
    if isPrime(t):
        re = happy(flag,dp,t,temp)
        #print(re)
        #print(flag)
        if re:
            print(ii,t,"YES")
        else:
            print(ii,t,"NO")
    else:
        print(ii,t,"NO")

    


