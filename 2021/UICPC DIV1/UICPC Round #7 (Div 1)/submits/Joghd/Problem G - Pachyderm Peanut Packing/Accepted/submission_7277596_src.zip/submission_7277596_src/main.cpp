#include <iostream>
#include <string>
using namespace std;
string ans0[15000];
string ans1[15000];
int con=0;
struct box {
    float x1;
    float y1;
    float x2;
    float y2;
    string type;
};
int isinbox(float x,float y,box b){
    if(x>=b.x1 && x<=b.x2 && y>=b.y1 && y<=b.y2)
        return 1;
    return 0;
}

void que(int n) {
    int m;
    box b[n];
    for(int i=0;i<n;i++)
        cin >> b[i].x1 >> b[i].y1 >> b[i].x2 >> b[i].y2 >> b[i].type;
    cin >> m;
    float x,y;
    string t;
    for(int j=0;j<m;j++) {
        cin >> x >> y >> t;
        ans0[con] = t;
        int i;
        for(i=0;i<n;i++) {
            if(isinbox(x,y,b[i]))
                break;
        }
        if(i==n)
            ans1[con] = "floor";
        else if(t==b[i].type)
            ans1[con] = "correct";
        else
            ans1[con] = b[i].type;
        con++;

    }
    ans0[con] = "";
    ans1[con] = "";
    con++;

}
int main() {
    int  n;
    cin >> n;
    while (n>0) {
        que(n);
        cin >> n;
    }
    for(int i=0;i<con;i++)
        cout << ans0[i] << " " << ans1[i] << endl;
}
