#include <iostream>
#include <math.h>
using namespace std;
int isprime(int n) {
    if(n==1)
        return 0;
    if(n!=2 && n%2==0)
        return 0;
    for(int i=3;i<=sqrt(n);i+=2) {
        if(n%i==0)
            return 0;
    }
    return 1;
}
int nexthap(int n) {
    int d = 0;
    while(n>0) {
        d += pow((n%10),2);
        n /= 10;
    }
    return d;
}
int hap[100000] = {0};
int ishap(int n){
    int s=0;
    int num[10000] = {0};
    for(int i=0;i<10000;i++) {
        num [i]=n;
        if(hap[n]==1) {
            s=1;
            break;
        }
        n = nexthap(n);
    }
    if(s==1) {
        for(int i=0;i<10000 && num[i]>0;i++)
            if(num[i]<100000)
                hap[num[i]]=1;
    }
    return s;
}
int main() {
   hap[1]=1;
   int n;
   cin >> n;
   int a[2][n];
   for(int i=0;i<n;i++)
       cin >> a[0][i] >> a[1][i];
   for(int i=0;i<n;i++)
   {cout << a[0][i] << " " << a[1][i] << " ";
       if(isprime(a[1][i])==1 && ishap(a[1][i])==1)
           cout << "YES";
       else cout << "NO";
       cout << endl;
   }


}
