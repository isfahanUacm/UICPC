#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll const mx = 1e5+10;
bool num[mx];
ll ss(ll m)
{
    int sum = 0;
    while(m)
    {
        ll n = m % 10;
        sum += n * n;
        m /= 10;
    }
    return sum;
}
void solve(){
	ll k,m;
	cin >> k >> m;
	ll st=m;
	if(num[m]){
		cout<<k<<' '<<st<<' '<<"NO"<<endl;
		return;
	}
	for(ll i=0;i<15;i++){
		m=ss(m);
		if(m==1){
			cout<<k<<' '<<st<<' '<<"YES"<<endl;
			return;
		}
	}
	cout<<k<<' '<<st<<' '<<"NO"<<endl;
}
int main(){
	num[1]=1;
	for(ll i=2;i<mx;i++){
		if(num[i]==false){
			for(ll j=2*i;j<mx;j+=i){
				num[j]=true;
			}
		}
	}
	ll t;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}