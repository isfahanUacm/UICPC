#include <bits/stdc++.h>
using namespace std ;

void f(int n){
    int m;
    double a[n][4];
    string s[n];
    for (int i = 0 ; i < n ; ++i){
        for (int j = 0 ; j < 4 ; ++j)
            cin >> a[i][j];
        cin >> s[i];
    }
    cin >> m;
    double aa[m][2];
    string ss[m];
    for (int i = 0 ; i < m ; ++i)
        cin >> aa[i][0] >> aa[i][1] >> ss[i];

    for (int i = 0 ; i < m ; ++i){
        for (int j = 0 ; j < n ; ++j){
            if ( (aa[i][0]>=a[j][0] && aa[i][0]<=a[j][2]) && (aa[i][1]>=a[j][1] && aa[i][1]<=a[j][3])){
                if (s[j] == ss[i]){
                    cout << ss[i] << " " << "correct"<<endl;
                }else{
                    cout << ss[i] << " " << s[j]<<endl;
                }
                goto A;
            }
        }
        cout << ss[i] << " " << "floor"<<endl;
        A:;
    }
    cout << endl;
}

int main()
{
    int n;
    cin >> n;
    while (n) {
        f(n);
        cin >> n;
    }
    return 0;
}


