#include <bits/stdc++.h>
using namespace std;

int main()
{
   int t;
   cin>>t;
   while(t--)
   {
       int k,m;
       cin>>k>>m;
       string forsum = to_string(m);
       bool prime = true;

       for (int i = 2; i <= sqrt(m) && prime; i++)
       {
           if(m%i==0)
               prime = false;

       }
       while((forsum.size()>1 || stoi(forsum)>=7)&& prime)
       {
           int s=0;
           for (int i = 0; i <forsum.size();i++)
           {
               int p = stoi(forsum.substr(i,1));
               s+= p*p ;
           }
           forsum =to_string(s);
       }
       if(forsum == "1" && m!=1 && prime)
           cout<<k<<" "<<m<<" "<< "YES"<<endl;
       else {
           cout<<k<<" "<<m<<" "<< "NO"<<endl;
       }
   }

    return 0;
}
