#include <bits/stdc++.h>
using namespace std;

int main() {
    map<char, int> mp;
    string a;
    cin >> a;
    for (auto x : a) {
        mp[x]++;
    }
    if (mp.size() <= 2) {
        cout << 0 << endl;
    }
    else {
        int mx = INT_MIN;
        int mxx = INT_MIN;

        for (auto x : mp) {
            if (x.second >= mx) {
                mxx = mx;
                mx = x.second;
            }
            else if(x.second >= mxx) {
                mxx = x.second;
            }
        }

        cout << a.length() - mx - mxx << endl;
    }
}