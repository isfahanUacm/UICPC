#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
using namespace std;


int main()
{
    ll n, k;
    cin >> n >> k;
    ld lastAns = 0;
    for(ll i = 0; i < k; i++)
    {
        ll fullSum = n * (n + 1) / 2;
        ll kaf = (ll)(floor(lastAns));
        ll partSum = (kaf) * (kaf + 1) / 2;
        lastAns = (ld)(fullSum - partSum) / n + (ld)(kaf * lastAns / n);
    }
    cout << setprecision(15) << lastAns << endl;

    return 0;
}
