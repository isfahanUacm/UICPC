#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

int main()
{
    map<char, ll> m;
    string s;
    cin >> s;
    for(char c: s)
    {
        if(m.find(c) == m.end())
        {
            m[c] = 0;
        }
        m[c]++;
    }
    ll len = m.size();
    multiset<pair<ll, char>> st;
    for(auto i: m)
    {
        st.insert({i.second, i.first});
    }
    ll ans = 0;
    while(len > 2 && st.size())
    {
        ll current = (*st.begin()).first;
        st.erase(st.begin());
        ans += current;
        len -= 1;
    }
    cout << ans;
    return 0;
}