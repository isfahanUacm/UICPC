#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
   ll w,s,c,k;
   cin>>w>>s>>c>>k;
   if(k>min(s,w+c)){
       cout<<"YES"<<endl;
   }
   else if( k == min(s, w+c) && max(s, w+c) <= 2*k){
       cout<<"YES"<<endl;
   }
   else{
       cout<<"NO"<<endl;
   }

}
