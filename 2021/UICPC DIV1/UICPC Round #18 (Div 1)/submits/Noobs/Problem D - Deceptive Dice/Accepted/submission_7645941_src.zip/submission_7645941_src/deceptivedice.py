import math

n, k = map(int, input().split())
res = 0
for i in range(1, k + 1):
    
    m = math.floor(res)
    res = (m * res + (n - m) * (n + m + 1) / 2) / n
    
print(res)
