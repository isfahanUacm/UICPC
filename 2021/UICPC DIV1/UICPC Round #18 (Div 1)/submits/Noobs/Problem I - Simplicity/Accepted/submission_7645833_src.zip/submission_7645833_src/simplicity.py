string = input()

s = set()
for item in string:
    s.add(item)

d = dict()

c = 0
for item in s:
    for ch in string:
        if ch == item:
            c += 1
    d[item] = c
    c = 0

d = sorted(d.items(), key=lambda k: k[1])
# print(d)

l = len(s)
res = 0
if l <= 2:
    pass
else:
    for i in range(l - 2):
        res += d[i][1]
print(res)
