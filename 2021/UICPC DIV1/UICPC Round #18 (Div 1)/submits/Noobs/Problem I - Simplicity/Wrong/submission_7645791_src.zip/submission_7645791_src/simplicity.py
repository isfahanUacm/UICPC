string = input()

s = set()
for item in string:
    s.add(item)

l = len(s)
if l <= 2:
    print(0)
else:
    print(l - 2)
