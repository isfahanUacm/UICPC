#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;


int t, n, m, s;
lli l;
lli value[10000 + 5];
set<pair<lli, int>> SET;
vector<vector<pair<lli, int>>> adj(10000+5);
lli each[10000 + 5];

int main() {
	cin >> t;
	while (t--) {
		//global
		SET.clear();
		adj.clear();
		adj.resize(10000 + 5);

		cin >> n >> m >> l >> s;
		fill_n(value, 10000 + 5, LONG_MAX);
		fill_n(each, 10000 + 5, 0);
		for (int i = 0; i < s; i++) {
			int e;
			cin >> e;
			value[e] = 0;
		}
		for (int i = 0; i < m; i++) {
			int x, y;
			lli w;
			cin >> x >> y >> w;
			adj[x].push_back({ w, y });
			adj[y].push_back({ w, x });
		}
		for (int i = 1; i <= n; i++) {
			SET.insert({ value[i], i });
		}

		int count = 0;
		lli sum = 0;
		while (!SET.empty()) {
			//if (count == n) break;
			int cur = SET.begin()->second;
			lli w = SET.begin()->first;
			SET.erase(SET.begin());

			for (auto p : adj[cur]) {
				lli v = value[p.second];
				if (p.first + w < v) {
					SET.erase({ v, p.second });
					value[p.second] = p.first + w;
					SET.insert({ value[p.second], p.second });
					each[p.second] = p.first;
				}
				else if (p.first + w == v) {
					each[p.second] = min(each[p.second], p.first);
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			sum += each[i];
			if (each[i] != 0)
				sum += l;
			//cout << each[i] << endl;
		}
		cout << sum << endl;
	}
}