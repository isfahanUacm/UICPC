W, S, C, K = map(int, input().split())
flag = False

#s?
#w + c?
if S<=W+C:
    if S<K:
        flag = True
elif S>W+C:
    if W+C<K:
        flag = True

if S<=W+C:
    if S==K:
        if W+C<=2*K:
            flag = True
elif S>W+C:
    if W+C==K:
        if S <= 2*K:
            flag = True

'''if K == S and K == C and K == W:
    flag = True
elif S+W+C <= K:
    flag = True
elif K>=S:
    #print("YES")
    if K>=W+C:
        flag = True
    elif 2*K >= W+C:
        flag = True
else:
    if K>=W+C:
        flag = True'''

if flag:
    print("YES")
else:
    print("NO")
