#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;

int id[2000 + 5];
int edgesize;
int t, m, c;
vector<pair<int, pair<int, int>>> edge;

int get_id(int n)
{
    if (id[n] == n)
        return n;
    return id[n] = get_id(id[n]);
}

void make_set(int u, int v)
{
    if (id[u] != id[v]) {
        if (id[u] == u) {
            id[id[v]] = id[u];
            id[v] = id[u];
        }
        else {
            id[id[u]] = id[v];
            id[u] = id[v];
        }
    }
}

int kruskal() {
    for (int i = 0; i < c; i++)
        id[i] = i;
    sort(edge.begin(), edge.end());
    int sum = 0;

    edgesize = c * (c - 1) / 2;
    for (int i = 0; i < edgesize; i++){
        pair<int, pair<int, int>> p = edge[i];
        if (get_id(p.second.first) != get_id(p.second.second))
        {
            sum += p.first;
            make_set(p.second.first, p.second.second);
        }
    }
    return sum;
}


int main() {
    int x, y, w;
    cin >> t;
    while (t--) {
        //init all local values
        edge.clear();
        cin >> m >> c;
        for (int i = 0; i < (c * (c - 1)) / 2; ++i) {
            cin >> x >> y >> w;
            edge.push_back({ w, {x, y} });
            //edge.push_back({ w, {y, x} });
        }

        int sum = kruskal();
        //cout << sum << endl;
        if (sum + c <= m){
            cout<<"yes"<<endl;
        }
        else{
            cout<<"no"<<endl;
        }
    }

}