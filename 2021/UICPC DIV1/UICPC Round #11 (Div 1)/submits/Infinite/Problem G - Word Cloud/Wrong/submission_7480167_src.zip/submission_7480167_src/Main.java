import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int w = s.nextInt();
		int n  = 0 ;
		while (w != 0){
			 n = s.nextInt();
			int t = 0 , max = Integer.MIN_VALUE;
			String word[] = new String[n];
			int[] cnt = new int[n];
			for(int i = 0 ; i < n ; i ++){
				String tmp = s.next();
				int tmp1 = s.nextInt();
				if (tmp1 < 5) {
					continue;
				}
				else{
					word[i] = tmp;
					cnt[i] = tmp1;
					t ++ ;
					if (cnt[i] > max) max = cnt[i];
				}
			}
			double h[] = new double[t];
			double wid [] = new double [t];
			//System.out.println(max);
			for (int i = 0 ; i < t ; i ++){
				double so = cnt[i]- 4 ;
				double ma = max - 4;
				double tmph = 40 * (so/ma);
				h[i] = 8 + Math.ceil(tmph);
				//System.out.println(h[i]);
				wid[i] = Math.ceil(9*word[i].length()*h[i]/16);
				//System.out.println(wid[i]);
			}
			int sumer = 0 , max1 = Integer.MIN_VALUE , summax = 0 , f = 0;
			for (int i = 0 ; i < t - 1 ; i ++){
				if (sumer == 0){
					sumer = (int) wid[i];
					max1 = (int) h[i];

				}
				{
					if (sumer + 10 + (int )wid[i+1] <= w){
						sumer += 10 + wid[i+1];
						max1 = (int) Math.max(max1 , h[i+1]);

					}
					else{

						summax += max1;
						f = 1;
						sumer = 0 ;
						max1 = Integer.MIN_VALUE;
						//System.out.println("summax =   " + summax);
					}
				}
			}
			if (sumer == 0 ) summax += h[t-1];
			else{
				summax += max1;
			}

			System.out.println( summax);
			w = s.nextInt();


		}
		n = s.nextInt();
	}
}
