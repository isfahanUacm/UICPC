import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int kitten = s.nextInt();
        s.nextLine();
        HashMap<Integer , Integer> map = new HashMap<>();
        int a=0;
        while (a != -1){
            String line = s.nextLine();
            String[] array = line.split(" ");
            a = Integer.parseInt(array[0]);
            for (int i = 1; i < array.length; i++) {
                map.put(Integer.parseInt(array[i]) , a);
            }
        }
        while (map.containsKey(kitten)){
            System.out.print(kitten + " ");
            kitten = map.get(kitten);
        }
        System.out.print(kitten);
    }
}

