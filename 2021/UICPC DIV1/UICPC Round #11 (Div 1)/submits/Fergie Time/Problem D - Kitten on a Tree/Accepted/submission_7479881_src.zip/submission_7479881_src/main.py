k = int(input())
graph = [[] for _ in range(101)]
line = list(map(int, input().split()))
while line[0] != -1:
    a = line[0]
    b = line[1:]
    for i in b:
        graph[i].append(a)
    line = list(map(int, input().split()))

index = k
while len(graph[index]) != 0:
    print(index, end=" ")
    index = graph[index][0]
print(index, end="")
