#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

vector<ll> getPrimes(ll maxnum)
{
    ll maxPrime = maxnum;
    vector<bool> isPrime(maxPrime + 1, true);
    isPrime[1] = false;
    for (ll i = 2; i <= maxPrime; i++)
    {
        if (isPrime[i])
        {
            for (ll num = i * i; num <= maxPrime; num += i)
            {
                isPrime[num] = false;
            }
        }
    }
    vector<ll> primes;
    for (ll i = 1; i < isPrime.size(); i++)
    {
        if (isPrime[i])
        {
            primes.push_back(i);
        }
    }
    return primes;
}
ll Pval(ll c, ll cmax)
{
    return 8 + ceil(((ld)40 * (ld)(c - 4)) / (ld)(cmax - 4));
}
ll getWidth(ll t, ll P)
{
    return ceil((ld)9 * t * P / 16);
}
int main()
{
    ll w, n;
    cin >> w >> n;
    ll test_case_index = 1;
    while(!(w == 0 && n == 0))
    {
        vector<pair<string, ll>> arr;
        ll cmax = 0;
        for(ll i = 0; i < n; i++)
        {
            string s;
            ll x;
            cin >> s >> x;
            if(x >= 5)
            {
                arr.push_back({s, x});
            }
            cmax = max(cmax, arr[i].second);
        }
        vector<ll> width(arr.size(), 0);
        sort(arr.begin(), arr.end());
        for(ll i = 0; i < arr.size(); i++)
        {
            width[i] = getWidth((ll)arr[i].first.length(), Pval(arr[i].second, cmax));
        }
        ll ans = 0;
        ll currentWidth = 0;
        ll temp_max = Pval(arr[0].second, cmax);
        for(ll i = 0; i < arr.size(); i++)
        {
            if(currentWidth + width[i] > w)
            {
                ans += temp_max;
                temp_max = Pval(arr[i].second, cmax);
                currentWidth = 0;
            }
            temp_max = max(temp_max, Pval(arr[i].second, cmax));
            currentWidth = currentWidth + width[i] + 10;
        }
        if(currentWidth)
        {
            ans += temp_max;
        }
        cout << "CLOUD " << test_case_index << ": " << ans << endl;
        cin >> w >> n;
        test_case_index++;
    }
    return 0;
}
