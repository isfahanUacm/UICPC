#include<bits/stdc++.h>
using namespace std;
int k,n,dp[10+10][100+10];

double solve(int j,int i){
    if (i==n-1){
        if (j==0 || j==k) return 2;
        else return 3;
    }
    if (dp[j][i]!=-1) return dp[j][i];

    double tmp=0;
    if (j==0)
        tmp=solve(0,i+1)+solve(1,i+1);
    else if (j==k)
        tmp=solve(k,i+1)+solve(k-1,i+1);
    else
        tmp=solve(j-1,i+1)+solve(j,i+1)+solve(j+1,i+1);

    return dp[j][i]=tmp;
}

double check(){
    double ans=k+1;
    for (int i=0;i<n-1;i++)
        ans*=(k+1);
    return ans;
}

int main()
{
    while (cin>>k>>n){
        double ans=0;
        if (n==1) ans=k+1;
        else {
            memset(dp,-1,sizeof(dp));
            for (int i=0;i<=k;i++)
                ans+=solve(i,1);
        }
        double Ans=(ans/check())*100;
        printf("%.9lf\n",Ans);
    }



    return 0;
}
