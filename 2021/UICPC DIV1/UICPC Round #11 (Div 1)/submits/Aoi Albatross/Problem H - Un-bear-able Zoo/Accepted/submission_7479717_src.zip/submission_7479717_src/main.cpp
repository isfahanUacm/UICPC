#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    int tc = 1;
    int n;
    cin >> n;
    string t;
    while (n != 0) {
        getline(cin, t);
        multiset<string> mp;
        set<string> st;
        for (int i = 0; i < n; ++i) {
            string a;
            getline(cin, a);
            string b;
            if (a.find_last_of(' ') < a.length()) {
                b = a.substr(a.find_last_of(' ') + 1);
            }
            else {
                b = a;
            }
            for (char & k : b) {
                k = tolower(k);
            }
            mp.insert(b);
            st.insert(b);
        }
        cin >> n;
        cout << "List " << tc++ << ':' << endl;
        for (auto t : st) {
            cout << t << " | " << mp.count(t) << endl;
        }
    }
}