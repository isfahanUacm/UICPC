#include <bits/stdc++.h>
using namespace std;

int main(){
    int tc;
    cin >> tc;
    while (tc--) {
        int p, n, mi = INT_MAX;
        cin >> p >> n;
        int arr[n];
        for (int i = 0; i < n; ++i) {
            cin >> arr[i];
        }
        stack<int> stc;
        int ans = 0;
        for (int i = 0; i < n; ++i) {
            if (stc.empty()) {
                stc.push(arr[i]);
            }
            else {
                while (!stc.empty() && stc.top() > arr[i]) {
                    ans++;
                    mi = min(mi, stc.top());
                    stc.pop();
                }
                stc.push(arr[i]);
            }
        }
        while (!stc.empty() && stc.top() > mi) {
            stc.pop();
            ans++;
        }
        cout << p << ' ' << ans << endl;
    }
}