class Node:
    def __init__(self, key) -> None:
        self.key = key
        self.child = []

    def set_child(self, arr):
        self.child = arr

    def get_child(self):
        return self.child


def newNode(key):
    temp = Node(key)
    return temp

location = int(input())

brr = []

while 1:
    arr = list(map(int, input().strip().split(" ")))
    if -1 in arr:
        break

    par = newNode(arr[0])
    par.set_child(arr[1::])
    brr.append(par)



    # brr.append(arr[])


# for i in brr:
#     print(i.key)
#     print(i.get_child())
i = 0
crr = []
while i < (len(brr)):
    if location in brr[i].get_child():
        crr.append(location)
        location = brr[i].key
        i = -1
    i+=1
crr.append(location)
for j in crr:
    print(j, end=' ')


# 3 4 5 6 1 7 8 2