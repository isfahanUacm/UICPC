import java.util.*;

public class Main {
    private static HashMap<String,Integer> que(int n) {
        Scanner scanner = new Scanner(System.in);
        HashMap<String, Integer> animals = new HashMap<>();
        for(int i=0;i<n;i++) {
            String string = scanner.nextLine();
            String[] strings = string.split(" ");
            string = strings[strings.length-1].toLowerCase();
            if(animals.get(string) == null) animals.put(string,1);
            else animals.put(string,animals.get(string)+1);
        }
        return animals;
    }
    public static void main(String[] args) {
        int n;
        Scanner scanner = new Scanner(System.in);
        List<HashMap<String,Integer>> ans = new ArrayList<>();
        while (true) {
            n = Integer.parseInt(scanner.nextLine());
            if( n == 0 ) break;
            ans.add(que(n));
        }
        int i=1;
        for(HashMap<String,Integer> animals : ans) {
            System.out.println("List "+i+":");
            TreeMap<String,Integer> s= new TreeMap<>(animals);
            for(Map.Entry<String,Integer> x : s.entrySet()) {
                System.out.println(x.getKey()+" | "+x.getValue());
            }
        }
    }
}
