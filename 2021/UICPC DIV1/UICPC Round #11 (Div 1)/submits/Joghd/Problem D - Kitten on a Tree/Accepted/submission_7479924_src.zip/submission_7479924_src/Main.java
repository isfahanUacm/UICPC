import java.util.*;

public class Main {
    static List<String> input = new ArrayList<>();
    static int inputi = 0;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String string;
        do{
            string = scanner.nextLine();
            input.add(string);
        } while(!string.equals("-1"));
        Map<String,String> map = new HashMap<>();
        String target = input.get(inputi); inputi++;
        while (!input.get(inputi).equals("-1")) {
            String[] strings = input.get(inputi).split(" "); inputi++;
            for(int i=1;i<strings.length;i++) {
                map.put(strings[i],strings[0]);
            }
        }
        do {
            System.out.print(target+" ");
            if(map.get(target) == null) break;
            target = map.get(target);
        } while (true);
    }
}
