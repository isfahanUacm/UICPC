#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

int que(int *x,int size) {
    int arr[size];
    for(int i=0;i<size;i++) arr[i] = x[i];
    sort(x,x+size);
    int ans =0;
    for(int i=0;i<size;i++) {
        if(arr[i] == x[ans] )
            ans++;
    }
    return size-ans;

}

int main() {
    int jj; cin >> jj;
    int n,m;
    queue<int> x;
    for(int j=0;j<jj;j++) {
        cin >> n >> m;
        int arr[m];
        for(int i=0;i<m;i++) cin >> arr[i];
        x.push(que(arr,m));
    }
    int i=1;
    while (x.size()) {
        cout << i << " " << x.front() << endl;
        x.pop(); i++;
    }
}
