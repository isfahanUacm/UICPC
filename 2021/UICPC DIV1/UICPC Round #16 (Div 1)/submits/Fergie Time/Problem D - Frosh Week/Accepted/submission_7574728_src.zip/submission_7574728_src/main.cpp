#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
#include <iostream>
#include<vector>
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n,m,i;
    cin>>n>>m;
    vector<int> t(n);
    vector<int> l(m);
    for(i=0;i<n;i++)
    {
        cin>>t[i];
    }
    for(i=0;i<m;i++)
    {
        cin>>l[i];
    }
    sort(t.begin(), t.end());
    sort(l.begin(), l.end());
    int result=0,coutl=0,countt=0;
    while(coutl<m&&countt<n)
    {
        if(l[coutl]>=t[countt])
        {
            result+=1;
            countt+=1;
            coutl+=1;
        }
        else
        {
            coutl+=1;
        }
    }



    cout<<result<<endl;

}
