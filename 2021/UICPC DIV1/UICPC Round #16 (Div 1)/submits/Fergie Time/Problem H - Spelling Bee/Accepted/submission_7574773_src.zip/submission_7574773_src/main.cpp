#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

int main()
{
    string w;
    cin >> w;
    ll n;
    cin >> n;
    while(n--)
    {
        string s;
        cin >> s;
        if(s.find(w[0]) == string::npos)
        {
            continue;
        }
        else
        {
            if(s.size() < 4)
            {
                continue;
            }
            else
            {
                bool tempb = true;
                for(ll i = 0; i < s.size(); i++)
                {
                    if(w.find(s[i]) == string::npos)
                    {
                        tempb = false;
                    }
                }
                if(!tempb)
                {
                    continue;
                }
            }
        }
        cout << s << endl;

    }
    return 0;
}