#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;
vector<vector<ll>> graph;
vector<ll> parent;
vector<ll> low;
vector<ll> disc;
vector<bool> visited;
ll gindex = 0;
set<pll> bridges;

void findBridges(ll index)
{
    visited[index] = true;
    disc[index] = gindex;
    low[index] = gindex;
    gindex++;
    for(ll i: graph[index])
    {
        if(!visited[i])
        {
            parent[i] = index;
            findBridges(i);
            low[index] = min(low[i], low[index]);
            if(disc[index] < low[i])
            {
                bridges.insert({index, i});
                bridges.insert({i, index});
            }
        }
        else if(i != parent[index])
        {
            low[index] = min(low[index], disc[i]);
        }
    }
}
void dfs(ll index)
{
    visited[index] = true;
    for(ll i: graph[index])
    {
        if(!visited[i] && bridges.find({index, i}) == bridges.end())
        {
            dfs(i);
        }
    }
}

int main()
{
    ll n, m;
    cin >> n >> m;
    while(!(n == 0 && m == 0))
    {
        vector<ll> sample;
        graph = vector<vector<ll>> (n, sample);
        for(ll i = 0; i < m; i++)
        {
            ll x, y;
            cin >> x >> y;
            graph[x].push_back(y);
            graph[y].push_back(x);
        }
        visited = vector<bool>(n, false);
        parent = vector<ll>(n, -1);
        low = vector<ll>(n, -1);
        disc = vector<ll>(n, -1);
        bridges = set<pll>();
        gindex = 0;
        findBridges(0);
        visited = vector<bool>(n, false);
        dfs(0);
        bool visitedAll = true;
        for(ll i = 0; i < n; i++)
        {
            if(!visited[i])
            {
                visitedAll = false;
            }
        }
        cout << ((bridges.size() != 0 || !visitedAll)? "Yes" : "No") << endl;
        cin >> n >> m;
    }

    return 0;
}