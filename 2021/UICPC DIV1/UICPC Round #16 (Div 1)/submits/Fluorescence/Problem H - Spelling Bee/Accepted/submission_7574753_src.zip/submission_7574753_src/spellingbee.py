base = input()
n = int(input())
l = []
res = []
for i in range(n):
    s = input()
    ls = list(s)
    flag = True
    if base[0] in ls and len(ls) >= 4:
        for e in ls:
            if e not in base:
                flag = False
                break
        if flag:
            res.append(s)

for r in res:
    print(r)

