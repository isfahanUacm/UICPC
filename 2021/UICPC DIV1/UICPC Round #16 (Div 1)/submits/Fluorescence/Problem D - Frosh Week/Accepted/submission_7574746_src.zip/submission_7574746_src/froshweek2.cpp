#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
typedef unsigned long long int ulli;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
int t[200000 + 5], l[200000 + 5];
int main() {
	int n, m;
	cin >> n >> m;

	for (int i = 0; i < n; i++) {
		cin >> t[i];
	}
	for (int i = 0; i < m; i++) {
		cin >> l[i];
	}
	sort(t, t + n);
	sort(l, l + m);

	int count = 0;
	int j = 0;
	for (int i = 0; i < m; i++) {
		if (j == n)
			break;
		if (t[j] <= l[i]) {
			count++;
			j++;
		}
	}
	cout << count;
	return 0;
}