#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
typedef unsigned long long int ulli;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);

int n;
/*
Blue 0
Orange 1
Pink 2
Green 3
Red 4
Yellow 5
*/
lli last[6 + 5];
lli color[200000 + 5][6 + 5];
lli dp[200000 + 5];
lli countcolor[6 + 5];
int which_color(string s) {
	if (s == "Blue")
		return 0;
	else if (s == "Orange")
		return 1;
	else if (s == "Pink")
		return 2;
	else if (s == "Green")
		return 3;
	else if (s == "Red")
		return 4;
	else return 5;
}
int main() {
	cin >> n;
	string s;
	fill_n(last, 11, -1);
	fill_n(countcolor, 11, 0);
	for (int i = 0; i < 200000 + 5; i++)
		for (int j = 0; j < 11; j++)
			color[i][j] = 0;
	dp[0] = 0;
	for (int i = 0; i < n; i++) {
		cin >> s;
		int cur = which_color(s);

		countcolor[cur]++;
		
		if (i > 0) {
			for (int j = 0; j < 6; j++) {color[i][j] = color[i - 1][j];}
		}

		lli MN = LONG_MAX;
		for (int j = 0; j < 6; j++) {
			lli l = last[j];
			lli many;
			if (j == cur && l == -1)
				many = 1;
			else if (l == -1)
				many = INT_MAX;
			else
				many = dp[l] + countcolor[cur] - color[l][cur];
			MN = min(MN, many);
		}
		dp[i] = MN;
		last[cur] = i;
		color[i][cur]++;

	}

	cout << dp[n - 1];
}