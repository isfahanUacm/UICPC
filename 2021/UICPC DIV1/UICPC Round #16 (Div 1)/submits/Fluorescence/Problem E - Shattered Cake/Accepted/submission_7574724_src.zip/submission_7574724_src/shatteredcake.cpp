#include<bits/stdc++.h>
using namespace std;


int main()
{
    int w, n, a, b, s, sum = 0;
    cin>>w;
    cin>>n;
    for (int i = 0; i < n; ++i) {
        cin>>a>>b;
        s = a*b;
        sum += s;
    }

    cout<<sum/w<<endl;
}

