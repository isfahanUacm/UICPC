
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author golnoosh
 */
public class Frosh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int m = input.nextInt();
        Integer time[] = new Integer[n];
        Integer len[] = new Integer[m];
        for(int i=0; i<n; i++)
            time[i] = input.nextInt();
        for(int i=0; i<m; i++)
            len[i] = input.nextInt();
        
        Arrays.sort(time);
        Arrays.sort(len);
        int t=0;
        int l=0;
        
        while(t < n && l < m) {
            if(len[t] >= time[l]) {
                
                l++;
            }
            t++;
        }
        
        System.out.println(l);
        
    }
    
}
