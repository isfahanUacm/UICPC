#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 100200;
stack<ll> stc[MAX];

int main() {
    ll c, n, a;
    cin >> c >> n >> a;
    ll arr[a + 10];
    for (ll i = 0; i < a; ++i) {
        cin >> arr[i];
    }

    for (ll i = a - 1; i >= 0; --i) {
        stc[arr[i]].push(i);
    }

    set<ll> reg;
    set<pair<ll, ll>> stt;
    set<pair<ll, ll>, greater<>> st;
    ll ans = 0;
    for (ll i = 0; i < a; ++i) {
        while (!stt.empty() && stt.begin()->first <= i) {
            ll x = stt.begin()->second;
            st.erase({stt.begin()->first, stt.begin()->second});
            stt.erase(stt.begin());
            if (!stc[x].empty())
                stc[x].pop();
            if (stc[x].empty()) {
                stc[x].push(INT_MAX);
                st.emplace(INT_MAX, x);
                stt.emplace(INT_MAX, x);
            }
            else {
                st.emplace(stc[x].top(), x);
                stt.emplace(stc[x].top(), x);
            }
        }

        if (reg.count(arr[i]) > 0) {
            continue;
        }

        if (reg.size() >= c) {
            ll x = st.begin()->second;
            stt.erase({st.begin()->first, st.begin()->second});
            st.erase(st.begin());
            reg.erase(x);
        }
        reg.insert(arr[i]);
        st.emplace(stc[arr[i]].top(), arr[i]);
        stt.emplace(stc[arr[i]].top(), arr[i]);
        ans++;
    }
    cout << ans << endl;
}