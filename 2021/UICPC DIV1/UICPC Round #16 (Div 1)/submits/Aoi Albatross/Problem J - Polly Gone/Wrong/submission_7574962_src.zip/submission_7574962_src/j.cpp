#include <bits/stdc++.h>
using namespace std ;

long long n,p,dp[1000+10][10000+10];
pair<long long,long long> num[1000] ;

long long solve(long long i , long long pro){
    if (pro >= p) return 0 ;
    if (i>=n) return 100000000000 ;
    if (dp[i][pro] != -1)
        return dp[i][pro] ;

    long long tmp1 = num[i].first+solve (i+1 , pro+num[i].second) ;
    long long tmp2 = solve(i+1, pro) ;

    return dp[i][pro] = min(tmp1,tmp2) ;
}

int main(){
    double pp ;
    memset(dp,-1,sizeof(dp)) ;
    cin >> n >> pp ;
    p=pp*10000;
    for (long long i=0 ; i<n ; i++){
        cin >> num[i].first >> pp ;
        num[i].second = pp * 10000 ;
    }

    cout << solve(0 , 0) << endl;

    return 0;
}