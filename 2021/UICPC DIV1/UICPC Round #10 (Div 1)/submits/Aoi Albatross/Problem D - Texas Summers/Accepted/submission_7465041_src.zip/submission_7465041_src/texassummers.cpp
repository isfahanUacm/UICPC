// 					                                        ,   ,                                
// 					                                        $,  $,     ,                         
// 					                                        "ss.$ss. .s'                         
// 					                                ,     .ss$$$$$$$$$$s,                        
// 					                                $. s$$$$$$$$$$$$$$`$$Ss                      
// 					                                "$$$$$$$$$$$$$$$$$$o$$$       ,              
// 					                               s$$$$$$$$$$$$$$$$$$$$$$$$s,  ,s               
// 					                              s$$$$$$$$$"$$$$$$""""$$$$$$"$$$$$,             
// 					                              s$$$$$$$$$$s""$$$$ssssss"$$$$$$$$"             
// 					                             s$$$$$$$$$$'         `"""ss"$"$s""              
// 					                             s$$$$$$$$$$,              `"""""$  .s$$s        
// 					                             s$$$$$$$$$$$$s,...               `s$$'  `       
// 					                         `ssss$$$$$$$$$$$$$$$$$$$$####s.     .$$"$.   , s-   
// 					                           `""""$$$$$$$$$$$$$$$$$$$$#####$$$$$$"     $.$'    
// 					 Posable artist:                 "$$$$$$$$$$$$$$$$$$$$$####s""     .$$$|     
// 					   -Tua Xiong                      "$$$$$$$$$$$$$$$$$$$$$$$$##s    .$$" $    
// 					                                   $$""$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"   `    
// 					                                  $$"  "$"$$$$$$$$$$$$$$$$$$$$S""""'         
// 					                             ,   ,"     '  $$$$$$$$$$$$$$$$####s             
// 					                             $.          .s$$$$$$$$$$$$$$$$$####"            
// 					                 ,           "$s.   ..ssS$$$$$$$$$$$$$$$$$$$####"            
// 					                 $           .$$$S$$$$$$$$$$$$$$$$$$$$$$$$#####"             
// 					                 Ss     ..sS$$$$$$$$$$$$$$$$$$$$$$$$$$$######""              
// 					                  "$$sS$$$$$$$$$$$$$$$$$$$$$$$$$$$########"                  
// 					           ,      s$$$$$$$$$$$$$$$$$$$$$$$$#########""'                      
// 					           $    s$$$$$$$$$$$$$$$$$$$$$#######""'      s'         ,           
// 					           $$..$$$$$$$$$$$$$$$$$$######"'       ....,$$....    ,$            
// 					            "$$$$$$$$$$$$$$$######"' ,     .sS$$$$$$$$$$$$$$$$s$$            
// 					              $$$$$$$$$$$$#####"     $, .s$$$$$$$$$$$$$$$$$$$$$$$$s.         
// 					   )          $$$$$$$$$$$#####'      `$$$$$$$$$###########$$$$$$$$$$$.       
// 					  ((          $$$$$$$$$$$#####       $$$$$$$$###"       "####$$$$$$$$$$      
// 					  ) \         $$$$$$$$$$$$####.     $$$$$$###"             "###$$$$$$$$$   s'
// 					 (   )        $$$$$$$$$$$$$####.   $$$$$###"                ####$$$$$$$$s$$' 
// 					 )  ( (       $$"$$$$$$$$$$$#####.$$$$$###'                .###$$$$$$$$$$"   
// 					 (  )  )   _,$"   $$$$$$$$$$$$######.$$##'                .###$$$$$$$$$$     
// 					 ) (  ( \.         "$$$$$$$$$$$$$#######,,,.          ..####$$$$$$$$$$$"     
// 					(   )$ )  )        ,$$$$$$$$$$$$$$$$$$####################$$$$$$$$$$$"       
// 					(   ($$  ( \     _sS"  `"$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$S$$,       
// 					 )  )$$$s ) )  .      .   `$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"'  `$$      
// 					  (   $$$Ss/  .$,    .$,,s$$$$$$##S$$$$$$$$$$$$$$$$$$$$$$$$S""        '      
// 					    \)_$$$$$$$$$$$$$$$$$$$$$$$##"  $$        `$$.        `$$.                
// 					        `"S$$$$$$$$$$$$$$$$$#"      $  
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 7*1e6;
ll n;
ll dist[mx];
ll parent[mx];
set<pair<ll,ll>> pq;
vector<pair<ll,ll>> point;
//map<pair<ll,ll>,ll> id;
vector<pair<ll,ll>> adj[mx];
pair<ll,ll> e;
stack<ll> s;
double dc(pair<ll,ll> a,pair<ll,ll> b){
	return ((a.first-b.first)*(a.first-b.first)+(a.second-b.second)*(a.second-b.second));
}
void solve(){
	parent[0] = 0;
	dist[0]=0;
	pq.insert({0,0});
	while(!pq.empty()){
		ll u = pq.begin()->second;
		pq.erase(pq.begin());
		for(auto v:adj[u]){
			if(dist[u]+v.second<dist[v.first]){
				pq.erase({dist[v.first],v.first});
				dist[v.first] = dist[u]+v.second;
				pq.insert({dist[v.first],v.first});
				parent[v.first] = u;
			}
		}

	}
}
void print(){
	
	ll u = n+1;
	while(true){
		s.push(u);
		if(u==0)break;
		u = parent[u];
	}
	if(s.size()==2){
		cout<<"-"<<endl;
	}
	else{
		while(!s.empty()){
		if(s.top()!=0 && s.top()!= n+1){
			cout<<s.top()-1<<endl;
			}
		s.pop();
		}
	}
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cin >> n;
	point.resize(n+1);
	for(ll i=0;i<mx;i++)dist[i]=LONG_LONG_MAX;
	for(ll i=1;i<=n;i++){
		cin >> point[i].first >> point[i].second;
		//id[point[i]] = i;
	}
	cin >> point[0].first >> point[0].second >> e.first >> e.second;
	// id[point[0]]=0;
	// id[e]=n+1;
	for(ll i=0;i<point.size();i++){
		for(ll j=0;j<point.size();j++){
			if(i==j)continue;
			ll w = dc(point[i],point[j]);
			adj[i].push_back({j,w});
		}
	}
	solve();
	ll w = LONG_LONG_MAX;
	for(ll i=0;i<point.size();i++){
		 ll w2 = dc(e,point[i])+dist[i];
		 if(w2<w){
		 	w=w2;
		 	parent[n+1]=i;
		 }

	}
	print();
	return 0;
}
