#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n= 1, m= 1, result= 0, index= 0, i, j;
    while (true)
    {
        cin>> n>> m;
        if (n == 0 && m == 0)
            break;
        int * d= new int [n];
        int * h= new int [m];
        int * boo= new int [n];
        for (i=0; i<n; i++)
            boo[i]= false;
        for (i=0; i<n; i++)
            cin>> d[i];
        sort (d, d+ n);
        for (i=0; i<m; i++)
            cin>> h[i];
        sort (h, h+ m);

        if (m < n)
            cout<< "Loowater is doomed!"<< endl; 
        else
        {
            result= 0;
            index= 0;
            for (i=0; i<n; i++)
            {
                for (j=index; j<m; j++)
                    if (h[j] >= d[i])
                    {
                        boo[i]= true;
                        result += h[j];
                        index= j+ 1;
                        break;
                    }
            }
            if (boo[n-1] == true)
                cout<< result<< endl;
            else
                cout<< "Loowater is doomed!"<< endl;

        }
    }
    return 0;
}
