#include <iostream>
using namespace std;

int main()
{
    int h, w, n, width= 0, height= 0, i;
    bool b= false;
    cin>> h>> w>> n;
    int * x= new int [n];
    for (i=0; i<n; i++)
    {
        cin>> x[i];
        if (height < h)
        {
            width += x[i];
            if (width == w)
            {
                height ++;
                width = 0;
            }
            else if (width > w)
                height= h + 1;

            if (height == h)
                b= true;
        }
    }
    if (b)
        cout<< "YES"<< endl;
    else
        cout<< "NO"<< endl;

    return 0;
}
