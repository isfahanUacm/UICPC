#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main()
{
    ll n,m;
  pll test;
  cin>>test.first>>test.second;
  while (test.first!=0 && test.second!=0)
  {

      n=test.first;
      m=test.second;
      ll *sar=new ll[n];
      ll *shobale=new ll[m];
      for(ll i=0;i<n;i++)
      {
          cin>>sar[i];
      }
      for(ll i=0;i<m;i++)
      {
          cin>>shobale[i];
      }
      if(n>m)
      {
          cout<<"Loowater is doomed!"<<endl;

      }
      else{
          sort(sar, sar + n);
          sort(shobale, shobale + m);
          ll minimumcoin=0,j=0,i=0;
          while (i<n && j<m) {

              if(shobale[j]>=sar[i])
              {
                  minimumcoin+=shobale[j];

                  j++;
                  i++;
              }
              else{
                  j++;
              }
          }
          if(j==m && i!=n)
          {
              cout<<"Loowater is doomed!"<<endl;
          }
          else if(i==n)
          {
              cout<<minimumcoin<<endl;
          }
      }
      cin>>test.first>>test.second;
  }
}
