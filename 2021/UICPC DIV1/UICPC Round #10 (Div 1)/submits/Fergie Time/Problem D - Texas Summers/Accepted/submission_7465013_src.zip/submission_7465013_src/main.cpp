#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

void watchstack(stack<ll> s)
{
    while (s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

void print2DArr(ll **arr, ll n, ll m)
{
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}
vector<pll> points;

ll distance(pll a, pll b)
{
    return (a.first - b.first) * (a.first - b.first) + (a.second - b.second) * (a.second - b.second);
}

vector<ll> dijkstra(ll src, ll n)
{

    vector<ll> dist(n, LLONG_MAX);
    vector<bool> visited(n, false);
    vector<ll> path(n, n);

    dist[src] = 0;
    path[src] = -1;

    multiset<pair<ll, ll>> pq;

    pq.insert({0, src});

    while(!pq.empty())
    {
        ll current = pq.begin()->second;
        pq.erase(pq.begin());
        if(visited[current])
        {
            continue;
        }
        visited[current] = true;

        for (ll i = 0; i < n; i++)
        {
            if(i == current)
            {
                continue;
            }
            if (dist[current] + distance(points[current], points[i]) < dist[i])
            {
                dist[i] = dist[current] + distance(points[current], points[i]);
                pq.insert({dist[i], i});
                path[i] = current;
            }
        }
    }
    return path;
}

int main()
{
    ll n;
    cin >> n;
    n += 2;
    pll sample = {-1, -1};
    points = vector<pll>(n, sample);
    for(ll i = 0; i < n; i++)
    {
        cin >> points[i].first >> points[i].second;
    }

    vector<ll> path = dijkstra(n - 1, n);
//    for(ll i : path)
//    {
//        cout << i << " ";
//    }
//    cout << endl;

    if(path[n - 2] == n - 1)
    {
        cout << "-";
    }
    else
    {
        ll index = n - 2;
        while(index != n - 1)
        {
            index = path[index];
            if(index == n - 1)
            {
                break;
            }
            cout << index << endl;
        }
    }

    return 0;
}
