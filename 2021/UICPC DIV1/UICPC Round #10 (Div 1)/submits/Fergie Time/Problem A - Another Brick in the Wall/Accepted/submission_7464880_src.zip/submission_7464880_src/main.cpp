#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

void watchstack(stack<ll> s)
{
    while (s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

void print2DArr(ll **arr, ll n, ll m)
{
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}

int main()
{
    ll h, w, n;
    cin >> h >> w >> n;

    ll currentWidth = 0;
    ll currentHeight = 0;

    string ans = "NO";

    while(n--)
    {
        ll brick;
        cin >> brick;
        currentWidth += brick;
        if(currentWidth == w)
        {
            currentHeight++;
            currentWidth = 0;
        }
        else if(currentWidth > w)
        {
            ans = "NO";
            break;
        }
        if(currentHeight == h)
        {
            ans = "YES";
            break;
        }
    }
    cout << ans;
    return 0;
}
