#include <iostream>
using namespace std;

int main() {
    int h, w, n;
    cin >> h >> w >> n;
    int layersum = 0, line = 0, flag = 0, bluck;
    for(int i=0;i<n;i++) {
    	cin >> bluck;
    	if(flag == 0) {
    		if(layersum + bluck == w) {
    			line ++;
    			layersum = 0;
    			if(line == h) {
    				flag = 1;
				}
			}
			else if(layersum + bluck < w)
				layersum += bluck;
			else
				flag = -1;
		}
	}
	if(flag == 1) cout << "YES";
	else cout << "NO";
    

}

