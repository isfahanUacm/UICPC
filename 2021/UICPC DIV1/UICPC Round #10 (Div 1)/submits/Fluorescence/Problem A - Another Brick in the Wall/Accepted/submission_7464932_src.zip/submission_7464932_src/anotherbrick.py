h, w, n = map(int, input().split())
brick = list(map(int, input().split()))
flag = True
if sum(brick) < int(h*w):
    flag = False
wsum = 0
for b in range(len(brick)):
    br = brick[b]
    wsum += br
    if wsum > w:
        flag = False
        break
    if wsum == w:
        wsum = 0
    
    
if flag:
    print("YES")
else:
    print("NO")