#include <bits/stdc++.h>
using namespace std ;
int main()
{
    long long int t , n , m , i , mid , l=1 , r ,c ,c1,tmp;
    cin >> t >> n;
    r = t;
    long long int a[n][2];
    for (i = 0 ; i < n ; ++i) cin >> a[i][0] >> a[i][1];
    cin >> m;
    long long int b[m][2];
    for (i = 0 ; i < m ; ++i) cin >> b[i][0] >> b[i][1];
    while (l<=r) {
        mid = (l+r)/2;
        c = 0, c1 = 0;
        for (i = 0 ; i < n ; ++i){
            if (mid-a[i][0]>=0)
                c += (mid-a[i][0])/a[i][1];
        }
        for (i = 0 ; i < m ; ++i){
            if ((t-mid)-b[i][0]>=0)
            c1 += ((t-mid)-b[i][0])/b[i][1];
        }
        if (c == c1){
            cout << mid;
            return 0;
        }else if (c>c1){
            r = mid-1;
        }else{
            l = mid+1;
        }
    }
    return 0;
}


