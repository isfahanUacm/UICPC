#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    int matrix[n][n];
    vector<int> smin(n,INT_MAX);
    for (int i = 0; i <n ; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin>>matrix[i][j];
            if(matrix[i][j]<smin[i] && matrix[i][j])
                smin[i]=matrix[i][j];
        }
    }
    set<pair<int,int>> road;
     std::set<pair<int,int>>::iterator it;
    for (int i = 0; i < n ; i++)
    {
        for (int  j = 0; j < n;j++)
        {
            if(matrix[i][j]==smin[i])
            {
                pair<int,int> p;
                p.first = i+1;
                p.second = j+1;

                if(road.find(p)==road.end())
                {
                    swap(p.first, p.second);
                    if(road.find(p)==road.end())
                    {
                        swap(p.first, p.second);
                        road.insert(p);

                    }
                }
            }
        }
    }
    for (it=road.begin(); it!=road.end(); ++it)
        cout<<(*it).first<<" "<<(*it).second<<endl;




    return 0;
}
