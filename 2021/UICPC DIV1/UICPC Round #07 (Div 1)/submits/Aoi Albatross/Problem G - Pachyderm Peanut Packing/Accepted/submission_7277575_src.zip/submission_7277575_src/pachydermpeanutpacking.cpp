#include  <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
struct box{
	string tp;
	double x1;
	double x2;
	double y1;
	double y2;
};
struct pen{
	double x;
	double y;
	string tp;
	string s="floor";
};
bool is_in(pen p,box b){
	return (p.x>=b.x1&&p.x<=b.x2)&&(p.y>=b.y1&&p.y<=b.y2);
}



int main(){

	while(1){
		cin>>n;
		if(n==0)break;
		std::vector<box> bo(n);
		for(ll i=0;i<n;i++){
			cin>>bo[i].x1>>bo[i].y1>>bo[i].x2>>bo[i].y2>>bo[i].tp;
		}
		cin >> m;
		for(ll i=0;i<m;i++){
			pen p;
			cin >> p.x >> p.y >> p.tp;
			for(auto b:bo){
				if(is_in(p,b)){
					if(p.tp==b.tp){
						p.s="correct";
					}
					else{
						p.s=b.tp;
					}
				}
			}
			cout<<p.tp<<' '<<p.s<<endl;
		}
		cout<<endl;
	}
	return 0;
}