#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 110;
ll t,n,m,a[mx],b[mx],c[mx],d[mx];
ll f(ll mid){
    ll c1=0;
    for(ll i=0;i<n;i++){
        ll st = mid-a[i];
        if(st>=0){
            c1+=(st/b[i]+1);
        }
    }
    return c1;
}
ll s(ll mid){
    ll c2=0;
    for(ll i=0;i<m;i++){
        ll st = mid-c[i];
        if(st>=0){
            c2+=(st/d[i]+1);
        }
    }
    return c2;
}
ll bi(ll l,ll h){
    ll mid;
    while(1<h-l){
        mid = (l+h)/2;
        ll c1 = f(mid);
        ll c2 = s(t-mid);
        if(c1>c2){
            h=mid;
        }
        else
            l=mid;
    }
    return l;
}
int main(){
    cin >> t >> n;
    for(ll i=0;i<n;i++){
        cin >> a[i] >> b[i];
    }
    cin >> m;
    for(ll i=0;i<m;i++){
        cin >> c[i] >> d[i];
    }
    cout<<bi(1,t)<<endl;
}
