#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
class Point
{
public:
    ll x;
    ll y;
    ll z;
    ll index3D()
    {
        return x * maxN * maxN + y * maxN + z;
    }
    ll index2D()
    {
        return x * maxN + y;
    }
};
map<ll, vector<ll>> graph3D;
map<ll, vector<ll>> graph2D;
map <ll, bool> visited3D;
map <ll, bool> visited2D;


void watchPoint(ll x)
{
    cout << x / 1000000 << " " << (x / 1000) % 1000 << " " << x % 1000 << endl;
}
void watchPoint2D(ll x)
{
    cout << (x / 1000) % 1000 << " " << x % 1000 << endl;
}
bool one3DCycle(ll index, map<ll, bool> &recstack)
{
    if(!visited3D[index])
    {
        visited3D[index] = true;
        recstack[index] = true;

        for(ll i: graph3D[index])
        {
            if(!visited3D[i])
            {

                if(one3DCycle(i, recstack))
                {
                    return true;
                }
            }
            if(recstack[i])
            {
                return true;
            }
        }
    }
    recstack[index] = false;
    return false;
}

bool has3DCycle()
{
    map<ll, bool> visited;
    for(auto i: graph3D)
    {
        visited3D[i.first] = false;
        visited[i.first] = false;
    }
    for(auto i: graph3D)
    {
        if(one3DCycle(i.first, visited))
        {
            return true;
        }
    }
    return false;
}

bool one2DCycle(ll index, ll parent)
{

    visited2D[index] = true;

    for(ll i: graph2D[index])
    {
        if(!visited2D[i])
        {
            if(one2DCycle(i, index))
            {
                return true;
            }
        }
        else if(visited2D[i] && i != parent)
        {
            return true;
        }
    }
    return false;
}

bool has2DCycle()
{
    for(auto i: graph2D)
    {
        visited2D[i.first] = false;
    }
    for(auto i: graph2D)
    {
        if(true)
        {
            if(one2DCycle(i.first, -1))
            {
                return true;
            }
        }
    }
    return false;
}
int main ()
{
    ll n;
    cin >> n;
    vector<pair<Point, Point>> v(n, {Point(), Point()});
    set<pair<ll, ll>> st;
    for(ll i = 0; i < n; i++)
    {
        cin >> v[i].first.x >> v[i].first.y >> v[i].first.z >> v[i].second.x >> v[i].second.y >> v[i].second.z;
        if(graph3D.find(v[i].first.index3D()) == graph3D.end())
        {
            graph3D[v[i].first.index3D()] = vector<ll>();
        }
        graph3D[v[i].first.index3D()].push_back(v[i].second.index3D());

        if(graph3D.find(v[i].second.index3D()) == graph3D.end())
        {
            graph3D[v[i].second.index3D()] = vector<ll>();
        }
        //        graph3D[v[i].second.index3D()].push_back(v[i].first.index3D());

        pair<ll, ll> currentNeedle = {v[i].first.index2D(), v[i].second.index2D()};
        //2D
        if(graph2D.find(v[i].first.index2D()) == graph2D.end())
        {
            graph2D[v[i].first.index2D()] = vector<ll>();
        }
        if(v[i].first.index2D() != v[i].second.index2D() && st.find(currentNeedle) == st.end())
        {
            graph2D[v[i].first.index2D()].push_back(v[i].second.index2D());
        }

        if(graph2D.find(v[i].second.index2D()) == graph2D.end())
        {
            graph2D[v[i].second.index2D()] = vector<ll>();
        }
        if(v[i].first.index2D() != v[i].second.index2D() && st.find(currentNeedle) == st.end())
        {
            graph2D[v[i].second.index2D()].push_back(v[i].first.index2D());
        }
        st.insert(currentNeedle);
        st.insert({v[i].second.index2D(), v[i].first.index2D()});

    }
    bool ans1 = has3DCycle();
    if(ans1)
    {
        cout << "True closed chains" << endl;
    }
    else
    {
        cout << "No true closed chains" << endl;
    }
    bool ans2 = has2DCycle();
    if(ans2)
    {
        cout << "Floor closed chains" << endl;
    }
    else
    {
        cout << "No floor closed chains" << endl;
    }
    return 0;
}
