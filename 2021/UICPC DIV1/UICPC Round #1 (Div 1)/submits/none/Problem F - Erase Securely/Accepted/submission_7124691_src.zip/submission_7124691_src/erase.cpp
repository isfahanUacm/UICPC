#include<bits/stdc++.h>
using namespace std;

string xoring(string a, string b, int n)
{
string ans = "";

    for (int i = 0; i < n; i++)
    {
        if (a[i] == b[i])
            ans += "0";
        else
            ans += "1";
    }
    return ans;
}

int main()
{
    int a, i;
    string s1, s2;
    cin>> a;
    cin>> s1>> s2;
    int n= int (s1.length());
    string c = xoring(s1, s2, n);
    for (i=0; i<n; i++)
    {
        if (a%2 == 1)
            if (c[i] == '0')
            {
                cout<< "Deletion failed"<< endl;
                break;
            }
        if (a%2 == 0)
            if (c[i] == '1')
            {
                cout<< "Deletion failed"<< endl;
                break;
            }
    }
    if (i == n)
        cout<< "Deletion succeeded"<< endl;
}