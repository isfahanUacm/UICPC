#include<bits/stdc++.h>

using namespace std;

int main()
{
  int n;
  cin>>n;
  string c,d;
  cin>>c>>d;
  bool check= true;
  if (n % 2 == 0)
  {
      for(int i=0;i<c.length();i++)
          if(c[i] != d[i])
          {
              check = false;
              break;
          }
  }
  else{
      for(int i=0;i<c.length();i++)
          if(c[i] == d[i])
          {
              check = false;
              break;
          }
  }

  if(check == true)
      cout<<"Deletion succeeded";
  else {
      cout<<"Deletion failed";
  }
}
