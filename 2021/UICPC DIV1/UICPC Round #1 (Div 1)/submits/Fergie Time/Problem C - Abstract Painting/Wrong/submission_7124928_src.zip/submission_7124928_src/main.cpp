#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
vector<pll> v;
ll T;

ll ansC = LLONG_MAX;
vector<ll> vans;

void f(ll cT, ll cC, vector<ll> cV)
{
    if(cT == T)
    {
        if(cC < ansC)
        {
            ansC = cC;
            vans = cV;
        }
        return;
    }
    if(cC > ansC)
    {
        return;
    }

    for(ll i = 0; i < v.size(); i++)
    {
        vector<ll> temp = cV;
        temp.push_back(i + 1);
        f(cT + v[i].first, cC + v[i].second, temp);
    }
}
ll mul(ll a, ll b)
{
    return ((a % mod) * (b % mod)) % mod;
}
int main ()
{
    ll n;
    cin >> n;
    while(n--)
    {
        ll r, c;
        cin >> r >> c;
        ll ans = 18;
        if((r + c - 2) > 0)
        {
//            ans = ans * (r + c - 2) * 6;
            ans = mul(mul(ans, (r + c - 2)), 6);
        }
        if((mul(r, c) - (r + c - 1)) > 0)
        {
//            ans = ans * (r * c - (r + c - 1)) * 2;
            ans = mul(mul(ans, (mul(r, c) - (r + c - 1))), 2);
        }
        cout << ans << endl;
    }
    return 0;
}
