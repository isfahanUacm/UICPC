n=int(input())
for i in range(n):
    r,c = map(int,input().split())
    ans = 18
    if (r + c - 2) > 0:
        ans = ans * (r + c - 2) * 6
    if (r*c - (r + c - 1)) > 0:
        ans = ans * (r * c - (r + c - 1)) * 2
    print(ans%1000000007)
