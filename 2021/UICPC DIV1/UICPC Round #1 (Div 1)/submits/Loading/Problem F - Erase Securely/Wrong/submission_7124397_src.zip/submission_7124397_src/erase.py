n = int(input())
one = input()
two = input()
i_one = int(one)
i_two = int(two)
flag = True

if n % 2 == 0:
    if one == two:
        print("Deletion succeeded")
    else:
        print("Deletion failed")
else:
    for i in range(len(one)):
        if one[i] == '0':
            if two[i] != '1':
                print("Deletion failed")
                flag = False
        elif one[i] == '1':
            if two[i] != '0':
                print("Deletion failed")
                flag = False
    if flag == True:
        print("Deletion succeeded")
