#include <bits/stdc++.h>
using namespace std;

long long int how( int r, int c ,long long int** a)
{
    int mul = r*c;
    if( mul == 1 )
    {
        a[r-1][c-1] = 18;
        return 18;
    }
    if( mul == 2)
    {
       a[r-1][c-1] =108;
       a[c-1][r-1] = 108;
       return 108;
    }
    else
    {
        long long int output;
        long long int o1 = pow(6 , (r+c-2));
        long long int o2 =pow(2 , (r-1)*(c-1));
        output = 18 * o1 * o2;

        a[r-1][c-1] = output;
        if(c<14)
        {
            a[c-1][r-1] = output;
        }

        return output;
    }
}

int main()
{
    int t;
    cin >> t;
    long long int ** array = new long long int* [14];

    for(int i=0 ;i<14; i++)
    {
        array[i]= new long long int [2000];
    }

    for(int i=0 ;i<14; i++)
    {
        for(int j=0; j<2000 ; j++)
        {
            array[i][j]=0;
        }
    }
//            trou[i][j]=0;

    while( t-- )
    {
        int r, c;
        cin >> r >> c;

        if( array[r-1][c-1] != 0 )
        {
            cout << array[r-1][c-1] <<endl ;
        }

        else
        {
           cout << how(r, c, array) << endl;
        }

    }


}
