#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    unsigned long long int c, r, common, ans = 1;

    for(int i = 0; i < n; i++)
    {
        ans = 1;
        cin >> c >> r;
        if(c != 1 && r != 1)
        {
            common = (r -1)*c + r*(c -1);
        }
        else if(c > 1)
            common = c -1;
        else
            common = r -1;

        //18 --> 3^2 ,, 3^common,, 18^(c*r), 18(cr - common)*9^(common)
        for(unsigned long long int j = 0; j < (c*r); j++)
            ans = ((ans *= 18) % 1000000007);
        for(unsigned long long int j = 0; j < common; j++)
            ans /= 3;

        cout << ans << endl;
    }
}
