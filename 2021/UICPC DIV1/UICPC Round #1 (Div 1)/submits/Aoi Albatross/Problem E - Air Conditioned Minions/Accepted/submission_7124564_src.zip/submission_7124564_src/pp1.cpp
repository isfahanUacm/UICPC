#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main ()
{
    vector<pair<int,int>> ans,num;
    int n;
    cin>>n;
    num.resize(n);
    for (int i=0;i<n;i++)
        cin>>num[i].first>>num[i].second;

    sort(num.begin(),num.end());
    for (int i=0;i<n;i++){
        pair<int,int> tmp=num[i];
        bool flag=false;
        for (int j=0;j<ans.size();j++){
            if ((tmp.first>=ans[j].first && tmp.first<=ans[j].second) || (tmp.second>=ans[j].first && tmp.second<=ans[j].second)){
                ans[j].first=max(ans[j].first,tmp.first);
                ans[j].second=min(ans[j].second,tmp.second);
                flag=true;
                break;
            }
        }
        if (!flag)
            ans.push_back(tmp);
    }
    cout<<ans.size()<<endl;

    return 0;
}
