#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mo = 1e9+7;
ll add(ll a,ll b){
	return (a+b)%mo;
}
ll mul(ll a,ll b){
	return (a*b)%mo;
}
ll power(ll a, ll b){
	if(b==0)
		return 1;
	ll ans = power(a,b/2);
	return mul(mul(b%2 ? a:1,ans),ans);
}
int main(){
	ll t;
	cin >> t;
	while(t--){
		ll r,c;
		cin >> r >> c;
		cout<<mul(power(3,add(r,c)),power(2,mul(r,c)))<<endl;;
	}
	return 0;
}