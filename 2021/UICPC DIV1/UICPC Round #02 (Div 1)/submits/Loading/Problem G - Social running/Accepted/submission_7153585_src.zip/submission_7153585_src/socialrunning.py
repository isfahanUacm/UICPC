t = int(input())
lst = []
lst_sum = []
for i in range(t):
    lst.append(int(input()))

lst_sum.append(lst[0] + lst[t-2])
lst_sum.append(lst[1] + lst[t-1])

for i in range(t-2):
    lst_sum.append(lst[i] + lst[i + 2])

print(min(lst_sum))