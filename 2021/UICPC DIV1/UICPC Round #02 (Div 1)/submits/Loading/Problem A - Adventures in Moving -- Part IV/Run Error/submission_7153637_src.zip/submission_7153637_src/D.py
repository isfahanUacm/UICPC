big_city =  int(input())
a,b = 0, 0
max_price = 2001
liter = 100
d_gas=[]
p_gas=[]
map_price = [max_price]*(big_city+201)
d_gas.append(0)
p_gas.append(0)
s=input()
while (s):
    a,b = map(int, s.split())
    d_gas.append(a)
    p_gas.append(b)
    s=input()
    '''print(a)
    print(b)'''

'''print(big_city)
print(d_gas)
print(p_gas)'''
if (d_gas[1] > 100):
    print("Impossible")
else:
    n = len(d_gas)
    for i in range(n):
        for j in range(liter):
            if (p_gas[i] <= map_price[d_gas[i]+j]): map_price[d_gas[i]+j] = p_gas[i]
        liter=200

    #print(map_price)
    thesum=0
    flag=1
    for k in range(big_city+100):
        if (map_price[k] == 2001):
            flag=0
        else:
            thesum += map_price[k]

    if (flag):
        print(thesum)
    else:
        print("Impossible")
