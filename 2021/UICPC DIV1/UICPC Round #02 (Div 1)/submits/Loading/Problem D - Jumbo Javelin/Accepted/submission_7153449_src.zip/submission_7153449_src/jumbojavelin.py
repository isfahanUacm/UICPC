t = int(input())
lst = []
f = int(input())
for i in range(t-1):
    lst.append(int(input()) - 1)

print(f + sum(lst))