x = []
n = int(input())
for i in range(0, n):
    ele = int(input())
    x.append(ele)
import sys
minn= sys.maxsize
for i in range (0, n):
    sum= x[i]+ x[(2- n)+ i]
    if sum < minn:
        minn= sum
print (minn)
