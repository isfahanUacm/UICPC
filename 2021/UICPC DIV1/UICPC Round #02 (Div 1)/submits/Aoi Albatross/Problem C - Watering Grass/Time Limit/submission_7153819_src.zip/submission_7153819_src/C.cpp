#include <bits/stdc++.h>
using namespace std;
typedef long long ll ;
struct circle{
	ll x;
	ll r;
};
struct cover{
	double a;
	double b;

};
bool cmp(circle a,circle b){
	return a.x<b.x;
}
int main(){

	ll n,l,w;
	while(cin >> n >> w >> l){
		stack<cover> base;
		std::vector<circle> cir;
		for(ll i=0;i<n;i++){
			circle in;
			cin >> in.x >> in.r;
			cir.push_back(in);

		}
		sort(cir.begin(),cir.end(),cmp);
		for(auto c: cir){
			if(!base.empty()&&base.top().b>=w)break;
			bool f=true;
			cover d;
			d.a= 1.0*c.x-sqrt(pow(c.r,2)-pow(double(l)/2,2));
			d.b = 1.0*c.x+sqrt(pow(c.r,2)-pow(double(l)/2,2));
			while(!base.empty()){
				if(d.a>base.top().b){f=0;break;}
				else if(d.b>=base.top().b&&d.a<=base.top().a){
					base.pop();
				}
				else if(d.a>=base.top().a&&d.b<=base.top().b){f=0;break;}
				else if(d.a<=base.top().b&&d.b>=base.top().b){
					f=true;
					//cout<<"babaa "<<d.a<<' '<<d.b<<endl;
					d.a = base.top().b;
					base.push(d);
					break;
				}

			}
			if(base.empty()){
				if(c.x-sqrt(pow(c.r,2)-pow(double(l)/2,2))<=0){
					d.a=0;
					d.b=c.x+sqrt(pow(c.r,2)-pow(double(l)/2,2));
					//cout<<"babaa "<<d.a<<' '<<d.b<<endl;
					base.push(d);
					continue;
				}
			}

		}
		if(base.empty()||base.top().b<w){
			cout<<-1<<endl;
			continue;
		}
		cout<<base.size()<<endl;

	}




}