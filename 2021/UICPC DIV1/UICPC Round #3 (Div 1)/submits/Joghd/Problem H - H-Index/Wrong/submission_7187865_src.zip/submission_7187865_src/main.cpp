#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int x[n];
    for(int i=0;i<n;i++)
        cin >> x[i];
    sort(x,x+n);
    for(int i=n-1;i>=0;i--) {
        if(i+1 >= x[i]) {
            cout << x[i];
            return 0;
        }
    }
    cout << x[0];


}
