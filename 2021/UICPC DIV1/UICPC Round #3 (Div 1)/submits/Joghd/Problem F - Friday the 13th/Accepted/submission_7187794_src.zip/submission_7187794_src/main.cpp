#include <iostream>
#include <string>
using namespace std;
struct x {
    string nam;
    string hezb;
    int a;
};
int que(int y,int m,int *w) {
    int days=13, ans=0;
    for(int i=0;i<m;i++) {
        if(i!=0)
            days+=w[i-1];
        if(w[i]<13)
            continue;
        if(days%7==6)
            ans++;
    }
    return ans;
}
int main()
{
    int n;
    cin >> n;
    int ans[n];
    for(int i=0;i<n;i++) {
        int y, m;
        cin >> y >> m;
        int a[m];
        for(int j=0;j<m;j++)
            cin >> a[j];
        ans[i]=que(y,m,a);
    }
    for(int i=0;i<n;i++)
        cout << ans[i] << endl;

}
