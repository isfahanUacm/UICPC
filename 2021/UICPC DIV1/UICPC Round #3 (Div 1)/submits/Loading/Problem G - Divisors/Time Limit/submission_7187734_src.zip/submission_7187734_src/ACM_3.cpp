
#include <iostream>
#include <string.h>
#include <vector>
#include <math.h>
using namespace std;
#define uint unsigned long long int
uint from = 0;
uint distinct(uint number)
{
    uint count=0;
    for (uint i = 1; i <= number; i++)
    {
        if (number % i == 0)
        {
            count++;
        }
    }
    return count;
}
uint make(uint n, uint k, uint** sum)
{
    for (int i = from; i <= 431; i++)
    {
        int to = 0;
        if (i < n)
            to = i;
        else if (i < k)
            to = i;
        else
            to = k;
        for(int j = 0; j <= to; j++)
        {
            if (j == 0 || j == i)
            {
                sum[i][j] = 1;
                if (i == n && j == k)
                {
                    //cout << sum[i][j];
                    return sum[i][j];
                }
            }
            else
            {
                sum[i][j] = sum[i - 1][j - 1] + sum[i - 1][j];
                if (i == n && j == k)
                {
                    //cout << sum[i][j];
                    return sum[i][j];
                }
            }
        }
    }
    
}
int main()
{
    uint n, k;
    uint** sum = new uint * [432];
    for (int j = 0; j < 432; j++)
    {
        sum[j] = new uint[432];
    }
    for (int i = 0; i < 432; i++)
    {
        for (int j = 0; j < 432; j++)
        {
            sum[i][j] = 0;
        }
    }
    while (true)
    {
        cin >> n >> k;
        uint ans = 0;

        if (sum[n][k] != 0)
        {
            ans = sum[n][k];
            //cout << ans <<" ";
        }
        else
        {
            ans = make(n, k, sum);
            //cout << ans <<" ";
        }
        if (n > from)
        {
            from = n;
        }
       /* for (int i = 0; i <= 431; i++)
        {
            int to = 0;
            if (i < k)
                to = i;
            else
                to = k;
            bool exit = false;
            for (int j = 0; j <= to; j++)
            {
                if (sum[i][j] == -1)
                {
                    exit = true;
                    break;
                }
                else
                {
                    cout << sum[i][j] << " ";
                }
                if (exit == true)
                    break;
                else
                    cout << endl;
            }

           
        }*/
        cout << distinct(ans) << endl;
    }
}

