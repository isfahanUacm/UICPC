n = int(input())
li=[]
for i in range(n):
    li.append(int(input()))
li.sort()
#print(li)
res = -1
for i in range(n-1,-1,-1):
    number = n - i 
    if li[i] >= number:
        if number > res:
            res = number
#if li[0] == 1: print("1")
#else: print("0")
'''
if n>= li[0]:
    print(li[0])
else:
    print(n)'''
print(res)