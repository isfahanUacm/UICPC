n = int(input())
li=[]
for i in range(n):
    li.append(int(input()))
li.sort()

for i in range(n-1,0,-1):
    number= i +1
    if number >= li[i]:
        print(li[i])
        exit()
#if li[0] == 1: print("1")
#else: print("0")
print(li[0])