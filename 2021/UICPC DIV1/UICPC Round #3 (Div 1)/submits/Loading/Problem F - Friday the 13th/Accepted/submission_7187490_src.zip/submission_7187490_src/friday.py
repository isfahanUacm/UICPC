

t = int(input())
for i in range(t):
    count = 0
    d, m = map(int, input().split())
    d_m = list(map(int, input().split()))

    if d_m[0] >= 13:
        count += 1

    x = d
    for i in range(m-1, 0, -1):
        x = x - d_m[i]
        if x % 7 == 0:
            if d_m[i] >= 13:
                count += 1

    print(count)
    
    