n= int (input ())
candidate= []
party= []
person= []
for i in range (0, n):
    candidate.append(input())
    party.append(input())
    person.append(0)
m= int (input())
vote= []
for i in range (0, m):
    vote.append(input())
    for j in range (0, n):
        if vote[i] == candidate[j]:
            person[j]= person[j] +1
max= person[0]
index= 0
a= 0
for i in range (1, n):
    if person[i] > max:
        max= person[i]
        index= i

for i in range (0, n):
    if person[i] == max:
        a+= 1
        break
if a > 1:
    print ("tie")
else:
    print (party[index])
