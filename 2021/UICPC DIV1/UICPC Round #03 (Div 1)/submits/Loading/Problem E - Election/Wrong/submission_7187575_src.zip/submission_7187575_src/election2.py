
lst = []
n = int(input())
for i in range(n):
    name = input()
    party = input()
    lst.append([name, party, 0])

m = int(input())
for i in range(m):
    ballot = input()
    for j in range(n):
        if ballot == lst[j][0]:
            lst[j][2] += 1
            break
maxi = -1
index = -1
f = 0
for i in range(n):
    if maxi < lst[i][2]:
        maxi = lst[i][2]
        index = i
    elif maxi == lst[i][2]:
        f += 1

if f == n-1:
    print("tie")
else:
    print(lst[index][1])
