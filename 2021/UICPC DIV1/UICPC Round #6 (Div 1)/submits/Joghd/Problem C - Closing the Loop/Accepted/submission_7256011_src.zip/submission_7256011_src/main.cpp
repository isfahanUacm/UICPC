#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int min(int a,int b) {
    if(a<b)
    return a;
    return b;
}
int que(){
    int n;
    cin >> n;
    int r[n];
    int b[n];
    int rs=0 , bs=0;
    string  s;
    for(int i=0;i<n;i++) {
        cin >> s;
        int num=0;
        for(int i=0;i<=s.size()-2;i++) {
            num*=10;
            num+=s[i]-'0';
        }
        if(s[s.size()-1]=='B') {
            b[bs] = num;
            bs++;
        }
        else {
            r[rs] = num;
            rs++;
        }


    }
    sort(r,r+rs);
    sort(b,b+bs);
    int ans = 0;
    for(int i=0;i<min(bs,rs);i++) {
        ans += b[bs-i-1]+r[rs-i-1];
    }
    ans -= 2*min(bs,rs);
    return ans;
}
int main() {
    int n;
    cin >> n;
    int x[n];
    for(int i=0;i<n;i++)
        x[i]=que();
    for(int i=0;i<n;i++)
        cout << "Case #" << i+1 << ": " << x[i] << endl;

}
