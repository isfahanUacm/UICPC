#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int main() {
    int q, n ,n1,nq;
    cin >> q >> n >>n1 >> nq;
//1
    int max = ceil(nq/n) * q;
    int baq = ( n - nq%n)* q;
    if(baq >= n1)
        cout << max;
    else {
        n1 -= baq;
        cout << max + ceil(n1/n);
    }


}
