#include <iostream>
#include <string>

using namespace std;
int ceil(int a,int b) {
    int aa=a%b;
    return (a-aa)/b+1;
}
int main() {
    int q, n ,n1,nq;
    cin >> q >> n >>n1 >> nq;
//1
    int max = ceil(nq,n) * q;
    int baq = ( n - nq%n)* q;
    if(baq >= n1)
        cout << max;
    else {
        n1 -= baq;
        cout << max + ceil(n1,n);
    }


}
