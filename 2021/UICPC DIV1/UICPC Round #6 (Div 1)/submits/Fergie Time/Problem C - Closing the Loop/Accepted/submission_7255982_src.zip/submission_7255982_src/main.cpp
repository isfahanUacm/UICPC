#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main ()
{
    ll n;
    cin >> n;
    for(ll t = 1; t <= n; t++)
    {
        ll s;
        cin >> s;
        vector<ll> r;
        vector<ll> b;

        for(ll i = 0; i < s; i++)
        {
            string temp;
            cin >> temp;
            if(temp[temp.size() - 1] == 'R')
            {
                r.push_back(stoi(temp.substr(0, temp.size() - 1)));
            }
            else if(temp[temp.size() - 1] == 'B')
            {
                b.push_back(stoi(temp.substr(0, temp.size() - 1)));
            }

        }
        sort(r.begin(), r.end(), greater<ll>());
        sort(b.begin(), b.end(), greater<ll>());

        ll ans = 0;
        ll indexR = 0;
        ll indexB = 0;
        char select = 'r';
        if(r.size() == 0 || b.size() == 0)
        {
            ans = 0;
        }
        else if(r[0] > b[0])
        {
            select = 'r';
        }
        else if(r[0] < b[0])
        {
            select = 'b';
        }
        ll it = 1;
        while((select == 'r' && indexR < r.size()) || (select == 'b' && indexB < b.size()))
        {
            if((it % 2 == 1) && (indexB == b.size() || indexR == r.size()))
            {
                break;
            }
            if(select == 'r' && indexR < r.size())
            {
                ans += r[indexR] - 1;
                indexR++;
                select = 'b';
            }
            else if(select == 'b' && indexB < b.size())
            {
                ans += b[indexB] - 1;
                indexB++;
                select = 'r';
            }
            else
            {
                break;
            }

            it++;
        }
        cout << "Case #" << t << ": " << ans << endl;
    }
    return 0;
}
