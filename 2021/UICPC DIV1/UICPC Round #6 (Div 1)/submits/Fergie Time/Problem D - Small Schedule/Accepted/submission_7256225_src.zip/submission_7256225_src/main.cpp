#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main ()
{
    ll Q, M, S, L;
    cin >> Q >> M >> S >> L;
    ll had1 = (L / M) + ((L % M)? 1 : 0);
    ll remaining_ones = ((L % M)? 1 : 0) * Q * (M - L % M);
    S = max(0ll, S - remaining_ones);
    ll had2 = (S / M) + ((S % M)? 1 : 0);
    cout << had1 * Q + had2;
    return 0;
}
