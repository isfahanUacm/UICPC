k, m, n = map(int, input().split())
r = k%n
p = k//n
if p%2 == 0:
    if r < m:
        print("Barb")
    else:
        print("Alex")
else:
    if r < m:
        print("Alex")
    else:
        print("Barb")