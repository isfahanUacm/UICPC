#include <bits/stdc++.h>
using namespace std;

int main()
{
    long long int k , n , m;
    cin >> k >> n >> m;
    if ((k%m)<n && (k%m)>0)
        cout << "Barb";
    else
        cout << "Alex";
    return 0;
}
