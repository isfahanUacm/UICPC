def pr(k1, k2):
    print(f"Case #{k1}: {k2}")


m = int(input())

for i in range(m):
    n = int(input())
    if n == 1:
        pr(i + 1, 0)
        temp = input()
        continue
    l = list(map(str, input().split()))
    lb = []
    lr = []
    for j in l:
        if j[-1] == 'B':
            lb.append(int(j[:-1]))
        else:
            lr.append(int(j[:-1]))
    s = 0
    q = 0
    lb.sort()
    lr.sort()
    while len(lb) > 0 and len(lr) > 0:
        s += (lb[-1] + lr[-1])
        q += 2
        lb.pop(-1)
        lr.pop(-1)
    pr(i + 1, s - q)
