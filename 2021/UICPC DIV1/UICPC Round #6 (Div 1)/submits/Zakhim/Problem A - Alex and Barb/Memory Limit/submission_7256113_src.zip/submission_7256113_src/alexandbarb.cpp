#include <iostream>

using namespace std;

int main() {
    int k, m, n;
    cin >> k >> m >> n;
    int dp[k + 1];
    for (int i = 0; i < n + 1; i++) {
        if (m <= i && i <= n)
            dp[i] = 1;
        else
            dp[i] = 0;
    }
    for (int i = n + 1; i < k + 1; i++) {
        dp[i] = max(dp[i - m], dp[i - n]);
    }
    if (dp[k] == 1)
        cout << "Alex";
    else
        cout << "Barb";
}