c, k = map(int, input().split())
print(round(c, -k))
