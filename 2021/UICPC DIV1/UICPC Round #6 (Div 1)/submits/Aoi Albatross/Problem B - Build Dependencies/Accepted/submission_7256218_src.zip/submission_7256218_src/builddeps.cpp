#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 1e5+20;
ll n;
map<string,ll> id;
map<ll,string> id2;
bool visited[mx];
vector<ll> adj[mx];
map<ll,vector<string>> inp;
string s;
vector<ll> ts;
void dfs(ll u){
	visited[u]=true;
	for(auto v:adj[u]){
		if(!visited[v]){
			dfs(v);
		}
	}
	ts.push_back(u);
}
int main(){
	cin >> n;
	cin.ignore();
	for(ll i=0;i<n;i++){
		string name;
		getline(cin,name);
		string word = "";
		for(ll c=0;c<name.length();c++){
			if(name[c]==':'){
				c++;
				id[word]=i;
				id2[i]=word;
				word.clear();
			}
			else if(name[c]==' '||c==name.length()-1){
				if(c==name.length()-1)word+=name[c];
				inp[i].push_back(word);
				word.clear();
			}
			else{
				word+=name[c];
			}
		}
	}
	cin >> s;
	for(ll i=0;i<n;i++){
		for(auto j:inp[i]){
			adj[id[j]].push_back(i);
		}
	}
	dfs(id[s]);
	reverse(ts.begin(),ts.end());
	for(auto i:ts){
		cout<<id2[i]<<endl;
	}
	return 0;
}