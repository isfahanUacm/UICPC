#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool cmp(ll a,ll b){
	return a>b;
}
void solve(){
	ll n,ans=0;
	cin >> n;
	std::vector<ll> r,b;
	for(ll i=0;i<n;i++){
		string in;
		cin >> in;
		if(in[in.length()-1]=='R')r.push_back(stoll(in.substr(0,in.length()-1)));
		else{
			b.push_back(stoll(in.substr(0,in.length()-1)));
		}
	}
	if(b.size()==0||r.size()==0){
		cout<<0<<endl;
		return;
	}
	sort(b.begin(),b.end(),cmp);
	sort(r.begin(),r.end(),cmp);
	for(ll i=0;i<min(r.size(),b.size());i++){
			ans+=(b[i]+r[i]);
	}
	cout<<ans-2*(min(r.size(),b.size()))<<endl;
}
int main(){
	ll t;
	cin >> t;
	for(ll i=0;i<t;i++){
		cout<<"Case #"<<i+1<<':'<<' ';
		solve();
	}
}