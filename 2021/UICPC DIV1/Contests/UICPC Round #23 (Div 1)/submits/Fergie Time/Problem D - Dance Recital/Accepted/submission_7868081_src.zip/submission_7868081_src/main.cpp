#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
vector <vector< char>> arr;
ll min1 = LLONG_MAX;

void routines(int last, ll min2, vector<bool> visited,int num){

    if (min2 >= min1)
        return;

    if(num == visited.size())
    {
        if (min2 <= min1)
           min1 = min2;
       // cout << min1 <<endl;
        return;
    }
    ll t=0;
    for(int i=0;i<visited.size();i++)
    {
        t = 0;
        if(visited[i] == false)
        {
            visited[i] = true;
            if (last != -1)
            {
            for(int j=0;j<arr[last].size();j++)
                for(int k=0;k<arr[i].size();k++)
                {
                    if (arr[last][j] == arr[i][k])
                    {
                        min2 += 1;
                        t += 1;
                    }
                }
            }
            routines(i,min2,visited,num+1);
            visited[i] = false;
            min2 -= t;
        }
    }

}

int main()
{
    int n;
    cin >> n;
    arr = vector <vector<char>> (n);
    for (int i=0;i<n;i++)
    {
        string s;
        cin >> s;
        for(int j=0;j<s.size();j++)
            arr[i].push_back(s[j]);
    }

    vector <bool> visited(n);
    for (int i=0;i<n;i++)
        visited[i] = false;
    routines(-1,0,visited,0);
    cout << min1;

}
