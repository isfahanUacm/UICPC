#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll maxN = 30001;
ll p[maxN];


int main()
{
    ll n, p;
    cin >> n >> p;
    vector<ll> a(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> a[i];
        a[i] -= p;
    }
    ll ans = 0;
    ll temp = 0;
    for(ll i = 0; i < n; i++)
    {
        temp += a[i];
        if(temp > ans)
        {
            ans = temp;
        }
        else
        {
            temp = max(temp, (ll)0);
        }
    }
    cout << ans;

    return 0;
}
