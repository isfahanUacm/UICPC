#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll maxN = 30001;
const ll val2 = 2018 * 2018;

int main()
{
    ll n;
    cin >> n;
    vector<pll> arr(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> arr[i].first >> arr[i].second;
    }
    set<pll> st;
    ll ans = 0;
    vector<pll> ways = {{-2018, 0}, {2018, 0}, {0, 2018}, {0, -2018},
                        {1118, 1680}, {1118, -1680}, {-1118, 1680}, {-1118, -1680},
                        {1680, 1118}, {-1680, 1118}, {1680, -1118}, {-1680, -1118}};
    for(ll i = 0; i < n; i++)
    {
        st.insert(arr[i]);
        for(pll way: ways)
        {
            if(st.find({arr[i].first + way.first, arr[i].second + way.second}) != st.end())
            {
                ans++;
            }
        }
    }
    cout << ans;

    return 0;
}
