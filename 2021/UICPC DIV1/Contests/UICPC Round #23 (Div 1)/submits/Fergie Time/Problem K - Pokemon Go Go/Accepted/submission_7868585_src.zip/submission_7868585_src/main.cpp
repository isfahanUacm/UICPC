#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll maxN = 30001;

ll n;
ll pindex = 0;
vector<pair<pll, string>> arr;
unordered_set<string> pokemonSet;
map<string, ll> pokemonToIndex;
ll dp[22][1 << 16];
bool visited[22][1 << 16];
ll calcDist(pll a, pll b)
{
    return abs(a.first - b.first) + abs(a.second - b.second);
}

ll tsp(ll pos, ll mask)
{
    if(dp[pos][mask] != LLONG_MAX)
    {
        return dp[pos][mask];
    }
    ll ans = LLONG_MAX;
    for(ll i = 0; i < n + 1; i++)
    {
        if(i != pos && ((pokemonToIndex[arr[i].second] & mask) == 0))
        {
            ans = min(ans, tsp(i, mask | pokemonToIndex[arr[i].second]) + calcDist(arr[pos].first, arr[i].first));
        }
    }
    dp[pos][mask] = ans;
    return ans;
}

int main()
{
    cin >> n;

    arr = vector<pair<pll, string>> (n + 1);
    arr[0] = {{0, 0}, "$"};
    pokemonSet.insert("$");
    pokemonToIndex["$"] = 1 << pindex;
    pindex++;
    for(ll i = 1; i < n + 1; i++)
    {
        cin >> arr[i].first.first >> arr[i].first.second >> arr[i].second;
        if(pokemonSet.find(arr[i].second) == pokemonSet.end())
        {
            pokemonSet.insert(arr[i].second);
            pokemonToIndex[arr[i].second] = 1 << pindex;
            pindex++;
        }
    }

    fill(&dp[0][0], &dp[0][0] + (22 * (1 << 16)), LLONG_MAX);

    dp[0][(1 << pindex) - 1] = 0;
    for(ll i = 1; i < n + 1; i++)
    {
        dp[i][(1 << pindex) - 1] = calcDist(arr[i].first, {0, 0});
    }
    cout << tsp(0, 0);


    return 0;
}
