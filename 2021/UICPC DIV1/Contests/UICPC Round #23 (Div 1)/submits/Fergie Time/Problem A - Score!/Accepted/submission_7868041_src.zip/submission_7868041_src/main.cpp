#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll maxN = 30001;
ll p[maxN];

pll timeDiff(pll t1, pll t2)
{
    // t1 - t2
    pll ans;
    if(t1.second < t2.second)
    {
        t1.first--;
        t1.second += 60;
    }
    ans.second = t1.second - t2.second;
    ans.first = t1.first - t2.first;
    return ans;
}

pll timePlus(pll t1, pll t2)
{
    // t1 + t2
    pll ans;
    ans.second = t1.second + t2.second;
    ans.first  = t1.first + t2.first;
    if(ans.second >= 60)
    {
        ans.first++;
        ans.second -= 60;
    }
    return ans;
}
int main()
{
    ll n;
    scanf("%lld", &n);
    vector<pair<char, pair<ll, pll>>> event(n + 1);
    event[0] = {'H', {0, {0, 0}}};
    for(ll i = 0; i < n; i++)
    {
        scanf(" %c %lld %lld:%lld", &event[i + 1].first, &event[i + 1].second.first, &event[i + 1].second.second.first, &event[i + 1].second.second.second);
    }
    pll timeA = {0, 0};
    pll timeH = {0, 0};
    ll pointA = 0;
    ll pointH = 0;
    for(ll i = 1; i < n + 1; i++)
    {
        pll diff = timeDiff(event[i].second.second, event[i - 1].second.second);
        if(pointH > pointA)
        {
            timeH = timePlus(timeH, diff);
        }
        else if(pointA > pointH)
        {
            timeA = timePlus(timeA, diff);
        }
        if(event[i].first == 'H')
        {
            pointH += event[i].second.first;
        }
        else
        {
            pointA += event[i].second.first;
        }
    }
    pll const32 = {32, 0};
    if(pointA > pointH)
    {
        timeA = timePlus(timeA, timeDiff(const32, event[n].second.second));
    }
    else if(pointH > pointA)
    {
        timeH = timePlus(timeH, timeDiff(const32, event[n].second.second));
    }
    if(pointH > pointA)
    {
        cout << 'H' << " ";
    }
    else
    {
        cout << 'A' << " ";
    }

    cout << timeH.first;
    cout << ":";
    cout << setfill('0') << setw(2) << timeH.second;
    cout << " ";

    cout << timeA.first << ":" << setfill('0') << setw(2) << timeA.second;

//    for(ll i = 0; i < n + 1; i++)
//    {
//        cout << event[i].first << " " << event[i].second.first << " " << event[i].second.second.first << " " << event[i].second.second.second << endl;
//    }


    return 0;
}
