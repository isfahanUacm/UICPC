n = int(input())
a_score, h_score, a_lead, h_lead, cur_time = 0, 0, 0, 0, 0
for i in range(n):
    team, score, event_time = input().split(" ")
    
    l = list(event_time.split(":"))
    event_time = (int(l[0])*60) + int(l[1])

    if a_score > h_score:
        a_lead += event_time - cur_time
    elif h_score > a_score:
        h_lead += event_time - cur_time
    
    cur_time = event_time

    if(team == 'H'):
        h_score += int(score)
    else:
        a_score += int(score)

a_res = ""
h_res = ""

if(a_score > h_score):
    a_lead += (32*60) - cur_time
    if h_lead%60 < 10:
        h_res = (str(h_lead//60)) + ":" + "0"+ (str(h_lead%60))
    else:
        h_res = (str(h_lead//60)) + ":" + (str(h_lead%60))
    if a_lead%60 >= 10:
        a_res = (str(a_lead//60)) + ":" + (str(a_lead%60))
    else:
        a_res = (str(a_lead//60)) + ":" + "0"+ (str(a_lead%60))
    print("A ",h_res, " ", a_res, sep="")
elif a_score < h_score:
    h_lead += (32*60) - cur_time
    if h_lead%60 < 10:
        h_res = (str(h_lead//60)) + ":" + "0"+ (str(h_lead%60))
    else:
        h_res = (str(h_lead//60)) + ":" + (str(h_lead%60))
    if a_lead%60 >= 10:
        a_res = (str(a_lead//60)) + ":" + (str(a_lead%60))
    else:
        a_res = (str(a_lead//60)) + ":" + "0"+ (str(a_lead%60))
    print("H ", h_res, " ", a_res, sep="")
    