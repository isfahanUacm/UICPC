#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi
int n=0;
map<string,int> MAP;
vector<int> mat[15+5];
pair<int,int> each[20+5];
const int num = (1<<15)+5;
int dp[15+5][20+5][num];

int dist(int x, int y, int a, int b){
    return abs(x-a) + abs(y-b);
}
int tsm(int cur, int last, int mask){
    if(dp[cur][last][mask] != -1){
        return dp[cur][last][mask];
    }
    if(mask == (1<<n+1)-1){
        return dist(0, 0, each[last].first, each[last].second);
    }
    int mn = INT_MAX;
    for(int i=1; i<=n; i++){
        if(!(mask & (1<<i))){
            for(auto x : mat[i]){
                int d1 = dist(each[last].first, each[last].second,
                 each[x].first, each[x].second);
                int d2 = tsm(i, x, mask|(1<<i));
                mn = min(mn, d1+d2);
                dp[i][x][mask|(1<<i)] = d2;
            }
        }
    }
    return mn;
}
int main(){
    int N;
    cin>>N;
    int id=1;
    each[0]={0,0};
    for(int i=1; i<=N; i++){
        int r, c;
        string name;
        cin>>r>>c>>name;
        auto it = MAP.find(name);
        int nowid;
        each[i]={r,c};
        if(it==MAP.end()){
            n++;
            MAP[name]=id;
            mat[id].push_back(i);
            id++;
        }
        else{
            nowid=it->second;
            mat[nowid].push_back(i);
        }
    }
    for(int i=0; i<15+5; i++){
        for(int h=0; h<20+5; h++){
            for(int p=0; p<num; p++){
                dp[i][h][p]=-1;
            }
        }
    }
    cout<<tsm(0, 0, 1);
}