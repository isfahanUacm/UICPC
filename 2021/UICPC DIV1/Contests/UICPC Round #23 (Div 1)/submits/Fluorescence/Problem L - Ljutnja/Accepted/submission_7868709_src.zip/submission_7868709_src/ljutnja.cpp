#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

lli ch, n;
const int num=100000+5;
lli arr[num];
int main(){
    cin>>ch>>n;
    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
    sort(arr, arr+n);
    lli maxNumber=arr[n-1], mxCount=1, sum=0;
    int TO;
    for(int i=n-2; i>=0; i--){
        TO = i;
        if(ch<=0) break;
        if(arr[i]==maxNumber){
            mxCount++;
        }
        else{
            lli dif = (maxNumber-arr[i])*mxCount;
            if(ch<=dif){
                lli up = ceil(double(ch)/double(mxCount));
                lli down = ch/mxCount;
                lli downSum = down*mxCount;
                lli numberUp = ch - downSum;
                sum += numberUp*(maxNumber-up)*(maxNumber-up);
                sum += (mxCount-numberUp)*(maxNumber-down)*(maxNumber-down);
                ch=0;
                break;
            }
            else{
                ch -= dif;
                maxNumber = arr[i];
                mxCount++;
            }
        }
    }
    if(ch > 0){
        lli up = ceil(double(ch)/double(mxCount));
        lli down = ch/mxCount;
        lli downSum = down*mxCount;
        lli numberUp = ch - downSum;
        sum += numberUp*(maxNumber-up)*(maxNumber-up);
        sum += (mxCount-numberUp)*(maxNumber-down)*(maxNumber-down);
        TO =-1;
    }
    for(int i=0; i<=TO; i++){
        sum += arr[i]*arr[i];
    }
    cout<<sum;
}