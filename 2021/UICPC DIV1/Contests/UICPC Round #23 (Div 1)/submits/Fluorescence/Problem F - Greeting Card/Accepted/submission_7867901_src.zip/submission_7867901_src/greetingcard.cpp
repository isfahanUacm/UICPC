#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int ax[12] = { 0, 0, 2018, -2018, 1118, 1118, -1118, -1118, 1680, 1680 , -1680, -1680 };
int ay[12] = { 2018, -2018, 0, 0, 1680, -1680, 1680, -1680, 1118, -1118, 1118, -1118 };

int main() {
    int n;
    cin >> n;
    pair<int, int> p;
    set<pair<int, int>> ms;
    for (int i = 0; i < n; i++) {
        cin >> p.first >> p.second;
        ms.insert(p);
    }

    

    int count = 0;

    while (!ms.empty()) {
        pair<int, int> it = *ms.begin();
        int cx = it.first;
        int cy = it.second;
        ms.erase(it);
        for (int i = 0; i < 12; i++) {
            int tx = ax[i];
            int ty = ay[i];
            auto it2 = ms.find({ cx+tx, cy+ty });
            if (it2 != ms.end()) {
                count++;
            }
        }
    }
    cout << count;
}