#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

int dis[10+5][10+5];
int n;
const int num = (1<<10)+5;
int dp[10+5][num];
int countDis(string a, string b){
    int sa=a.size(), sb=b.size();
    int i=0, j=0, sum=0;
    while(1){
        if(i==sa || j==sb) break;
        if(a[i] == b[j]){
            sum++;
            i++;
            j++;
        }
        else if(b[j]<a[i]){
            j++;
        }
        else{
            i++;
        }
    }
    return sum;
}
int cdp(int last, int mask){
    if(dp[last][mask] != -1){
        return dp[last][mask];
    }
    if(mask == (1<<n+1)-1){
        return 0;
    }
    int mn = INT_MAX;
    for(int i=1; i<=n; i++){
        if(!(mask & (1<<i))){
            int d1 = dis[last][i];
            int d2 = cdp(i, mask|(1<<i));
            dp[i][mask|(1<<i)] = d2;

            mn = min(mn, d1+d2);
        }
    }
    return mn;
}
int main(){
    cin>>n;
    vector<string> names;
    names.push_back("");
    for(int i=1; i<=n; i++){
        string s;
        cin>>s;
        names.push_back(s);
    }
    for(int i=0; i<n; i++){
        for(int j=i+1; j<=n; j++){
            dis[i][j] = dis[j][i] = countDis(names[i], names[j]);
        }
    }
    for(int i=0; i<15; i++){
        for(int j=0; j<num; j++){
            dp[i][j]=-1;
        }
    }
    
    cout<<cdp(0, 1);
}