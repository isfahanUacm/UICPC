#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 1e5+10;
ll n,m;
ll dist1[mx];
ll dist2[mx];
vector<pair<ll,ll>> adj[mx];
set<pair<ll,ll>> pq2;
set<pair<ll,ll>> pq;
void dijksrta1(){
    dist1[0] = 0;
    pq.insert({0,0});
    while(pq.size()){
        ll u = pq.begin()->second;
        pq.erase(pq.begin());
        for(auto v:adj[u]){
            if(dist1[u]+v.second<dist1[v.first]){
                pq.erase(make_pair(dist1[v.first],v.first));
                dist1[v.first]=dist1[u]+v.second;
                pq.insert(make_pair(dist1[v.first],v.first));
            }
        }
    }
}
void dijksrta2(){
    dist2[0] = 0;
    pq2.insert({0,0});
    while(pq2.size()){
        ll u = pq2.begin()->second;
        ll hu = dist2[u];
        ll huh = hu;
        pq2.erase(pq2.begin());
        for(auto v:adj[u]) {
            ll ht;
            hu %= 24;
            if (hu + v.second <= 12)
                ht = v.second + huh;
            else {
                ht = v.second + huh + (24 - hu);
            }


            if(ht<dist2[v.first]){
                pq2.erase({dist2[v.first], v.first});
                dist2[v.first]=ht;
                pq2.insert({dist2[v.first], v.first});
            }
        }
    }
}
int main(){
    for(ll i=0;i<mx;i++){
        dist1[i] = LONG_LONG_MAX / 5;
        dist2[i] = LONG_LONG_MAX / 5;
    }
    cin >> n >> m;
    for(ll i=0;i<m;i++){
        ll u,v,w;
        cin >> u >> v >> w;
        adj[u].emplace_back(v,w);
        adj[v].emplace_back(u,w);
    }
    dijksrta1();
    dijksrta2();
    ll ans1 = dist1[n-1]/12*24 + dist1[n - 1] % 12;

    ll t = dist2[n - 1] % 24;
    if (t > 12)
        return 1;
    cout<<dist2[n-1]-ans1<<endl;
    return 0;
}