#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    ll m, n;
    cin >> m >> n;
    ll arr[n + 1];
    ll brr[n + 1];
    for (ll i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    arr[n] = 0;
    sort(arr, arr + n, greater<>());
    ll add = 0;
    memset(brr, 0, sizeof(brr));

    for (ll i = 0; i < n; ++i) {
        add += (arr[i] - arr[i + 1]) * (i + 1);
        brr[i] = arr[i] - arr[i + 1];
        if (add > m) {
            ll z = (add - m) / (i + 1);
            ll b = (add - m) % (i + 1);
            for (ll j = 0; j <= i; ++j) {
                arr[j] += z;
            }
            for (ll j = 0; j < b; ++j) {
                arr[j]++;
            }
            break;
        }
    }

    ll rmv = 0;
    ll ans = 0;
    for (ll i = n - 1; i >= 0; --i) {
        rmv += brr[i];
        ans += (arr[i] - rmv) * (arr[i] - rmv);
    }

    cout << ans << endl;
}