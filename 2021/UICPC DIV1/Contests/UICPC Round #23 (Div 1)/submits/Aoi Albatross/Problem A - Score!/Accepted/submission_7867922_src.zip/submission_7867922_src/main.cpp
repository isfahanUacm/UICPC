#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    int h = 0, a = 0;
    int lh = 0, la = 0;
    int lastT = 0;

    for (int i = 0; i < n; ++i) {
        string val, temp;
        int s;
        cin >> val >> s >> temp;
        int ss = stoi(temp.substr(0, temp.find(':'))) * 60 + stoi(temp.substr(temp.find(':') + 1));

        if (h > a) {
            lh += ss - lastT;
        }
        else if (h < a) {
            la += ss - lastT;
        }

        if (val == "H") {
            h += s;
        }
        else {
            a += s;
        }
        lastT = ss;
    }
    if (a > h) {
        la += 32 * 60 - lastT;
    }
    else if (h > a ){
        lh += 32 * 60 - lastT;
    }

    string hs = to_string(lh % 60);
    if (hs.size() == 1) {
        hs = "0" + hs;
    }

    string as = to_string(la % 60);
    if (as.size() == 1) {
        as = "0" + as;
    }

    string H1 = to_string(lh / 60) + ":" + hs;
    string A1 = to_string(la / 60) + ":" + as;

    if (h > a) {
        cout << 'H' << ' ' << H1 << ' ' << A1 << endl;
    }
    else {
        cout << 'A' << ' ' << H1 << ' ' << A1 << endl;
    }
}