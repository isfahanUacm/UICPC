import datetime

n = int(input())

h_time = datetime.timedelta(minutes=0, seconds=0)
a_time = datetime.timedelta(minutes=0, seconds=0)

h_score, a_score = 0, 0

prev_t = datetime.timedelta(minutes=0, seconds=0)

# a=0, h=1
winner = -1
flag = False
for i in range(n):
    w_team, point, time = input().split()
    if w_team == 'H':
        h_score += int(point)
    else:
        a_score += int(point)

    tlist = time.split(":")
    t = datetime.timedelta(minutes=int(tlist[0]), seconds=int(tlist[1]))

    if flag:
        flag = False
        if winner == 1:
            h_time += t - prev_t
        else:
            a_time += t - prev_t

    if h_score > a_score:
        flag = True
        winner = 1
    elif a_score > h_score:
        flag = True
        winner = 0
    else:
        winner = -1

    prev_t = t

total = datetime.timedelta(minutes=32, seconds=0)

if winner == 1:
    h_time += total - prev_t
    hls = str(h_time).split(':')
    als = str(a_time).split(':')
    print('H {}:{} {}:{}'.format(int(hls[1]), hls[2], int(als[1]), als[2]))
else:
    a_time += total - prev_t
    hls = str(h_time).split(':')
    als = str(a_time).split(':')
    print('A {}:{} {}:{}'.format(int(hls[1]), hls[2], int(als[1]), als[2]))
