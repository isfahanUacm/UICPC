#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1e5 + 10;
vector<ll> fenwickStep1;
void addStep1(ll k, ll x)
{
    while(k < fenwickStep1.size())
    {
        fenwickStep1[k] += x;
        k += k & (-k);
    }
}
ll sumStep1(ll k)
{
    ll result = 0;
    while(k)
    {
        result += fenwickStep1[k];
        k -= k & (-k);
    }
    return result;
}

vector<ll> fenwickStep2;
void addStep2(ll k, ll x)
{
    while(k < fenwickStep2.size())
    {
        fenwickStep2[k] += x;
        k += k & (-k);
    }
}
ll sumStep2(ll k)
{
    ll result = 0;
    while(k)
    {
        result += fenwickStep2[k];
        k -= k & (-k);
    }
    return result;
}
int main()
{
    ll n;
    cin >> n;
    vector<ll> arr(n + 1);
    for(ll i = 1; i <= n; i++)
    {
        cin >> arr[i];
    }
    ll ans = 0;
    fenwickStep1 = vector<ll>(n + 1);
    fenwickStep2 = vector<ll>(n + 1);

    for(ll i = n; i >= 1; i--)
    {
        ll temp = sumStep2(arr[i] - 1);
        ans += temp;
        ll step1s = sumStep1(arr[i] - 1);
//        watch(step1s);
        addStep1(arr[i], 1);
        addStep2(arr[i], step1s);
    }
    cout << ans;
    return 0;
}