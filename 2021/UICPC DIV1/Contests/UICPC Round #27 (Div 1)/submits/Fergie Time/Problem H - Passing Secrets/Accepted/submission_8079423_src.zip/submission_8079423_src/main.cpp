#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1e5 + 10;
bool cmp(vector<string> a, vector<string> b)
{
    return a.size() < b.size();
}

set<string> split(string s)
{
    set<string> ans;
    string temp = "";
    for(char i : s)
    {
        if(i == ' ')
        {
            ans.insert(temp);
            temp = "";
        }
        else
        {
            temp += i;
        }
    }
    ans.insert(temp);
    return ans;
}

int main()
{
    string a, b;
    while(cin >> a >> b)
    {
        ll m;
        cin >> m;
        vector<set<string>> graph(m);
        getchar();
        for(ll i = 0; i < m; i++)
        {
            string s;
            getline(cin, s);
            graph[i] = split(s);
        }
        string index = a;
        map<string, ll> dist;
        map<string, string> parent;

        multiset<pair<ll, string>> q;
        q.insert({0, index});
        dist[index] = 0;
        parent[index] = "hsakdfhklj";

        dist[b] = LLONG_MAX;

        ll answer = -1;
        while(q.size())
        {
            string current = q.begin()->second;
            ll currentDist = q.begin()->first;
            q.erase(q.begin());
            for(ll i = 0; i < m; i++)
            {
                if(graph[i].find(current) != graph[i].end())
                {
                    for(string item: graph[i])
                    {
                        if(item != current)
                        {
                            if(dist.find(item) == dist.end())
                            {
                                dist[item] = LLONG_MAX;
                            }
                            if(currentDist + (ll)graph[i].size() - 2 < dist[item])
                            {
                                dist[item] = currentDist + (ll)graph[i].size() - 2;
                                parent[item] = current;
                                q.insert({currentDist + (ll)graph[i].size() - 2, item});
                            }
                        }
                    }
                }
            }
        }

        if(dist[b] == LLONG_MAX)
        {
            cout << "impossible" << endl;
        }
        else
        {
            vector<string> ans;
            index = b;
            while(index != a)
            {
                ans.push_back(index);
                index = parent[index];
            }
            ans.push_back(a);
            cout << dist[b] + ans.size() - 2 << " ";
            for(ll i = ans.size() - 1; i >= 0; i--)
            {
                cout << ans[i] << " ";
            }
            cout << endl;
        }
    }
    return 0;
}