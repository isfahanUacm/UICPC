#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 50010;

int main()
{
    ll n, X;
    cin >> n >> X;
    vector<ll>  price(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> price[i];
    }
    sort(price.begin(), price.end());
    set<ll> st;
    ll i = 0;
    for(i = 0; i < n; i++)
    {
        if(st.upper_bound(X - price[i]) != st.end())
        {
            break;
        }
        st.insert(price[i]);
    }
    cout << i;
    return 0;
}