#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1e5 + 10;
struct maxSegmentTree
{
    vector<ll> maxs;
    ll size;

    void init(ll n)
    {
        size = 1;
        while(size < n)
        {
            size *= 2;
        }
        maxs = vector<ll> (2 * size, 0);
    }
    void build(vector<ll> &arr, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            if(lx < arr.size())
            {
                maxs[x] = arr[lx];
            }
            return;
        }
        ll m = (lx + rx) / 2;
        build(arr, 2 * x + 1, lx, m);
        build(arr, 2 * x + 2, m, rx);
        maxs[x] = max(maxs[2 * x + 1], maxs[2 * x + 2]);
    }
    void buildFromVector(vector<ll> arr)
    {
        build(arr, 0, 0, size);
    }

    void set(ll v, ll i, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            maxs[x] = v;
            return;
        }
        ll m = (lx + rx) / 2;
        if(i < m)
        {
            set(v, i, 2 * x + 1, lx, m);
        }
        else
        {
            set(v, i, 2 * x + 2, m, rx);
        }
        maxs[x] = max(maxs[2 * x + 1], maxs[2 * x + 2]);
    }
    void set(ll v, ll i)
    {
        set(v, i, 0, 0, size);
    }

    ll getMax(ll l, ll r, ll x, ll lx, ll rx)
    {
        if(lx >= r || rx <= l)
        {
            return LLONG_MIN;
        }
        if(lx >= l && rx <= r)
        {
            return maxs[x];
        }
        ll m = (lx + rx) / 2;
        return max(getMax(l, r, 2 * x + 1, lx, m), getMax(l, r, 2 * x + 2, m, rx));
    }
    ll getMax(ll l, ll r)
    {
        return getMax(l, r, 0, 0, size);
    }
};

struct minSegmentTree
{
    vector<ll> mins;
    ll size;

    void init(ll n)
    {
        size = 1;
        while(size < n)
        {
            size *= 2;
        }
        mins = vector<ll> (2 * size, 0);
    }
    void build(vector<ll> &arr, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            if(lx < arr.size())
            {
                mins[x] = arr[lx];
            }
            return;
        }
        ll m = (lx + rx) / 2;
        build(arr, 2 * x + 1, lx, m);
        build(arr, 2 * x + 2, m, rx);
        mins[x] = min(mins[2 * x + 1], mins[2 * x + 2]);
    }
    void buildFromVector(vector<ll> arr)
    {
        build(arr, 0, 0, size);
    }

    void set(ll v, ll i, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            mins[x] = v;
            return;
        }
        ll m = (lx + rx) / 2;
        if(i < m)
        {
            set(v, i, 2 * x + 1, lx, m);
        }
        else
        {
            set(v, i, 2 * x + 2, m, rx);
        }
        mins[x] = min(mins[2 * x + 1], mins[2 * x + 2]);
    }
    void set(ll v, ll i)
    {
        set(v, i, 0, 0, size);
    }

    ll getMin(ll l, ll r, ll x, ll lx, ll rx)
    {
        if(lx >= r || rx <= l)
        {
            return LLONG_MAX;
        }
        if(lx >= l && rx <= r)
        {
            return mins[x];
        }
        ll m = (lx + rx) / 2;
        return min(getMin(l, r, 2 * x + 1, lx, m), getMin(l, r, 2 * x + 2, m, rx));
    }
    ll getMin(ll l, ll r)
    {
        return getMin(l, r, 0, 0, size);
    }
};
int main()
{
    ll n, k;
    cin >> n >> k;
    vector<ll> a(n, 0);
    for(ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    minSegmentTree minT;
    maxSegmentTree maxT;
    minT.init(n);
    maxT.init(n);
    minT.buildFromVector(a);
    maxT.buildFromVector(a);

    ll ans = LLONG_MAX;
    for(ll i = k; i <= n; i++)
    {
        ans = min(ans, maxT.getMax(i - k, i) - minT.getMin(i - k, i));
    }

    cout << ans;
    return 0;
}