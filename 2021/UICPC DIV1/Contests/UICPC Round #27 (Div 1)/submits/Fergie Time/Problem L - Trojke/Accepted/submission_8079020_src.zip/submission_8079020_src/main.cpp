#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

vector <pld> number;




int main()
{
    ll n;
    char s;
    cin >> n;
    number = vector<pld>();
    for (ll i=0;i<n;i++)
        for(ll j=0;j<n;j++)
        {
            cin >> s;
            if (s != '.')
                number.push_back({i,j});
        }

    //sort(number.begin(),number.end());
    ll ans = 0;
    double m , r;
    for(ll i=0;i<number.size();i++)
        for (ll j=i+1; j<number.size();j++)
            for(ll k=j+1;k<number.size();k++)
            {
                pld a = number[i];
                pld b = number[j];
                pld c = number[k];

                   if ((b.second - a.second) * (c.first - a.first) == (b.first - a.first) * (c.second - a.second))
                   {
                       ans ++;
                   }
            }


        cout << ans;

}
