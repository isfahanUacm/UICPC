#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1e5 + 10;
struct segmentTree
{
    vector<ll> sums;
    ll size;

    void init(ll n)
    {
        size = 1;
        while(size < n)
        {
            size *= 2;
        }
        sums = vector<ll> (2 * size, 0);
    }
    void build(vector<ll> &arr, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            if(lx < arr.size())
            {
                sums[x] = arr[lx];
            }
            return;
        }
        ll m = (lx + rx) / 2;
        build(arr, 2 * x + 1, lx, m);
        build(arr, 2 * x + 2, m, rx);
        sums[x] = sums[2 * x + 1] + sums[2 * x + 2];
    }
    void buildFromVector(vector<ll> arr)
    {
        build(arr, 0, 0, size);
    }

    void set(ll i, ll x, ll lx, ll rx)
    {
        if(lx == rx - 1)
        {
            sums[x] = (sums[x] == 0)? 1 : 0;
            return;
        }
        ll m = (lx + rx) / 2;
        if(i < m)
        {
            set(i, 2 * x + 1, lx, m);
        }
        else
        {
            set(i, 2 * x + 2, m, rx);
        }
        sums[x] = sums[2 * x + 1] + sums[2 * x + 2];
    }
    void set(ll i)
    {
        set(i, 0, 0, size);
    }

    ll getSum(ll l, ll r, ll x, ll lx, ll rx)
    {
        if(lx >= r || rx <= l)
        {
            return 0;
        }
        if(lx >= l && rx <= r)
        {
            return sums[x];
        }
        ll m = (lx + rx) / 2;
        return getSum(l, r, 2 * x + 1, lx, m) + getSum(l, r, 2 * x + 2, m, rx);
    }
    ll getSum(ll l, ll r)
    {
        return getSum(l, r, 0, 0, size);
    }
};
int main()
{
    ll n, k;
    cin >> n >> k;
    vector<ll> a(n, 0);
    segmentTree st;
    st.init(n);
    st.buildFromVector(a);
    for(ll q = 0; q < k; q++)
    {
        char act;
        cin >> act;
        if(act == 'F')
        {
            ll i;
            cin >> i;
            st.set(i);
        }
        else
        {
            ll l, r;
            cin >> l >> r;
            cout << st.getSum(l, r + 1) << endl;
        }
    }
    return 0;
}