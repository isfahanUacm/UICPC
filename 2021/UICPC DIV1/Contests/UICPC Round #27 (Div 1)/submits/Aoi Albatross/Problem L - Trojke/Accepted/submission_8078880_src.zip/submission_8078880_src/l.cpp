#include <bits/stdc++.h>
using namespace std;

typedef pair<double, double> pii;

vector <pii> num;
double m, y;
long long ans = 0;

void check(double i, double j){
      if (num[i].first - num[j].first == 0) m = 10000000;
      else m = (num[i].second - num[j].second) / (num[i].first - num[j].first);
      y = (num[i].second - m * num[i].first);
}

int main(){
      int n;
      char tmp;

      cin >> n;
      for (double i=n; i>0; i--)
            for (double j=1; j<=n; j++){
                  cin >> tmp;
                  if (tmp != '.')
                        num.push_back(pii(j, i));
            }
            
      for (double i=0; i<num.size(); i++)
            for (double j=0; j<num.size(); j++){
                  if (j != i){
                        check(i, j);
                        for (double k=0; k<num.size(); k++){
                              if (k != i and k != j and (abs((num[k].second - (m *num[k].first + y))) <= (0.00001)))
                                    ans++;
                        }
                  }
            }

      for (double i=0; i<num.size(); i++){
            for (double j=0; j<num.size(); j++){
                  if (i != j and num[i].first == num[j].first){
                        for (double k=0; k<num.size(); k++){
                              if (k != i and k != j and num[k].first == num[i].first)
                                    ans++;
                        }
                  }
            }
      }
      cout << ans/6 << endl;

      return 0;
}