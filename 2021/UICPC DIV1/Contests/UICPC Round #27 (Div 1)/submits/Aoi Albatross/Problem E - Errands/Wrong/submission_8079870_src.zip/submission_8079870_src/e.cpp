#include <bits/stdc++.h>
using namespace std;

typedef pair<double,double> pdd;

unordered_map<string, pdd> name;
vector <string> str;
stack <string> A;

int n;

double dis(double x, double y, int index){
      return sqrt((x-name[str[index]].first)*(x-name[str[index]].first) + (y-name[str[index]].second)*(y-name[str[index]].second));
}

int main(){
      string ee;
      cin >> n;
      for (int i=0; i<n; i++){
            double x, y;
            string s;
            if (i == 1) ee = s;
            cin >> s >> x >> y;
            name[s] = pdd(x, y);
      }
      
      cin.ignore();
      string s, tmp;
      while (getline(cin, s)){
            str.clear();
            stringstream ss(s);
            while (ss >> tmp)
                  str.push_back(tmp);
            
            int num = 0, index = 0;
            double x = name[ee].first, y = name[ee].second;
            while (num != (1<<str.size())-1){
                  double ans = 1000000000;
                  for (int i=0; i<str.size(); i++){
                        if (!(1<<i & num)){
                              if (dis(x, y, i) <= ans){
                                    ans = dis(x, y, i);
                                    index = i;
                              }
                        }
                  }
                  cout << str[index] << " ";
                  num = (1<<index | num);
                  x = name[str[index]].first, y = name[str[index]].second;
            }
            cout << endl;
      }



      return 0;
}