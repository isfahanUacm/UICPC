#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

map<string, int> id;
map<int, pair<int, int>> di;
map<int, string> lid;


int hx, hy;
int ex, ey;
int eh;

double_t dist(double_t x1, double_t y1, double_t x2, double_t y2) {
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

double_t calc(vector<int> vc) {
    double_t ans = 0;
    int lx = hx;
    int ly = hy;
    vc.emplace_back(eh);
    for (auto temp : vc) {
        auto i = di[temp];
        ans += dist(lx, ly, i.first, i.second);
        lx = i.first;
        ly = i.second;
    }
    return ans;
}

int main(){
    int n;
    cin >> n;

    for (int i = 0; i < n; ++i) {
        string a;
        double_t x, y;
        cin >> a >> x >> y;
        lid[i] = a;
        id[a] = i;
        di[i] = {x, y};
        if (a == "home") {
            hx = x;
            hy = y;
        }
        else if (a == "work") {
            ex = x;
            ey = y;
            eh = i;
        }
    }

    string a, temp;
    cin.ignore();

    while (getline(cin, a)) {
        double_t ans = LONG_LONG_MAX;
        vector<int> aa;
        vector<int> vc;
        stringstream ss(a);
        while (ss >> temp) {
            vc.emplace_back(id[temp]);
        }
        sort(vc.begin(), vc.end());
        do {
            double_t dist = calc(vc);
            if (dist < ans) {
                aa = vc;
            }
        } while (next_permutation(vc.begin(), vc.end()));

        for (int i = aa.size() - 1; i >= 0; --i) {
            cout << lid[aa[i]] << ' ';
        }
        cout << endl;
    }
}