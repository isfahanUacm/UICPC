#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    map<int, int> st;
    for (int i = 0; i < n; ++i) {
        int temp;
        cin >> temp;
        st[temp] = i;
    }
    vector<int> arr;

    for (int i = 0; i < n; ++i) {
        int temp;
        cin >> temp;
        arr.push_back(st[temp]);
    }

    vector<int> L(arr.size());
    int lisCount = 0;

    for (int i = 0; i < arr.size(); ++i) {
        int pos = lower_bound(L.begin(), L.begin() + lisCount, arr[i]) - L.begin();
        L[pos] = arr[i];
        if (pos == lisCount) {
            ++lisCount;
        }
    }

    cout << 2 << ' ' << lisCount + 1 << endl;

    return 0;
}