#include <bits/stdc++.h>
using namespace std;

int num[1000000];

int main(){
      int n, k;
      cin >> n >> k;
      for (int i=0; i<n; i++)
            cin >> num[i];

      sort(num, num+n);

      for (int i=1; i<n; i++){
            if (num[i]+num[i-1] > k){
                  cout << i << endl;
                  return 0;
            }
      }
      cout << n << endl;

      return 0;
}