#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int n, k, p;
int bs[1000010];
int arr[1003];

int main() {
    cin >> n >> k;
    p = sqrt(n);


    for (int i = 0; i < k; ++i) {
        char t;
        cin >> t;
        if (t == 'F') {
            int pos;
            cin >> pos;
            pos--;
            int x = pos / p;
            if (bs[pos] == 0) {
                arr[x]++;
            }
            else {
                arr[x]--;
            }
            bs[pos] = 1 ^ bs[pos];
        }
        else {
            int l, h;
            cin >> l >> h;
            l--;
            h--;

            int pl = l / p;
            int ph = h / p;

            int ans = 0;

            int tg = (pl + 1) * p;
            tg = min(tg, h + 1);

            for (int j = l; j < tg; ++j) {
                ans += bs[j];
            }

            for (int j = pl + 1; j < ph; ++j) {
                ans += arr[j];
            }
            tg = (ph) * p;

            if (ph != pl) {
                for (int j = tg; j <= h; ++j) {
                    ans += bs[j];
                }
            }
            cout << ans << endl;
        }
    }
}

