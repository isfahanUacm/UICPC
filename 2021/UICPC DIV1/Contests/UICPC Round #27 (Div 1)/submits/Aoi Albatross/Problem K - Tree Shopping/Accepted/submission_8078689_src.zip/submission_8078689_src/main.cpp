#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int cnt[105];

ll test() {
    int mi = INT_MAX;
    int mx = INT_MIN;

    for (int i = 1; i <= 100; ++i) {
        if (cnt[i]) {
            mi = min(mi, i);
            mx = max(mx, i);
        }
    }
    return mx - mi;
}

int main() {
    int n, m;
    cin >> n >> m;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    memset(cnt, 0, sizeof(cnt));

    ll ans = LONG_LONG_MAX;
    for (int i = 0; i < m; ++i) {
        cnt[arr[i]]++;
    }

    ans = min(ans, test());

    for (int i = m; i < n; ++i) {
        cnt[arr[i]]++;
        cnt[arr[i - m]]--;
        ans = min(ans, test());
    }

    cout << ans << endl;
}

