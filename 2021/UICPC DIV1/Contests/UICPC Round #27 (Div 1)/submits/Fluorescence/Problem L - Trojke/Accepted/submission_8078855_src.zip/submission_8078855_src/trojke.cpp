#include <bits/stdc++.h>
using namespace std;

int triangle_area(int x1, int x2, int x3, int y1, int y2, int y3){
    return x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2);
}

int main(){
    int n;
    char grid[105][105];
    vector<pair<int, int>> lett;
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin>>grid[i][j];
            if(grid[i][j] != '.'){
                lett.push_back({i, j});
            }
        }
    }
    
    int cnt = 0;
    for (int i = 0; i < lett.size(); i++)
    {
        for (int j = i+1; j < lett.size(); j++)
        {
            //if(i == j) continue;
            for (int k = j+1; k < lett.size(); k++)
            {
                //if(j == k || i == k) continue;
                /*float mi_j = gra(lett[i].first, lett[j].first, lett[i].second, lett[j].second);
                float mi_k = gra(lett[i].first, lett[k].first, lett[i].second, lett[k].second);
                float mj_k = gra(lett[k].first, lett[j].first, lett[k].second, lett[j].second);*/
                //if(mi_j != -1 && mi_k != -1 && mj_k != -1)
                /*if(mi_j == mi_k && mi_k == mj_k) {
                    cout<<grid[lett[i].first][lett[i].second]<<" "<<grid[lett[j].first][lett[j].second]<<" "
                    <<grid[lett[k].first][lett[k].second]<<endl;
                    cnt++;
                }*/
                if(triangle_area(lett[i].first, lett[j].first, lett[k].first, 
                lett[i].second, lett[j].second, lett[k].second) == 0) cnt++;
            }
        }
    }
    cout<<cnt;
}