#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi
vector<string> name(5000+5);
int dist[5000+5];
int parent[5000+5];
map<string, int> MAP;
int start, destination;
int main(){
    string a, b;
    while(cin>>a>>b){
        MAP.clear(); name.clear();
        vector<pair<int, int>> edge[5000+5];
        int indx=0;
        MAP[a] = 0; name[0] = a; start = 0; dist[0]=INT_MAX;
        if(b != a){
            indx++;
            MAP[b] = 1; name[1] = b;
            destination=1;
            dist[1]=INT_MAX;
        }
        else destination=0;
        int n; cin>>n;
        string line;
        cin.ignore();
        while(n--){
            getline(cin, line);
            stringstream ss(line);
            string each;
            int size=0;
            vector<int> nodes;
            while(ss >> each){
                size++;
                auto it = MAP.find(each);
                if(it == MAP.end()){
                    indx++; MAP[each]=indx, name[indx]=each;
                    nodes.push_back(indx);
                    dist[indx]=INT_MAX;
                }
                else{
                    nodes.push_back(it->second);
                }
            }
            for(int i=0; i<size-1; i++){
                for(int j=i+1; j<size; j++){
                    edge[nodes[i]].push_back({size-2, nodes[j]});
                    edge[nodes[j]].push_back({size-2, nodes[i]});
                }
            }
        }
        //dijk();
        set<pair<int, int>> pq;
        dist[0] = 0; parent[0] = -1;
        pq.insert({0, 0});
        while(!pq.empty()){
            auto it = pq.begin();
            int d = it->first; int cur = it->second;
            pq.erase(pq.begin());
            if(d>dist[cur]) continue;

            for(auto p : edge[cur]){
                int w = p.first; int x = p.second;
                if(dist[x] > d+w){
                    dist[x] = d+w;
                    if(x != destination) dist[x]++;
                    pq.insert({dist[x], x});
                    parent[x] = cur;
                } 
            }
        }
        //end of dijk
        //dijk_path();
        vector<string> ans;
        int x = destination;
        if(dist[x] == INT_MAX){
            cout<<"impossible"<<endl;
            continue;
        }
        cout<<dist[x]<<" ";
        while(x != -1){
            ans.push_back(name[x]);
            x = parent[x];
        }
        for(int i=ans.size()-1; i>=0; i--){
            cout<<ans[i]<<" ";
        }
        cout<<endl;
        //end of dijk path
    }
}