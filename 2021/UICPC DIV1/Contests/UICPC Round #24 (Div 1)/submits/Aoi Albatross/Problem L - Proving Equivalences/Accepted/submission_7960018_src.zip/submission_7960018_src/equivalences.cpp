#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 40000;
vector<int> adj [MAX], adj_rev [MAX];
bool used[MAX];
int scNum[MAX];
stack<int> st;
int sc = 0;

void dfs1(int v) {
    used[v] = true;
    for (auto u : adj[v])
        if (!used[u])
            dfs1(u);
    st.push(v);
}

void dfs2(int v) {
    used[v] = true;
    scNum[v] = sc;
    for (auto u : adj_rev[v])
        if (!used[u])
            dfs2(u);
}

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        for (auto & x : adj)
            x.clear();
        for (auto & x : adj_rev)
            x.clear();
        memset(used, false, sizeof(used));
        memset(scNum, -1, sizeof(scNum));
        sc = 0;

        int n, m;
        cin >> n >> m;
        int deg[MAX];
        int ideg[MAX];
        memset(deg, 0, sizeof(deg));
        memset(ideg, 0, sizeof(ideg));

        for (int i = 0; i < m; ++i) {
            int a, b;
            cin >> a >> b;
            adj[a].push_back(b);
            adj_rev[b].push_back(a);
        }

        for (int i = 1; i <= n; i++)
            if (!used[i])
                dfs1(i);

        memset(used, 0, sizeof(used));

        while (!st.empty()) {
            int v = st.top();
            st.pop();
            if (!used[v]) {
                sc++;
                dfs2(v);
            }
        }

        for (int i = 1; i <= n; ++i) {
            for (auto v: adj[i]) {
                if (scNum[i] != scNum[v]) {
                    deg[scNum[i]]++;
                    ideg[scNum[v]]++;
                }
            }
        }

        if (sc == 1) {
            cout << 0 << endl;
            continue;
        }

        int od = 0;
        int id = 0;
        for (int i = 1; i <= sc; ++i) {
            if (deg[i] == 0)
                od++;
            if (ideg[i] == 0) 
                id++;
        }
        cout << max(id,od) << endl;
    }
}