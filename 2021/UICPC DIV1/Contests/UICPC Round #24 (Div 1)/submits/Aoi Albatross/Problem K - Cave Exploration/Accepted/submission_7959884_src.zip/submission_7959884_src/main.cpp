#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 150;
int arr[MAX][MAX];
ll ans[MAX][MAX];
int n;

pair<int, int> mv[] = {
        {0, 1},
        {1, 0},
        {0, -1},
        {-1, 0},
};

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < n;
}

void dfs(int x, int y, int h) {
    if (h >= ans[x][y])
        return;
    ans[x][y] = h;

    for (auto temp: mv) {
        int nx = x + temp.first;
        int ny = y + temp.second;

        if (ir(nx, ny))
            dfs(nx, ny, max(arr[nx][ny], h));
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            ans[i][j] = INT_MAX;
            cin >> arr[i][j];
        }
    }
    dfs(0, 0, 0);
    cout << ans[n - 1][n - 1] << endl;
}
