#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool cmp(pair<ll,ll> a, pair<ll,ll> b){
    if(a.second==b.second){
        return a.first < b.first;
    }
    return a.second<b.second;
}
int main() {
    ll n, k;
    cin >> n >> k;
    multiset<ll> pq;
    vector<pair<ll, ll>> vc;
    for (ll i = 0; i < n; ++i) {
        ll a, b;
        cin >> a >> b;
        vc.emplace_back(a,b);
    }

    sort(vc.begin(), vc.end(),cmp);
    ll ans = 0;
    for(auto v:vc){
        if(pq.empty()){
            pq.insert(v.second);
            ans++;
            continue;
        }
        auto ev = pq.lower_bound(v.first);
        if(ev!=pq.begin()) {
            ev = prev(ev);
            pq.erase(ev);
            pq.insert(v.second);
            ans++;
        }
        else if(pq.size()<k){
            pq.insert(v.second);
            ans++;
        }
    }
    cout << ans << endl;
}