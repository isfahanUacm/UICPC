#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    ll n, m;
    cin >> n >> m;
    priority_queue<ll, vector<ll>, greater<>> pq;
    vector<pair<ll, ll>> vc;

    for (ll i = 0; i < n; ++i) {
        ll a, b;
        cin >> a >> b;
        vc.emplace_back(b, a);
    }

    sort(vc.begin(), vc.end());
    ll ans = 0;
    for (ll i = 0; i < n; ++i) {
        if (pq.empty()) {
            pq.push(vc[i].first);
            ans++;
        }
        else if (pq.top() < vc[i].second) {
            pq.pop();
            pq.push(vc[i].first);
            ans++;
        }
        else if (pq.size() < m){
            pq.push(vc[i].first);
            ans++;
        }
    }
    cout << ans << endl;
}
