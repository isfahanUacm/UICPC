#include <bits/stdc++.h>
using namespace std;
#define M 2000
long long c, l, num[M][M], cl[M], sl[M], el[M], dp[M][M];
pair <pair <int, int>, int> ll[M];

bool check(pair <int, pair <int, int>> a, pair <int, pair <int, int>> b){
      if (a.second.first < b.second.first) return true;
      if (a.second.first == b.second.first and a.second.second < b.second.second) return true;
      if (a.second.first == b.second.first and a.second.second == b.second.second and a.first < b.first) return true;
      return false;
}

long long solve(long long i, long long pre){
      if (i == l) return 0;
      if (dp[i][pre] != -1) return dp[i][pre];

      long long tmp1 = -1;
      if (pre == 1500)
            tmp1 = 1 + solve(i+1, i);
      
      else if ((ll[pre].first.second + num[ll[i].second][ll[pre].second]) <= ll[i].first.first)
            tmp1 = 1 + solve (i+1, i);

      long long tmp2 = solve(i+1, pre);

      return dp[i][pre] = max(tmp1, tmp2);
}

int main(){
      long long tc;
      cin >> tc;
      while (tc--){
            cin >> c >> l;
            for (long long i=0; i<(c*(c-1))/2; i++){
                  long long x, y, tmp;
                  cin >> x >> y >> tmp;
                  num[x][y] = tmp;
                  num[y][x] = tmp;
            }
            for (int i=0; i<c; i++)
                  num[i][i] = 0;

            for (long long k = 0; k < c; k++)
                  for (long long i = 0; i < c; i++)
                        for (long long j = 0; j < c; j++)
                              num[i][j] = min(num[i][j], num[i][k] + num[k][j]);
            
            for (long long i=0; i<l; i++){
                  int tmp;
                  cin >> tmp >> ll[i].first.first >> ll[i].first.second;
                  ll[i].second = tmp;
            }
            
            sort(ll, ll+l);

            memset(dp, -1, sizeof(dp));
            cout << solve(0, 1500) << endl;
      }

      return 0;
}