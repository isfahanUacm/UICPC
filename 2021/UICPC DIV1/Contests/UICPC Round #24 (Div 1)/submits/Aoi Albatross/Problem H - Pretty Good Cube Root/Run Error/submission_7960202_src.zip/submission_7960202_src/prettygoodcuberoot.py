import sys
line = sys.stdin.readline()
while line:
    x = int(line)
    ans = int(x**(1/3))
    best = ans
    dist = abs(x-(ans**3))
    for i in range(0,10):
        if(abs((ans+i)**3-x)<dist):
            dist = abs((ans+i)**3-x)
            best = ans+i
    print(best)
    line = sys.stdin.readline()