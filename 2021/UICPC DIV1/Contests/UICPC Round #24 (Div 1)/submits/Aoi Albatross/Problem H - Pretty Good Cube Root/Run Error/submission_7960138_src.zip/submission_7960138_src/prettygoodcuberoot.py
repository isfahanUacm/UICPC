from sys import stdin
for line in stdin:
    if line == '':
        break
    x = int(line)
    ans = int(x**(1/3))
    best = ans
    dist = x-(ans**3)
    for i in range(1,20):
        if(abs((ans+1)**3-x)<dist):
            dist = abs((ans+i)**3-x)
            best = ans+i
    print(best)

     