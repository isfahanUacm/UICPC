import sys
import decimal
line = sys.stdin.readline()
while line:
    x = int(line)
    l =0
    h = x//2
    ans = x
    while(l<h):
        ans = (l+h)//2
        if(abs(ans**3-x)<abs((ans-1)**3-x) and abs(ans**3-x)<abs((ans+1)**3-x) ):
            break
        elif(abs(ans**3-x)>abs((ans-1)**3-x)):
            h = ans
        else:
            l=ans+1
    print(ans)
    line = sys.stdin.readline()