#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;



int main()
{
    ll t;
    cin >> t;
    while(t--){

        ll c,l;
        cin >> c >> l;
         ll **graph = new ll *[c];
         for (ll i=0;i<c;i++)
             graph[i] = new ll [c];

        for (ll i=0;i<(c*(c-1))/2; i++)
        {
            ll x,y,z;
            cin >> x >> y >> z;
            graph[x][y]= z;
            graph[y][x] = z;
        }
        vector <pair<ll,pll>> lectures(l);

        for (ll i=0;i<l;i++)
        {
            ll x,y,z;
            cin >> x >> y >> z;
            lectures[i] = {y,{z,x}};
        }

        vector <ll> sample(c,0);
        vector <vector <ll>> distance(c,sample);
        for (ll i=0;i<c;i++)
            for (ll j=0;j<c;j++)
            {
                if (i == j)
                    distance[i][j] = 0;
                else
                {
                    distance[i][j] = graph[i][j];
                }
            }
        for (ll k=0;k<c;k++)
        {
            for (ll i=0;i<c;i++)
            {
                for (ll j=0;j<c;j++)
                {
                       if (distance[i][k] + distance[k][j] < distance[i][j])
                           distance[i][j] = distance[i][k]+ distance[k][j];
                }
            }
        }

      vector<ll> dp (l,1);
      sort(lectures.begin(),lectures.end());
      ll ans = 1;
      for (ll i=1;i<l;i++)
      {
          for (ll j=0;j<i;j++)
          {
              if (distance[lectures[i].second.second][lectures[j].second.second] <= lectures[i].first - lectures[j].second.first)
              {
                  if (dp[i] < dp[j]+1)
                  {
                      dp[i] = dp[j]+1;
                  }
              }

          }

          if (dp[i] > ans)
          {
              ans = dp[i];
              //cout << dp[lectures[i].second.second]<<endl;
          }
      }

       cout << ans << endl;
    }

}
