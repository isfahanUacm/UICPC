#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;



int main()
{
    int n ,k;
    cin >> n >> k;
   // vector<ll> sample(n);
    vector<pll> pokemon1;
    vector<pll> pokemon2;
    vector<pll> pokemon3;
    set<ll> choose;
    pokemon1 = vector<pll>(n);
    pokemon2 = vector<pll>(n);
    pokemon3 = vector<pll>(n);
    for(ll i=0;i<n;i++)
    {
        cin >> pokemon1[i].first;
        cin >> pokemon2[i].first;
        cin >> pokemon3[i].first;
        pokemon1[i].second = i;
        pokemon2[i].second = i;
        pokemon3[i].second = i;
    }

    sort(pokemon1.rbegin(),pokemon1.rend());
    sort(pokemon2.rbegin(),pokemon2.rend());
    sort(pokemon3.rbegin(),pokemon3.rend());

    for (ll i=0;i<k;i++)
    {
        choose.insert(pokemon1[i].second);
        choose.insert(pokemon2[i].second);
        choose.insert(pokemon3[i].second);
    }
    cout << choose.size();


}
