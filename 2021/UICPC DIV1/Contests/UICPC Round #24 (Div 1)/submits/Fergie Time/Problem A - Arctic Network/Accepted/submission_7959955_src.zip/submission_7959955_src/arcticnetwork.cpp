#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<ll> parents;
vector<ll> sizes;
ld disto(pll a, pll b){
    return sqrt(pow((b.second - a.second),2) + pow((b.first-a.first),2));
}
ll find(ll x){
    if(x == parents[x] ) return x;
    return find(parents[x]);
}
bool same(ll x, ll y){
    ll px = find(x);
    ll py = find(y);
    if(px == py){
        return true;
    }
    else{
        return false;
    }
}
int main()
{
    ll t;
    cin>>t;
    while (t--) {
        ll s,p;
        cin>>s>>p;
        vector<pll> numarr(p);
        ll x,y;
        for(ll i=0; i<p;i++){
            cin>>x>>y;
            numarr[i]={x,y};
        }
        vector<pair<ld,pll>> graph;
        for(ll i=0; i<p;i++){
            for(ll j=i+1;j<p;j++){
                ld dist=disto(numarr[i],numarr[j]);
                graph.push_back({dist,{i,j}});
            }
        }
        sort(graph.begin(),graph.end());
        parents = vector<ll> (p,-1);
        sizes = vector<ll> (p,0);
        for(ll i = 0; i < p; i++){
           if(parents[i] == -1){
             parents[i] = i;
             sizes[i] = 1;
            }
        }
        ld ans=LDBL_MAX;
        vector<ld> dis;
        for(ll i = 0; i <(p*(p-1))/2; i++){
              pll temp = graph[i].second;

              ll px = find(temp.first);
              ll py = find(temp.second);
              if(px != py){

                   if(sizes[px] < sizes[py]){
                           parents[px] = py;
                           sizes[py] += sizes[px];
                   }
                   else{
                       parents[py] = px;
                       sizes[px] += sizes[py];
                   }
                   dis.push_back(graph[i].first);

                   }
           }

        ans=dis[dis.size()-s];
        cout<<fixed<<setprecision(2)<<ans<<endl;

    }

}
