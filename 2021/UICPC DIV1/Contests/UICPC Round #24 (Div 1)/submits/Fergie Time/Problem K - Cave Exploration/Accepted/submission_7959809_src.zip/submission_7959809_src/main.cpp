#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

ll n;
ll h[110][110];
bool visited[110][110];

ll height;
vector<ll> ans;

void bfs(pll index)
{
    multiset<tuple<ll, ll, ll>> q;
    q.insert({h[0][0], 0, 0});
    while(q.size())
    {
        pll current = {get<1>(*q.begin()), get<2>(*q.begin())};
        ll currentH = get<0>(*q.begin());
        q.erase(q.begin());
        visited[current.first][current.second] = true;
        ans.push_back(h[current.first][current.second]);
        if(current.first == n - 1 && current.second == n - 1)
        {
            return;
        }
        vector<pll> dirs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        for(pll dir: dirs)
        {
            ll x = current.first + dir.first;
            ll y = current.second + dir.second;
            if(x >= 0 && x < n && y >= 0 && y < n)
            {
                if(!visited[x][y])
                {
                    q.insert({h[x][y], x, y});
                }
            }
        }
    }
}
int main()
{
    cin >> n;
    for(ll i = 0; i < n; i++)
    {
        for(ll j = 0; j < n; j++)
        {
            cin >> h[i][j];
        }
    }
    bfs({0, 0});
    cout << *max_element(ans.begin(), ans.end());
    return 0;
}
