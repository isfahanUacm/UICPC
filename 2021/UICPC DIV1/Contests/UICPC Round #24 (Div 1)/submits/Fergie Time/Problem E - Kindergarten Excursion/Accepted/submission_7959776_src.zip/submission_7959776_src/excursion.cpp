#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    string s;
    cin>>s;
    ll ans=0,num1=0,num2=0,num0=0;
    for(ll i=0;i<s.size();i++){
        if(s[i]=='0'){
            ans+=(num1+num2);
            num0+=1;
        }
        if(s[i]=='1'){
            ans+=(num2);
            num1+=1;
        }
        if(s[i]=='2'){
            num2+=1;
        }
    }

    cout<<ans<<endl;
}
