mod = (10 ** 9) + 7
t = int(input())
for i in range(t):
    n = int(input())
    print((8 * pow(9, n - 1, mod) % mod))
