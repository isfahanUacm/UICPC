import sys

for line in sys.stdin:
    x = int(line)
    l = 1
    r = 10 ** 167 + 1
    while r > l:
        # print(l, r)
        mid = (l + r) // 2
        if mid ** 3 < x:
            l = mid + 1
        elif mid ** 3 >= x:
            r = mid
    if abs(x - (l ** 3)) < abs(x - ((l - 1) ** 3)):
        print(l)
    else:
        print(l - 1)
