#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 20010;

vector<vector<ll>> graph;
vector<vector<ll>> graphRev;
bool visited[maxN];
ll n, m;
ll group;
ll groups[maxN];
ll degreeIn[maxN];
ll degreeOut[maxN];

stack<ll> st1;

void dfs1(ll index)
{
    visited[index] = true;
    for (ll i: graph[index])
    {
        if (!visited[i])
        {
            dfs1(i);
        }
    }
    st1.push(index);
}

void dfs2(ll index)
{
    groups[index] = group;
    visited[index] = true;
    for (ll i: graphRev[index])
    {
        if (!visited[i])
        {
            dfs2(i);
        }
    }
}

int main()
{
    ll t;
    cin >> t;
    while (t--)
    {
        cin >> n >> m;
        st1 = stack<ll>();
        graph = vector<vector<ll>>(n);
        graphRev = vector<vector<ll>>(n);
        for (ll i = 0; i < m; i++)
        {
            ll a, b;
            cin >> a >> b;
            a--;
            b--;
            graph[a].push_back(b);
            graphRev[b].push_back(a);
        }
        fill(visited, visited + n, false);
        for (ll i = 0; i < n; i++)
        {
            if (!visited[i])
            {
                dfs1(i);
            }
        }
        group = 0;
        fill(visited, visited + n, false);
        fill(groups, groups + n, -1);
        while(st1.size())
        {
            ll i = st1.top();
            st1.pop();
            if (!visited[i])
            {
                dfs2(i);
                group++;
            }
        }
        fill(degreeIn, degreeIn + n, 0);
        fill(degreeOut, degreeOut + n, 0);

        for (ll i = 0; i < n; i++)
        {
            for (ll j: graph[i])
            {
                if (groups[i] != groups[j])
                {
                    if(degreeOut[groups[i]] == -1)
                    {
                        degreeOut[groups[i]] = 0;
                    }
                    if(degreeIn[groups[j]] == -1)
                    {
                        degreeIn[groups[j]] = 0;
                    }
                    degreeOut[groups[i]]++;
                    degreeIn [groups[j]]++;
                }
            }
        }
        ll degreeInNum = 0;
        ll degreeOutNum = 0;
        for (ll i = 0; i < group; i++)
        {
            if(degreeIn[i] == 0)
            {
                degreeInNum++;
            }
            if(degreeOut[i] == 0)
            {
                degreeOutNum++;
            }
        }
        cout << max(degreeInNum, degreeOutNum) << endl;
    }
    return 0;
}
