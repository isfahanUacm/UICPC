#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1505;

ll n;
string grid[maxN];
bool visited[maxN][maxN];
ll dist[maxN][maxN];


int main()
{
    cin >> n;
    for(ll i = 0; i < n; i++)
    {
        cin >> grid[i];
    }
    fill(&dist[0][0], &dist[n - 1][n - 1], LLONG_MAX);
    multiset<tuple<ll, ll, ll>> q;
    for(ll i = 0; i < n; i++)
    {
        for(ll j = 0; j < n; j++)
        {
            if(grid[i][j] == '3')
            {
                q.insert({0, i, j});
                dist[i][j] = 0;
            }
        }
    }
    ll ans = 0;
    while(q.size())
    {
        pll current = {get<1>(*q.begin()), get<2>(*q.begin())};
        ll currentDist = get<0>(*q.begin());
        q.erase(q.begin());
        visited[current.first][current.second] = true;
        if(grid[current.first][current.second] == '1')
        {
            ans = max(ans, currentDist);
        }
        vector<pll> dirs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        for(pll dir: dirs)
        {
            ll x = current.first + dir.first;
            ll y = current.second + dir.second;
            if(x >= 0 && x < n && y >= 0 && y < n)
            {
                if(!visited[x][y] && currentDist + 1 < dist[x][y])
                {
                    q.insert({currentDist + 1, x, y});
                    dist[x][y] = currentDist + 1;
                }
            }
        }
    }
    cout << ans;
    return 0;
}
