#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi
int dx[4]={0,-1,0,1};
int dy[4]={-1,0,1,0};
int n;
const int num = 1500+5;
char grid[num][num];
bool visited[num][num];
pair<int,int> three;
vector<pair<int,int>> Q;
bool inrange(int x, int y){
    return (x>=0 && x<n && y>=0 && y<n);
}
void bfs(){
    int x = Q.front().first;
    int y = Q.front().second;
    Q.erase(Q.begin());
    visited[x][y]=1;
    if(grid[x][y]=='3'){
        three={x,y};
        return;
    }
    for(int i=0; i<4; i++){
        int x2 = x+dx[i];
        int y2 = y+dy[i];
        if(inrange(x2,y2)){
            if(!visited[x2][y2]){
                Q.push_back({x2 ,y2});
            }
        }
    }
    bfs();
}
int main(){
    cin>>n;
    vector<pair<int,int>> ones;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            char ch;
            cin>>ch;
            grid[i][j]=ch;
            if(ch == '1'){
                ones.push_back({i, j});
            }
        }
    }
    int mx = -1;
    for(auto p : ones){
        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                visited[i][j]=0;
            }
        }
        Q.clear();
        Q.push_back(p);
        bfs();
        mx = max(mx, abs(p.first-three.first)+abs(p.second-three.second));
    }
    cout<<mx;
}