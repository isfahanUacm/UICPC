#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
int dx[4]={0,-1,0,1};
int dy[4]={-1,0,1,0};
int n;
const int num = 1500+5;
char grid[num][num];
bool visited[num][num];
queue<pair<int, int>> q;
int dist[num][num];

bool inrange(int x, int y){
    return (x>=0 && x<n && y>=0 && y<n);
}

int main(){
    cin>>n;
    vector<pair<int,int>> th;
    vector<pair<int,int>> one;
    vector<int> mins;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            dist[i][j] = INT_MAX;
            char ch;
            cin>>ch;
            grid[i][j]=ch;
            if(ch == '1'){
                //ones.push_back({i, j});
                //q.push({i, j});
                //dist[i][j] = 0;
                one.push_back({i, j});
            }
            else if(ch == '3'){
                th.push_back({i, j});
                q.push({i, j});
                dist[i][j] = 0;
            }
        }
    }

    while(!q.empty()){
        int x = q.front().first;
        int y = q.front().second;
        q.pop();

        for(int i=0; i<4; i++){
            int x2 = x+dx[i];
            int y2 = y+dy[i];
            if(inrange(x2,y2)){
                if(dist[x2][y2] > dist[x][y] + 1){
                    dist[x2][y2] = dist[x][y] + 1;
                    q.push({x2, y2});
                }
            }
        }
    }

    int mx = -1;
    for(pair<int, int> o : one){
    //for(int d : mins){
        if (mx < dist[o.first][o.second]){
            mx = dist[o.first][o.second];
        }
    }

    cout<<mx;
    
}
