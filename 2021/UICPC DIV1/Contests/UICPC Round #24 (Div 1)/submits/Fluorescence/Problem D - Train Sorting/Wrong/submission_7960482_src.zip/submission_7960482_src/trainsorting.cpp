#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

int main(){
    int n;
    cin>>n;
    const int num = 2000+5;
    int a[num], b[num];
    for(int i=0; i<n; i++){
        cin>>a[i];
        b[i] = -1 * a[i];
    }
    vector<int> lis[num];
    vector<int> lds[num];
    for(int i=0; i<n; i++){
        for(int j=i; j<n; j++){
            int x = a[j];
            int t = lower_bound(lis[i].begin(), lis[i].end(), x) - lis[i].begin();
            if(t==lis[i].size()){
                lis[i].push_back(x);
            }
            else{
                lis[i][t] = x;
            }
        }
    }
    for(int i=0; i<n; i++){
        for(int j=i; j<n; j++){
            int x = b[j];
            int t = lower_bound(lds[i].begin(), lds[i].end(), x) - lds[i].begin();
            if(t==lds[i].size()){
                lds[i].push_back(x);
            }
            else{
                lds[i][t] = x;
            }
        }
    }
    int mx=0;
    for(int i=0; i<n; i++){
        int s1 = lds[i].size(), s2 = (lis[i].size());
        mx = max(mx, s1 + s2 -1);
    }
    cout<<mx;
}