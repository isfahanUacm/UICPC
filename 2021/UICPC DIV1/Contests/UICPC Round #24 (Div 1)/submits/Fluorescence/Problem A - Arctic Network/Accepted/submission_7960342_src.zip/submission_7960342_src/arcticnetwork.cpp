#include <bits/stdc++.h>
using namespace std;
#define MAX_N 5005

int n, m;
int a, b, w;
vector<pair<double, pair<int, int>>> edgeList;
int parent[MAX_N];
int raank[MAX_N];

void initSets(int n){
    for(int i = 0; i < n; i++){
        parent[i] = i;
        raank[i] = 0;
    }
}

int findSet(int i){
    if(parent[i] == i)
        return i;
    return parent[i] = findSet(parent[i]);
}

inline bool inSameSets(int i, int j){
    return findSet(i) == findSet(j);
}

void mergeSets(int i, int j){
    int a = findSet(i);
    int b = findSet(j);
    if(a == b)
        return;
    if(raank[a] >= raank[b])
        parent[b] = a;
    else
        parent[a] = b;
    if(raank[a] == raank[b])
        raank[a]++;
}

int main(){
    int t, s;
    double res = 0;
    cin>>t;
    while (t--)
    {
        edgeList.clear();
        res = 0;
        vector<pair<int, int>> nodes;
        int x, y;
        cin>>s>>n;
        for (int i = 0; i < n; i++){
            cin>>x>>y;
            nodes.push_back({x, y});
        }

        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                if(i == j) continue;
                double d = sqrt((nodes[i].first - nodes[j].first)*(nodes[i].first - nodes[j].first) +
                (nodes[i].second - nodes[j].second)*(nodes[i].second - nodes[j].second));
                edgeList.push_back({d, {i, j}});
            }
        }
        
        initSets(n);
        sort(edgeList.begin(), edgeList.end());
        int no_sat = n;
        //for (int i = 0; i < n; i++){
        for(pair<double, pair<int, int>> edge : edgeList){
            if(no_sat == s)
                    break;
            if(findSet(edge.second.first) != findSet(edge.second.second)){
                mergeSets(edge.second.first, edge.second.second);
                no_sat--;
                if(res < edge.first) res = edge.first;
            }
        }
        cout<<fixed<<setprecision(2)<<res<<endl;
    }
}
