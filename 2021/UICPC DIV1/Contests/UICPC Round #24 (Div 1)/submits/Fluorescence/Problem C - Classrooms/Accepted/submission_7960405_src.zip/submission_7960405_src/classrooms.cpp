#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

int main(){
    int n, k;
    cin>>n>>k;
    const int num = 200000+5;
    pair<int,int> act[num];
    for(int i=0; i<n; i++){
        cin>> act[i].second>> act[i].first;
    }
    sort(act, act+n);
    multiset<int> clas;
    for(int i=0; i<k; i++){
        clas.insert(0);
    }
    int count=0;
    for(int i=0; i<n; i++){
        int f=act[i].second;
        int l=act[i].first;
        auto it = clas.upper_bound(f);
        if(it == clas.begin()) continue;
        it = prev(it);
        clas.erase(it);
        clas.insert(l+1);
        count++;
    }
    cout<<count;
}