import math

my_list = []
for i in range(int(input())):
    m = int(input())
    my_list.append(m)

for i in range(len(my_list)):
    r = (8*pow(9,(my_list[i]-1),1000000007))%1000000007
    print(int(r))