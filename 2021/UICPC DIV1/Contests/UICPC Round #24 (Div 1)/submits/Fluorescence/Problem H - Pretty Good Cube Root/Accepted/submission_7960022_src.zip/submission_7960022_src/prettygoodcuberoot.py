
import sys
import decimal

'''def cubicRoot(n) :
    start = 0
    end = n

    e = 0.1
    while (end>start):
         
        mid = (start + end) // 2

        if (mid**3==n):
            return mid

        if ((mid * mid * mid) > n) :
            end = mid
        else :
            start = mid
    return mid'''

for line in sys.stdin:
    decimal.getcontext().prec = 500
    d =decimal.Decimal(int(line))
    res = d**(decimal.Decimal(1) / decimal.Decimal(3))
    print(round(res))