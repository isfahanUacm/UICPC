#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    int h, w, n;
    cin >> h >> w >> n;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    int i = 0;
    int j = 0;
    int k = 0;
    bool flag = false;
    while (j != n) {
        i += arr[j++];
        if (i > w) {
            flag = true;
            break;
        }
        else if (i == w) {
            i = 0;
            k++;
            if (k == h)
                break;
        }
    }
    if (flag || k != h || i != 0) {
        cout << "NO" << endl;
    }
    else {
        cout << "YES" << endl;
    }
}