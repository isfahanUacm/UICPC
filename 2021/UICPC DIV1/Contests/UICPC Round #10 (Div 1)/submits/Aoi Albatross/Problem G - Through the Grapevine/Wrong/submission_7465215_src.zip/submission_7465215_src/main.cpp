#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

const int MAX = 100001;
map<string, int> id;
int val[MAX];
int t[MAX];
vector<int> vc[MAX];

int main() {
    for (int & i : t) {
        i = INT_MAX;
    }

    int n, m, d;
    cin >> n >> m >> d;
    for (int i = 0; i < n; ++i) {
        string a;
        int temp;
        cin >> a >> temp;
        id[a] = i;
        val[i] = temp;
    }
    for (int i = 0; i < m; ++i) {
        string a, b;
        cin >> a >> b;
        int aa = id[a];
        int bb = id[b];
        vc[aa].push_back(bb);
        vc[bb].push_back(aa);
    }
    string src;
    cin >> src;
    int s = id[src];

    queue<int> q;
    t[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int x = q.front();
        q.pop();
        for (auto u : vc[x]) {
            val[u]--;
            t[u] = min(t[u], t[x] + 1);
            if (val[u] == 0) {
                q.push(u);
            }
        }
    }

    ll ans = -1;
    for (int i = 0; i < n; ++i) {
        if (t[i] <= d) {
            ans++;
        }
    }

    cout << ans << endl;
}