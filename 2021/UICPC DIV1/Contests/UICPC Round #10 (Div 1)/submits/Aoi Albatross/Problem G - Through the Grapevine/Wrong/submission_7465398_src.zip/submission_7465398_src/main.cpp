#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

const ll MAX = 100010;
map<string, ll> id;
ll val[MAX];
ll t[MAX];
ll w[MAX];
vector<ll> vc[MAX];

int main() {
    for (ll & i : t) {
        i = LONG_LONG_MAX;
    }

    ll n, m, d;
    cin >> n >> m >> d;
    for (ll i = 0; i < n; ++i) {
        string a;
        ll temp;
        cin >> a >> temp;
        id[a] = i;
        val[i] = temp;
    }
    for (ll i = 0; i < m; ++i) {
        string a, b;
        cin >> a >> b;
        ll aa = id[a];
        ll bb = id[b];
        vc[aa].push_back(bb);
        vc[bb].push_back(aa);
    }
    string src;
    cin >> src;
    ll s = id[src];

    queue<ll> q;
    w[s] = 1;
    t[s] = 1;
    q.push(s);
    while (!q.empty()) {
        ll x = q.front();
        q.pop();
        for (auto u : vc[x]) {
            val[u]--;

            if (t[u] == LONG_LONG_MAX)
                t[u] = w[x];

            if (val[u] == 0) {
                w[u] = w[x] + 1;
                q.push(u);
            }
        }
    }

    ll ans = -1;
    for (ll i = 0; i < n; ++i) {
        if (t[i] <= d) {
            ans++;
        }
    }

    cout << ans << endl;
}