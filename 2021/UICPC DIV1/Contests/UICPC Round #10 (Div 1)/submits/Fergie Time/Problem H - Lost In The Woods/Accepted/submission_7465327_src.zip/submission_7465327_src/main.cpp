#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

const ld error = 0.00000000001;
ll n, m;
vector<vector<ll>> graph;

int main()
{
    cin >> n >> m;
    vector<ll> sample;
    graph = vector<vector<ll>> (n, sample);
    while(m--)
    {
        ll x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    ld maximum = 1;
    vector<ld> p(n, 0);
    p[0] = 1;
    ll distance = 0;
    ld ans = 0;
    while(maximum > error)
    {
        distance++;
        vector<ld> tp(n, 0);
        maximum = p[0];
        for(ll i = 0; i < n; i++)
        {
            maximum = max(maximum, p[i]);
            for(ll j: graph[i])
            {
                tp[j] += p[i] / graph[i].size();
            }
        }
        ans += distance * tp[n - 1];
        tp[n - 1] = 0;
        p = tp;
    }
    cout << fixed << setprecision(6) << ans;
    return 0;
}
