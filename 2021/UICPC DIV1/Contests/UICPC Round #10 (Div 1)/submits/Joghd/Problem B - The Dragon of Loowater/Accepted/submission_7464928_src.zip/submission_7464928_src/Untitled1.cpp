#include <iostream>
#include <algorithm>
using namespace std;

int que(int n,int m) {
	int head[n], shva[m];
	for(int i=0;i<n;i++) cin >> head[i];
	for(int i=0;i<m;i++) cin >> shva[i];
	sort(head,head+n); sort(shva,shva+m);
	
	int sum = 0, hcount = 0,i;
	for(i=0;i<m;i++) {
		if(head[hcount] <= shva[i]) {
			sum += shva[i];
			hcount++;
			if(hcount == n)
				break;
		}
	}
	if(hcount == n) return sum;
	return -1;
}

int main() {
    int n,m;
    int size =0;
    int x[5];
    cin >> n >> m;
    while(n!=0 && m!=0) {
    	x[size] = que(n,m);
    	size++;
    	cin >> n>> m;
	}
	for(int i=0;i<size;i++) {
		if(x[i]== -1) cout<< "Loowater is doomed!" << endl;
		else cout << x[i] << endl;
	}
}

