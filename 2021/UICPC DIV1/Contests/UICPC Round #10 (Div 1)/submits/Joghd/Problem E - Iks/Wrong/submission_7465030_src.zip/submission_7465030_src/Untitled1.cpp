#include <iostream>
#include <math.h>
using namespace std;
int isprime(int n) {
    for(int i=sqrt(n);i>1;i--)
        if(n%i==0) return 0;
    return 1;
}
int count(int n,int p) {
    int ans = 0;
    while(n>=p && n%p == 0) {
        ans++;
        n/=p;
    }
    return ans;
}
int main() {
    int n;
    cin >> n;
    int num[n];
    int ans = 1, sum = 0;
    for(int i=0;i<n;i++) cin >> num[i];
    for(int i=2;i<1000;i++) {
        if(isprime(i) ==1){
            int summ = 0;
            int x[n];
            for(int j=0;j<n;j++) x[j] = 0;
            for(int j=0;j<n;j++) {
                x[j] = count(num[j],i);
                summ += x[j];
            }
            if((summ/n)>0)
            ans *= (summ/n) * i;
            for(int j=0;j<n;j++) {
                if(summ/n - x[j] > 0)
                sum +=summ/n - x[j];

            }}



    }
    cout << ans << " " << sum;
}

