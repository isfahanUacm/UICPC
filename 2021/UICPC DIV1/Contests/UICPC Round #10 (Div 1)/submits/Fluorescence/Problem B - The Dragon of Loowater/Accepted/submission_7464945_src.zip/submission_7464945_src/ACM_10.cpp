#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;



int main()
{
    lli n, m;
    while (true) {
        cin >> n >> m;
        if (n == 0 && m == 0)
            break;
        lli sum1 = 0, sum2 = 0;
        lli* a = new lli[n];
        lli* b = new lli[m];
        for (lli i = 0; i < n; i++)
        {
            cin >> a[i];
            sum1 += a[i];
        }
        for (lli i = 0; i < m; i++)
        {
            cin >> b[i];
            sum2 += b[i];
        }
        if (m < n) {
            cout << "Loowater is doomed!"<<endl;
            continue;
        }
        if (sum1 > sum2) {
            cout << "Loowater is doomed!"<<endl;
            continue;
        }
        sort(a, a + n);
        sort(b, b + m);
        lli count = 0;
        int j = 0;
        for (int i = 0; i < m; i++) {
            if (j == n)
                break;
            if (a[j] <= b[i]) {
                count += b[i];
                j++;
            }
        }
        if (j == n){
            cout << count << endl;;
        }
        else {
            cout << "Loowater is doomed!" << endl;
        }
    }


}