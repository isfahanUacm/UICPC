#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


int main()
{
    ll n;
    cin >> n;
    int flag = 0;
    unordered_map <string, bool> savewords;
    string word, temp;
    cin >> word;
    savewords[word] = 0;
    for (ll i=1;i<n;i++)
    {
        temp = word;
        cin >> word;
        if (savewords.find(word) == savewords.end())
            savewords[word] = i;
        else
        {
             if(i % 2 == 0)
                 flag = 1;
             else
             {
                 flag = 2;
             }
              break;
        }

        if(temp[temp.size()-1] != word[0])
        {
            if(i % 2 == 0)
                flag = 1;
            else
            {
               flag = 2;
            }
           break;

        }

    }

    switch (flag)
    {
        case 0:
            cout << "Fair Game";
        break;
        case 1:
        cout << "Player 1 lost";
        break;
        case 2:
        cout << "Player 2 lost";
        break;


    }
}
