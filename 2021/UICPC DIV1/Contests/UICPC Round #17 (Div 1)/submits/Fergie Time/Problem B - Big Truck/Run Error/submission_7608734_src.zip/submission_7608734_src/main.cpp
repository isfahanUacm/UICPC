#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

ll n;
ll ansDistance = LLONG_MAX;
ll ansItems = LLONG_MAX;

vector<ll> t;
vector<vector<pair<ll, ll>>> graph;
vector<bool> visited;

bool bfs(ll index)
{
    queue<ll> q;
    q.push(index);
    while(q.size())
    {
        ll current = q.front();
        q.pop();
        visited[current] = true;
        for(pll i: graph[current])
        {
            if(!visited[i.first])
            {
                q.push(i.first);
            }
        }
    }
}
void f(ll index, ll dist, ll items)
{
    if(dist > ansDistance)
    {
        return;
    }
    if(index == n - 1)
    {
        if(dist < ansDistance)
        {
            ansDistance = dist;
            ansItems = items + t[index];
        }
        else if(dist == ansDistance)
        {
            ansItems = max(ansItems, items + t[index]);
        }
        return;
    }
    for(pll i : graph[index])
    {
        if(!visited[i.first])
        {
            visited[index] = true;
            ll nextItems = items + t[index];
            f(i.first, dist + i.second, nextItems);
            visited[index] = false;
        }
    }
}

int main()
{
    cin >> n;
    t = vector<ll>(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> t[i];
    }
    ll m;
    cin >> m;
    vector<pair<ll, ll>> sample;
    graph = vector<vector<pair<ll, ll>>>(n, sample);
    for(ll i = 0; i < m; i++)
    {
        ll a, b, d;
        cin >> a >> b >> d;
        a--;
        b--;
        graph[a].push_back({b, d});
        graph[b].push_back({a, d});
    }
    visited = vector<bool>(n, false);
    bfs(0);
    if(visited[n - 1])
    {
        ansDistance = LLONG_MAX;
        visited = vector<bool>(n, false);
        f(0, 0, 0);
        cout << ansDistance << " " << ansItems;
    }
    else
    {
        cout << "impossible";
    }
    return 0;
}