#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 500;

vector<ll> queens;
set<pll> forbidden;
ll ans;

bool valid(ll x, ll y)
{
    for(ll i = 0; i < x; i++)
    {
        if((queens[i] == y) || (abs(queens[i] - y) == abs(i - x)))
        {
            return false;
        }
    }
    return true;
}


void f(ll index, ll n)
{
    if(index == n)
    {
        ans++;
        return;
    }
    for(ll i = 0; i < n; i++)
    {
        if(forbidden.find({index, i}) == forbidden.end())
        {
            if(valid(index, i))
            {
                queens[index] = i;
                f(index + 1, n);
            }
        }
    }
}

int main()
{
    ll n, m;
    cin >> n >> m;
    queens = vector<ll>(n, -1);
    forbidden = set<pll>();
    ans = 0;
    while(!(n == 0 && m == 0))
    {
        for(ll i = 0; i < m; i++)
        {
            ll x, y;
            cin >> x >> y;
            forbidden.insert({x, y});
        }
        f(0, n);
        cout << ans << endl;

        cin >> n >> m;
        ans = 0;
        queens = vector<ll>(n, -1);
        forbidden = set<pll>();
    }
    return 0;
}