#include <bits/stdc++.h>
using namespace std ;

int n,m;
vector<int> num;

bool test(int dis){
    int ans = 0;
    for (int i=0 ; i<n ; i++){
        int tmp = num[i]+2*dis ;
        ans++;
        i++;
        while (i<n && num[i]<=tmp) 
            i++;
        i--;
    }
    return ans<=m ;
}

int bs(int s , int e){
    if (s==e) return s ;

    int tmp = (e+s)/2 ;
    if (test(tmp) && !test(tmp-1)) return tmp;
    else if (test(tmp)) return bs(s,tmp) ;
    else return bs(tmp,e) ;
}

int main(){
    int tc ;
    cin >> tc ;
    for (int x=0 ; x<tc ; x++){
        cin >> m >> n ;
        num.clear() ;
        num.resize(n) ;
        for (int i=0 ; i<n ; i++)
            cin >> num[i] ;
        for (int i=0 ; i<n ; i++)
            num[i]*=10;
        sort(num.begin(),num.end()) ;
        int ans = bs(0,num[n-1]) ;
        double answer = double(ans) / 10 ;
        printf("%.1lf\n" , answer);

    }

    return 0;
}