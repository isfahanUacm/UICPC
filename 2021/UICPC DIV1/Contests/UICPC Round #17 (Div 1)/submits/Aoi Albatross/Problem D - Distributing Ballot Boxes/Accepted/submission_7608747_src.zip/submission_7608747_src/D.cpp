#include <bits/stdc++.h> 
using namespace std ;

int n,m;
vector<int> num ;

bool test(int dis){
    int ans = 0;
    for (int i=0 ; i<n ; i++){
        int tmp = num[i]/dis ;
        if (tmp * dis < num[i]) tmp++ ;
        ans+=tmp ;
    }
    return ans <= m ;
}

int bs(int s , int e){
    if (s==e) return s;

    int tmp = (s+e)/2;
    if (test(tmp) && !test(tmp-1)) return tmp ;
    else if (test(tmp)) return bs(s , tmp) ;
    else return bs(tmp , e) ;

}

int main(){
    cin >> n >> m ;
    while (n != -1 || m != -1){
        num.clear() ;
        num.resize(n) ;
        for (int i=0 ; i<n ; i++)
            cin >> num[i];
        sort(num.begin() , num.end()) ;

        cout << bs(0 , num[n-1]) << endl;
        
        cin >> n >> m;
    }


    return 0;
}