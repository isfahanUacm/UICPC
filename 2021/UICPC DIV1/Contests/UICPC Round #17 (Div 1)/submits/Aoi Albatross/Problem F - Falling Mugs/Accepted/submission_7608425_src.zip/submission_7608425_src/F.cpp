#include <bits/stdc++.h>
using namespace std ;

long long n,i;

long long bs(long long s , long long e){
    if (e == s) return s;
    if (e-s == 1 ) return s ;
    if (s-e==1) return s ;

    long long tmp = i*i - ((e+s)/2)*((e+s)/2) ;
    if (tmp-n == 0) return ((e+s)/2) ;
    else if (tmp-n < 0) return bs(s , ((e+s)/2)-1) ;
    else return bs(((e+s)/2)+1 , e) ;

}

int main(){
    cin >> n;
    i = (long long)(sqrt(n))+1 ;
    for (i=(long long)(sqrt(n)) ; i<=200000 ; i++){
        long long j = bs(0,i) ;
        if (i*i - j*j == n){
            cout << j << " " << i << endl;
            return 0;
        }
    }
    cout << "impossible" << endl;

    return 0;
}