def main():
    num = int(input())
    words = []
    last_letter = ""
    for index in range(1, num + 1):
        break_function = False;
        player = 0
        if index % 2 == 0:
            player = 2
        else:
            player = 1
        word = input()
        if word in words:
            print(f"Player {player} Lost")
            break_function = True
            break
        if not index == 1:
            if word[0] != last_letter:
                print(f"Player {player} Lost")
                break_function = True
                break
        words.append(word)
        last_letter = word[len(word) - 1]

    if break_function:
        return
    print("Fair Game")


if __name__ == '__main__':
    main()
