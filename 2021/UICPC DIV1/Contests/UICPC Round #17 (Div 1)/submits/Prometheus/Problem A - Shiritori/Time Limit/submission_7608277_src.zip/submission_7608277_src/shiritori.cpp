#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

int main(){
    int num;
    cin >> num;

    vector<string> words;
    char last_letter;
    bool break_function = false;

    for (int index = 1; index < num + 1; index++) {
        break_function = false;
        int player = index % 2 == 0 ? 2 : 1;
        
        string word;
        cin >> word;
        
        if (find(words.begin(), words.end(), word) != words.end()) {
            cout << "Player " << player << " Lost" << endl;
            break_function = true;
            break;
        }

        if (index != 1) {
            if (word[0] != last_letter) {
                cout << "Player " << player << " Lost" << endl;
                break_function = true;
                break;
            }
        }
        words.push_back(word);
        last_letter = word[word.length() - 1];
    }

    if (break_function) {
        return 0;
    }

    cout << "Fair Game" << endl;
}