import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        Map<String,Integer> a=new HashMap<>();
        int n=s.nextInt();
        String st;
        for (int i = 0; i < n; i++) {
            st=s.next();
            if(a.getOrDefault(st,0)!=0){
                if(i%2==0) {
                    System.out.println("Player 1 lost");
                }else {
                    System.out.println("Player 2 lost");
                }
                return;
            }
            a.put(st,1);
        }
        System.out.println("Fair Game");
    }
}
