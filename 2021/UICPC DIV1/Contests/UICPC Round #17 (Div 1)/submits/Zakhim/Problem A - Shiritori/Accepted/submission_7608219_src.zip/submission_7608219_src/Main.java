import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        Map<String,Integer> a=new HashMap<>();
        int n=s.nextInt();
        String st,prev,ne;
        prev=s.next();
        a.put(prev,1);
        for (int i = 1; i < n; i++) {
            st=s.next();
            ne=st;
            if(a.getOrDefault(st,0)!=0 || ne.charAt(0)!=prev.charAt(prev.length()-1)){
                if(i%2==0) {
                    System.out.println("Player 1 lost");
                }else {
                    System.out.println("Player 2 lost");
                }
                return;
            }
            a.put(st,1);
            prev=ne;
        }
        System.out.println("Fair Game");
    }
}
