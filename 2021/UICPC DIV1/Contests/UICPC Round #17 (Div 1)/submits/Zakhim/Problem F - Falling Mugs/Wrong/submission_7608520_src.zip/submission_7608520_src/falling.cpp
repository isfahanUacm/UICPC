#include <bits/stdc++.h>
using namespace std;
int n;
bool isValue(int menha,int jam){
    int n2=menha+jam;
    if(n2%2!=0)
        return false;
    n2=n2/2;
    int n1=n2-menha;
    if(n1<=0||n2<=0)
        return false;
    if(n2*n2-n1*n1!=n)
        return false;
}
int main(){
    cin>>n;
    if(n==0){
        cout<<0<<" "<<0;
        return 0;
    }
    if(n==1){
        cout<<0<<" "<<1;
        return 0;
    }
    int n1=0,n2=0;
    for (int i = 1; i <= sqrt(n); i++)
    {
        if(n%i == 0){
            if(isValue(i,n/i)){
                n2=i+n/i;
                n2=n2/2;
                n1=n2-i;
            }
        }
    }
    if(n1!=0){
        cout<<n1<<" "<<n2;
        return 0;
    }
    cout<<"impossible";
}