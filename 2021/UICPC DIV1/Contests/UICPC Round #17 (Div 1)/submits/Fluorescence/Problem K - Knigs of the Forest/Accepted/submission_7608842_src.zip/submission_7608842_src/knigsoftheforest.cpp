	#include <bits/stdc++.h>
	using namespace std;
	typedef long long int lli;
	// std::cout << std::setprecision(3) << std::fixed << doubllle;
	typedef unsigned long long int ulli;
	// sort(arr, arr + n, greater<int>());
	//c = ::tolower(c);
	//for (int i = 0; i < s.size(); i++) {
	//s[i] = tolower(s[i]);
	//multiset<lli, greater<lli>> mset;


	//there is at most one road between
	//any two locations, and no road starts and ends at the same location.
	
	int k, n;
	pair<lli, lli> each[2*100000+5];

	int main() {
		set<lli, greater<lli>> pq;
		cin >> k >> n;
		cin >> each[0].first >> each[0].second;
		lli moose = each[0].second;
		if (each[0].first == 2011) pq.insert(each[0].second);
		for (int i = 1; i <= n + k - 2; i++) {
			cin >> each[i].first >> each[i].second;
			if (each[i].first == 2011) pq.insert(each[i].second);
		}
		sort(each, each + n + k - 1);

		bool flag = 0;
		lli ans = -1;
		if (*pq.begin() == moose) {
			flag = 1;
			ans = 2011;
		}
		else {
			for (int i = k; i <= n + k - 2; i++) {
				pq.erase(pq.begin());
				pq.insert(each[i].second);

				lli top = *pq.begin();
				if (top == moose) {
					flag = 1;
					ans = each[i].first;
					break;
				}
			}
		}
		if (!flag) cout << "unknown";
		else cout << ans;
	}