#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){

    while(true){
        ll cit, box, each;
        priority_queue<pair<ll,pair<ll, ll>>> pq; //assi, {num , orig}
        cin>>cit>>box;
        if(cit == -1 && box == -1) break;
        for (ll i = 0; i < cit; ++i) {
            cin>>each;
            pq.push({each, {1, each}});
        }

        ll num, assi, orig;
        //for (ll i = 0; i <box ; ++i) {
        box -= cit;
        while(box){
            box--;
            assi = pq.top().first;
            num = pq.top().second.first;
            orig = pq.top().second.second;
            pq.pop();
            //cout<<assi<<" "<<num<<endl;
            pq.push({ceil((double)orig/(double)(num+1)), {num+1, orig}});
            //cout<<orig/(num+1)<<" "<<num+1<<endl<<endl;
        }
        cout<<pq.top().first<<endl;
    }

}