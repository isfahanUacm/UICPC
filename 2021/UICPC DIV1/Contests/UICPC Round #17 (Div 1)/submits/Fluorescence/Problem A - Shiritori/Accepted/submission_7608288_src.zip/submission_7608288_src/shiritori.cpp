	#include <bits/stdc++.h>
	using namespace std;
	typedef long long int lli;
	// std::cout << std::setprecision(3) << std::fixed << doubllle;
	typedef unsigned long long int ulli;
	// sort(arr, arr + n, greater<int>());
	//c = ::tolower(c);
	//for (int i = 0; i < s.size(); i++) {
	//s[i] = tolower(s[i]);
	//multiset<lli, greater<lli>> mset;

	int main() {
		int n;
		cin >> n;
		map<string, int> map;
		string s, last="*";
		int flag = 3;
		for (int i = 1; i <= n; i++) {
			cin >> s;
			if (flag != 3) continue;
			if (i == 1) {
				map[s] = 1;
				last = s;
				continue;
			}
			auto it = map.find(s);
			if (it != map.end()) {
				flag = i%2;
			}
			else if (s[0] != last[last.size() - 1]) {
				flag = i % 2;
			}
			last = s;
			map[s] = 1;
		}
		if (flag == 3)
			cout << "Fair Game";
		else if (flag == 0) cout << "Player 2 lost";
		else
			cout << "Player 1 lost";
	}