#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 600;

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {

        ll n, y;
        cin >> n >> y;
        vector<ll> amp(n);
        unordered_set<ll> all_nums;
        all_nums.insert(1);
        for(ll i = 0; i < n; i++)
        {
            cin >> amp[i];
        }
        ll ans = 0;
        for(ll i = 0; i < amp.size(); i++)
        {
            unordered_set<ll> temp_nums;
            for(ll j: all_nums)
            {
                if(j * amp[i] <= y)
                {
                    if(j * amp[i] > ans)
                    {
                        ans = j * amp[i];
                    }
                    temp_nums.insert(j * amp[i]);
                }
            }
            for(ll j: temp_nums)
            {
                all_nums.insert(j);
            }
        }
        cout << ans << endl;
    }

    return 0;
}