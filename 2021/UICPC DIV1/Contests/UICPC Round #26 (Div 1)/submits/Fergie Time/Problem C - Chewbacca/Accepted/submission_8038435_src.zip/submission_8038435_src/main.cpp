#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;



int main()
{
    ll n , k , q, x, y;
    cin >> n >> k >> q;

    while (q--)
    {
        cin >> x >> y;
        ll stepx = 0;
        ll stepy = 0;
        x--;
        y--;
        while (true){
            if (y <= x)
            {


            if (x == y)
            {
                cout << stepx + stepy<<endl;
                break;
            }

            x--;
            x /= k;
            stepx ++;
            }


           if (x < y)
           {



            y--;
            y /= k;
            stepy ++;



        }
    }
    }

}
