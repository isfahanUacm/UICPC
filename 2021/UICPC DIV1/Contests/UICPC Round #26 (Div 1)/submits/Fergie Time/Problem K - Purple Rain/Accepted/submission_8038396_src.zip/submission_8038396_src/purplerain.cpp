#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
   string s;
   cin>>s;
   vector<ll> rain(s.length()+1);
   rain[0]=0;
   for(ll i=1;i<=s.length();i++){
       if (s[i-1] == 'B') {
         rain[i] = rain[i-1] + 1;
       } else {
         rain[i] = rain[i-1] - 1;
       }
   }
   ll min_index=min_element(rain.begin(), rain.end())-rain.begin();
   ll max_index=max_element(rain.begin(), rain.end())-rain.begin();
   if (min_index < max_index){
       cout<<min_index+1<<" "<<max_index<<endl;
   }
   else{
       cout<<max_index+1<<" "<<min_index<<endl;
   }

}
