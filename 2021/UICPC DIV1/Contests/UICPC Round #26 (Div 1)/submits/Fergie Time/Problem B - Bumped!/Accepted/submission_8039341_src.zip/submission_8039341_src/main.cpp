#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 50010;
vector<vector<pll>> graph;
bool visited[maxN];
ll dist[maxN][2];

ll dijkstra(ll src, ll goal)
{
    multiset<tuple<ll, ll, ll>> q;
    q.insert({0, src, 1});
    dist[src][1] = 0;
    while(q.size())
    {
        ll current = get<1>(*q.begin());
        ll currentDist = get<0>(*q.begin());
        ll currentFlights = get<2>(*q.begin());
        q.erase(q.begin());
        if(current == goal)
        {
            return currentDist;
        }
        for(pll i: graph[current])
        {
            ll u = i.first;
            ll w = i.second;
            if(w == -1)
            {
                if(currentFlights == 1)
                {
                    if(currentDist + w < dist[u][currentFlights - 1])
                    {
                        w = 0;
                        dist[u][currentFlights - 1] = currentDist + w;
                        q.insert({currentDist + w, u, 0});
                    }
                }

            }
            else
            {
                if(currentDist + w < dist[u][currentFlights])
                {
                    dist[u][currentFlights] = currentDist + w;
                    q.insert({currentDist + w, u, currentFlights});
                }
            }

        }
    }

}

int main()
{
    ll n, m, f, src, goal;
    cin >> n >> m >> f >> src >> goal;
    graph = vector<vector<pll>>(n);
    for(ll i = 0; i < m; i++)
    {
        ll a, b, w;
        cin >> a >> b >> w;
        graph[a].push_back({b, w});
        graph[b].push_back({a, w});
    }
    for(ll i = 0; i < f; i++)
    {
        ll a, b;
        cin >> a >> b;
        graph[a].push_back({b, -1});
    }
    fill(&dist[0][0], &dist[0][0] + maxN * 2, LLONG_MAX);
    cout << dijkstra(src, goal);
    return 0;
}