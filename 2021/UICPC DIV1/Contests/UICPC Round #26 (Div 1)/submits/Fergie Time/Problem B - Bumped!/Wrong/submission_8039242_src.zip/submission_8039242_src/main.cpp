#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 50010;
vector<vector<pll>> graph;
bool visited[maxN];
ll dist[maxN];

ll dijkstra(ll src, ll goal)
{
    multiset<pll> q;
    q.insert({0, src});
    dist[src] = 0;
    while(q.size())
    {
        ll current = q.begin()->second;
        ll currentDist = q.begin()->first;
        q.erase(q.begin());
        if(current == goal)
        {
            return currentDist;
        }
        for(pll i: graph[current])
        {
            ll u = i.first;
            ll w = i.second;
            if(!visited[u] && currentDist + w < dist[u])
            {
                dist[u] = currentDist + w;
                q.insert({currentDist + w, u});
            }
        }
    }

}

int main()
{
    ll n, m, f, src, goal;
    cin >> n >> m >> f >> src >> goal;
    graph = vector<vector<pll>>(n);
    for(ll i = 0; i < m; i++)
    {
        ll a, b, w;
        cin >> a >> b >> w;
        graph[a].push_back({b, w});
        graph[b].push_back({a, w});
    }
    for(ll i = 0; i < f; i++)
    {
        ll a, b;
        cin >> a >> b;
        graph[a].push_back({b, 0});
    }
    fill(dist, dist + maxN, LLONG_MAX);
    cout << dijkstra(src, goal);
    return 0;
}