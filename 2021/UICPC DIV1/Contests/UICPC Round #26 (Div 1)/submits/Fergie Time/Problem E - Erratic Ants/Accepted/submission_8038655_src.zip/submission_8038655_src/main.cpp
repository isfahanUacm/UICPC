#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 600;
map<pll, set<pll>> graph;
ll dist[maxN][maxN];
bool visited[maxN][maxN];

ll dijkstra(pll src, pll goal)
{
    multiset<pair<ll, pll>> q;
    q.insert({0, src});
    visited[100 + 0][100 + 0] = true;
    dist[100 + 0][100 + 0] = 0;
    while(q.size())
    {
        pll current = q.begin()->second;
        ll currentDist = q.begin()->first;
        if(current == goal)
        {
            return currentDist;
        }
        q.erase(q.begin());
        visited[100 + current.first][100 + current.second] = true;
        for(pll u: graph[current])
        {
            if(currentDist + 1 < dist[100 + u.first][100 + u.second])
            {
                dist[100 + u.first][100 + u.second] = currentDist + 1;
                q.insert({1 + currentDist, u});
            }
        }
    }
}
int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        ll x = 0, y = 0;
        ll n;
        cin >> n;
        fill(&visited[0][0], &visited[0][0] + maxN * maxN, false);
        fill(&dist[0][0], &dist[0][0] + maxN * maxN, LLONG_MAX);
        graph = map<pll, set<pll>>();

        map<string, pll> dirs ={
                {"E", {0, 1}},
                {"W", {0, -1}},
                {"N", {1, 0}},
                {"S", {-1, 0}}
        };
        for(ll i = 0; i < n; i++)
        {
            string s;
            cin >> s;
            pll dir = dirs[s];
            ll newX = x + dir.first;
            ll newY = y + dir.second;

            graph[{newX, newY}].insert({x, y});
            graph[{x, y}].insert({newX, newY});

            x = newX;
            y = newY;
        }
        cout << dijkstra({0, 0}, {x, y}) << endl;
    }

    return 0;
}