#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
char last_char='a';
ll n;
ll W,H;
vector<vector<ll>>  mapgame;
vector<vector<char>> later_basins;
char find_basins(ll i,ll j){
    if(later_basins[i][j] != ' '){
        return later_basins[i][j];
    }
    ll min = mapgame[i][j];
    ll showway=0;
    if ((i > 0) && (mapgame[i-1][j] < min)){
           min = mapgame[i-1][j];
           showway=1;
    }
    if ((j > 0) && (mapgame[i][j-1] < min)){
         min = mapgame[i][j-1];
         showway=2;
    }

    if ((j < W-1) && (mapgame[i][j+1] < min) ){
           min = mapgame[i][j+1];
          showway=3;


    }
    if((i < H-1) && (mapgame[i+1][j] < min)){
          min = mapgame[i+1][j];
          showway=4;


    }

    if(showway==0){
       later_basins[i][j] = last_char;
       last_char = ((last_char-'0') + 1)+'0';
    }
    else if(showway==1){
         later_basins[i][j]=find_basins(i-1,j);
    }
    else if(showway==2){
          later_basins[i][j]=find_basins(i,j-1);
    }
    else if(showway==3){
        later_basins[i][j]= find_basins(i,j+1);
    }
    else if(showway==4){
         later_basins[i][j]=find_basins(i+1,j);
    }

    return later_basins[i][j];

}
void drainage_basins(ll h,ll w,ll numcase){
    vector<char> samplechar(w,' ');
    later_basins=vector<vector<char>>(h,samplechar);
    last_char='a';
    W=w;
    H=h;
    char s;
    for(ll i=0;i<h;i++){
        for(ll j=0;j<w;j++){
               s=find_basins(i,j);
        }
    }
    cout<<"Case #"<<n-numcase<<":"<<endl;
    for(ll i=0;i<h;i++){
        for(ll j=0;j<w;j++){
            cout<<later_basins[i][j]<<" ";
        }
        cout<<endl;
    }
}
int main()
{
    ll mapnum;
    cin>>mapnum;
    n=mapnum;
    while(mapnum--){
        ll h,w;
        cin>>h>>w;
        vector<ll> sample(w,0);
        mapgame= vector<vector<ll>>(h,sample);
        for(ll i=0;i<h;i++){
            for(ll j=0;j<w;j++){
                cin>>mapgame[i][j];
            }
        }
        drainage_basins(h,w,mapnum);
    }
}
