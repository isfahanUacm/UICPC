#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 600;
string names[2] = {"Chikapu", "Bash"};

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        string s;
        cin >> s;
        ll index = 1;
        ll player_to_play = 0;
        while(index < s.length() - 1)
        {
            if(s[index - 1] != s[index + 1])
            {
                player_to_play = (player_to_play + 1) % 2;
                s.erase(s.begin() + index);
                index = (index - 1 >= 1)? index - 1: index;
            }
            else
            {
                index++;
            }
        }
        cout << names[1 - player_to_play] << endl;
    }

    return 0;
}