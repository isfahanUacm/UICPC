import sys
l = []
f_dict = {}
for line in sys.stdin:
    s1, s2 = line.split()
    l.append((s2, s1))
    if not s1 in f_dict:
        f_dict[s1] = 0
    f_dict[s1] += 1

l.sort()
for i in l:
    if f_dict[i[1]] > 1:
        print(i[1], i[0])
    else:
        print(i[1])

