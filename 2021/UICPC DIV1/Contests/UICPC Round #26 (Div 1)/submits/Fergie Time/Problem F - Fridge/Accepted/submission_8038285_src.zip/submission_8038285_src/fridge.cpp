#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    string num;
    cin>>num;
    vector<ll> arr(10);
    for(ll i=0;i<num.length();i++){
        arr[(num[i]-'0')]+=1;
    }
    ll min=min_element(arr.begin(), arr.end())-arr.begin();
    for(ll i=1;i<10;i++){
        if(min==0 && arr[min]==arr[i]){
            min=i;
            break;
        }
    }

    string s;
    if (min != 0){
        for(ll i=0;i<=arr[min];i++){
            s += min+'0' ;
        }
    }
    else{
        s += '1';
        for(ll i=0;i<=arr[min];i++){
            s += min+'0';
        }
    }
    cout<<s<<endl;
}
