#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
ll n;
ll goal;
vector<ll> vc;
ll mx = LONG_LONG_MIN;

void solve(ll i, ll val) {
    if (val > goal)
        return;

    mx = max(mx, val);

    if (i == vc.size())
        return;

    solve(i + 1, val);
    solve(i + 1, val * vc[i]);
}

int main() {
    ll tc;
    cin >> tc;
    while (tc--) {
        vc.clear();
        cin >> n >> goal;

        for (ll i = 0; i < n; ++i) {
            ll temp;
            cin >> temp;
            if (temp != 1)
                vc.push_back(temp);
        }
        mx = LONG_LONG_MIN;
        solve(0, 1);
        cout << mx << endl;
    }
}