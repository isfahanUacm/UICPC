#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
ll n;
ll goal;
set<ll> vals;
vector<ll> vc;


int main() {
    ll tc;
    cin >> tc;
    while (tc--) {
        vc.clear();
        cin >> n >> goal;

        for (ll i = 0; i < n; ++i) {
            ll temp;
            cin >> temp;
            if (temp != 1)
                vc.push_back(temp);
        }
        vals.insert(1);
        for (auto x : vc) {
            vector<int> added;
            for (auto t : vals) {
                if (x * t <= goal)
                    added.push_back(x * t);
            }
            for (auto temp : added) {
                vals.insert(temp);
            }
        }

        cout << *prev(vals.end()) << endl;
        vals.clear();
    }
}