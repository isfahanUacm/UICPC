#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    string a;
    cin >> a;

    int mx = INT_MIN;
    int tmp = 0;
    int l = 0, r = -1;
    int arr[4];
    memset(arr, 0, sizeof(arr));

    for (int i = 0; i < a.size(); i++) {
        char x = a[i];
        if (x == 'R') {
            tmp++;
        }
        else {
            tmp--;
        }
        if (tmp > mx) {
            r = i;
            mx = tmp;
            arr[0] = l;
            arr[1] = r;
        }

        if (tmp < 0) {
            l = i + 1;
            tmp = 0;
        }
    }

    int lh;
    int rh;
    int mxh = mx;

    mx = INT_MIN;
    tmp = 0;
    l = 0, r = -1;

    for (int i = 0; i < a.size(); i++) {
        char x = a[i];
        if (x == 'B') {
            tmp++;
        }
        else {
            tmp--;
        }
        if (tmp > mx) {
            r = i;
            mx = tmp;
            arr[2] = l;
            arr[3] = r;
        }

        if (tmp < 0) {
            l = i + 1;
            tmp = 0;
        }
    }

    lh = arr[0] + 1;
    rh = arr[1] + 1;
    l = arr[2] + 1;
    r = arr[3] + 1;

    if (mx > mxh) {
        cout << l << ' ' << r << endl;
    }
    else if (mxh > mx) {
        cout << lh << ' ' << rh << endl;
    }
    else {
        if (l < lh) {
            cout << l << ' ' << r << endl;
        }
        else if (lh < l) {
            cout << lh << ' ' << rh << endl;
        }
        else {
            if (r < rh) {
                cout << l << ' ' << r << endl;
            }
            else {
                cout << lh << ' ' << rh << endl;
            }
        }
    }
}
