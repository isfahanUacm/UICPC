#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    int arr[10];
    memset(arr, 0, sizeof(arr));
    string a;
    cin >> a;
    for (auto x : a) {
        int t = (int)(x - '0');
        arr[t]++;
    }

    int ih = 0;
    int izh = 0;
    for (int i = 1; i < 10; ++i) {
        if (arr[i] < arr[ih])
            ih = i;
    }

    for (int i = 9; i >= 0; --i) {
        if (arr[i] == arr[ih] && i != ih) {
            izh = i;
        }
    }

    if (ih == 0) {
        if (izh != 0) {
            string ans;
            for (int i = 0; i <= arr[izh]; ++i) {
                ans += (char)('0' + izh);
            }
            cout << ans << endl;
        }
        else {
            string ans = "1";
            for (int i = 0; i <= arr[0]; ++i) {
                ans += "0";
            }
            cout << ans << endl;
        }
    }
    else {
        string ans;
        for (int i = 0; i <= arr[ih]; ++i) {
            ans += (char)('0' + ih);
        }
        cout << ans << endl;
    }
}
