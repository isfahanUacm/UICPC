#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 1e5 + 10;
ll dist[MAX][2];
set<pair<pair<ll, ll>, ll>> ss;
vector<pair<ll, ll>> adj[MAX];

void dijkstra(int start) {
    dist[start][0] = 0;
    ss.insert({{0, start}, 0});
    while (!ss.empty()) {
        ll u = ss.begin()->first.second;
        bool used = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (used) {
                if (v.second == 0)
                    continue;

                if (dist[v.first][1] > dist[u][1] + v.second) {
                    ss.erase({{dist[v.first][1], v.first}, 1});
                    dist[v.first][1] = dist[u][1] + v.second;
                    ss.insert({{dist[v.first][1], v.first}, 1});
                }
            }
            else {
                if (v.second == 0) {
                    if (dist[v.first][1] > dist[u][0]) {
                        ss.erase({{dist[v.first][1], v.first}, 1});
                        dist[v.first][1] = dist[u][0];
                        ss.insert({{dist[v.first][1], v.first}, 1});
                    }
                }
                else {
                    if (dist[v.first][0] > dist[u][0] + v.second) {
                        ss.erase({{dist[v.first][0], v.first}, 0});
                        dist[v.first][0] = dist[u][0] + v.second;
                        ss.insert({{dist[v.first][0], v.first}, 0});
                    }
                }
            }
        }
    }
}

int main() {
    ll n, m, f, s, t;
    cin >> n >> m >> f >> s >> t;
    for (ll i = 0; i < n; ++i) {
        dist[i][0] = LONG_LONG_MAX;
        dist[i][1] = LONG_LONG_MAX;
    }
    for (ll i = 0; i < m; ++i) {
        ll w, a, b;
        cin >> a >> b >> w;
        adj[a].emplace_back(b, w);
        adj[b].emplace_back(a, w);
    }
    for (int i = 0; i < f; ++i) {
        ll a, b;
        cin >> a >> b;
        adj[a].emplace_back(b, 0);
    }
    dijkstra(s);
    cout << min(dist[t][0], dist[t][1]) << endl;
}