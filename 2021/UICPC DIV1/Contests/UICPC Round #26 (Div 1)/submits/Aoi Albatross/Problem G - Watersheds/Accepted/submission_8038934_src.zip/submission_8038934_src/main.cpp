#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int arr[150][150];
int mp[150][150];
int n, m;
int used = 0;

pair<int, int> mv[] = {
        {1, 0},
        {0, 1},
        {0, -1},
        {-1, 0},
};

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < m;
}

int dfs(int x, int y) {
    if (mp[x][y] != -1)
        return mp[x][y];

    int xh = -1, yh = -1;
    int mx = arr[x][y];
    for (auto t: mv) {
        int nx = x + t.first;
        int ny = y + t.second;

        if (ir(nx, ny) && arr[nx][ny] <= mx && arr[nx][ny] < arr[x][y]) {
            xh = nx;
            yh = ny;
            mx = arr[nx][ny];
        }
    }
    if (xh == -1) {
        mp[x][y] = ++used;
    }
    else {
        mp[x][y] = dfs(xh, yh);
    }

    return mp[x][y];
}

int main() {
    int tc;
    cin >> tc;
    for (int k = 0; k < tc; ++k) {
        cin >> n >> m;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cin >> arr[i][j];
            }
        }
        cout << "Case #" << k + 1 << ":" << endl;
        memset(mp, -1, sizeof(mp));
        used = -1;

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (mp[i][j] == -1) {
                    dfs(i, j);
                }
            }
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cout << (char)(mp[i][j] + 'a') << ' ';
            }
            cout << endl;
        }
    }
}