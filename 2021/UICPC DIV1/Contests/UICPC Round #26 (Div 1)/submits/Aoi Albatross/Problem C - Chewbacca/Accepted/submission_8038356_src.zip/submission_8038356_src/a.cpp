#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
      ll n, k, q;
      cin >> n >> k >> q;
      for (ll i=0; i<q; i++){
            ll tmp1, tmp2;
            cin >> tmp1 >> tmp2;
            tmp1--;
            tmp2--;

            set <ll> a;
            vector <ll> b;

            while (tmp1 > 0){
                  b.push_back(tmp1);
                  a.insert(tmp1);
                  if (tmp1 % k == 0)
                        tmp1 = (tmp1/k)-1;
                  else 
                        tmp1 /= k;

            }
            while (tmp2 > 0){
                  b.push_back(tmp2);
                  a.insert(tmp2);
                  if (tmp2 % k == 0)
                        tmp2 = (tmp2/k)-1;
                  else 
                        tmp2 /= k;
            }

            ll ans = 0;
            for (auto itr = a.begin(); itr != a.end(); itr++){
                  ll tmp = 0;
                  for (ll i=0; i<b.size(); i++)
                        if (b[i] == *itr)
                              tmp++;
                  if (tmp == 1) ans++;
            }

            cout << ans << endl;
      }


      return 0;
}