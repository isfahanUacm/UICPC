#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi
int visited[100+5][100+5];
int main(){
    int w, h;
    while(cin >> w>> h){
        for(int i=0; i<=h; i++){
            for(int j=0; j<=w; j++) visited[i][j] = 0;
        }
        vector<pair<string, pair<pair<int, int>, pair<int ,int>>>> person;
        int n; cin>>n;
        for(int i=0; i<n; i++){
            string s; int x1, x2, y1, y2; cin>>s>>y1>>x1>>y2>>x2;
            x1 = h-x1; x2 = h-x2;
            person.push_back({s, {{x1, y1}, {x2, y2}}}); 
            for(int i=x2; i<x1; i++){
                for(int j=y1; j<y2; j++){
                    if(visited[i][j] == 0){
                        visited[i][j] = 1;
                    }
                    else visited[i][j] = 2;
                }
            }
        }
        cout<<"Total "<<w*h<<endl;
        int Unallocated = 0, Contested = 0;
        for(int i=0; i<h; i++){
            for(int j=0; j<w; j++){
                if(visited[i][j] == 0) Unallocated++;
                else if(visited[i][j] == 2) Contested++;
            }
        }
        cout<<"Unallocated "<<Unallocated<<endl;
        cout<<"Contested "<<Contested<<endl;
        for(int i=0; i<n; i++){
            int x1, x2, y1, y2;
            x1 = person[i].second.first.first;
            y1 = person[i].second.first.second;
            x2 = person[i].second.second.first;
            y2 = person[i].second.second.second;
            int sum=0;
            for(int i=x2; i<x1; i++){
                for(int j=y1; j<y2; j++){
                    if(visited[i][j] == 1) sum++;
                }
            }
            cout<<person[i].first<<" "<<sum<<endl;
        }
        cout<<endl;
    }
}