#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
lli n, k;
vector<lli> nodes1, nodes2;

void go_up1(lli u){
    if(u == 0){
        nodes1.push_back(0);
        return;
    }
    nodes1.push_back(u);
    lli v = (u-1)/k;
    go_up1(v);
}
void go_up2(lli u){
    if(u == 0){
        nodes2.push_back(0);
        return;
    }
    nodes2.push_back(u);
    lli v = (u-1)/k;
    go_up2(v);
}
int main(){
    lli q, x, y, cnt;
    cin>>n>>k>>q;
    while(q--){
        cnt = 0;
        nodes1.clear(), nodes2.clear();
        cin>>x>>y;
        go_up1(x-1);
        go_up2(y-1);
        
        for (lli i = nodes1.size()-1 ; i >=0 ; i--){
            lli ind = nodes2.size() - (nodes1.size() - i);
            if(ind < nodes2.size() && ind >= 0 && nodes1[i] == nodes2[ind]) cnt++;
        }
        cout<<nodes2.size()+nodes1.size()-(2*cnt)<<endl;
    }
}