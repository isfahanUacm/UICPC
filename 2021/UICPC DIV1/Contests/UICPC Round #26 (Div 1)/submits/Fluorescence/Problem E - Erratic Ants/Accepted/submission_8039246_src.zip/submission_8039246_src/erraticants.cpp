#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
/*vector<int> graph[65];
map<pair<int, int>, int> id;
int n, s;
int dist[65];*/

int main(){
	vector<int> graph[65];
	map<pair<int, int>, int> id;
	int n, s;
	int dist[65];
	char c;
	cin>>n;
	while(n--){
		id.clear();
		for (int i = 0; i < 65; i++) graph[i].clear();
		
		int ind = 0, pre_ind = 0;
		int cx=0, cy=0;
		fill_n(dist, 65, INT_MAX);
		cin>>s;
		id[{cx, cy}] = 0;
		for (int i = 0; i < s; i++){
			pre_ind = id[{cx, cy}];
			cin>>c;
			if(c == 'S'){
                cx++;
            }
            else if(c == 'N'){
                cx--;
            }
            else if(c == 'E'){
                cy++;
            }
            else if(c == 'W'){
                cy--;
            }
			if(id.count({cx, cy}) == 0) id[{cx, cy}] = ++ind;
			graph[pre_ind].push_back(id[{cx, cy}]);
			graph[id[{cx, cy}]].push_back(pre_ind);
		}
		
		queue<int> q;
		dist[0] = 0;
		q.push(0);
		while (!q.empty()){
			int u = q.front();
			q.pop();
			for (int v : graph[u]){
				if(dist[v] > dist[u] + 1){
					dist[v] = dist[u] + 1;
					q.push(v);
				}
			}
		}

		cout<<dist[id[{cx, cy}]]<<endl;
	}
}