#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi
int dx[4]={-1, 0, 0, 1};
int dy[4]={0, -1, 1, 0};
int h, w;
int grid[100+5][100+5];
int lable[100+5][100+5];
bool visited[100+5][100+5];
int last_lable=0;
bool inrange(int x, int y){
    return (x>=0 && x<h && y>=0 && y<w);
}
void solve(int x, int y){
    visited[x][y] = true;
    stack<pair<int, int>> stk;
    stk.push({x, y});
    int cur_lable=-1;
    bool flag=0;
    while(true){
        int x_next=-2, y_next=-2;
        int comp=INT_MAX;
        for(int i=0; i<4; i++){
            int x2 = x+dx[i];
            int y2 = y+dy[i];
            if(inrange(x2, y2)){
                if((grid[x2][y2] < grid[x][y]) && (grid[x2][y2] < comp)){
                    comp = grid[x2][y2];
                    x_next = x2, y_next=y2;
                }
            }
        }
        if(x_next <0 && y_next <0){
            break;
        }
        if(visited[x_next][y_next]){
            cur_lable = lable[x_next][y_next];
            flag=1;
            break;
        }
        else{
            x = x_next, y = y_next;
            visited[x][y]=true;
            stk.push({x, y});
        }

    }
    if(!flag){
        last_lable++;
        cur_lable = last_lable;
    }
    while(!stk.empty()){
        auto p = stk.top();
        stk.pop();
        int i=p.first, j=p.second;
        lable[i][j]=cur_lable;
    }
}
int main(){
    int T;
    cin>>T;
    for(int t=1; t<=T; t++){
        //visited
        //lastlable
        cin>>h>>w;
        for(int i=0; i<h; i++){
            for(int j=0; j<w; j++){
                cin>>grid[i][j];
                visited[i][j] = false;
            }
        }
        last_lable = 0;
        for(int i=0; i<h; i++){
            for(int j=0; j<w; j++){
                if(!visited[i][j]){
                    solve(i, j);
                }
            }
        }
        cout<<"Case #" << t << ":" << endl;
        for(int i=0; i<h; i++){
            for(int j=0; j<w; j++){
                char ch = char(lable[i][j] + 96);
                cout<< ch<<" ";
            }
            cout<<endl;
        }
    }
}