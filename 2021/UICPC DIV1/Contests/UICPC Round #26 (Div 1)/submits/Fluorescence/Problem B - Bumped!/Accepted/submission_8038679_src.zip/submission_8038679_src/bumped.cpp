#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

const int num = 50000+5;
vector<pair<lli, int>> road[num];
vector<int> flight[num];
lli dist[num];
int n, m , f,start, destination;
void dijk(){
    set<pair<lli, pair<int ,bool>>> pq;//dist //where //use_flight
    dist[start] = 0;
    pq.insert({0, {start, 0}});
    while(!pq.empty()){
        auto p = pq.begin();
        lli d = p->first;
        int cur = p->second.first;
        bool flght = p->second.second;
        pq.erase(pq.begin());
        //if(d > dist[cur] ) continue;
        for(auto each : road[cur]){
            int neigh = each.second;
            lli w = each.first;
            if(dist[neigh] > d + w){
                dist[neigh] = d+w;
                pq.insert({dist[neigh], {neigh, flght}});
            }
        }
        if(flght) continue;
        for(auto neigh : flight[cur]){
            if(dist[neigh] > d ){
                dist[neigh] = d;
                pq.insert({dist[neigh], {neigh, 1}});
            }
            
        }
    }
}
int main(){
    cin>>n>>m>>f>>start>>destination;
    fill_n(dist, num, LONG_MAX);
    for(int i=0; i<m; i++){
        int u, v;
        lli w;
        cin>>u>>v>>w;
        road[u].push_back({w, v});
        road[v].push_back({w, u});
    }
    for(int i=0; i<f; i++){
        int u, v;
        cin>>u>>v;
        flight[u].push_back(v);
    }
    dijk();
    cout<<dist[destination];
}