#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

int main(){
    int count[10+5];
    fill_n(count, 10+5, 0);
    string s;
    cin>>s;
    for(int i=0; i<s.size(); i++){
        count[s[i]-'0']++;
    }
    string ans="";
    int fdigit=INT_MAX, digit;
    for(int i=1; i<9; i++){
        //fdigit = min(fdigit, count[i]);
        if(count[i] < fdigit){
            fdigit = count[i];
            digit = i;
        }
    }
    ans += to_string(digit);
    if(fdigit == 0){
        cout<<ans;
        return 0;
    }
    count[digit]--;
    while(true){
        fdigit=INT_MAX;
        for(int i=0; i<9; i++){
            if(count[i] < fdigit){
                fdigit = count[i];
                digit = i;
            }
        }
        ans += to_string(digit);
        if(fdigit == 0){
            cout<<ans;
            return 0;
        }
        count[digit]--;
    }
}