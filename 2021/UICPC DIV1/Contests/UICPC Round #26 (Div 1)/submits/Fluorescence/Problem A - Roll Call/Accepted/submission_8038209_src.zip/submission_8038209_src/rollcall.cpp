#include <bits/stdc++.h>
using namespace std;
bool cmp(pair<string, string> x, pair<string, string> y){
    if (x.first < y.first)
        return true;
    else if(x.first == y.first)
        return x.second < y.second;
    else return false;
}
int main(){
    string f, l;
    vector<pair<string, string>> mp;
    multiset<string> la, fe;
    while(cin>>f>>l){
        mp.push_back({l, f});
        la.insert(l);
        fe.insert(f);
        //if(f == "0") break;
    }
    sort(mp.begin(), mp.end(), cmp);
    for (int i = 0; i < mp.size(); i++){
        if(fe.count(mp[i].second) != 1){
            cout<<mp[i].second<<" "<<mp[i].first<<endl;
        }
        else{
            cout<<mp[i].second<<endl;
        }
    }
}