#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

const int maxn = 2e5 + 3;
int n, height[maxn], first[maxn], t[8 * maxn];
vector<int> euler;
vector<int> adjs[maxn];
bool vis[maxn];

void build(int v, int tl, int tr){
    if(tl == tr)
        t[v] = height[euler[tl]];
    else{
        int tm = (tl + tr) / 2;
        build(2 * v, tl, tm);
        build(2 * v + 1, tm + 1, tr);
        /*int l = t[2 * v], r = t[2 * v + 1];
        t[v] = (height[l] <= height[r]) ? l : r;*/
        t[v] = min(t[2 * v], t[2 * v + 1]);
    }
}

void dfs(int u,int p, int h){
    //vis[u] = 1;
    first[u] = euler.size();
    height[u] = h;
    euler.push_back(u);
    for(int v : adjs[u])
        if(p != v){
            dfs(v, u, h + 1);
            euler.push_back(u);
        }
}

int query(int v, int tl, int tr, int l, int r){
    if(l > r)
        return -1;
    if(tl == l && tr == r)
        return t[v];
    int tm = (tl + tr) / 2;
    int p1 = query(2 * v, tl, tm, l, min(tm, r));
    int p2 = query(2 * v + 1, tm + 1, tr, max(tm + 1, l), r);
    if(p1 == -1)
        return p2;
    if(p2 == -1)
        return p1;
    //return (height[p1] <= height[p2]) ? p1 : p2;
    return min(p1, p2);
}

int lca(int u, int v){
    if(first[u] > first[v])
        swap(u, v);
    int h2 =  query(1, 0, euler.size() - 1, first[u], first[v]);
    //cout<<h2<<endl;
    return height[u] - h2 + height[v] - h2;
}
//lli sum = 0;
int main(){
    cin >> n;
    for(int i = 0; i < n - 1; i++){
        int u, v;
        cin >> u >> v;
        adjs[u].push_back(v);
        adjs[v].push_back(u);
    }
    dfs(1, -1, 0);
    build(1, 0, euler.size() - 1);

    lli sum = 0;
    //cout<<lca(4, 5)<<endl;
    for(int u = 1; u <= n; u++){
        //cout<<sum<<endl;
        for(int v = 2 * u; v <= n; v += u){
            //cout<<u<<" "<<v<<" "<<lca(u, v)<<endl;
            sum += lca(u, v) + 1;
            //cout<<sum<<endl;
        }
    }
    
    cout<<sum<<endl;
}