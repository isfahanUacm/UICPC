import math

q, m, s, l = map(int, input().split())
if m == 1:
    print(q * l + s)
else:
    ans = 0
    ans += math.ceil(l / m) * q
    r = l % m
    if r == 0:
        print(ans + math.ceil(s / m))
    else:
        r = m - r
        r *= q
        if s > r:
            s -= r
            ans += math.ceil(s / r)

        print(ans)
