#include <iostream>
#include<bits/stdc++.h>
#include <math.h>
#define ll long long
using namespace std;

int main()
{
    ll c,i,x,y,z,k,power,krand,kranu;

    cin>>c>>k;
    power=pow(10, k);
    x=c/power;
    krand=power*x;
    kranu=power*(x+1);
    y=c-krand;
    z=kranu-c;
    if(y<z)
    {
        cout<<krand;
    }
    else
    {
        cout<<kranu;
    }







}
