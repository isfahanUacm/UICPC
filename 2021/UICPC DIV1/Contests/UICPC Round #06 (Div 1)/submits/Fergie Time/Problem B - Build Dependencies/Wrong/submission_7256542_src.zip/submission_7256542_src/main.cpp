#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
vector<string> split(string s)
{
    vector<string> ans;
    string temp = "";
    for(char i : s)
    {
        if(i == ' ')
        {
//            watch(temp);
            ans.push_back(temp);
            temp = "";
        }
        else
        {
//            watch(i);
            temp += i;
        }
    }
    ans.push_back(temp);
    return ans;
}
vector<ll> answer;
void f(vector<vector<ll>> graph, vector<bool> visited, ll index)
{
    queue<ll> q;
    q.push(index);
    visited[index] = true;
    while(q.size())
    {
        ll current = q.front();
        q.pop();
        answer.push_back(current);
        for(ll i: graph[current])
        {
            if(!visited[i])
            {
                visited[i] = true;
                q.push(i);
            }
        }
    }
}
int main ()
{
    ll n;
    cin >> n;
    getline(cin, waste);
    map<string, vector<string>> connections;
    map<string, ll> indexof;
    map<ll, string> nameof;

    for(ll i = 0; i < n ; i++)
    {
        string cline;
        getline(cin, cline);
        vector<string> line = split(cline);
        string s = line[0].substr(0, line[0].size() - 1);
        nameof[i] = s;
        indexof[s] = i;
        vector<string> sample;
        for(ll j = 1; j < line.size(); j++)
        {
            sample.push_back(line[j]);
        }
        connections[s] = sample;
    }

    string q;
    cin >> q;

    vector<ll> sample;
    vector<vector<ll>> graph(n, sample);
    vector<bool> visited(n, false);
    for(auto i: connections)
    {
        for(string j: i.second)
        {
            graph[indexof[j]].push_back(indexof[i.first]);
        }
    }
    f(graph, visited, indexof[q]);
    for(ll i: answer)
    {
        cout << nameof[i] << endl;
    }
    return 0;
}
