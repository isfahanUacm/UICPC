k, m, n = map(int, input().split(" "))

if m > k:
    print("Barb")
elif n >= k:
    print("Alex")
else:
    remiander = k % (m + n)
    if remiander < m:
        print("Barb")
    else:
        print("Alex")