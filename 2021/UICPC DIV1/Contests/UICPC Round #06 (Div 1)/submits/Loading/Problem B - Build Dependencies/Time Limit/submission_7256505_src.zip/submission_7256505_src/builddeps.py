visited = []

def bfs (lst):
    global visited
    for el in lst:
        if visited.count(el) == 0:
            print(el)
            visited.append(el)
    for el in lst:
        try:
            el_lst = theD[el]
            bfs(el_lst)
        except:
            return

n = int(input())
theD={}
for i in range(n):
    temp = list(map(str, input().split()))
    temp[0] = temp[0].replace(':','')
    for j in range(1,len(temp)):
        if theD.get(temp[j]) is None:
            theD.update({temp[j]:[temp[0]]})
        else:
            theD[temp[j]].append(temp[0])
c = input()
print(c)
#print(theD)
#visited.append(c)

bfs(theD[c])