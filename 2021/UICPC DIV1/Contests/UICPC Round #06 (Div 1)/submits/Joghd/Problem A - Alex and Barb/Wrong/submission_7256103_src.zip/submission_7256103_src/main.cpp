#include <iostream>
#include <string>

using namespace std;
int ceil(int a,int b) {
    int aa=a%b;
    return (a-aa)/b+1;
}
int main() {
   int k, m ,n;
   cin >> k >> m >> n;
   k-=m;
   int g = k/n;
   if(g%2==0)
       cout << "Alex";
   else cout << "Barb";

}
