#include <bits/stdc++.h>
using namespace std;

int main()
{
    unsigned long long int q, m, s, l, cnt = 0, rest;
    cin >> q >> m >> s >> l;
    if(l > 1){
        l += (s/q);
        s = s % q;
        unsigned long long int remain =0;
        if(l%m != 0)
            remain = 1;
        cnt += (l/m + remain)*q;
        rest = m - l%m;
        if(rest == 0)
        {
            cnt += s/m;
            if(s % m != 0)
                cnt++;
        }
    }
    else
    {
        if(l == 1)
            s += l;
        cnt += s/m;
        if(s % m != 0)
            cnt++;
    }
    cout << cnt << endl;
}
