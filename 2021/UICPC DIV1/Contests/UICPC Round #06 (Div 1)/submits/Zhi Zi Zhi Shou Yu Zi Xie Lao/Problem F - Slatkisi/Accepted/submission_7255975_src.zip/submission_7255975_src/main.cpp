#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
int main()
{
    ll c;
    int k;
    cin>>c;
    cin>>k;
    ll p =pow(10,k);
    ll m = c%p;
    if(m == 0)
        cout<<c<<endl;
    else if(m>= (p/2))
    {
        cout<<c - m +p <<endl;
    }
    else {
        cout<<c - m<<endl;
    }

    return 0;
}
