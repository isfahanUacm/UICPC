#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int x[n];
    for(int i=0;i<n;i++)
        cin >> x[i];
    sort(x,x+n);
    for(int i=n-1;i>=0;i--) {
        if(n-i >= x[i]) {
            cout << x[i];
            return 0;
        }
    }


}
