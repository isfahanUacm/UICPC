#include <iostream>
#include <string>
using namespace std;
struct x {
    string nam;
    string hezb;
    int a;
};
int sr(int first,int last,string s,x* d) {
    if(first>last)
        return -1;
    int mid=(first+last)/2;
    if(d[mid].nam==s)
        return mid;
    if(d[mid].nam>s)
        return sr(first,mid-1,s,d);
    return sr(mid+1,last,s,d);
}
int main()
{
  int n;
  cin >> n;
  x y[n];
  int ff=0;
  for(int i=0;i<n;i++) {
      if(ff==0) {
          cin.ignore();
          ff=1;
      }
      getline(cin,y[i].nam);
      getline(cin,y[i].hezb);
      y[i].a=0;
      int j=i-1;
      while(j>=0 && y[j+1].nam < y[j].nam) {
          swap(y[j+1], y[j]);
          j--;
      }
  }
  int m;
  cin >> m;
  string s;
  ff=0;
  for(int i=0;i<m;i++) {
      if (ff==0) {
          cin.ignore();
          ff=1;
      }
      getline(cin,s);
      int k=sr(0,n-1,s,y);
      if(k==-1);
      y[k].a++;
  }
  x ma;
  ma.a=-1; int t=0;
  for(int i=0;i<n;i++) {
      if(y[i].a>ma.a) {
          ma=y[i];
          t=0;
      }
      else if(y[i].a==ma.a) {
          t++;
      }

  }
  if(t>0)
      cout << "tie" << endl;
  if(t==0)
      cout << ma.hezb;

}
