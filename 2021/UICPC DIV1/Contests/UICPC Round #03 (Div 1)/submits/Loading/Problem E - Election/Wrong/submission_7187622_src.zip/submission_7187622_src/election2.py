
lst = []
n = int(input())
for i in range(n):
    name = input()
    party = input()
    lst.append([name, party, 0])

m = int(input())
for i in range(m):
    ballot = input()
    for j in range(n):
        if ballot == lst[j][0]:
            lst[j][2] += 1
            break

f = False
x = lst[0][2]
for i in range(n):
    if x != lst[i][2]:
        f = False
        break
    else:
        f = True

maxi = -1
index = -1
if f == False:
    for i in range(n):
        if maxi < lst[i][2]:
            maxi = lst[i][2]
            index = i
    print(lst[index][1])
else:
    print("tie")

