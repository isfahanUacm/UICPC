a, b = map(int, input().split())
x = 0
if b > 1:
    x += 0
if b > 2:
    x += 31
if b > 3:
    x += 31
if b > 4:
    x += 30
if b > 5:
    x += 31
if b > 6:
    x += 30
if b > 7:
    x += 31
if b > 8:
    x += 31
if b > 9:
    x += 30
if b > 10:
    x += 31
if b > 11:
    x += 30
x += a

x = x % 7
if x == 1:
    print("Thursday")
if x == 2:
    print("Friday")
if x == 3:
    print("Saturday")
if x == 4:
    print("Sunday")
if x == 5:
    print("Monday")
if x == 6:
    print("Tuesday")
if x == 0:
    print("Wednesday")
