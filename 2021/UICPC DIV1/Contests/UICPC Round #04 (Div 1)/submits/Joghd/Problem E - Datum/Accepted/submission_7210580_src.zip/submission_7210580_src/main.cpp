#include <iostream>
using namespace std;
int main() {
    int x[12] ={31,28,31,30,31,30,31,31,30,31,30,31};
    int a,b;
    cin >> b >> a;
    for(int i=1;i<a;i++)
        b+=x[i-1];
    if(b%7==1)
        cout << "Thursday";
    if(b%7==2)
        cout << "Friday";
    if(b%7==3)
        cout << "Saturday";
    if(b%7==4)
        cout << "Sunday";
    if(b%7==5)
        cout << "Monday";
    if(b%7==6)
        cout << "Tuesday";
    if(b%7==0)
        cout << "Wednesday";


}
