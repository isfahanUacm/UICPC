#include <iostream>
#include<bits/stdc++.h>
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
using namespace std;

int main()
{
    ll n,m ;
    int i,j;
    cin>>n>>m;
    ll k,r;
    cin>>k>>r;
   vector<ll> l(n);
   for(i=0;i<n;i++)
   {
       cin>>l[i];
   }
   vector<pll> curve(n-1);
   for(j=0;j<n-1;j++){
       cin>>curve[j].first>> curve[j].second;
   }
   ll **dp=new ll*[n+10];
   for( i=0; i<n+10;i++)
   {
       dp[i]=new ll[m+10];
   }
   for( i=0;i<n+10;i++)
   {
       for(j=0;j<m+10;j++)
       {
           dp[i][j]=LLONG_MAX;
       }
   }
   dp[0][1]=0;
   for(i=1;i<n;i++){

       ll maxl;
       maxl=l[i-1]/k;
       for(j=1;j<=m;j++)
       {
           for(int x=0;x<=maxl;x++)
           {
               if(j-x>=0)
               {
                   if(dp[i-1][j-x]!=LLONG_MAX)
                   {
                       dp[i][j]=min(dp[i][j],dp[i-1][j-x]+((l[i-1]-x*k+x*(k+r)))+(curve[i-1].first+(j*curve[i-1].second)));
                   }


               }
               if(j+x<=m)
               {
                   if(dp[i-1][j+x]!=LLONG_MAX)
                   {
                       dp[i][j]=min(dp[i][j],dp[i-1][j+x]+((l[i-1]-x*k+x*(k+r)))+(curve[i-1].first+(j*curve[i-1].second)));
                   }


               }

           }
       }
   }
   ll maxn;
   maxn=l[n-1]/k;
   ll ans=LLONG_MAX;
   for(int x=0;x<=maxn;x++)
   {
       if(1+x<=m)
       {
           if(dp[n-1][1+x]!=LLONG_MAX)
           {
               ans=min(ans,dp[n-1][1+x]+((l[n-1]-x*k+x*(k+r))));
           }


       }
   }
   cout<<ans<<"\n";

}
