#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

void printarr(int **arr)
{
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}
void up(int** arr)
{
    int** ans = new int*[4];
    for(ll i = 0; i < 4; i++)
    {
        ans[i] = new int[4];
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            ans[i][j] = 0;
        }
    }
    for(ll i = 0; i < 4; i++)
    {
        ll lastp = -1;
        ll lastv = -1;
        for(ll j = 0; j < 4; j++)
        {
            if(arr[j][i] != 0)
            {
                if(lastv != arr[j][i])
                {
                    ans[lastp + 1][i] = arr[j][i];
                    lastp = lastp + 1;
                    lastv = arr[j][i];
                    arr[j][i] = 0;
                }
                else
                {
                    ans[lastp][i] = arr[j][i] + lastv;
                    lastp = lastp;
                    lastv = -1;
                    arr[j][i] = 0;
                }
            }
        }
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            arr[i][j] = ans[i][j];
        }
    }
}
void down(int** arr)
{
    int** ans = new int*[4];
    for(ll i = 0; i < 4; i++)
    {
        ans[i] = new int[4];
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            ans[i][j] = 0;
        }
    }
    for(ll i = 0; i < 4; i++)
    {
        ll lastp = 4;
        ll lastv = -1;
        for(ll j = 3; j >= 0; j--)
        {
            if(arr[j][i] != 0)
            {
                if(lastv != arr[j][i])
                {
                    ans[lastp - 1][i] = arr[j][i];
                    lastp = lastp - 1;
                    lastv = arr[j][i];
                    arr[j][i] = 0;
                }
                else
                {
                    ans[lastp][i] = arr[j][i] + lastv;
                    lastp = lastp;
                    lastv = -1;
                    arr[j][i] = 0;
                }
            }
        }
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            arr[i][j] = ans[i][j];
        }
    }
}

void left(int** arr)
{

    for(ll i = 0; i < 4; i++)
    {
       // watch(i);
        int col = -1;

        int num;
        for(ll j = 0; j < 4; j++)
        {
            //watch(j);
            if(col == -1)
            {
                col = j;
                num = arr[i][col];
                continue;
            }
           if(arr[i][j] !=0 && arr[i][j] != num)
           {

               col = j;
               num = arr[i][col];
               continue;
           }
           if(arr[i][j] == num)
           {
               arr[i][col] = num * 2;
               arr[i][j]=0;
               col = -1;
               continue;
           }
           if(arr[i][j] == 0)
           {
               continue;
           }

        }
    }

    int cols [4];

    for(int i=0;i<4;i++)
    {
       int t=0;
       for(int j=0;j<4;j++)
       {
           cols[j] = arr[i][j];

       }
       for(int j=0;j<4;j++)
       {
           if(cols[j] != 0)
           {

               arr[i][t] = cols[j];
               t++;

           }
       }
       for(int j=t;j<4;j++)
           arr[i][j] = 0;
    }

}

void right(int** arr)
{

    for(ll i = 0; i < 4; i++)
    {
        //ll lastp = -1;
        //ll lastv = -1;
        int col = -1;

        int num;
        for(ll j = 3; j >=0 ; j--)
        {
            if(col == -1)
            {
                col = j;
                num = arr[i][col];
                continue;
            }
           if(arr[i][j] !=0 && arr[i][j] != num)
           {

               col = j;
               num = arr[i][col];
               continue;
           }
           if(arr[i][j] == num)
           {
               arr[i][col] = num * 2;
               arr[i][j]=0;
               col = -1;
               continue;
           }
           if(arr[i][j] == 0)
           {
               continue;
           }

        }
    }
    int cols [4];

    for(int i=0;i<4;i++)
    {
       int t=3;
       for(int j=0;j<4;j++)
       {
           cols[j] = arr[i][j];

       }
       for(int j=3;j>=0;j--)
       {
           if(cols[j] != 0)
           {
               arr[i][t] = cols[j];
               t--;
           }
       }
       for(int j=t;j>=0;j--)
           arr[i][j] = 0;
    }

}

int main ()
{
    int** arr = new int*[4];
    for(ll i = 0; i < 4; i++)
    {
        arr[i] = new int[4];
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            cin >> arr[i][j];
        }
    }
    ll x;
    cin >> x;
    if(x == 1)
    {
        up(arr);
    }
    if(x == 3)
    {
        down(arr);
    }
    if(x==0)
    {
        left(arr);
    }
    if(x==2)
    {
        right(arr);
    }
    for(ll i = 0; i < 4; i++)
    {
        for(ll j = 0; j < 4; j++)
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
