#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}
vector<string> answer;
void f(ll index, vector<string> names, vector<string> ans, map<string, set<string>> m, map<string, bool> visited)
{
    if(ans.size() == names.size() && answer.size() == 0)
    {
        answer = ans;
        return;
    }
    for(ll i = 0; i < names.size(); i++)
    {
        if(ans.size())
        {
            if(m[ans[ans.size() - 1]].find(names[i]) != m[ans[ans.size() - 1]].end())
            {
                continue;
            }
        }
        if(visited[names[i]])
        {
            continue;
        }
        ans.push_back(names[i]);
        visited[names[i]] = true;
        f(index, names, ans, m, visited);
        ans.pop_back();
        visited[names[i]] = false;
    }
}
int main ()
{
    ll n;
    while(cin >> n)
    {
        vector<string> names(n);
        for(ll i = 0; i < n; i++)
        {
            cin >> names[i];
        }
        ll conflictsnum;
        cin >> conflictsnum;
        map<string, set<string>> m;
        for(ll i = 0; i < conflictsnum; i++)
        {
            string name1, name2;
            cin >> name1 >> name2;
            if (m.find(name1) == m.end())
            {
                set<string> sample;
                m.insert({name1, sample});

            }
            if (m.find(name2) == m.end())
            {
                set<string> sample;
                m.insert({name2, sample});

            }
            m[name1].insert(name2);
            m[name2].insert(name1);
        }
        sort(names.begin(), names.end());
        map<string, bool> visited;
        for(string i : names)
        {
            visited.insert({i, false});
        }
        vector<string> ans;
        f(0, names, ans, m, visited);
        if(answer.size())
        {
            for(string i : answer)
            {
                cout << i << " ";
            }
            cout << endl;
        }

        else
        {
            cout << "You all need therapy." << endl;

        }
        answer.clear();
    }
    return 0;
}
