#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll d,m;
int main(){
	ll month[]={0,31,59,90,120,151,181,212,243,273,304,334};
	string days[] = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	cin >> d >> m;
	ll ans =(4+d-1+month[m-1])%7;
	cout<<days[ans]<<endl;

}