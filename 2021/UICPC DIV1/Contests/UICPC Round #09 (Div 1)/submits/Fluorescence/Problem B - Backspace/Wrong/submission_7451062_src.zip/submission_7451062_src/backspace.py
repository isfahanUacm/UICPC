s = list(input())
res = []
cnt = 0
while len(s)>0:
    #print(i)
    el = s.pop()
    if el == '<':
        cnt += 1
    elif cnt > 0:
        for j in range(cnt-1):
            s.pop()
        cnt = 0
    else:
        res.append(el)
    #print(i)
if cnt>0:
    for i in range(cnt):
        res.append('<')
res.reverse()
for r in res:
    print(r, end="")