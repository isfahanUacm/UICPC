s = list(input())
res = []
cnt = 0

for i in range(len(s)):
    if s[i] == '<':
        if len(res)>0:
            res.pop()
        else:
            res.append(s[i])
    else: #push to res
        res.append(s[i])
for r in res:
    print(r, end="")