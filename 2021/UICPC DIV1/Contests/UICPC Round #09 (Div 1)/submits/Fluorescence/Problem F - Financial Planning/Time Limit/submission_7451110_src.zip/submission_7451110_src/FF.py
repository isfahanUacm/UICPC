import math
n,m = map(int, input().split())
li=[]
for i in range(n):
    p,c = map(int, input().split())
    minDay = math.ceil(c/p)
    maxDay = math.ceil((c+m)/p)
    li.append([p,c,minDay,maxDay])

li.sort(key = lambda x:x[2])

days = li[0][2]
j=1
if j<n:
    while (days==li[j][2] and j<n):
        j+=1
        if j==n: 
            break

money = 0
for i in range(j):
    money += (days*li[i][0]) - li[i][1]

while (money<m):
    days+=1
    for i in range(j): 
        money += li[i][0]
    if j<n:
        while (li[j][2]<=days and j < n):
            money += (days*li[j][0]) - li[j][1]
            j+=1
            if j==n:
                break

print(days)