#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 500;
ll r,c;
set<pair<ll,pair<ll,ll> > > pq;
char b[mx][mx];
ll dist[mx][mx];
ll ans=LONG_LONG_MAX;
pair<ll,ll> mo[] = {{1,0},{0,1},{-1,0},{0,-1}};
bool ir(ll x,ll y){
	return x>=0 && x<r && y>=0 && y<c;
}
void solve(){
	while(pq.size()){
		ll x = pq.begin()->second.first;
		ll y = pq.begin()->second.second;
		pq.erase(pq.begin());
		for(auto move:mo){
			ll xn = x+move.first;
			ll yn = y+move.second;
			if(ir(xn,yn)&&b[xn][yn]!='#'){
				if(b[xn][yn]=='D'&&dist[xn][yn]>dist[x][y]){
					pq.erase({dist[xn][yn],{xn,yn}});
					dist[xn][yn] = dist[x][y];
					pq.insert({dist[xn][yn],{xn,yn}});
				}
				else if(b[xn][yn]=='c'&&dist[xn][yn]>dist[x][y]+1){
					pq.erase({dist[xn][yn],{xn,yn}});
					dist[xn][yn] = dist[x][y]+1;
					pq.insert({dist[xn][yn],{xn,yn}});
				}
			}
		}
	}
}
int main(){
	cin >> r >> c;
	for(ll i=0;i<r;i++){
		for(ll j=0;j<c;j++){
			cin >> b[i][j];
			dist[i][j]=LONG_LONG_MAX;
		}
	}
	pair<ll,ll> a;
	cin >> a.first >> a.second;
	a.first--;a.second--;
	dist[a.first][a.second]=1;
	pq.insert({0,a});
	solve();
	for(ll i=0;i<r;i++){
		for(ll j=0;j<c;j++){
			if(i==0||i==r-1||j==0||j==c-1){
				if(b[i][j]=='D'){
					ans= min(dist[i][j],ans);
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}