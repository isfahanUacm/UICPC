w, s, c, k = map(int, input().split())

result = "NO"

if k > s:
    result = "YES"

elif k == s:
    if w + c <= k:
        result = "YES"
    elif w == k and c == k:
        result = "YES"
    elif w + c <= 2 * k:
        result = "YES"

elif w + c < k:
    result = "YES"

elif w + c == k and s <= 2 * k:
    result = "YES"

print(result)