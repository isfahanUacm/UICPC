#include <bits/stdc++.h>
using namespace std;

int main() {
    int a, b, c, d;
    cin >> a >> b >> c >> d;

    if (d == 0)
        cout << "NO" << endl;
    else if (a + c < d || a + b < d || b + c < d || b < d)
        cout << "YES" << endl;
    else if (b == d && a <= d && c <= d)
        cout << "YES" << endl;
    else if (a+c == d && b <= 2*d)
        cout << "YES" << endl;
    else if (a+c<= 2*d && b<=d)
        cout << "YES" << endl;
    else 
        cout << "NO" << endl;
}