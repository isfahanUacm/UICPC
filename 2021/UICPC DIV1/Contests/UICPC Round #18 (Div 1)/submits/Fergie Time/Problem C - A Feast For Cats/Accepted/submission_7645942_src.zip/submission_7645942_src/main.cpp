#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


vector<pair<ll, pair<ll, ll>>> graph;
vector <pll> ans;
vector <ll> nodes;
ll find(ll v)
{
   // cout<<nodes[v];
    if(nodes[v] == v)
    {
        return v;
    }

    return find(nodes[v]);
}

void merge(ll v1 , ll v2)
{

    if(nodes[v1] < nodes[v2])
    {
        nodes[v2] = v1;
    }
    else {
        nodes[v1] = v2;
    }

}

ll kruskalfindway(ll n)
{

    sort(graph.begin(),graph.end());
    ll counter = 0,v1,v2,way=0,p1,p2, dist=0;
    while((n-1) > way )
    {
         v1 = graph[counter].second.first;
         v2 = graph[counter].second.second;
         p1 = find(v1);
         p2 = find(v2);
         if( p1 != p2 )
         {
            // cout<<v1<<" "<<v2<<endl;
             //ans.push_back({v1,v2});
             way++;
             merge(p1,p2);
             dist += graph[counter].first;
         }
         counter++;
    }

    return dist;

}




int main()
{

    ll test;
    cin >> test;
    while(test--)
    {
        ll m, c, a,b,dist;
        cin >> m >> c;
        for (ll i=0;i<((c*(c-1)) / 2); i++)
        {
            cin >> a >> b >> dist;
            graph.push_back({dist, {a,b}});
        }

        for(ll int i=0;i<c;i++)
        {
            nodes.push_back(i);
        }

         dist = kruskalfindway(c);

         if ( m - (c + dist) >= 0)
             cout << "yes" <<endl;
         else
         {
           cout << "no" <<endl;
         }
         graph = vector<pair<ll, pair<ll, ll>>> ();
         nodes = vector <ll> ();
    }




}
