#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;


int main() {
	string s;
	cin >> s;
	int mx = -1;
	map<char, int> map;
	set<pair<int, char>, greater<pair<int, char>>> SET;
	for (int i = 0; i < s.size(); i++) {
		char c = s[i];
		auto it = map.find(c);
		if (it == map.end()) {
			map[c] = 1;
			SET.insert({ map[c], c });
		}
		else {
			SET.erase({ map[c], c });
			map[c]++;
			SET.insert({ map[c], c });
		}
		
	}
	if (map.size() <= 2)
		cout << 0;
	else {
		int sum = SET.begin()->first;
		SET.erase(SET.begin());
		sum += SET.begin()->first;
		cout << s.size() - sum;
	}
}