#include <bits/stdc++.h>
#include <iostream> 
#include <string>
using namespace std;


void printall(vector<vector<int>> &indexs,vector<string> &word,int lasti){
    cout<<word[lasti];
    for(int u : indexs[lasti])
        printall(indexs,word,u);
}

int main(){
    cin.tie(NULL);ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    string a;
    vector<string> words(n);
    for(int i=0;i<n;i++) {
        cin >> words[i];
    }
    int x,y,last=0;
    vector<vector<int>> indexs;
    indexs.assign(n, vector<int>());
    for(int i=0;i<n-1;i++) {
        cin >> x >> y;
        x--;
        y--;
        indexs[x].push_back(y);
        last=x;
    }
    printall(indexs,words,last);
}