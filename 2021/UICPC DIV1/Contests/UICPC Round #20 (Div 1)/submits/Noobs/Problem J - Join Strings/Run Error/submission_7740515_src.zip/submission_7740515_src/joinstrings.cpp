#include <bits/stdc++.h>
#include <iostream> 
#include <string>
using namespace std;

vector<string> words;

void printall(vector<vector<int>> &indexs,int lasti){
    cout<<words[lasti];
    for(int u : indexs[lasti])
        printall(indexs,u);
}

int main(){
    cin.tie(NULL);ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    string a;
    for(int i=0;i<n;i++) {
        cin >> a;
        words.push_back(a);
    }
    int x,y,last;
    vector<vector<int>> indexs;
    indexs.assign(n, vector<int>());
    for(int i=0;i<n-1;i++) {
        cin >> x >> y;
        x--;y--;
        indexs[x].push_back(y);
        last=x;
    }
    printall(indexs,last);
}