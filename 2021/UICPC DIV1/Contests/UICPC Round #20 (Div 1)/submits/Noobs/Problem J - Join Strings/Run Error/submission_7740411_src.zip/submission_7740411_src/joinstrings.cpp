#include <bits/stdc++.h>
#include <iostream> 
#include <string>
using namespace std;

int main(){
    cin.tie(NULL);ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    vector<string> words(n);
    for(int i=0;i<n;i++) {
        cin >> words[i];
    }
    int x,y,last;
    for(int i=0;i<n-1;i++) {
       cin >> x >> y;
       x--;y--;
       words[x]+=words[y];
       last=x;
    }
    cout<<words[last];
}