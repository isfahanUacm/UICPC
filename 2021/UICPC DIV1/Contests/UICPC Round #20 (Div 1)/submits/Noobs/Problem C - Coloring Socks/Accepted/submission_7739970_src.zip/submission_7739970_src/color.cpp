#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int s, c, k, socks[100003];

int main(){
    cin >> s >> c >> k;
    for(int i = 0; i < s; i++)
        cin >> socks[i];
    sort(socks, socks + s);
    int tempc=1, res=1, dif =socks[0];
    for(int i = 1; i < s; i++){
        if(tempc == c || socks[i] - dif > k){
            res++;
            tempc = 1;
            dif = socks[i];
        }
        else{
            tempc++;
        }
    }
    cout << res << endl;
}