#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;

vector<string> s;
string solution;
vector<bool> visited;
vector<bool> isFirstLetter;
ll val[26];
ll multInItems[26];
ll multInSolution[26];
ll answer;

set<ll> allLettersSet;
vector<ll> allLetters;

void f(ll index)
{
    if(index == allLetters.size())
    {
        ll ans1 = 0;
        ll ans2 = 0;

        for(ll i = 0; i < allLetters.size(); i++)
        {
            ans1 += multInItems[allLetters[i]]    * val[allLetters[i]];
            ans2 += multInSolution[allLetters[i]] * val[allLetters[i]];
        }
        if(ans1 == ans2)
        {
            answer++;
//            for(ll i: val)
//            {
//                cout << i << " ";
//            }
//            cout << endl;
        }
        return;
    }

    for(ll j = 0; j < 10; j++)
    {
        if(isFirstLetter[allLetters[index]] && j == 0)
        {
            continue;
        }
        if(!visited[j])
        {
            val[allLetters[index]] = j;
            visited[j] = true;
            f(index + 1);
            val[allLetters[index]] = 0;
            visited[j] = false;
        }
    }
}

int main()
{
    ll n;
    cin >> n;
    n--;

    s = vector<string>(n);
    isFirstLetter = vector<bool>(26, false);
    fill(val, val + 26, -1);
    for(ll i = 0; i < n; i++)
    {
        cin >> s[i];
        isFirstLetter[s[i][0] - 'A'] = true;
        reverse(s[i].begin(), s[i].end());
        for(ll j = 0; j < s[i].size(); j++)
        {
            char c = s[i][j];
            val[c - 'A'] = 0;
            allLettersSet.insert(c - 'A');
            multInItems[c - 'A'] += pow(10, j);
        }
    }

    cin >> solution;
    isFirstLetter[solution[0] - 'A'] = true;
    reverse(solution.begin(), solution.end());
    for(ll j = 0; j < solution.size(); j++)
    {
        char c = solution[j];
        val[c - 'A'] = 0;
        allLettersSet.insert(c - 'A');
        multInSolution[c - 'A'] += pow(10, j);
    }
    answer = 0;
    for(ll i: allLettersSet)
    {
        allLetters.push_back(i);
    }
    visited = vector<bool>(10, false);

    f(0);

    cout << answer;
    return 0;
}