#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;
ll n, m;
vector<vector<pll>> graph;
vector<vector<pll>> SPTree;
vector<ll> dist;
vector<bool> visited;


void dijkstra(ll index)
{
    multiset<pll> q;
    q.insert({0, index});
    dist[index] = 0;

    while(q.size())
    {
        ll current = q.begin()->second;
        ll w = q.begin()->first;
        q.erase(q.begin());

        visited[current] = true;

        for(pll i: graph[current])
        {
            if(!visited[i.first])
            {
                if(dist[current] + i.second < dist[i.first])
                {
                    dist[i.first] = w + i.second;
                    q.insert({w + i.second, i.first});
                }
            }
        }
    }
}

void buildSPTree(ll index)
{
    visited[index] = true;
    for(pll i: graph[index])
    {
        if(dist[i.first] + i.second == dist[index])
        {
            SPTree[i.first].push_back({index, i.second});
            SPTree[index].push_back({i.first, i.second});
            if(!visited[i.first])
            {
                buildSPTree(i.first);
            }
        }
    }
}

int main()
{
    cin >> n >> m;
    graph = vector<vector<pll>>(n);

    for(ll i = 0; i < m; i++)
    {
        ll a, b, w;
        cin >> a >> b >> w;
        graph[a].push_back({b, w});
        graph[b].push_back({a, w});
    }

    visited = vector<bool>(n, false);
    dist    = vector<ll> (n, LLONG_MAX);
    dijkstra(0);

    visited = vector<bool>(n, false);
    SPTree  = vector<vector<pll>>(n);
    buildSPTree(n - 1);

    ll ans = 0;
    for(ll i = 0; i < SPTree.size(); i++)
    {
        for (pll j: SPTree[i])
        {
            ans += j.second;
        }
    }
    cout << ans;
    return 0;
}