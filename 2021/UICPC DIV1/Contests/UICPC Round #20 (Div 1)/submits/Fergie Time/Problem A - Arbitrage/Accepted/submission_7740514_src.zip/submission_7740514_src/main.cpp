#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

vector<pair<pll,double>> cur;
map <string , ll > m;
ll counter = 0;
double arr[200][200];
void toint(string a){
    m[a] = counter;
    //cout <<a << " : " <<counter<<endl;

}


int main()
{
    ll c,n;
    double n1,n2;
    string a,b,k;
    ll mul=0;
    bool flag  = false;
    cin >> c;
    while(c)
    {

        for (ll i=0;i<c;i++)
        {
            cin >> a;
            toint(a);
            counter++;
        }

        cin >> n;
       // cur = vector<pair<pll,double>>(n);
        fill(&arr[0][0],&arr[0][0]+200*200,0.0);
        for (ll i=0;i<n;i++)
        {
            cin >> a >> b;
            cin >> k;
            n1 = 0;
            n2 = 0;
            mul = 0;
            flag = false;
            for(ll i=0;i<k.size();i++)
            {
                if (k[i] == ':')
                {
                    mul = 0;
                    flag = true;
                }
                else if (!flag)
                {
                    n1 *= pow(10,mul);
                    mul ++;
                    n1 += k[i] - 48;

                }
                else
                {
                    n2 *= pow(10,mul);
                    mul ++;
                    n2 += k[i] - 48;
                }



            }

           // cur.push_back({{m[a],m[b]},(double)n2/n1});
           // watch(n2/n1);
            arr[m[a]][m[b]] = (double) n2/n1;
//             watch(arr[m[a]][m[b]]);
//             watch(m[a]);
//             watch(m[b]);

        }
//        for (ll i=0;i<c;i++)
//        {
//            for (ll j=0;j<c;j++)
//                cout << arr[i][j] << " ";
//            cout << endl;
//        }
        flag = false;
        for (ll i=0;i<c;i++)
            arr[i][i] = 1.0;
        for(ll i=0;i<c;i++)
          for(ll j=0;j<c;j++)
              for(ll k=0;k<c;k++)
              {
                  arr[j][k] = max(arr[j][k], arr[j][i] * arr[i][k]);
              }
//        for (ll i=0;i<c;i++)
//        {
//            for (ll j=0;j<c;j++)
//                cout << arr[i][j] << " ";
//            cout << endl;
//        }

        for(ll i=0;i<c;i++)
        {
            if (arr[i][i] > 1.0)
            {
                flag = true;
            }
        }
        if (flag)
            cout << "Arbitrage"<<endl;
        else
        {
           cout << "Ok"<<endl;
        }




       flag = false;
       counter = 0;
        cin >> c;

    }
}
