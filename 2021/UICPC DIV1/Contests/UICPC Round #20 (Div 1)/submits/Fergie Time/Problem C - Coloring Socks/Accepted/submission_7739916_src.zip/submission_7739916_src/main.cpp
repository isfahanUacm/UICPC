#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;




int main()
{
    ll s,c,k;
    cin >> s >> c >> k;
    vector <ll> socks(s);
    for (ll i=0;i<s;i++)
        cin >> socks[i];
    sort(socks.begin(),socks.end());
    ll counter = 1;
    ll t = socks[0];
    ll capacity = 1;
    ll temp = socks[0];
    for (ll i=1;i<s;i++)
    {
        if (capacity < c)
        {
            if (socks[i] - socks[i-1] <= k)
            {
                capacity++;

            }
            else
            {
                counter ++;
                capacity = 1;

            }
        }
        else
        {
            counter ++;
            capacity =1;

        }
    }
    cout << counter;

}
