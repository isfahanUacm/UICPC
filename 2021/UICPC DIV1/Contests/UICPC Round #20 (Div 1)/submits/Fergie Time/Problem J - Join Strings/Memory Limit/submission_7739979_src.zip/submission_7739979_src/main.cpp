#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    ll n;
    cin >> n;
    vector<string> s(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> s[i];
    }
    for(ll i = 0; i < n - 1; i++)
    {
        ll a, b;
        cin >> a >> b;
        a--;
        b--;
        s[a] = s[a] + s[b];
        s[b] = "";
    }
    for(string i: s)
    {
        cout << i;
    }
    return 0;
}