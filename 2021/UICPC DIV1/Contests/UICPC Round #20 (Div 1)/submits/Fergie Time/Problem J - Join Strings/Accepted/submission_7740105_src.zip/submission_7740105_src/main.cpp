#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;
vector<vector<ll>> graph;
vector<string> s;

void dfs(ll index)
{
    cout << s[index];
    for(ll i: graph[index])
    {
        dfs(i);
    }
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    ll n;
    cin >> n;
    s = vector<string>(n);

    vector<ll> sample;
    graph = vector<vector<ll>> (n, sample);

    for(ll i = 0; i < n; i++)
    {
        cin >> s[i];
    }
    ll start = 0;
    for(ll i = 0; i < n - 1; i++)
    {
        ll a, b;
        cin >> a >> b;
        a--;
        b--;
        graph[a].push_back(b);
        start = a;
    }
    dfs(start);
    return 0;
}