import math


def main():
    xb, yb = map(int, input().split(" "))
    rx1, ry1, rx2, ry2 = map(int, input(). split(" "))

    gcd = math.gcd(xb, yb)
    closest_tree_x = None
    closest_tree_y = None

    if xb == yb:
        in_sight = True
        for x in range(1, xb + 1):
            if x < rx1 or x > rx2 or x < ry1 or x > rx2:
                in_sight = False
                closest_tree_y = closest_tree_x = x
                break
        if in_sight:
            print("Yes")
        else:
            print("No")
            print(closest_tree_x, closest_tree_y)
    elif gcd == 1:
        print("yes")
    else:
        first_step_x = xb / gcd
        first_step_y = yb / gcd
        in_sight = True
        for k in range(1, gcd):
            step_x = k * first_step_x
            step_y = k * first_step_y
            if step_x < rx1 or step_x > rx2 or step_y < ry1 or step_y > ry2:
                in_sight = False
                closest_tree_x = step_x
                closest_tree_y = step_y
                break
        if in_sight:
            print("Yes")
        else:
            print("No")
            print(int(closest_tree_x), int(closest_tree_y))


if __name__ == "__main__":
    main()