import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author golnoosh
 */
public class Socks2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
       int S = input.nextInt();    //number of socks
       int C = input.nextInt();    //capacity of laundry machine
       int K = input.nextInt();    //maximum color diffrence
       
       int[] D = new int[S];
       for(int i=0; i<S; i++) {
           D[i] = input.nextInt();
       }
       
       Arrays.sort(D);
       
       int machinecount=1;
       int Ccopy = C;
       int testwith = 0;
       for(int i=1; i<S; i++)
       {
           if(i==testwith)
               continue;
           if((D[i]-D[testwith]) > K) {
                machinecount++;
                testwith = i;
                C = Ccopy-1;
           }
           
           else {
               if(C==0) {
                   machinecount++;
                   C = Ccopy-1;
                   testwith = i;
               }
                   
               else {
                  C--;
               }
           }
       }
       
        System.out.println(machinecount);
    }
    
}
