#include <bits/stdc++.h>
using namespace std ;

int n;
vector <string> s;
vector <vector <int>> num;

void print(int index){
    cout << s[num[index][0]];
    for (int i=1 ; i<num[index].size() ; i++){
        print(num[index][i]);
    }
}

int main(){
    int a, b;

    cin >> n;
    s.resize(n);
    num.resize(n);

    for (int i=0 ; i<n ; i++)
        num[i].push_back(i);

    for (int i=0 ; i<n ; i++)
        cin >>s[i];
    
    for (int i=0 ; i<n-1 ; i++){
        cin >> a >> b;
        num[a-1].push_back(b-1);
        if (i == n-2){
            print(a-1);
            cout << endl;
        }
    }
    if (n == 1)
        cout << s[0] << endl;
 

    return 0;
}