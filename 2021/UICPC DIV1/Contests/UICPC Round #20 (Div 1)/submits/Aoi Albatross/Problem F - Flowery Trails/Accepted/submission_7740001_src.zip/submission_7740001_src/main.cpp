#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 1e5 + 10;
ll dist[MAX];
vector<ll> parent[MAX];
set<pair<ll, ll>> ss;
vector<pair<ll, ll>> adj[MAX];
bool isValid[MAX];
ll ans = 0;

void dijkstra(ll start) {
    dist[start] = 0;
    parent[start].clear();
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (dist[v.first] > dist[u] + v.second) {
                ss.erase({dist[v.first], v.first});
                dist[v.first] = dist[u] + v.second;
                ss.insert({dist[v.first], v.first});
                parent[v.first].clear();
                parent[v.first].push_back(u);
            }
            else if (dist[v.first] == dist[u] + v.second) {
                parent[v.first].push_back(u);
            }
        }
    }
}

void path(ll x) {
    isValid[x] = true;
    if (x == 0)
        return;
    for (auto temp: parent[x]) {
        ans += dist[x] - dist[temp];
        if (!isValid[temp]) {
            path(temp);
        }
    }
}

int main() {
    ll n, m;
    cin >> n >> m;
    for (ll i = 0; i < n; ++i) {
        dist[i] = LONG_LONG_MAX;
    }
    for (ll i = 0; i < m; ++i) {
        ll w, a, b;
        cin >> a >> b >> w;
        adj[a].emplace_back(b, w);
        adj[b].emplace_back(a, w);
    }
    dijkstra(0);
    path(n - 1);
    cout << ans * 2 << endl;
}
