#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
ll cx1, cy1, cx2, cy2;

bool in_rect(ll x, ll y) {
    ll xmin = min(cx1, cx2);
    ll xmax = max(cx1, cx2);
    ll ymin = min(cy1, cy2);
    ll ymax = max(cy1, cy2);
    return x >= xmin && x <= xmax && y >= ymin && y <= ymax;
}

ll gcd(ll a, ll b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}


int main() {
    ll x, y;
    cin >> x >> y;
    cin >> cx1 >> cy1 >> cx2 >> cy2;

    ll tx = x, ty = y;
    ll t = gcd(tx, ty);
    tx /= t;
    ty /= t;
    if (t == 1) {
        cout << "Yes" << endl;
        return 0;
    }

    if (in_rect(tx, ty) && in_rect(x - tx, y - ty)) {
        cout << "Yes" << endl;
    }
    else {
        cout << "No" << endl;
        for (int i = 1; ; ++i) {
            if (!in_rect(tx * i, ty * i)) {
                cout << tx * i << ' ' << ty * i << endl;
                break;
            }
        }
    }
}
