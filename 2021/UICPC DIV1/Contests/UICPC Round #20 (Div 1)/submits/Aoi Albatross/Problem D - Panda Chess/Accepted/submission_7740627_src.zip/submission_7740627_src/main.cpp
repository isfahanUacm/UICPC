#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAX = 1e5 + 100;
vector<int> adj[MAX];
bool visited[MAX];
map<string, int> id;
stack<int> stc;

void dfs(int x) {
    visited[x] = true;
    for (auto temp: adj[x]) {
        if (!visited[temp])
            dfs(temp);
    }
    stc.push(x);
}

int main() {
    int n, m, d;
    cin >> n >> m >> d;
    int index = 0;
    for (int i = 0; i < m; ++i) {
        string a, b;
        cin >> a >> b;
        if (id.count(a) == 0) {
            id[a] = index++;
        }
        if (id.count(b) == 0) {
            id[b] = index++;
        }
        adj[id[a]].push_back(id[b]);
    }

    for (int i = 0; i < index; ++i) {
        if (!visited[i]) {
            dfs(i);
        }
    }
    map<int, int> ord;
    int ind = 0;
    while (!stc.empty()) {
        ord[stc.top()] = ind++;
        stc.pop();
    }
    int del = 0;
    vector<int> vc;
    for (int i = 0; i < n; ++i) {
        string temp;
        cin >> temp;
        if (id.count(temp) == 0)
            del++;
        else {
            vc.push_back(ord[id[temp]]);
        }
    }


    int ans = 0;
    int size = vc.size() + 100;
    int f[size];
    int x[size];

    for (int i = 0; i < size; ++i) {
        x[i] = INT_MAX;
    }
    f[0] = 0;

    for (int i = 1; i <= vc.size(); ++i) {
        int l = 0, r = i;
        while (l + 1 < r) {
            int mid = (l + r) / 2;
            if (x[mid] < vc[i - 1])
                l = mid;
            else
                r = mid;
        }
        f[i] = l + 1;
        x[l + 1] = vc[i - 1];
        if (f[i] > ans)
            ans = f[i];
    }
    cout << vc.size() - ans + n - ans + del << endl;
}