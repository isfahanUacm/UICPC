#include <bits/stdc++.h>
using namespace std;

int n, d, dp[100+10][20000][3];
vector <int> num; 
vector <int> eat;

int solve(int i, int j, int k){
    if (i == n) return 0;
    if (dp[i][j][k] != -1) return dp[i][j][k];
    if (k == 2){
        j = 0;
        k=1;
    }
    int tmp1 = solve(i+1, j-1, k+1);
    int tmp2 = min(num[i], eat[j]) + solve(i+1, j+1, 0);

    return dp[i][j][k] = max(tmp1, tmp2);
}

int main(){
    cin >> n >> d;
    
    memset(dp, -1, sizeof(dp));

    for (int i=0 ; i<n ; i++){
        eat.push_back(d);
        d = (d*2) / 3;
    }

    num.resize(n);
    for (int i=0 ; i<n ; i++)
        cin >> num[i];

    cout << solve(0, 0, 0) << endl;


    return 0;
}