#include <bits/stdc++.h>
using namespace std;

int n, d, dp[100+10][200000];
vector <int> num; 
vector <int> eat;

int solve(int i, int j){
    if (i == n) return 0;
    if (dp[i][j] != -1) return dp[i][j];

    int tmp1 = solve(i+1, j-1);
    int tmp2 = min(num[i], eat[j]) + solve(i+1, j+1);

   // cout << i << " " << j << " : " << max(tmp1, tmp2) << endl;

    return dp[i][j] = max(tmp1, tmp2);
}

int main(){
    cin >> n >> d;
    
    memset(dp, -1, sizeof(dp));

    eat.resize(500);
    int tmp = (d*3)/2;
    for (int i=499 ; i>=0 ; i--){
        eat[i] = tmp;
        tmp = (tmp*3) / 2;
    }

    while (d > 0){
        eat.push_back(d);
        d = (d*2) / 3;
    }

    for (int i=0 ; i<500 ; i++)
        eat.push_back(0);

    num.resize(n);
    for (int i=0 ; i<n ; i++)
        cin >> num[i];

    cout << solve(0, 500) << endl;


    return 0;
}