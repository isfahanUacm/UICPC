n, c, k = map(int, input().split())
l = list(map(int, input().split()))
l.sort()
cnt = 1
tc = c-1
index = 0
while index < n-1:
    if tc != 0:
        if l[index+1] - l[index] <= k:
            index += 1
            tc -= 1
        else:
            cnt +=1
            tc = c-1
            index += 1
    else:
        cnt +=1
        tc = c-1
        index += 1

print(cnt)