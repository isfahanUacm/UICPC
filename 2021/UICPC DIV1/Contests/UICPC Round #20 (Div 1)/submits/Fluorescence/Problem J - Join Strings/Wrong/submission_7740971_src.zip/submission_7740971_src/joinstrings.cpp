#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<vector<int>> adj(100005);
vector<string> v;
bool vis[100005];
int indeg[100005];
bool done[100005];

void dfs(int u) {
    vis[u] = true;
    printf(v[u].c_str());
    cout << v[u];
    for (int v : adj[u]) {
        if (!vis[v]) {
            dfs(v);
        }
    }
}

int main()
{
    int n;
    scanf("%d", &n);
    //cin >> n;

    char t[1000003];
    string s;
    for (int i = 0; i < n; i++)
    {
        scanf("%s", t);
        //cin >> s;
        s = t;
        v.push_back(s);
    }

    int a, b, rem;
    fill_n(vis, n, false);
    for (int i = 0; i < n - 1; i++)
    {
        //scanf("%d %d", &a, &b);
        cin >> a >> b;
        a--, b--;
        if (!done[b]) {
            adj[a].push_back(b);
            indeg[b]++;
            done[b] = 1;
        }
    }

    for (int i = 0; i < n; i++) {
        if (!indeg[i]) {
            dfs(i);
            printf("\n");
        }
    }
    //dfs(rem);
}
