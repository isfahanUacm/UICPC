#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<vector<int>> adj(100005);
vector<string> v;
bool vis[100005];
void dfs(int u){
    vis[u] = true;
    printf(v[u].c_str());
    for(int v:adj[u]){
        if(!vis[v]){
            dfs(v);
        }
    }
}
int main()
{
    int n;
    scanf("%d", &n);

    char t[1000003];
    string s;
    for (int i = 0; i < n; i++)
    {
        scanf("%s", t);
        s = t;
        v.push_back(s);
    }

    int a, b, rem;
    fill_n(vis, n, false);
    for (int i = 0; i < n-1; i++)
    {
        scanf("%d %d", &a, &b);
        a--, b--;
        rem = a;
        adj[a].push_back(b);
    }
    dfs(rem);

}