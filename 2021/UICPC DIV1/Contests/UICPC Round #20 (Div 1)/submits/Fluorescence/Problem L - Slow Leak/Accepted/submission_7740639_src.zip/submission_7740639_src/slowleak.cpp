#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<vector<pair<int, ll>>> adj(505);
ll dist[505];
priority_queue<pair<ll, int>> q;
int n, m, t;
ll d;
ll AdjMat[505][505];
bool rep[505];

void dijkstra()
{
    pair<ll, int> p;
    ll ww, u;
    while(!q.empty())
    {
        p = q.top(); q.pop();
        ww = p.first; u = p.second;
        if(ww>dist[u]) continue;

        for(auto v : adj[u])
        {
            if(dist[v.first] > dist[u] + v.second)
            {
                dist[v.first] = dist[u] + v.second;
                q.push({dist[v.first], v.first});
            }
        }
    }
}

int main()
{
    memset(AdjMat, 2147483650, sizeof(AdjMat));
    //cout<<AdjMat[1][1]<<endl;
    cin>>n>>m>>t>>d;
    fill_n(rep, n+1, false);
    int rl;
    for (int i = 0; i < t; i++)
    {
        cin>>rl;
        rep[rl] = true;
    }
    int a, b;
    ll w;
    for (int i = 0; i < m; i++)
    {
        cin>>a>>b>>w;
        AdjMat[a][b] = w;
        AdjMat[b][a] = w;
    }
    //FW
    for (int k = 1; k < n+1; k++) // remember that loop order is k->i->j
        for (int i = 1; i < n+1; i++)
            for (int j = 1; j < n+1; j++)
                AdjMat[i][j] = min(AdjMat[i][j], AdjMat[i][k] + AdjMat[k][j]);

            /*for (int i = 1; i < n+1; i++){
                for (int j = 1; j < n+1; j++){
                    cout<<AdjMat[i][j]<<" ";
                }cout<<endl;
            }*/

            for (int i = 1; i < n+1; i++){
                for (int j = 1; j < n+1; j++){
                    /*if(i == 1 || j==1){
                        if(AdjMat[i][j] != INT_MAX && AdjMat[i][j] <= d){
                            adj[i].push_back({j, AdjMat[i][j]});
                        }
                    }
                    else if(i == n || j==n){
                        if(AdjMat[i][j] != INT_MAX && AdjMat[i][j] <= d){
                            adj[i].push_back({j, AdjMat[i][j]});
                        }
                    }
                    else if(rep[i] || rep[j]){
                        if(AdjMat[i][j] != INT_MAX && AdjMat[i][j] <= d){
                            adj[i].push_back({j, AdjMat[i][j]});
                        }
                    }*/
                    if((i == 1 || i == n || rep[i])&&(j == 1 || j == n || rep[j])){
                        if(AdjMat[i][j] < INT_MAX && AdjMat[i][j] <= d){
                            adj[i].push_back({j, AdjMat[i][j]});
                        }
                    }
                }
            }

            /*for (int i = 1; i < n+1; i++)
            {
                cout<<i<<endl;
                for (int j = 0; j < adj[i].size(); j++)
                {
                    cout<<adj[i][j].first<<" ";
                }
                cout<<endl<<endl;
            }*/

            fill_n(dist, n+1, LONG_LONG_MAX);
            dist[1] = 0;
            q.push({0, 1});
            dijkstra();
            if(dist[n] < LONG_LONG_MAX)
                cout<<dist[n]<<endl;
            else cout<<"stuck";
}