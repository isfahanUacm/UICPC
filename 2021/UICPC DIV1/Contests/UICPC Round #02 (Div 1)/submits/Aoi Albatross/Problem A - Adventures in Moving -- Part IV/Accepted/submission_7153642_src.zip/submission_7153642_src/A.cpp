#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll d;
ll dp[110][210],pr[110],ds[110];
ll solve(ll i,ll f){
    f-=ds[i];
    if(f<0)return 1000000000;
    if(dp[i][f]!=-1)return dp[i][f];
    if(i==d){
        return f<100 ? 1000000000:0;
    }
    ll ans=1000000000;
    for(ll j=0;j<=200-f;j++){
        ans=min(ans,pr[i]*j+solve(i+1,f+j));
    }
    dp[i][f]=ans;
    return dp[i][f];
}
int main(){
    memset(dp,-1,sizeof(dp));
    cin >> d;
    ll i=0,di,pd=0,ps;
    while(cin >> di >> ps) {
        pr[i] = ps;
        ds[i] = di-pd;
        pd = di;
        i++;
    }
    ds[i]=d-pd;
    d=i;
    ll ans = solve(0,100);
    if(ans >= 1000000000){
        cout<<"Impossible"<<endl;
        return 0;
    }
    cout<<ans<<endl;
    return 0;
}