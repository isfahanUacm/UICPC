

counter = 1
num = int(input())
brr = {}
while num != 0:
    for i in range(num):
        name = input().lower()
        name = name[::-1]
        # print(name)
        if " " in name:
            name = name[:name.index(' ')+1:]
            name = name[:len(name)-1:]

        name = name[::-1]
        if name in brr:
            brr[name]+=1
        else:
            brr[name]=1

    ww = str(counter)+':'
    print('List', ww)


    for key in sorted(brr.keys()):
        print(key, '|', brr[key])
    counter+=1
    brr.clear()

    num = int(input())





