import java.util.*;

public class DA_Sort1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt(), count;
        for (int i = 0; i < n; i++) {
            input.nextInt();
            int length = input.nextInt();
            Info[] array = new Info[length], sort_array = new Info[length];
            LinkedList<Info> sort = new LinkedList<>(), non_sort = new LinkedList<>();
            for (int j = 0; j < length; j++) {
                int value = input.nextInt();
                array[j] = new Info(j, value);
                sort_array[j] = new Info(j, value);
            }

            Arrays.sort(sort_array, Comparator.comparingInt(o -> o.value));
            sort.add(sort_array[0]);
            for (int j = 1; j < length; j++) {
                if (sort.get(sort.size() - 1).index < sort_array[j].index) {
                    sort.add(sort_array[j]);
                }
                else non_sort.add(sort_array[j]);
            }
            count = non_sort.size();
            while (!non_sort.isEmpty() && sort.removeLast().value > non_sort.get(0).value) count++;
            System.out.println((i+1) + " " + count);
        }
    }
}

class Info {
    int index;
    int value;
    public Info (int i, int val) {
        index = i;
        value = val;
    }
}
