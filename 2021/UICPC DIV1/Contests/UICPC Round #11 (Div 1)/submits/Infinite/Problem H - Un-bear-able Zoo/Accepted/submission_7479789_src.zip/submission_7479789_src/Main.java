import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int t = 1;
		s.nextLine();
		while (n != 0){
			String st[] = new String[n];
			for (int i = 0 ; i < n ; i ++){
				st[i] = s.nextLine();
			}
			ArrayList<String> kind = new ArrayList<>();
			ArrayList<animal> a = new ArrayList<>();
			int cnt [] = new int [n];
			for (int i = 0 ; i < n ; i ++ ) cnt[i] = 1;
			for (int i = 0 ; i < n ; i ++){
				String tmp = "";
				int space = 0;
				for (int j = st[i].length() - 1 ; j >= 0 ; j --){
					if (st[i].charAt(j) == ' ') {
						space = j;
						break;
					}
				}
				//System.out.println(space);
				if (space == 0) space -- ;
				for (int k = space + 1 ; k < st[i].length() ; k ++) {
					tmp += st[i].charAt(k);
				}
				tmp = tmp.toLowerCase();
				if ( ! kind . contains(tmp) ) {
					kind.add(tmp);
					animal aa = new animal();
					aa.cnt = 1;
					aa.k = tmp;
					a.add(aa);
				}
				else{
					cnt[kind.indexOf(tmp)] ++ ;
					for (int k = 0 ; k < a.size() ; k ++){
						if (a.get(k).k . equals(tmp)){
							a.get(k).cnt ++ ;
						}
					}
				}

			}

			Collections.sort(kind);

			System.out.println("List " + t + ":" );
			for (int k = 0 ; k < kind.size() ; k ++){
				for (int j = 0 ; j < a.size() ; j ++){
					if (a.get(j).k.equals(kind.get(k))){
						System.out.println(a.get(j).k + " " + "| " + a.get(j).cnt);
						a.get(j).cnt = -1;
						break;
					}
				}
			}
			t ++ ;
			n = s.nextInt();
			s.nextLine();
		}
	}
}
class animal {
	int cnt ;
	String k ;
}