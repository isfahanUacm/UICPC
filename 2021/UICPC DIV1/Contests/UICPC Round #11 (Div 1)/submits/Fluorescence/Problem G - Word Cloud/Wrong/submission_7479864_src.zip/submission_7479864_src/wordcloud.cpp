#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

bool cmp(pair<string, lli> a, pair<string, lli> b){
    return a.first < b.first;
}

int main() {
    lli w, n, cmax, p, curent, overal, hmax, cloud;
    cloud = 0;
    while(true){
        cin>>w>>n;
        if (w == 0 && n == 0) break;
        vector<pair<string, lli>> set;
        vector<pair<string, lli>> width;
        vector<pair<string, lli>> height;
        pair<string, lli> word;
        overal = 0; hmax = 0;
        cloud ++;
        for (int i = 0; i < n; i++)
        {
            cin>>word.first>>word.second;
            if (word.second >= 5) set.push_back(word);
        }

        sort(set.begin(), set.end(), cmp);

        cmax = set[0].second;
        for (int i = 1; i < n; i++)
        {
            if(cmax < set[i].second) cmax = set[i].second;
            //cout<<set[i].first<<endl;
        }

        for (int i = 0; i < n; i++)
        {
            p = 8 + ceil(40*(set[i].second - 4) / (cmax - 4));
            height.push_back({set[i].first, p});
            width.push_back({set[i].first, ceil(0.5625 * set[i].first.length() * p)});
        }
        curent = 0;
        hmax = height[0].second;
        for (int i = 0; i < n; i++)
        {
            //cout<<width[i].first<<width[i].second<<" "<<curent<<" "<<overal;
            curent += width[i].second + ceil(0.5625 * 10);

            if (curent >= w){
                curent = width[i].second;
                overal += hmax;
                hmax = 0;
            }

            if(height[i].second > hmax) hmax = height[i].second;

            //cout<<width[i].first<<" "<<curent<<" "<<overal<<endl;
        }
        overal += hmax;
        cout<<"CLOUD "<<cloud<<": "<<overal<<endl;
        //cout<<height[5].second<<height[0].second<<height[2].second<<height[5].second;
    }
    
}