#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;


int main()
{
    int n;
    cin >> n;
    vector<int> out;
    vector<string> v;
    int list = 0;
    while (n) {
        list++;
        out.push_back(list);
        string l = "List " + to_string(list) + ":";
        v.push_back(l);
        string line;
        map<string, int> map;
        cin.ignore();
        for (int j = 0; j < n; j++) {
            getline(cin, line);
            int i;
            for (i = line.size() - 1; i >= 0; i--) {
                if (line[i] == ' ') {
                    break;
                }
            }
            if (i == 0) {
                i--;
            }
            string w = line.substr(i + 1, line.size() - 1 - i);
            transform(w.begin(), w.end(), w.begin(), ::tolower);
            auto it = map.find(w);
            if (it == map.end()) {
                map[w] = 1;
            }
            else {
                map[w]++;
            }
        }
        for (auto it : map) {
            string name = it.first + " | " + to_string(it.second);
            v.push_back(name);
        }

        cin >> n;
    }

    for (auto it : v) {
        cout << it << endl;
    }
}