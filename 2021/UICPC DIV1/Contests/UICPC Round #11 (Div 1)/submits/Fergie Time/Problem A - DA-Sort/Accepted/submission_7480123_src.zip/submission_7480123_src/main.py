p = int(input())
while p!=0:
    p-=1
    k , m =map(int,input().split())
    li = []
    li2 = []
    while m>0:
        li.extend(map(int,input().split()))
        m -= 10

    li2 = li.copy()
    li2.sort()
    j = 0
    for i in range(len(li)):
         if li[i] == li2[j]:
             j += 1

    print(k,len(li)-j)