from collections import OrderedDict
n=1
t=1
while n != 0:

    n=int(input())
    if n==0:
        break

    animals=[]
    i=0
    for i in range(n):
        animals.append(input())

    ans={}


    for item in animals:
        animi=item.split()

        ani=animi[len(animi)-1].lower()
        mylist= ans.keys()
        if ani in mylist:
            ans[ani] +=1
        else:
            ans[ani]=1




    dict1 = OrderedDict(sorted(ans.items()))

    print("List",t)
    t+=1
    for i in dict1:
        print(i,"|",dict1[i])