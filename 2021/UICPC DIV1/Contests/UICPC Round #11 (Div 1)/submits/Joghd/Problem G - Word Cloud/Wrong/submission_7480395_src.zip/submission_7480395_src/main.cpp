#include <iostream>
#include <queue>
#include <string>
using namespace std;

int P(int a,int b) {
    a -= 4;
    b -= 4;
    a *= 40;
    if(a%b==0) a/=b;
    else {a/=b; a++;}
    return a+8;
}

int W(int p,int t) {
    p = 9*p*t;
    if(p%16==0) return p/16;
    return p/16 + 1;
}
int que(int w,int n) {
    string frut; int max=0;
    int sizes[n]; int num[n];
    for(int i=0;i<n;i++) {
        cin >> frut;
        sizes[i] = frut.size();
        cin >> num[i];
        if(max<num[i]) max = num[i];
    }
    int maxhi=0;
    int line = 0;
    int ans = 0;
    for(int i=0;i<n;i++) {

        int p = P(num[i],max);
        int ww = W(p,sizes[i]);
        if(line +ww > w || i==n-1) {
            ans += maxhi;

            line = 0;
            if(i==n-1) return ans;
            i--;
            continue;

        }
        if(maxhi<p) maxhi = p;
        line += ww + 10;

    }

    return ans;

}

int main() {
    int n,m;
    queue<int> x;
    while(1) {
        cin >> n >> m;
        if(n==0 && m==0) break;

        x.push(que(n,m));
    }
    int i=1;
    while (x.size()) {
        cout << "CLOUD " <<i << ": " << x.front() << endl;
        x.pop(); i++;
    }
}
