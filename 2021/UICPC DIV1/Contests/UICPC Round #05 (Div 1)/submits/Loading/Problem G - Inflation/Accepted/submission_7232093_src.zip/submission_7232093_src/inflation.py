n = int(input())
gas = list(map(int, input().split()))

gas.sort()
#print(gas)
the = [x for x in range(1,n+1)]
#print(the)
mini = 1
for i in range(n):
    if gas[i] > the[i]:
        print("impossible")
        exit()
    else:
        temp = gas[i]/the[i]
        if temp < mini:
            mini = temp
print("{:.6f}".format(mini))