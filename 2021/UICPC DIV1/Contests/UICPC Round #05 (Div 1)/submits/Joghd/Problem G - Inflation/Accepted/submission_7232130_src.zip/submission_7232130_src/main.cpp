#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int n;
    cin >> n;
    float x[n];
    for(int i=0;i<n;i++)
        cin >> x[i];
    sort(x,x+n);
    float min=1;
    for(int i=0;i<n;i++) {
        if(x[i]>i+1) {
            cout << "impossible";
            return 0;
        }
        float d = i+1;
        float f=x[i]/d;
        if(min > f)
            min =f;
    }
    int ans = min * 1000000;
    float r = ans / 1000000.0;
    cout << r;

}
