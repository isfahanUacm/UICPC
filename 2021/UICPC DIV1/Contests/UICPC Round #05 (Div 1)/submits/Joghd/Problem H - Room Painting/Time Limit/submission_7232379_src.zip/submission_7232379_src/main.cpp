#include <iostream>
#include <math.h>
#include <algorithm>
using namespace std;

int main() {
    int n,m;
    cin >> n >> m;
    double st[n];
    double jo[m];
    double ans=0;
    for(int i=0;i<n;i++)
        cin >> st[i];
    for(int i=0;i<m;i++)
        cin >> jo[i];
    for(int i=0;i<m;i++) {
        double d=999999;
        for(int j=0;j<n;j++) {
            if(jo[i]<=st[j] && d>st[j]-jo[i])
                d=st[j]-jo[i];
        }
        ans +=d;
    }
    cout << ans;




}
