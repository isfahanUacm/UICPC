
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

int main ( void )
{
    int n,m,ans=0;
    cin >> n >> m;
    int a[n];
    for(int i=0;i<n;i++)
        cin >> a[i];
    sort(a,a+n);
    int b;
    for(int i=0;i<m;i++) {
        cin >> b;
        int j=0;
        while (b>a[j])
            j++;
        ans += a[j]-b;
    }
    cout << ans;
}
