#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
lli v, ed, s, e;
vector<vector<pair<lli, lli>>> adj;
lli dis[10000+5], path[10000 + 5];

//pair<int, int>

lli dijk() {
	fill_n(dis, 10000 + 5, LONG_MAX);
	fill_n(path, 10000 + 5, 0);

	dis[s] = 0;
	path[s] = 1;
	set<pair<lli, lli>> pq;
	pq.insert({dis[s] , s});

	while (!pq.empty()) {
		lli cur = pq.begin()->second;
		lli len = pq.begin()->first;
		pq.erase(pq.begin());
		for (auto it : adj[cur]) {
			lli child = it.second;
			lli w = it.first;
			if (child == -1)
				continue;
			if (dis[child] > dis[cur] + w) {
				pq.erase({ dis[child], child });
				dis[child] = dis[cur] + w;
				pq.insert({ dis[child], child });
				path[child] = path[cur];
			}
			else if (dis[child] == dis[cur] + w) {
				path[child] += path[cur];
			}
		}

	}

	return path[e];
}

int main()
{
	cin >> v >> ed;
	int x, y, w;
	vector<pair<lli, lli>> temp;
	temp.push_back({ -1, -1 });
	for (int i = 0; i < v; i++) {
		adj.push_back(temp);
	}
	for (int i = 0; i < ed; i++) {
		cin >> x >> y >> w;
		adj[x].push_back({ w,y });
	}
	cin >> s >> e;
	if (s == e)
		cout << 0;
	else
		cout << dijk();
}