#include<bits/stdc++.h>
using namespace  std;
int One(long long x)
{
    int res = 0;
    while(x>0)
    {
        if(x%2 == 1)
            res++;
        x = x/2;
    }
    return res;
}
int main()
{
    int t;
    cin>>t;
    while(t--){
        string s;
        int Max = 0;
        long long x;
        cin>>s;
        string help;
        help.clear();
        for (int i=0; i < s.size(); i++) {
            help+=s[i];
            x = stoll(help);
            Max = max(Max, One(x));

        }
        cout<<Max<<endl;

    }

}
