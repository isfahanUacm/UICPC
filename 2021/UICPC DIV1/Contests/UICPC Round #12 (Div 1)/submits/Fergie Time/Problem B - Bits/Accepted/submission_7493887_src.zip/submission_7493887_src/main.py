n=int(input())
while(n):
    n-=1
    li=input()
    max=0
    for j in range(len(li)):
        item=li[0:j+1]
        y=str(bin(int(item)))
        one_count = 0
        for i in y:
            if i == "1":
                one_count += 1
        if(one_count>max):
            max=one_count

    print(max)