n=int(input())
while(n):
    n-=1
    x=input()
    li=list(x)
    li.append(x)
    max=0
    for item in li:
        y=str(bin(int(item)))
        one_count = 0
        for i in y:
            if i == "1":
                one_count += 1
        if(one_count>max):
            max=one_count

    print(max)