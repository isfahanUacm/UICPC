import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	static int a[];
	static double dp[][];
	static int n, k;

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String in = s.next();
		int n = s.nextInt();
		String out = s.next();
		ArrayList<Character> atoms = new ArrayList<>();
		ArrayList<Long> cnts = new ArrayList<>();
		int a[] = new int[in.length()];
		Arrays.fill(a, 0);
		for (int i = 0; i < in.length() - 1; i++) {
			String strtmp = "";
			long cnt = 0;
			if (a[i] == 0 && in.charAt(i) >= 'A' && in.charAt(i) <= 'Z') {
				if (in.charAt(i + 1) < 'A') {
					for (int h = i + 1; h < in.length(); h++)
						if (in.charAt(h) < 'A') {
							strtmp += in.charAt(h);
						} else {
							break;
						}
					cnt = Long.parseLong(strtmp);
				} else cnt += 1;
				for (int j = i + 1; j < in.length(); j++) {
					String strtmp1 = "";
					if (in.charAt(j) == in.charAt(i)) {
						a[j] = -1;
						if (j < in.length() - 1 && in.charAt(j + 1) < 'A') {

							for (int h = j + 1; h < in.length(); h++) {
								if (in.charAt(h) < 'A') {
									strtmp1 += in.charAt(h);
								} else {
									break;
								}
							}
							long cntt = Long.parseLong(strtmp1);
							cnt += cntt;
						} else cnt += 1;
					}
				}
			}
			if (cnt > 0) {
				atoms.add(in.charAt(i));
				cnts.add(cnt);
			}
		}
		if (a[in.length() - 1] == 0 && in.charAt(in.length() - 1) >= 'A') {
			atoms.add(in.charAt(in.length() - 1));
			cnts.add((long) 1);
		}


		ArrayList<Character> atomsOut = new ArrayList<>();
		ArrayList<Long> cntsOut = new ArrayList<>();
		int aOut[] = new int[out.length()];
		Arrays.fill(aOut, 0);


		for (int i = 0; i < out.length() - 1; i++) {
			String strtmp = "";
			long cnt = 0;
			if (aOut[i] == 0 && out.charAt(i) >= 'A' && out.charAt(i) <= 'Z') {
				if (out.charAt(i + 1) < 'A') {
					for (int h = i + 1; h < out.length(); h++)
						if (out.charAt(h) < 'A') {
							strtmp += out.charAt(h);
						} else {
							break;
						}
					cnt = Long.parseLong(strtmp);
				} else cnt += 1;
				for (int j = i + 1; j < out.length(); j++) {
					String strtmp1 = "";
					if (out.charAt(j) == out.charAt(i)) {
						aOut[j] = -1;
						if (j < out.length() - 1 && out.charAt(j + 1) < 'A') {
							for (int h = j + 1; h < out.length(); h++) {

								if (out.charAt(h) < 'A') {
									strtmp1 += out.charAt(h);
								} else {
									break;
								}
							}
							long cntt = Long.parseLong(strtmp1);
							cnt += cntt;
						} else cnt += 1;
					}
				}
			}
			if (cnt > 0) {
				atomsOut.add(out.charAt(i));
				cntsOut.add(cnt);
			}
		}
		if (aOut[out.length() - 1] == 0 && out.charAt(out.length() - 1) >= 'A') {
			atomsOut.add(out.charAt(out.length() - 1));
			cntsOut.add((long) 1);
		}

		int con = 1;
		for (int i = 0; i < atomsOut.size(); i++) {
			if (!atoms.contains(atomsOut.get(i))) {
				con = 0;
				System.out.println(0);
				break;
			}
		}
		if (con == 1) {
			long min = Long.MAX_VALUE;
			for (int i = 0; i < atomsOut.size(); i++) {
				int indin = atoms.indexOf(atomsOut.get(i));
				long tmp = (cnts.get(indin) * n) / cntsOut.get(i);
				if (tmp < min) min = tmp;
			}

			if (min == 0) System.out.println(0);
			else {
				int sumOut = 0, sumIn = 0;
				for (int i = 0; i < cntsOut.size(); i++) {
					sumOut += cntsOut.get(i);
				}
				for (int i = 0; i < cnts.size(); i++) sumIn += cnts.get(i);
				sumIn *= n;
				for (long k = min; k >= 0; k--) {
					if (sumOut * k <= sumIn) {
						System.out.println(k);
						break;
					}
				}
			}

		}
	}

}
