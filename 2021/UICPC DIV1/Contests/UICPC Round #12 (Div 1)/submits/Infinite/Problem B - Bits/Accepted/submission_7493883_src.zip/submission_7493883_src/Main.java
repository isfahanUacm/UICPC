import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	static int a[];
	static double dp[][];
	static int n, k;

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();

		for (int i = 0 ; i < n ; i ++){
			String x = s.next();
			String tmp = "";
			int max = Integer.MIN_VALUE;
			for (int j = 0 ; j < x.length() ; j ++){
				int cnt = 0;
				tmp += x.charAt(j);
				int c = Integer.parseInt(tmp);

				String bin = Integer.toBinaryString(c);
				for (int k = 0 ; k < bin.length() ; k ++){
					if (bin.charAt(k) == '1') cnt ++ ;
				}
				if (cnt > max) max = cnt;
			}
			System.out.println(max);
		}

	}

}
