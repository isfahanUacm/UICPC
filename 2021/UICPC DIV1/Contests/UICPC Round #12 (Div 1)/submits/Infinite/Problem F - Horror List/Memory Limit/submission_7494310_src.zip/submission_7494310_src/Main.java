import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {


	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		 int cond[];
		 int dp[];
		 int n , h , l;
		 int fi[] , se[] , Hlist[];
		n = s.nextInt() ; h = s.nextInt() ; l = s.nextInt();
		Hlist= new int[h];
		dp = new int[n];
		cond = new int[n];
		for (int i = 0 ; i < h ; i ++) Hlist[i] = s.nextInt();
		fi = new int[l];
		se = new int[l];

		for (int i = 0 ; i < l ; i ++) {
			fi[i] = s.nextInt();
			se[i] = s.nextInt();
		}


		Arrays.fill(dp , -1);
		Arrays.fill(cond , 0);

		for (int i = 0 ; i < h ; i ++){
			dp[Hlist[i]] = 0 ;
			cond[Hlist[i]] = 1;
		}
		//func(0);
		for (int i = 0 ; i < n ; i ++){
			if (cond[i] != 1) func(i , -1 , dp , fi , se , n , h , l , cond );
		}
		int imax = 0 , max = dp[0];
		for (int i = 1 ; i < n ; i ++){
			if (dp[i] > max) {
				max = dp[i];
				imax = i ;
			}
		}
		System.out.println(imax);
	}
	static void func(int j , int no , int [] dp , int []fi , int[] se , int n , int h , int l, int [] cond ){


		int min = Integer.MAX_VALUE;
		for (int i = 0 ; i < n ; i ++){
			for(int k = 0 ; k < l ; k ++){
				if ((fi[k] == j && se[k] == i) || (fi[k] == i && se[k] == j) && i != no ){

						if (dp[i] == -1){
							func(i , j , dp , fi , se , n , h , l , cond );
						}

					if (dp[i] < Integer.MAX_VALUE) if (dp[i] + 1 < min) min = (dp[i] + 1);

				}
			}

		}
		dp[j] = min;
		if ( no == -1 )cond[j] = 1;
	}

}
