#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main(){
    string a;
    cin >> a;
    map<char, ll> st;
    map<char, ll> st2;
    char t = '*';
    string num;
    for (ll i = 0; i < a.length(); ++i) {
        if (isalpha(a[i])) {
            if (t != '*') {
                if (num.empty()) {
                    st[t]++;
                } else {
                    st[t] += stol(num);
                }
            }
            num = "";
            t = a[i];
        }
        else {
            num += a[i];
        }
    }
    if (num.empty()) {
        st[t]++;
    } else {
        st[t] += stol(num);
    }

    ll k;
    cin >> k;

    string b;
    cin >> b;
    ll ans = LONG_LONG_MAX;

    t = '*';
    num = "";

    for (ll i = 0; i < b.length(); ++i) {
        if (isalpha(b[i])) {
            if (t != '*') {
                if (num.empty()) {
                    st2[t]++;
                } else {
                    st2[t] += stol(num);
                }
            }
            num = "";
            t = b[i];
        }
        else {
            num += b[i];
        }
    }
    if (num.empty()) {
        st2[t]++;
    } else {
        st2[t] += stol(num);
    }


    for (auto x : st2) {
        ans = min(ans, st[x.first] * k / x.second);
    }

    cout << ans << endl;

}