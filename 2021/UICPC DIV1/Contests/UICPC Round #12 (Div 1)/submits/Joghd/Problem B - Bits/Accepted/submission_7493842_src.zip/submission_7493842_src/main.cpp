#include <iostream>
#include <queue>
#include <string>
using namespace std;

int oneNum(int n) {
    int ans = 0;
    while(n>0) {
        ans += n%2;
        n /=2 ;
    }
    return ans;
}

int maxNum(int n) {
    int max = 0;
    for(int i=1000000000;i>0;i/=10) {
        int ans = oneNum(n/i);
        if(ans > max)
            max = ans;
    }
    return max;
}

int main() {
    int n;
    cin >> n;
    int x[n];
    for(int i=0;i<n;i++) {
        int temp;
        cin >> temp;
        x[i] = maxNum(temp);
    }
    for(int i=0;i<n;i++)
        cout << x[i] << endl;
}
