letters = list(input())

num = int(input())

acceptedWords = []

for _ in range(num):
  word = input()

  if len(word) < 4:
    continue
  if not letters[0] in word:
    continue
  
  doesHave = True
  for letter in word:
    if not letter in letters:
      doesHave = False
      continue
  
  if not doesHave:
    continue

  acceptedWords.append(word)

for word in acceptedWords:
  print(word)