#include <iostream>

using namespace std;

int main()
{
    int w,n, sum=0;
    cin>>w>>n;
    while(n--){
        int L,W;
        cin>>L>>W;
        int surf = L*W;
        sum+=surf;

    }
    cout<<sum/w<<endl;
}
