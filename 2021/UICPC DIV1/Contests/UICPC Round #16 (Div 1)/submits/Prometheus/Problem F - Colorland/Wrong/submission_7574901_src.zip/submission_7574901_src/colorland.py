num = int(input())

squares = []

for _ in range(num):
  squares.append(input())

x = 1

for index in range(num - 1):
  if squares[index] == squares[num - 1]:
    x += 1

print(x)