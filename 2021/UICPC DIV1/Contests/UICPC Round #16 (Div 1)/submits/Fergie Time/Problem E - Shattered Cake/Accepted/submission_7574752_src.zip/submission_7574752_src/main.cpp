#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


int main()
{
   ll w, l;
   ll sum = 0;
   cin >> w;
   ll n;
   cin >> n;
   ll wt , lt;
   for (ll i =0;i<n;i++)
   {
       cin >> wt >> lt;
       sum += (wt * lt);

   }
   l = sum / w;
   cout << l;
}
