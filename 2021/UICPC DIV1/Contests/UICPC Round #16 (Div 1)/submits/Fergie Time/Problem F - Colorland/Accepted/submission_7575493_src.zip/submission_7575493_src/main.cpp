#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


ll colortonum(string color)
{
    if(color == "Blue")
        return 0;
    if(color == "Orange")
        return 1;
    if(color == "Pink")
        return 2;
    if(color == "Green")
        return 3;
    if(color == "Red")
        return 4;
    if(color == "Yellow")
        return 5;

}

int main()
{
  ll n;
  cin >> n;
  ll numcolor;
  string * board = new string[n];
  vector <ll> dp (n+1, LLONG_MAX);

  for (ll i=0;i<n;i++)
      cin >> board[i];

  vector<ll> sample(n+1, LLONG_MAX);
  vector<vector<ll>> colors(6, sample);

  vector <ll> temp (6,LLONG_MAX);

  for(ll j=n; j>0; j--)
  {
      numcolor = colortonum(board[j-1]);
      for(ll i=0; i<6;i++)
      {
        //  colors[i][j] = (j == n-1)? LLONG_MAX : colors[i][j+1];
            colors[i][j] = (j == n)? LLONG_MAX : temp[i];

      }
      temp[numcolor] = j;

  }

  for(ll i=0;i<6;i++)
      colors[i][0] = temp[i];



  dp[n] = 0;

  for(ll j=n-1; j>=0;j--)
  {

      for(ll i=0;i<6;i++)
      {

          dp[j] = (colors[i][j]== LLONG_MAX) ?   dp[j] : (min(dp[j] , 1 + dp[colors[i][j]]));

      }


  }

  ll ans =  LLONG_MAX;
  for(ll i=0; i<6; i++)
  {
      ans = min(ans, dp[colors[i][0]]);
  }

  cout << ans+1;



}
