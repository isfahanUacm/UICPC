#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
typedef unsigned long long int ulli;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);


int p, c;
vector<vector<int>> adj(100 + 5);
bool Find = 0;
bool vis[100 + 5];
int Time[100 + 5];
int Low[100 + 5];
int C = 0;

void find_bridge(int x, int parent) {
    vis[x] = 1;
    C++;
    Time[x] = Low[x] = C;
    for (int child : adj[x]) {
        if (child == parent)
            continue;
        if (!vis[child]) {
            parent = x;
            find_bridge(child, parent);
            Low[x] = min(Low[x], Low[child]);
            if (Low[child] > Time[x]) {
                for (auto xx = adj[x].begin(); xx != adj[x].end(); xx++) {
                    if (*xx == child) {
                        *xx = -1;
                        break;
                    }
                }
                for (auto xx = adj[child].begin(); xx != adj[child].end(); xx++) {
                    if (*xx == x) {
                        *xx = -1;
                        break;
                    }
                }
                Find = 1;
                //break;
            }
        }
        else {
            Low[x] = min(Low[x], Time[child]);
        }

    }
//    return Find;
}
int sum = 1;
void dfs(int x) {
    vis[x] = 1;
    for (auto it = adj[x].begin(); it != adj[x].end(); it++) {
        int cur = *it;
        if (cur == -1 || cur==x)
            continue;
        else if (!vis[cur]) {
            sum++;
            dfs(cur);
        }
    }

}
int main() {
    while (true) {
        cin >> p >> c;
        if (p + c == 0)
            break;
        C = 0;
        sum = 1;
        //adj->clear();
        //adj.clear();
        for (int i = 0; i < 105; ++i) {
            adj[i].clear();
        }
        Find = 0;

        int x, y;
        for (int i = 0; i < c; i++) {
            cin >> x >> y;
            adj[x].push_back(y);
            adj[y].push_back(x);
        }

        fill_n(vis, 105, false);
        fill_n(Low, 105, 0);
        fill_n(Time, 105, 0);
        find_bridge(0, -1);
        fill_n(vis, 105, false);
        dfs(0);
        if (sum == p)cout << "NO";
        else cout << "YES";
        /*if (!Find) cout << "NO";
        else cout << "YES";*/
        cout << endl;
    }
}
