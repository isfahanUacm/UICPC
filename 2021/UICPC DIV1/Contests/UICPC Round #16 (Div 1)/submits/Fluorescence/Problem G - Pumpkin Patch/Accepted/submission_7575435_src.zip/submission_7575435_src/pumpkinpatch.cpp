#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
int p, d, n;
bool grd[33][33];
int live[903];
vector<pair<int, int>> pk;

bool in_range(int x, int y){
    return x>=0 && y>=0 && x<n && y<n;
}
int main(){
    int x, y;
    memset(grd, 0, sizeof(grd));
    fill_n(live, 903, 0);
    cin>>p>>d>>n;
    for (int i = 0; i < p; ++i) {
        cin>>x>>y;
        grd[x][y] = 1;
        pk.push_back({x, y});
    }

    int mv[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
    int xx, yy, xxx, yyy;
    for (int i = 1; i < d+1; ++i) {
        for (int j = 0; j < pk.size(); ++j) {
            if(live[j] > 0) continue;
            for (auto m : mv){
                xx = pk[j].first + (i*m[0]);
                yy = pk[j].second + (i*m[1]);
                if(in_range(xx, yy)){
                    if(grd[xx][yy]){
                        live[j] = i;

                        for (int l = 1; l <= i; ++l) {
                            for (int k = 0; k < j; ++k) {
                                if(live[k] > 0) continue;
                                //cout<<j<<" "<<k<<endl;
                                for (auto mm : mv){
                                    xxx = pk[k].first + (i*mm[0]);
                                    yyy = pk[k].second + (i*mm[1]);
                                    if(xxx == xx && yyy == yy) live[k] = i;
                                }
                            }
                        }

                        //cout<<j<<" dy2\n";
                    }else{
                        grd[xx][yy] = 1;
                    }
                }else{
                    //cout<<j<<" dy1\n";
                    live[j] = i;
                }
            }
        }

        /*for (int j = 0; j < n; ++j) {
            for (int k = 0; k < n; ++k) {
                cout<<grd[j][k]<<" ";
            }cout<<endl;

        }*/

    }

    for (int i = 0; i < p; ++i) {
        if(live[i] == 0) cout<<"ALIVE\n";
        else cout<<live[i]<<endl;
    }

}
