#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 100010;
stack<ll> stc[MAX];

int main() {
    ll c, n, a;
    cin >> c >> n >> a;
    ll arr[a];
    for (ll i = 0; i < a; ++i) {
        cin >> arr[i];
        stc[arr[i]].push(i);
    }

    set<ll> reg;
    set<pair<ll, ll>, greater<>> st;
    ll ans = 0;
    for (ll i = 0; i < a; ++i) {
        while (!st.empty() && st.begin()->first <= i) {
            ll x = st.begin()->second;
            st.erase(st.begin());
            if (!stc[x].empty())
                stc[x].pop();
            if (stc[x].empty()) {
                st.emplace(INT_MAX, x);
            }
            else {
                st.emplace(stc[x].top(), x);
            }
        }

        if (reg.count(arr[i]) > 0) {
            continue;
        }
        if (reg.size() >= c) {
            ll x = st.begin()->second;
            st.erase(st.begin());
            reg.erase(x);
        }
        reg.insert(arr[i]);
        st.emplace(stc[arr[i]].top(), arr[i]);
        ans++;
    }
    cout << ans << endl;
}