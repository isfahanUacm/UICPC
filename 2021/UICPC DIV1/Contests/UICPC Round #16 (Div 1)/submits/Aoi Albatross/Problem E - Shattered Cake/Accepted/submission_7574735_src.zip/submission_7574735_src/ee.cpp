#include <bits/stdc++.h> 
using namespace std ;
int main (){
    long long w,n,ans=0;
    cin >> w >> n ;
    for (int i=0 ; i<n ; i++){
        int tmp1,tmp2 ;
        cin >> tmp1 >> tmp2 ;
        ans +=(tmp1*tmp2) ;
    }
    cout << ans/w << endl;

    return 0;
}