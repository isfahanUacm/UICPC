#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAX = 40;
int m[MAX][MAX];
vector<pair<int, int>> vc;
bool isDead[MAX * MAX];
int t[MAX * MAX];
int p, n, d;

pair<int, int> mv []= {
        {0, -1},
        {0, +1},
        {+1, 0},
        {-1, 0},
};

bool ir(int x, int y) {
    return x < n && x >= 0 && y < n && y >= 0;
}

int main() {
    memset(m, -1, sizeof(m));
    cin >> p >> d >> n;
    for (int i = 0; i < p; ++i) {
        int x, y;
        cin >> x >> y;
        m[x][y] = vc.size();
        vc.emplace_back(x, y);
    }
    for (int i = 1; i <= d; ++i) {
        for (int j = 0; j < vc.size(); ++j) {
            if (!isDead[j]) {
                bool possible = true;
                for (auto item : mv) {
                    int nx = vc[j].first + item.first * i;
                    int ny = vc[j].second + item.second * i;
                    if (!ir(nx, ny)) {
                        possible = false;
                    }
                    else {
                        if (m[nx][ny] != -1) {
                            possible = false;
                            if (!isDead[m[nx][ny]]) {
                                isDead[m[nx][ny]] = true;
                                t[m[nx][ny]] = i;
                            }
                        }
                        m[nx][ny] = j;
                    }
                }

                if (!possible) {
                    t[j] = i ;
                    isDead[j] = true;
                }
            }
        }
    }


    for (int i = 0; i < vc.size(); ++i) {
        if (isDead[i]) {
            cout << t[i] << endl;
        }
        else {
            cout << "ALIVE" << endl;
        }
    }
}


