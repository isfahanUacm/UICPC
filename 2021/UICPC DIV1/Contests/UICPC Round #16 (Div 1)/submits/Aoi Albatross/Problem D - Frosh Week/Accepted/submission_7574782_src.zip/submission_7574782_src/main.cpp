#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    int n, m, temp;
    cin >> n >> m;
    priority_queue<int> pq;
    int arr[m];
    for (int i = 0; i < n; ++i) {
        cin >> temp;
        pq.push(temp);
    }
    for (int i = 0; i < m; ++i) {
        cin >> arr[i];
    }
    sort(arr, arr + m, greater<>());
    int ans = 0;
    for (int i = 0; i < m; ++i) {
        while (!pq.empty() && pq.top() > arr[i]) {
            pq.pop();
        }
        if (!pq.empty()) {
            pq.pop();
            ans++;
        }
    }
    cout << ans << endl;
}


