#include <bits/stdc++.h> 
using namespace std ;

queue <int> q[8] ;

int main (){
    int n ;
    cin >> n ;
    string s ;
    for (int i=0 ; i<n ; i++){
        cin >> s ;
        if (s == "Blue") q[0].push(i) ;
        else if ( s== "Orange") q[1].push(i);
        else if ( s== "Green") q[2].push(i);
        else if ( s== "Red") q[3].push(i);
        else if ( s== "Pink") q[4].push(i);
        else if ( s== "Yellow") q[5].push(i);
    }
    int tmp = 0 , ans=0 ;
    while (tmp!=n-1){
        int tmp1 = -1 ,tmp2 =-1 , tmp3=-1 , tmp4=-1 , tmp5=-1 ,tmp6=-1 ;
        if (!q[0].empty())
            tmp1 = q[0].front() ;
        if (!q[1].empty())
            tmp2 = q[1].front() ;
        if (!q[2].empty())
            tmp3 = q[2].front() ;
        if (!q[3].empty())
            tmp4 = q[3].front() ;
        if (!q[4].empty())
            tmp5 = q[4].front() ;
        if (!q[5].empty())
            tmp6 = q[5].front() ;
        tmp = max(tmp1,max(tmp2,max(tmp3,max(tmp4,max(tmp5,tmp6))))) ;
        ans++ ;
        while (!q[0].empty() && q[0].front() <= tmp) 
            q[0].pop() ;
        while (!q[1].empty() && q[1].front() <= tmp)
            q[1].pop() ;
        while (!q[2].empty() && q[2].front() <= tmp) 
            q[2].pop() ;
        while (!q[3].empty() && q[3].front() <= tmp )
            q[3].pop() ;
        while (!q[4].empty() && q[4].front() <= tmp)
            q[4].pop() ;
        while (!q[5].empty() && q[5].front() <= tmp)
            q[5].pop() ;
    }
    if (n==1) cout << 1<< endl;
    else cout << ans << endl;

    return 0;
}