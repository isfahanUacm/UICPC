#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// cout << setprecision(3) << fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};
//M_PI >>Pi

lli n, t, sum=0;
lli a[200000+5];
bool visited[200000+5];
void one(){
    cout<<7;
}
void two(){
    if(a[0] > a[1]) cout<<"Bigger";
    else if(a[0] == a[1]) cout<<"Equal";
    else cout<<"Smaller";
}
void three(){
    lli b[3];
    b[0]=a[0], b[1]=a[1], b[2]=a[2];
    sort(b, b+3);
    cout<<b[1];
}
void four(){
    cout<<sum;
}
void five(){
    lli s=0;
    for(int i=0; i<n; i++){
        if(a[i]%2==0){
            s+=a[i];
        }
    }
    cout<<s;
}
void six(){
    char b[200000+5];
    for(int i=0; i<n; i++){
        b[i] = a[i]%26 + 97;
    }
    for(int i=0; i<n; i++){
        cout<<b[i];
    }
}
void seven(){
    int i=0;
    while(true)
    {
        int x = a[i];
        if(visited[x]){
            cout<<"Cyclic";
            return;
        }
        visited[x]=1;
        if(x>=n){
            cout<<"Out";
            return;
        }
        if(x==n-1){
            cout<<"Done";
            return;
        }
        i=x;
    }
}
int main(){
    cin>>n>>t;
    for(int i=0; i<n; i++){
        cin>>a[i];
        sum+=a[i];
    }
    if(t==1) {one();}
    else if(t==2){
        two();
    }
    else if(t==3){
        three();
    }
    else if(t==4){
        four();
    }
    else if(t==5){
        five();
    }
    else if(t==6){
        six();
    }
    else{
        seven();
    }
}