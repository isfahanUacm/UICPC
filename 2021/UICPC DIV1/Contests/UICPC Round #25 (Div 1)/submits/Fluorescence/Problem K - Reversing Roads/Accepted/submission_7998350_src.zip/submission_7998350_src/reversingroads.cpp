#include <bits/stdc++.h>
using namespace std;

#define MAX_N 55

int n, m, nums = 1, scc = 0;
int dfs_low[MAX_N], dfs_num[MAX_N];
int compo[MAX_N];
int compoSize[MAX_N];
vector<int> adj[MAX_N];
vector<int> s;
int id[MAX_N];
bool visited[MAX_N];
vector<pair<int, int>> edges;

void dfs(int u){
    dfs_num[u] = dfs_low[u] = nums++;
    s.push_back(u);
    visited[u] = true;
    for(auto v: adj[u]){
        if(!dfs_num[v])
            dfs(v);
        if(visited[v])
            dfs_low[u] = min(dfs_low[u], dfs_low[v]);
    }
    if(dfs_low[u] == dfs_num[u]){
        scc++;
        while(true){
            int w = s.back();
            s.pop_back();
            visited[w] = false;
            compo[w] = scc;
            id[w] = compoSize[scc]++;
            if(w == u)
                break;
        }
    }
}

int main(){
    int t = 0;
    while(cin>>n>>m){
        t++;
        //initialize
        bool valid = false;
        int x, y;
        fill_n(dfs_num, 55, 0);
        fill_n(dfs_low, 55, 0);
        fill_n(visited, 55, false);
        scc = 0;
        for (int i = 0; i < n; i++){
            adj[i].clear();
        }
        edges.clear();
        
        //read
        //cin>>n>>m;
        for (int i = 0; i < m; i++){
            cin>>x>>y;
            adj[x].push_back(y);
            edges.push_back({x, y});
        }
        //SCC
        for (int i = 0; i < n; i++)
            if(!dfs_num[i])
                dfs(i);
        if(scc == 1){
            cout<<"Case "<<t<<": "<<"valid"<<endl;
            valid = true;
        }
        else{
            for (int i = 0; i < m; i++){
                fill_n(dfs_num, 55, 0);
                fill_n(dfs_low, 55, 0);
                fill_n(visited, 55, false);
                scc = 0;
                auto ind = find(adj[edges[i].first].begin(), adj[edges[i].first].end(), edges[i].second); //- 
                //adj[edges[i].first].begin();
                adj[edges[i].first].erase(ind);
                adj[edges[i].second].push_back(edges[i].first);
                for (int j = 0; j < n; j++)
                    if(!dfs_num[j])
                        dfs(j);
                if(scc == 1){
                    valid = true;
                    cout<<"Case "<<t<<": "<<edges[i].first<<" "<<edges[i].second<<endl;
                    break;
                }
                else{
                    ind = find(adj[edges[i].second].begin(), adj[edges[i].second].end(), edges[i].first); //- 
                    //adj[edges[i].first].begin();
                    adj[edges[i].second].erase(ind);
                    adj[edges[i].first].push_back(edges[i].second);
                }
            }
            if(!valid){
                cout<<"Case "<<t<<": "<<"invalid"<<endl;
            }
        }
    }
}