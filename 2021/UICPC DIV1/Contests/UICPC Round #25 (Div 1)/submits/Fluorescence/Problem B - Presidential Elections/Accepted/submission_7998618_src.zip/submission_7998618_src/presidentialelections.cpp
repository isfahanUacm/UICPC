#include <bits/stdc++.h>
using namespace std;
int dp[2021];
int main()
{
   fill_n(dp, 2021,777777777);
   dp[0] = 0;
   int n; cin>>n;
   int d,c,f,u,allsv,winv,remain;
   int alld=0;
   for (int i = 0; i < n; i++)
   {
      cin>>d>>c>>f>>u;
      alld+=d;
      allsv=c+f+u;
      winv=int((allsv/2) + 1);
      //cout<<winv<<endl;
      remain = winv-c;
      if (remain < 0) remain = 0;
      if (remain > u) continue;

        for (int j = alld; j >= d; j--) 
        {
            dp[j] = min(dp[j], dp[j - d] + remain);
        }
   }
    int res = 777777777;
    int alltowin = int((alld/2) + 1);
    //cout<<alltowin<<"   "<<alld<<endl;
    for (int j = alltowin; j <= alld; j++)
    {
        res = min(res,dp[j]);
    }
    if (res!=777777777) cout<<res;
    else cout<<"impossible";
}