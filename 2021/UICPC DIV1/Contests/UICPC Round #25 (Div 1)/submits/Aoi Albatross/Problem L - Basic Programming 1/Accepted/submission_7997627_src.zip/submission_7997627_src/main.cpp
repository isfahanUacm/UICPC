#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    int n, t;
    cin >> n >> t;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    if (t == 1) {
        cout << 7 << endl;
    }
    else if (t == 2) {
        if (arr[0] > arr[1]) {
            cout << "Bigger" << endl;
        }
        else if (arr[0] == arr[1]) {
            cout << "Equal" << endl;
        }
        else {
            cout << "Smaller" << endl;
        }
    }
    else if (t == 3) {
        vector<int> vc;
        vc.push_back(arr[0]);
        vc.push_back(arr[1]);
        vc.push_back(arr[2]);
        sort(vc.begin(), vc.end());
        cout << vc[1] << endl;
    }
    else if (t == 4) {
        ll sum = 0;
        for (auto x : arr) {
            sum += x;
        }
        cout << sum << endl;
    }
    else if (t == 5) {
        ll sum = 0;
        for (auto x : arr) {
            if (x % 2 == 0) {
                sum += x;
            }
        }
        cout << sum << endl;
    }
    else if (t == 6) {
        string ans;
        for (auto x : arr) {
            x %= 26;
            ans += (char) (x + 'a');
        }
        cout << ans << endl;
    }
    else if (t == 7) {
        bool visited[n];
        memset(visited, 0, sizeof(visited));
        int ind = 0;
        while (true) {
            if (ind >= n) {
                cout << "Out" << endl;
                break;
            }
            if (ind == n - 1) {
                cout << "Done" << endl;
                break;
            }
            if (visited[ind]) {
                cout << "Cyclic" << endl;
                break;
            }
            visited[ind] = true;
            ind = arr[ind];
        }
    }
}
