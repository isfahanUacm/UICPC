#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 100;
ll n;
ll color[mx];
ll adj[mx][mx];
pair<ll,ll> deg[mx];
ll used=0;

bool cmp(pair<ll,ll> a, pair<ll,ll> b){
    return a.second>=b.second;
}

bool ok(ll u, ll c){
    for(ll i=0;i<n;i++){
        if(adj[u][i]&&color[i]==c)return false;
    }
    return true;
}

void solve(){
    for(ll i=0;i<n;i++){
        ll u = deg[i].first;
        if(color[u]==-1){
            color[u] = used++;
        }
        for(ll j=0;j<n;j++){
            ll v = deg[j].first;
            if(u!=v && color[v] == -1 && ok(v,color[u])){
                color[v] = color[u];
            }
        }
    }
}
int main(){
    memset(color,-1,sizeof(color));
    cin >> n;
    cin.ignore();
    for(ll i=0;i<n;i++){
        deg[i].first = i;
        deg[i].second = 0;
        string s;
        getline(cin,s);
        stringstream ss(s);
        ll in;
        while(ss >> in){
            if (i == in)
                continue;

            adj[i][in] = 1;
            deg[i].second++;
        }
    }
    sort(deg,deg+n,cmp);
    solve();
    cout<<used<<endl;
    return 0;
}