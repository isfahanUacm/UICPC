#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int mi(string a) {
    int ans = 0;
    int n = a.length() / 2 - 1;
    for (int i = 0; i <= n; ++i) {
        if (a[i] != a[a.length() - 1 - i]) {
            ans++;
        }
    }
    return ans;
}

int main(){
    string a;
    cin >> a;


    int ans = mi(a);
    for (int i = 1; i <= a.length(); ++i) {
        string temp = a;
        for (int j = i - 1; j >= 0; --j) {
            temp += a[j];
        }
        ans = min(ans, i + mi(temp));
    }

    cout << ans << endl;
}
