#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

pair<int, int> mv[] {
        {0, 1},
        {0, -1},
        {1, 0},
        {-1, 0},
};

bool ir(int x, int y) {
    return x >= 0 && x < 4 && y >= 0 && y < 4;
}

int mp[4][4];
vector<pair<int,int>> vc[4];
vector<pair<int, int>> blanks;
bool visited[4][4];
bool possible = false;

bool dfs(int x, int y, int xt, int yt) {
    visited[x][y] = true;

    if (xt == x && yt == y) {
        bool all = true;
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                if (mp[i][j] == mp[x][y] && !visited[i][j]) {
                    all = false;
                }
            }
        }
        if (all) {
            return true;
        }
        else {
            visited[x][y] = false;
            return false;
        }
    }

    for (auto temp: mv) {

        int nx = x + temp.first;
        int ny = y + temp.second;

        if (ir(nx, ny) && !visited[nx][ny] && mp[nx][ny] == mp[x][y]) {
            if (dfs(nx, ny, xt, yt))
                return true;
        }
    }
    visited[x][y] = false;
    return false;
}

bool pos() {
    memset(visited, 0, sizeof(visited));
    bool tp = true;
    for (int i = 0; i < 4; ++i) {
        if (vc[i].empty()) {
            continue;
        }

        tp &= dfs(vc[i][0].first, vc[i][0].second, vc[i][1].first, vc[i][1].second);
    }

    return tp;
}

void solve(int step) {
    if (possible)
        return;
    if (step == blanks.size()) {
        if (pos()) {
            possible = true;
        }

        return;
    }
    for (int i = 1; i <= 4; ++i) {
        if (vc[i - 1].empty()) {
            continue;
        }

        mp[blanks[step].first][blanks[step].second] = i;
        solve(step + 1);
    }
}

int main(){
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 4; ++j) {
            char ch;
            cin >> ch;
            if (ch == 'R') {
                vc[0].push_back({i, j});
                mp[i][j] = 1;
            }
            else if (ch == 'G') {
                vc[1].push_back({i, j});
                mp[i][j] = 2;
            }
            else if (ch == 'Y') {
                vc[2].push_back({i, j});
                mp[i][j] = 3;
            }
            else if (ch == 'B') {
                vc[3].push_back({i, j});
                mp[i][j] = 4;
            }
            else {
                blanks.push_back({i, j});
                mp[i][j] = 0;
            }
        }
    }

    solve(0);
    if (possible) {
        cout << "solvable" << endl;
    }
    else {
        cout << "not solvable" << endl;
    }
}

