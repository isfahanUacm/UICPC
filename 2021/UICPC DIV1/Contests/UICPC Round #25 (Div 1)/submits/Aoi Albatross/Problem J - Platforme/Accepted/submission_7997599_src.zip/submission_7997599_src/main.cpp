#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ll n;
    cin >> n;
    vector<pair<ll, pair<ll, ll>>> vc;
    for (ll i = 0; i < n; ++i) {
        ll a, b, c;
        cin >> a >> b >> c;
        vc.push_back({a, {b, c}});
    }
    vc.push_back({0, {-1000000, 100000}});

    long long ans = 0;
    for (ll i = 0; i < n; ++i) {
        double fi = vc[i].second.first + 0.5;
        double si = vc[i].second.second - 0.5;

        ll fm = INT_MAX;
        ll sm = INT_MAX;
        for (ll j = 0; j <= n; ++j) {
            if (i == j || vc[i].first <= vc[j].first)
                continue;

            if (fi > vc[j].second.first && fi < vc[j].second.second) {
                fm = min(fm, vc[i].first - vc[j].first);
            }

            if (si > vc[j].second.first && si < vc[j].second.second) {
                sm = min(sm, vc[i].first - vc[j].first);
            }
        }
        ans += fm;
        ans += sm;
    }
    cout << ans << endl;
}
