#include<iostream>
#include<algorithm>
#include<string>
using namespace std;

int main()
{
	int n, t,sum=0;
	cin >> n>>t;
	int* a = new int[n];
	for (int i = 0; i < n; ++i)
	{
		cin >> a[i];
		sum += a[i];
	}
	if (t == 1)
		cout << '7';
	else if (t == 2)
	{
		if (a[0] > a[1])
			cout << "Bigger";
		else if (a[0] == a[1])
			cout << "Equal";
		else
			cout << "Smaller";
	}
	else if (t == 3)
	{
		int b[3]; b[0] = a[0]; b[1] = a[1]; b[2] = a[2];
		sort(b, b + 3);
		cout << b[1];
	}
	else if (t == 4)
	{
		cout << sum;
	}
	else if (t == 5)
	{
		int sum2 = 0;
		for (int i = 0; i < n; ++i)
		{
			if (a[i] % 2 == 0)
			{
				sum2 += a[i];
			}
		}
		cout << sum2;
	}
	else if (t == 6)
	{
		string temp="";
		for (int i = 0; i < n; ++i)
		{
			a[i] = (a[i] % 26);
			temp += char('a' + a[i]);	
		}
		cout << temp;
	}
	else if (t == 7)
	{
		int  i = 0,m=0;
		while (true)
		{
			++m;
			if (m > n *5)
			{
				cout << "Cyclic";
				break;
			}
			if (i == n - 1)
			{
				cout << "Done";
				break;
			}	
			else if (i<0 || i>n - 1)
			{
				cout << "Out";
				break;
			}
			i = a[i];
			
		}
	}
	delete[]a;

	return 0;
}
