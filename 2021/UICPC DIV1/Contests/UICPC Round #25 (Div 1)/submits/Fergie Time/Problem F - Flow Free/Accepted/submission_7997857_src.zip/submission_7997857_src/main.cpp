#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl

vector<vector<char>> grid;
map<ll, pll> whitesMap;
map<char, vector<pll>> pairsMap;
vector<char> colorsList;
vector<char> coloring;
ll gindex;
bool backtrackcolor(ll index)
{
    if(index == gindex)
    {

        //Dijkstra
        multiset<pair<pll, ll>> q;
        map<char, bool> ansVisited;
        map<char, ll> neededNum;
        for(auto i: pairsMap)
        {
            q.insert({*i.second.begin(), 0});
            ansVisited[i.first] = false;
            neededNum[i.first] = 0;
        }
        for(ll i = 0; i < 4; i++)
        {
            for(ll j = 0; j < 4; j++)
            {
                neededNum[grid[i][j]] += (1 << (i * 4 + j));
            }
        }
        while(q.size())
        {
            pll current = q.begin()->first;
            ll currentVisited = q.begin()->second;
            ll currentColor = grid[current.first][current.second];
            q.erase(q.begin());
            currentVisited = currentVisited | (1 << (current.first * 4 + current.second));
            if(currentVisited == neededNum[currentColor] && (current == pairsMap[currentColor][1]))
            {
                ansVisited[currentColor] = true;
            }
            vector<pll> dirs = {{0,1}, {0, -1}, {1, 0}, {-1, 0}};
            for(pll dir: dirs)
            {
                ll nextX = current.first + dir.first;
                ll nextY = current.second + dir.second;

                if(nextX >= 0 && nextX < 4 && nextY >= 0 && nextY < 4)
                {
                    if((currentVisited & (1 << (nextX * 4 + nextY))) == 0)
                    {
                        if(grid[nextX][nextY] == grid[current.first][current.second])
                        {
                            q.insert({{nextX, nextY}, currentVisited});
                        }
                    }
                }
            }
        }
        for(auto i: ansVisited)
        {
            if(!i.second)
            {
                return false;
            }
        }
        return true;
    }
    bool ans = false;
    for(char c: colorsList)
    {
        coloring[index] = c;
        grid[whitesMap[index].first][whitesMap[index].second] = c;
        ans = ans || backtrackcolor(index + 1);
        grid[whitesMap[index].first][whitesMap[index].second] = 'W';
        if(ans)
        {
            return ans;
        }
    }
    return ans;
}

int main()
{
    vector<char> sample(4);
    grid = vector<vector<char>>(4, sample);
    gindex = 0;

    for (ll i = 0; i < 4; i++)
    {
        string s;
        cin >> s;
        for (ll j = 0; j < s.size(); j++)
        {
            grid[i][j] = s[j];
            if (s[j] == 'W')
            {
                whitesMap[gindex] = {i, j};
                gindex++;
            }
            else
            {
                if (pairsMap.find(grid[i][j]) == pairsMap.end())
                {
                    pairsMap[grid[i][j]] = vector<pll>();
                }
                pairsMap[grid[i][j]].push_back({i, j});
            }
        }
    }
    colorsList = vector<char>();
    for(auto i: pairsMap)
    {
        colorsList.push_back(i.first);
    }
    coloring = vector<char>(gindex);
    bool ans = backtrackcolor(0);
    if(ans)
    {
        cout << "solvable" << endl;
    }
    else
    {
        cout << "not solvable" << endl;
    }

    return 0;
}
