#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;


using namespace std;

char alphabet(int a){
    char ans;
    switch (a){
    case 0:
        ans = 'a';
        break;
    case 1:
        ans = 'b';
        break;
    case 2:
        ans = 'c';
        break;
    case 3:
        ans = 'd';
        break;
    case 4:
        ans = 'e';
        break;
    case 5:
        ans = 'f';
        break;
    case 6:
        ans = 'g';
        break;
    case 7:
        ans = 'h';
        break;
    case 8:
        ans = 'i';
        break;
    case 9:
        ans = 'j';
        break;
    case 10:
        ans = 'k';
        break;
    case 11:
        ans = 'l';
        break;
    case 12:
        ans = 'm';
        break;
    case 13:
        ans = 'n';
        break;
    case 14:
        ans = 'o';
        break;
    case 15:
        ans = 'p';
        break;
    case 16:
        ans = 'q';
        break;
    case 17:
        ans = 'r';
        break;
    case 18:
        ans = 's';
        break;
    case 19:
        ans = 't';
        break;
    case 20:
        ans = 'u';
        break;
    case 21:
        ans = 'v';
        break;
    case 22:
        ans = 'w';
        break;
    case 23:
        ans = 'x';
        break;
    case 24:
        ans = 'y';
        break;
    case 25:
        ans = 'z';
        break;

    }

    return ans;

}

int main()
{

       ll n ,t;
       string s ="";
       cin >> n >> t;
       vector<ll> number(n);
       vector <bool> check(n,false);
       ll sum = 0;
       ll sumeven = 0;
       for(ll i=0;i<n;i++)
       {
           cin >> number[i];
           sum += number[i];
           if(number[i]%2==0)
               sumeven += number[i];
           s += alphabet(number[i]%26);
       }

       if (t == 1)
           cout << 7 <<endl;
       else if (t == 2)
       {
           if (number[0] > number[1])
               cout << "Bigger" <<endl;
           else if (number[0] == number[1])

               cout <<"Equal" <<endl;
           else
               cout << "Smaller" <<endl;

       }
       else if (t==3)
       {
           ll a,b,c;
           a = number[0];
           b = number[1];
           c = number[2];
           vector<ll> sortnum(3);
           sortnum[0] = a;
           sortnum[1] = b;
           sortnum[2] = c;
           sort(sortnum.begin(),sortnum.end());
           cout << sortnum[1]<<endl;
       }
       else if(t==4)
           cout << sum << endl;
       else if (t == 5)
           cout << sumeven << endl;
       else if(t==6)
            cout << s << endl;
       else if (t == 7)
       {
           ll index = 0;
           check[0] = true;
           ll current;
           while(true)
           {
                 if (index == n-1)
                 {
                     cout << "Done" <<endl;
                     break;
                 }
                 if (index >  n-1)
                 {
                     cout << "Out" <<endl;
                     break;
                 }

                 index = number[index];
                 if (check[index])
                 {
                     cout << "Cyclic" << endl;
                     break;
                 }
                 else
                    check[index] = true;
           }
       }


}
