#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;

int main()
{
    ll n , t = 0 , cost = 0;
    cin >> n;
    vector <ll> toll(n-1);
    vector<ll> time(n);
    vector <pll> mincost(n-1);
    for (ll i=0;i<n-1;i++)
    {
        cin >> toll[i];
        mincost[i] = {toll[i],i};
    }
    for (ll i=0;i<n;i++)
        cin >> time[i];

    sort(mincost.begin(),mincost.end());
    ll gate = 0;
    while( gate != n-1)
    {
        cost += toll[gate];
        t++;
        if (time[gate+1] <= t){
            gate = gate+1;
        }
        else
        {
            ll remaint = time[gate+1]-t;
            ll min=0;
            if (remaint%2)
            {
                remaint += 1;
            }
            for (ll i=0;i<n-1;i++)
            {
                if (mincost[i].second <= gate)
                {
                    min = mincost[i].first;
                    break;
                }
            }
            cost += min * remaint;
            t += remaint;
            gate++;
        }

    }

    cout << cost;

}
