#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000;
vector<vector<ll>> graph;
vector<vector<ll>> graphRev;
bool visited[maxN];
ll n, m;
ll group;
ll groups[maxN];
ll degreeIn[maxN];
ll degreeOut[maxN];

stack<ll> st1;

void dfs1(ll index)
{
    visited[index] = true;
    for (ll i: graph[index])
    {
        if (!visited[i])
        {
            dfs1(i);
        }
    }
    st1.push(index);
}

void dfs2(ll index)
{
    groups[index] = group;
    visited[index] = true;
    for (ll i: graphRev[index])
    {
        if (!visited[i])
        {
            dfs2(i);
        }
    }
}

ll numOfGroups()
{
    st1 = stack<ll>();
    fill(visited, visited + n, false);
    for (ll i = 0; i < n; i++)
    {
        if (!visited[i])
        {
            dfs1(i);
        }
    }
    group = 0;
    fill(visited, visited + n, false);
    fill(groups, groups + n, -1);
    while (st1.size())
    {
        ll i = st1.top();
        st1.pop();
        if (!visited[i])
        {
            dfs2(i);
            group++;
        }
    }
    return group;
}

int main()
{
    ll caseNum = 1;
    while (cin >> n >> m)
    {
        graph = vector<vector<ll>>(n);
        graphRev = vector<vector<ll>>(n);
        vector<pll> inputList;
        for (ll i = 0; i < m; i++)
        {
            ll a, b;
            cin >> a >> b;
            inputList.push_back({a, b});
            graph[a].push_back(b);
            graphRev[b].push_back(a);
        }
        ll groupAns = numOfGroups();
        if (groupAns == 1)
        {
            cout << "Case " << caseNum++ << ": " << "valid" << endl;
        } else
        {
            bool impossible = true;
            vector<pll> answer;
            for (ll i = 0; i < n; i++)
            {
                for (ll j = 0; j < graph[i].size(); j++)
                {
                    vector<ll> backUpList = graph[i];

                    ll temp1 = graph[i][j];
                    graph[graph[i][j]].push_back(i);
                    graph[i].erase(graph[i].begin() + j);

                    vector<ll> backUpListRev1 = graphRev[i];
                    vector<ll> backUpListRev2 = graphRev[temp1];

                    ll indexToDelete = -1;
                    for(ll ii = 0; ii < graphRev[temp1].size(); ii++)
                    {
                        if(graphRev[temp1][ii] == i)
                        {
                            indexToDelete = ii;
                        }
                    }
                    graphRev[temp1].erase(graphRev[temp1].begin() + indexToDelete);
                    graphRev[i].push_back(temp1);

                    ll tempAns = numOfGroups();
                    if (tempAns == 1)
                    {
                        impossible = false;
                        answer.push_back({i, temp1});
                    }
                    graph[temp1].pop_back();
                    graph[i] = backUpList;

                    graphRev[temp1] = backUpListRev2;
                    graphRev[i] = backUpListRev1;
                }
            }
            if (impossible)
            {
                cout << "Case " << caseNum++ << ": " << "invalid" << endl;
            } else
            {
                pll realAnswer;
                for(ll i = 0; i < inputList.size(); i++)
                {
                    for(ll j = 0; j < answer.size(); j++)
                    {
                        if((inputList[i].first == answer[j].first && inputList[i].second == answer[j].second) || (inputList[i].first == answer[j].second && inputList[i].second == answer[j].first))
                        {
                            realAnswer = inputList[i];
                            break;
                        }
                    }
                }
                cout << "Case " << caseNum++ << ": " << realAnswer.first << " " << realAnswer.second << endl;
            }

        }
    }
    return 0;
}