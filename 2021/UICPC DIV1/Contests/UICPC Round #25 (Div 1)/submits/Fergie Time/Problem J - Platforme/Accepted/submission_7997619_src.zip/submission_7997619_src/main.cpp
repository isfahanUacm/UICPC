#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 20010;

int main()
{
    ll n;
    cin >> n;
    vector<pair<ll, pll>> arr(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> arr[i].first >> arr[i].second.first >> arr[i].second.second;
    }
    sort(arr.begin(), arr.end());
    ll ans = 0;
    for(ll i = 0; i < arr.size(); i++)
    {
        ll floorLeft = 0;
        for(ll j = i - 1; j >= 0; j--)
        {
            if(arr[i].second.first < arr[j].second.second && arr[i].second.first >= arr[j].second.first)
            {
                floorLeft = arr[j].first;
                break;
            }
        }
        ans += (arr[i].first - floorLeft);
        ll floorRight = 0;
        for(ll j = i - 1; j >= 0; j--)
        {
            if(arr[i].second.second <= arr[j].second.second && arr[i].second.second > arr[j].second.first)
            {
                floorRight = arr[j].first;
                break;
            }
        }
        ans += (arr[i].first - floorRight);
    }
    cout << ans;
    return 0;
}
