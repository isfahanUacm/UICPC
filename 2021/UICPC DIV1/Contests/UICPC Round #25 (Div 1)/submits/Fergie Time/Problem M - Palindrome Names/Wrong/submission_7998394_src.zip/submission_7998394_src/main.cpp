#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

ll countdif(string s){
    ll distToPalindrome = 0;
    ll sizes = s.length();
//    if (sizes%2)
//        sizes+= 1;
    for(ll i = 0; i < sizes / 2; i++)
    {
        if(s[i] != s[s.length() - i - 1])
        {

            distToPalindrome++;
        }
    }

    return distToPalindrome;
}

int main()
{
    string s;
    cin >> s;
    string st;
    st = s;
    ll ans = 100;
    ll add = 0;
    ll ansdif = 0;
    for (ll i=0;i<s.length();i++)
    {
        // cout << countdif(st)<<endl;
         ansdif = add+countdif(st);
        ans = min(ans, ansdif);
        st += st[i];
        add ++;
    }

    cout << ans;
}
