#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

ll countdif(string s,ll first){

    ll distToPalindrome = 0;
    ll j=s.length()-1;
    for(ll i=first; j>i; ++i){
         if(s[i] != s[j]) ++distToPalindrome;
         j--;
    }
   return distToPalindrome;

}

int main()
{
    string s;
    cin >> s;
    string st;
    st = s;
    ll ans = 104;
    ll add = 0;
    ll ansdif = 0;
    for (ll i=0;i<s.length();i++)
    {

         ansdif = add+countdif(st,i);
        ans = min(ans, ansdif);
     
        add ++;
    }

    cout << ans;
}