

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author golnoosh
 */
public class WTM {

    /**
     * @param args the command line arguments
     */
    static HashMap<String, Integer> dictionary = new HashMap<>();
    static HashMap<String, Long> map = new HashMap<>();
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        String W = input.next();
        while(N>0)
        {
            dictionary.put(input.next(), input.nextInt());
            N--;
        }
        System.out.println(Find(W)%1000000007);
        
    }
    
    static long Find(String str)
    {
        long sum = 0;
        if(str.length() == 0)
            return 1;
        for(int i=0; i<=str.length(); i++)
        {
            String left = "";
            String right = "";
            for(int j=0; j<i;j++)
                left += str.charAt(j);
            for(int j=i; j<str.length();j++)
                right += str.charAt(j);
            if(dictionary.containsKey(left))
            {
                if(map.containsKey(right))
                    sum += (dictionary.get(left)*map.get(right))%1000000007;
                else
                    sum += (dictionary.get(left)*Find(right))%1000000007;
            }
            
        }
        map.put(str, sum);
        return sum;
        

    }
    
}
