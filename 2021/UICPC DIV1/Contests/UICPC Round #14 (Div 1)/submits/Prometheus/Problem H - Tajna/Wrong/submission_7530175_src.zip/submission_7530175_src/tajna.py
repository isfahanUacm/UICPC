import math
line = input()

length = len(line)

row = math.floor(length**(0.5))
column = 0

matrix = [ [] for _ in range(0,row) ]

while True:
  if (length / row).is_integer():
    column = int(length / row)
    break
  else:
    row -= 1

# print(row)
# print(column)

for i in range(0, row):
  for j in range(0, column):
    matrix[i].append(line[0])
    line = line[1:]

# for i in range(0, row):
#   for j in range(0, column):
#     print( matrix[i][j])
#   print("/n")

for j in range(0, column):
  for i in range(0, row):
    print( matrix[i][j], end = "" )