
import java.util.*;

/**
 *
 * @author golnoosh
 */
public class Fish {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int m = input.nextInt();
        int weight[] = new int[n];
                   
        for(int i=0; i<n; i++)
            weight[i] = input.nextInt();
        Arrays.sort(weight);
        
        pair arr[] = new pair[m];
        for (int i=0; i<m; i++)
            arr[i] = new pair(input.nextInt(), input.nextInt());
        Arrays.sort(arr);

        int index = weight.length-1;
        int sum = 0;
        for(int i=arr.length -1; i>=0; i--)
        {
            for(int j=0; j<arr[i].count && index>=0; j++)
            {
                sum += weight[index]*arr[i].price;
                index--;
            }
            
        }
        
        
        System.out.println(sum);
        
    }
    
    
}

class pair implements Comparable<pair>
{
    int count;
    int price;
    public pair(int count, int price) {
        this.count= count;
        this.price = price;
    }
    
    
    @Override
    public int compareTo(pair pa)
    {
       return this.price - pa.price  ;
    }
    
}    

