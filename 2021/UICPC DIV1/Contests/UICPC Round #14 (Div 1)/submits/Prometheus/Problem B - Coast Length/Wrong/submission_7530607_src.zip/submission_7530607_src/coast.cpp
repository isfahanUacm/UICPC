#include <iostream>
#include <math.h>
#include <string>
#include <vector>

using namespace std;

struct node{
    bool value ;
    bool oc=false;
    int walls =0;


};

int main(){
    int a,b;
    cin>>a>>b;
    vector<vector<node>> ww;

    // make mm
    for(int i=0;i<a;i++){
        vector<node> ss;
        string inp;
        cin>>inp;
        for(int j=0;j<b;j++){
            node vv;

            if(inp[j]=='0')
                vv.value=0;
            else
                vv.value=1;

            ss.push_back(vv);
        }
        ww.push_back(ss);
    }


    // set oc
    for(int i=0;i<a;i++){
        for(int j=0;j<b;j++){
            if((i==0&&j==0)||(i==a-1&&j==0)||(i==0&&j==b-1)||(i==a-1&&j==b-1)){
                if(!ww[i][j].value){
                    ww[i][j].oc = true;
                }
            }
            else if(i==0 ||i==a-1 || j==0|| j==b-1){
                if(!ww[i][j].value){
//                    ww[i][j].walls+=1;
                    ww[i][j].oc = true;
                }
            }

        }
        cout<<endl;
    }
   // set inner oc
    for(int i=0;i<a;i++){
        for(int j=0;j<b;j++){
            if((i>0 && i<a-1) && (j>0 && j<b-1)){
                    if(!ww[i][j].value){

                        if(ww[i][j-1].oc)
                            ww[i][j].oc=true;

                        else if(ww[i+1][j].oc)
                            ww[i][j].oc=true;

                        else if(ww[i-1][j].oc)
                            ww[i][j].oc=true;

                        else if(ww[i][j+1].oc)
                            ww[i][j].oc=true;

                    }
                }

            }
        }
    // set walls
    for(int i=0;i<a;i++){
        for(int j=0;j<b;j++){
         if((i>0 && i<a-1) && (j>0 && j<b-1)){
             if(ww[i][j].value){
                 if(ww[i][j+1].oc)
                     ww[i][j].walls+=1;

                 if(ww[i-1][j].oc)
                     ww[i][j].walls+=1;

                 if(ww[i][j-1].oc)
                     ww[i][j].walls+=1;

                 if(ww[i+1][j].oc)
                     ww[i][j].walls+=1;
             }
          }
         else if((i==0&&j==0)||(i==a-1&&j==0)||(i==0&&j==b-1)||(i==a-1&&j==b-1)){
             if(ww[i][j].value){
                 ww[i][j].walls+=2;
                 //U-L
               if(i==0&&j==0){
                     if(ww[i+1][j].oc)
                         ww[i][j].walls+=1;

                     if(ww[i][j+1].oc)
                         ww[i][j].walls+=1;
               }
               //D_L
               else if(i==a-1&&j==0){
                   if(ww[i-1][j].oc)
                       ww[i][j].walls+=1;

                   if(ww[i][j+1].oc)
                       ww[i][j].walls+=1;
             }
               //U_R
               else if(i==0&&j==b-1){
                   if(ww[0][j-1].oc)
                       ww[i][j].walls+=1;

                   if(ww[i+1][j].oc)
                       ww[i][j].walls+=1;
             }
               //D_R
               else if(i==a-1&&j==b-1){
                   if(ww[i-1][j].oc)
                       ww[i][j].walls+=1;

                   if(ww[i][j-1].oc)
                       ww[i][j].walls+=1;
             }

             }
            }
         //Edge
         else{
             if(ww[i][j].value){
                 ww[i][j].walls+=1;
                 if(i==0){
                     if(ww[i+1][j].oc)
                         ww[i][j].walls++;
                     if(ww[i][j-1].oc)
                         ww[i][j].walls++;
                     if(ww[i][j+1].oc)
                         ww[i][j].walls++;

                 }
                 else if(i==a-1){
                     if(ww[i-1][j].oc)
                         ww[i][j].walls++;
                     if(ww[i][j+1].oc)
                         ww[i][j].walls++;
                     if(ww[i][j-1].oc)
                         ww[i][j].walls++;
                 }
                 else if(j==0){
                     if(ww[i][j+1].oc)
                         ww[i][j].walls++;
                     if(ww[i-1][j].oc)
                         ww[i][j].walls++;
                     if(ww[i+1][j].oc)
                         ww[i][j].walls++;
                 }
                 else if(j==b-1){
                     if(ww[i][j-1].oc)
                         ww[i][j].walls++;
                     if(ww[i+1][j].oc)
                         ww[i][j].walls++;
                     if(ww[i-1][j].oc)
                         ww[i][j].walls++;
                 }
             }
            }
         }
        }

    // counter
    int count =0;
    for(int i=0;i<a;i++){
        for(int j=0;j<b;j++){
            count+=ww[i][j].walls;
        }
        }

    cout<<count<<endl;
}
