#include <bits/stdc++.h>
using namespace std;
const int mx = 505;
int adjMat[mx][mx];
map<string, int>  mp;

int main(){
    int n, m;
    cin >> n >> m;
    int index = -1;
    for (int i = 0; i < n; ++i) {
        string a, b, c;
        cin >> a >> b >> c;
        if (mp.count(a) == 0) {
            index++;
            mp[a] = index;
        }
        if (mp.count(c) == 0) {
            index++;
            mp[c] = index;
        }

        if (b == "is-a") {
            adjMat[mp[a]][mp[b]] = 1;
        }
        else {
            adjMat[mp[b]][mp[a]] = 1;
        }
    }

    for (int k = 0; k <= index; ++k) {
        for (int i = 0; i <= index; ++i) {
            for (int j = 0; j <= index; ++j) {
                adjMat[i][j] |= adjMat[i][k] & adjMat[k][j];
            }
        }
    }

    int q = 1;
    for (int i = 0; i < m; ++i) {
        string a, b, c;
        cin >> a >> b >> c;
        if (b == "is-a") {
            if (adjMat[mp[a]][mp[b]]) {
                cout << "Query " << q << ": true" << endl;
            }
            else {
                cout << "Query " << q << ": false" << endl;
            }
        }
        else {
            if (adjMat[mp[b]][mp[a]]) {
                cout << "Query " << q << ": true" << endl;
            }
            else {
                cout << "Query " << q << ": false" << endl;
            }
        }
        q++;
    }

    return 0;
}