#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    ll c, p;
    cin >> c >> p;
    ll val[p + 10];
    queue<ll> stc[p + 10];
    bool dead[c + 10];
    ll mg[c + 10];
    memset(dead, 0, sizeof(dead));
    memset(mg, 0, sizeof(mg));
    set<pair<ll, ll>> st;
    for (ll i = 1; i <= c; ++i) {
        st.insert({0, i});
    }
    for (ll i = 0; i < p; ++i) {
        ll t;
        cin >> t;
        val[i] = t;

        for (ll j = 0; j < c; ++j) {
            cin >> t;
            stc[i].push(t);
        }
    }


    for (ll i = 0; i < c - 1; ++i) {
        for (ll j = 0; j < p; ++j) {
            bool flag = i == 0;
            while (!stc[j].empty() && dead[stc[j].front()]) {
                flag = true;
                stc[j].pop();
            }
            if (flag && !stc[j].empty()) {
                st.erase({mg[stc[j].front()], stc[j].front()});
                mg[stc[j].front()] += val[j];
                st.insert({mg[stc[j].front()], stc[j].front()});
            }
        }
        if (!st.empty()) {
            ll x = st.begin()->second;
            dead[x] = true;
            st.erase(st.begin());
        }
    }
    if (!st.empty()) {
        cout << st.begin()->second << endl;
    }
    else {
        cout << "Puck u" << endl;
    }
}

