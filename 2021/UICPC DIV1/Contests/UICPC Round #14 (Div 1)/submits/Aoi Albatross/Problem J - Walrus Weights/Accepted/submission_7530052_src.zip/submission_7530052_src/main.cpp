#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int dp[1010][2020];

int main() {
    int n;
    cin >> n;
    int arr[n + 10];
    for (int i = 1; i <= n; ++i) {
        cin >> arr[i];
    }

    for (int i = 0; i <= 2005; ++i) {
        dp[0][i] = 0;
    }
    dp[0][0] = 1;

    int mx = 0;
    for (int i = 1; i <= n; ++i) {
        for (int j = 0; j <= 2005; ++j) {
            if (dp[i - 1][j]) {
                dp[i][j] = true;
            }
            else if (j >= arr[i] && dp[i - 1][j - arr[i]]) {
                dp[i][j] = true;
                int dist = abs(1000 - j);
                if (dist < abs(1000 - mx) || (dist == abs(1000 - mx) && j > mx)) {
                    mx = j;
                }
            }
        }
    }

    cout << mx << endl;
}