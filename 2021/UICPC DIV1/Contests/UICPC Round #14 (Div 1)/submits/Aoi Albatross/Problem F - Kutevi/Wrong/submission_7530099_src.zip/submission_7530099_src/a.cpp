#include <bits/stdc++.h> 
using namespace std ;

int n,k , num;
int nn[10] ;
unordered_set <int> vis ; 

bool dfs(int tmp){
    vis.insert(tmp) ;
    
    if (tmp == num) 
        return true ;
    
    for (int i=0 ; i<n ; i++)
        if (vis.find((tmp+nn[i])%360) == vis.end())
            if (dfs((tmp+nn[i])%360)) return true ;
    
    return false ;
}


int main(){
    cin >> n >> k;
    for (int i=0 ; i<n ; i++)
        cin >> nn[i] ;
    for (int i=0 ; i<k ; i++){
        vis.clear() ;
        cin >> num ;
        bool flag = false ;
        for (int j=0 ; j<n ; j++)
            if (dfs(nn[j])){
                cout << "YES" << endl ;
                flag = true ;
            }
        if (!flag) cout << "NO" << endl; 
    }

    return 0;
}