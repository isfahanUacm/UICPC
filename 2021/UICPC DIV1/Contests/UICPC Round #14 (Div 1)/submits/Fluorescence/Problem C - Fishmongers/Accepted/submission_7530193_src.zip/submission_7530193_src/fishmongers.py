n, m = map(int, input().split())
w = list(map(int, input().split()))
w.sort(reverse=True)
#print(w)
l = []
for i in range(m):
    x, p = map(int, input().split())
    l.append((p, x))
l.sort(reverse=True)
#print(l)
mony = 0
f = 1
index = 0
for pair in l:
    cost = pair[0]
    num = pair[1]
    #print(cost, num)
    #if num <= len(w):
    for i in range(num):
        if len(w) > index:
            mony += w[index]*cost
            #w.pop(0)
            index += 1
            #print(mony)
            #print(w)
        else:
            #print(mony)
            f = 0
            break
    if f == 0:
        break
print(mony)