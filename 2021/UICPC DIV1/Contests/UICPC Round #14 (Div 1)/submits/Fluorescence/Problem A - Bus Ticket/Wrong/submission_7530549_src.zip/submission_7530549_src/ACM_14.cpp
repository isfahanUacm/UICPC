#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);

lli s, p, m, n;
lli* a;
lli dp[1000006];

lli cdp(lli i, lli j) {

	if (j == n-1) {
		return 0;
	}
	if (i > a[n - 1])
		return 0;
	for (lli k = j + 1; k < n; k++) {
		if (a[k] >= i) {
			if (dp[k] != -1) {
				return dp[k];
			}
			lli t1 = LONG_MAX, t2 = LONG_MAX;
			if (k != n - 1) {
				t1 = s + cdp(i, k);
				t2 = p + cdp(i + m, k);			
			}
			else {
				t1 = t2 = 0;
			}
			return dp[k] = min(t1, t2);
		}
	}
}

int main()
{
	cin >> s >> p >> m >> n;
	a = new lli[n];
	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}
	sort(a, a + n);

	fill_n(dp, 1000006, -1);

	cout << cdp(a[0], -1);
}
