s = input()
n = len(s)

for i in range(n-1, 0, -1):
    if n%i == 0:
        if i <= int(n/i):
            r = i
            c = int(n/i)
            break

t = []
for i in range(c):
    t.append(s[i*r:(i*r)+r])

#print(t)
res = ""
for i in range(r):
    for j in range(c):
        res+=t[j][i]

print(res)


