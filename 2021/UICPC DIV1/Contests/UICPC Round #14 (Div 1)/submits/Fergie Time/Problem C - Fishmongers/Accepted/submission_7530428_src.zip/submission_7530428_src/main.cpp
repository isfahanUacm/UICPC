#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;


int main()
{
    int n , m ;
    cin >> n >> m;
    int temp;
    multiset <ll , greater<ll>> fish;
    for(int i=0; i<n; i++)
    {
        cin >> temp;
        fish.insert(temp);
    }
    multiset <pll, greater<pll>> stores;
    pll temp2;
    for(int i=0; i<m; i++)
    {
        cin>> temp2.first >> temp2.second;
        stores.insert({temp2.second , temp2.first});
    }
//    for (pll i : stores)
//        cout<< i.first <<"  "<<i.second<<endl;
    ll ans = 0;
    ll counter = n;
    while((counter > 0) && (!fish.empty()) && (!stores.empty())){
        if(counter - ((*stores.begin()).second) > 0)
        {
            for (ll i=0; i<(*stores.begin()).second ; i++)
            {
                ans += ((*fish.begin()) * ((*stores.begin()).first));
                fish.erase(fish.begin());

            }
            counter -= (*stores.begin()).second;
        }
        else
        {
            for (ll i=0; i<counter ; i++)
            {
                ans += ((*fish.begin()) * ((*stores.begin()).first));
                fish.erase(fish.begin());

            }
             counter = 0;
        }




        stores.erase(stores.begin());


    }

    cout << ans;
}
