import bisect

n = int(input())
w = []
for i in range(n):
    w.append(int(input()))

minw = min(w)
maxw = 1000 + minw


def dp(maxweight, weight, lenw):
    if lenw > 1:
        s = sum(weight)
        if s < 1000:
            return s
        tempk = []
        for k in range(lenw + 1):
            tempkk = []
            for j in range(maxweight + 1):
                tempkk.append(0)
            tempk.append(tempkk)

        wlists = set()

        for i in range(lenw + 1):
            for w in range(maxweight + 1):
                if weight[i - 1] <= w:
                    tempk[i][w] = max(weight[i - 1] + tempk[i - 1][w - weight[i - 1]], tempk[i - 1][w])
                else:
                    tempk[i][w] = tempk[i - 1][w]
                wlists.add(tempk[i][w])

        wlist = list(wlists)
        wlist.sort()
        if wlist[len(wlist) - 1] >= 1001:
            h = bisect.bisect_right(wlist, 1000)
            l = bisect.bisect_left(wlist, 1000)

            if (wlist[l] == 1000) or (wlist[h] - 1000) > (1000 - wlist[l]):
                return wlist[l]
            else:
                return wlist[h]

        else:
            return wlist[len(wlist) - 1]
    else:
        return weight[0]


print(dp(maxw, w, n))
