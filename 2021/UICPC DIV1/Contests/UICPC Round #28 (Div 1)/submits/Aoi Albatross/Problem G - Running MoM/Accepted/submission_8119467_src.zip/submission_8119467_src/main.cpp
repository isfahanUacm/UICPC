#include <bits/stdc++.h>
using namespace std;
const int MX = 10005;
vector<int> adj[MX];
int visited[MX];

map<string, int> id;
map<int, string> lid;

bool dfs(int v) {
    visited[v] = 1;
    bool tr = false;
    for (int x : adj[v]) {
        if (visited[x] == 1)
            return true;
        if (visited[x] == 0)
            tr |= dfs(x);
    }
    visited[v] = 2;
    return tr;
}

int main() {
    int n;
    cin >> n;
    int c = 0;
    for (int i = 0; i < n; ++i) {
        string a, b;
        cin >> a >> b;
        if (id.count(a) == 0) {
            lid[c] = a;
            id[a] = c;
            c++;
        }
        if (id.count(b) == 0) {
            lid[c] = b;
            id[b] = c;
            c++;
        }

        adj[id[a]].push_back(id[b]);
    }

    string temp;
    while (cin >> temp) {
        memset(visited, 0, sizeof(visited));
        cout << temp << ' ';
        bool tt = dfs(id[temp]);
        if (tt)
            cout << "safe" << endl;
        else
            cout << "trapped" << endl;
    }
}