#include <bits/stdc++.h>
using namespace std;
const int MX = 10005;
vector<int> adj[MX];
bool visited[MX];

map<string, int> id;
map<int, string> lid;

bool dfs(int v, int target) {
    visited[v] = true;
    bool tr = false;
    for (int x : adj[v]) {
        if (x == target)
            return true;
        if (!visited[x])
            tr |= dfs(x, target);
    }
    return tr;
}

int main() {
    int n;
    cin >> n;
    int c = 0;
    for (int i = 0; i < n; ++i) {
        string a, b;
        cin >> a >> b;
        if (id.count(a) == 0) {
            lid[c] = a;
            id[a] = c;
            c++;
        }
        if (id.count(b) == 0) {
            lid[c] = b;
            id[b] = c;
            c++;
        }

        adj[id[a]].push_back(id[b]);
    }

    string temp;
    while (cin >> temp) {
        memset(visited, 0, sizeof(visited));
        cout << temp << ' ';
        bool tt = dfs(id[temp], id[temp]);
        if (tt)
            cout << "safe" << endl;
        else
            cout << "trapped" << endl;
    }
}