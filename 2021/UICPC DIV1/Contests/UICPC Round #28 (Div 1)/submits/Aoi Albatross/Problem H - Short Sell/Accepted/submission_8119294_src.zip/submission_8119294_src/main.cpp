#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, k;
    cin >> n >> k;
    multiset<int> st;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
        arr[i] *= 100;
        arr[i] += i * k;
        st.insert(arr[i]);
    }
    int ans = 0;

    for (int i = 0; i < n; ++i) {
        ans = max(ans, arr[i] - *st.begin() - k);
        st.erase(st.find(arr[i]));
    }
    cout << ans << endl;
}