#include <bits/stdc++.h> 
using namespace std;

vector <string> names;
vector <bool> flag;
int n;

int main(){
      cin >> n;
      names.resize(n, " ");

      flag.resize(n, false);

      int k;
      cin >> k;
      for (int i=0; i<k; i++){
            string s1, s2;
            int num1, num2;

            cin >> num1 >> num2 >> s1 >> s2;
            names[num1-1] = s1, names[num2-1] = s2;
            
            if (s1 == s2){
                  flag[num1-1] = true;
                  flag[num2-1] = true;
            }
      }

      int ans = 0;
      for (int i=0; i<n; i++)
            if (!flag[i])
                  for (int j=0; j<n; j++)
                        if (i !=j and names[j] == names[i] and !flag[j] and names[i] != " "){
                              ans++;
                              flag[i] = true, flag[j] = true;
                        }

      int x = 0, y = 0;
      for (int i=0; i<n; i++){
            if (!flag[i] and names[i] != " ")
                  x++;
            if (!flag[i] and names[i] == " ")
                  y++;
      }

      if (n == 2) 
            cout << 1 << endl;
      else {
            if (y == x)
                  ans += y;
            else if (y == 2 and x == 0)
                  ans++;

            cout << ans << endl;
      }




      return 0;
}