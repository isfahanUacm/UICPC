#include <bits/stdc++.h>
using namespace std;
map<string, string> mp;


int main() {
    mp["at"] = "@";
    mp["and"] = "&";
    mp["one"] = "1";
    mp["two"] = "2";
    mp["too"] = "2";
    mp["to"] = "2";
    mp["four"] = "4";
    mp["for"] = "4";
    mp["bea"] = "b";
    mp["bee"] = "b";
    mp["be"] = "b";
    mp["sea"] = "b";
    mp["see"] = "c";
    mp["oh"] = "o";
    mp["owe"] = "o";
    mp["are"] = "r";
    mp["you"] = "u";
    mp["why"] = "y";

    int n;
    cin >> n;
    cin.ignore();
    while (n--) {
        string a, word;
        getline(cin, a);
        stringstream ss(a);

        while (ss >> word) {
            while (true) {
                bool c = word[0] >= 'A' && word[0] <= 'Z';
                if (c)
                    word[0] = word[0] + 'a' - 'A';
                int s = -1;
                int len = -1;
                pair<string, string> pi;
                for (const auto &x : mp) {
                    int temp = word.find(x.first);
                    if (temp != string::npos) {
                        if ((temp == s && x.first.size() > len) || (s == -1)) {
                            s = temp;
                            len = x.first.size();
                            pi = x;
                        }
                    }
                }
                string ans;
                if (s == -1) {
                    ans = word;
                } else {
                    ans = word.substr(0, s) + pi.second + word.substr(s + pi.first.size());
                }
                if (isalpha(ans[0]) && c) {
                    ans[0] = ans[0] - 'a' + 'A';
                }
                if (s == -1) {
                    cout << ans << ' ';
                    break;
                }
                word = ans;
            }
        }
        cout << endl;
    }
}





























































































