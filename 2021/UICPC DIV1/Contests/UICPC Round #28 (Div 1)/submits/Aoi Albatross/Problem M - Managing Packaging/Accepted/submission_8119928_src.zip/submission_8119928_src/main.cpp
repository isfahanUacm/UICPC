#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MX = 1e5 + 10;
vector<int> adj[MX];
map<string, int> id;
map<int, string> lid;
int in_deg[MX];

int main() {
    int n;

    while (cin >> n && n != 0) {
        for (auto &x : adj)
            x.clear();
        id.clear();
        lid.clear();
        memset(in_deg, 0, sizeof(in_deg));

        int c = 0;
        cin.ignore();
        string a;
        for (int i = 0; i < n; ++i) {
            getline(cin, a);
            stringstream ss(a);
            string first, temp;
            ss >> first;

            if (id.count(first) == 0) {
                id[first] = c;
                lid[c] = first;
                c++;
            }

            while (ss >> temp) {
                if (id.count(temp) == 0) {
                    id[temp] = c;
                    lid[c] = temp;
                    c++;
                }

                adj[id[temp]].push_back(id[first]);
                in_deg[id[first]]++;
            }
        }

        set<string> st;
        for (int i = 0; i < c; ++i) {
            if (in_deg[i] == 0) {
                st.insert(lid[i]);
            }
        }

        int count = 0;
        vector<string> ans;
        while (!st.empty()) {
            string x = *st.begin();
            st.erase(st.begin());
            ans.push_back(x);
            for (auto u : adj[id[x]]) {
                in_deg[u]--;
                if (in_deg[u] == 0)
                    st.insert(lid[u]);
            }
            count++;
        }
        if (count == c) {
            for (const auto& tmp : ans) {
                cout << tmp << endl;
            }
        }
        else {
            cout << "cannot be ordered" << endl;
        }
        cout << endl;
    }
}
