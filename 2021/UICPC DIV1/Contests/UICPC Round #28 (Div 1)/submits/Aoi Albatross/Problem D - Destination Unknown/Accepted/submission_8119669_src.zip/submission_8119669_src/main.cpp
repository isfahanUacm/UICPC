#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 2005;
ll dist[MAX];
set<pair<ll, ll>> ss;
vector<pair<ll, ll>> adj[MAX];
ll n, m, t;
ll s, g, h;

void dijkstra(int start) {
    dist[start] = 0;
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (dist[v.first] > dist[u] + v.second) {
                ss.erase({dist[v.first], v.first});
                dist[v.first] = dist[u] + v.second;
                ss.insert({dist[v.first], v.first});
            }
        }
    }
}

void clear() {
    for (ll i = 0; i < n; ++i) {
        dist[i] = LONG_LONG_MAX;
    }
}

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        for (auto &x: adj)
            x.clear();
        ll dm;
        cin >> n >> m >> t;
        cin >> s >> g >> h;
        s--;
        g--;
        h--;

        for (ll i = 0; i < m; ++i) {
            ll w, a, b;
            cin >> a >> b >> w;
            a--;
            b--;

            adj[a].emplace_back(b, w);
            adj[b].emplace_back(a, w);
            if ((a == g && b == h) || (a == h && b == g))
                dm = w;
        }

        clear();
        dijkstra(s);
        ll ds[MAX];
        for (int i = 0; i < MAX; ++i) {
            ds[i] = dist[i];
        }

        clear();
        dijkstra(g);
        ll dg[MAX];
        for (int i = 0; i < MAX; ++i) {
            dg[i] = dist[i];
        }

        clear();
        dijkstra(h);
        ll dh[MAX];
        for (int i = 0; i < MAX; ++i) {
            dh[i] = dist[i];
        }

        set<int> st;
        for (int i = 0; i < t; ++i) {
            int temp;
            cin >> temp;
            temp--;
            if ((ds[temp] == dh[s] + dg[temp] + dm) || (ds[temp] == dg[s] + dh[temp] + dm))
                st.insert(temp);
        }

        for (auto x : st) {
            cout << x + 1 << ' ';
        }
        cout << endl;
    }
}
