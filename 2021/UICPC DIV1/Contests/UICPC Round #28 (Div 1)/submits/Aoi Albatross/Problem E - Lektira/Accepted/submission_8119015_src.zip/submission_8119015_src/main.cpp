#include <bits/stdc++.h>
using namespace std;

int main() {
    string a;
    cin >> a;


    int n = a.size();
    vector<string> vc;
    for (int i = 1; i < n; ++i) {
        for (int j = 1; i + j < n; ++j) {
            int k = n - (i + j);
            string t = a.substr(0, i);
            string tt = a.substr(i, j);
            string ttt = a.substr(i + j, k);
            reverse(t.begin(), t.end());
            reverse(tt.begin(), tt.end());
            reverse(ttt.begin(), ttt.end());
            vc.push_back(t + tt + ttt);
        }
    }

    sort(vc.begin(), vc.end());
    cout << vc[0] << endl;
}





























































































