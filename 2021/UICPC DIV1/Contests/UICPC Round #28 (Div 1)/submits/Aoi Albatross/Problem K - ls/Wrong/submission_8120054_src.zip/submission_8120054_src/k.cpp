#include <bits/stdc++.h>
using namespace std;

string p, s;
int dp[10000][10000];

bool solve(int i, int j){
      if (p[i] == '*') i++;

      if (i >= p.size()) return true;
      if (j >= s.size()) return false;

      if (dp[i][j] != -1) return dp[i][j];

      bool tmp1 = false, tmp2 = false;
      
      tmp2 = solve(i, j+1);

      if (s[j] == p[i])
            tmp1 = solve(i+1, j+1);

      return dp[i][j] = (tmp1 || tmp2);
}

int main(){ 
      cin >> p;
      int n;
      cin >> n;
      while (n--){
            cin >> s;
            memset(dp, -1, sizeof(dp));

            if (solve(0, 0))
                  cout << s << endl;
      }


      return 0;
}