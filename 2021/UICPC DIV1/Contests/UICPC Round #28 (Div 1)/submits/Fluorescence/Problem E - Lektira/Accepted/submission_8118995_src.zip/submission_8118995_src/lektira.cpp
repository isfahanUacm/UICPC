#include <bits/stdc++.h>
using namespace std;

string s;
int n;
string solve(int f, int size){
    string sp = s.substr(f, size);
    reverse(sp.begin(), sp.end());
    return sp;
}
int main(){
    set<string> set;
    cin>>s;
    n=s.size();
    for(int i=1; i<n-1; i++){
        for(int j=i+1; j<n; j++){
            string sp1 = solve(0, i);
            string sp2 = solve(i, j-1-(i-1));
            string sp3 = solve(j, n-1-(j-1));
            set.insert(sp1+sp2+sp3);
        }
    }
    cout<<*set.begin();
}