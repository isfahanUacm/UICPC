import re
rex = list(input())
frex = ""
for i in rex:
    if (i=='*'):
        frex+='.*'
    elif (i=='.'):
        frex+='[.]'
    else:
        frex+=i
n = int(input())
#res = []
for i in range(n):
    txt = input()
    obj = re.fullmatch(frex,txt)
    if obj!=None:
        #res.append(obj.string)
        print(obj.string)
#print(res)
#print(*res,sep="\n")