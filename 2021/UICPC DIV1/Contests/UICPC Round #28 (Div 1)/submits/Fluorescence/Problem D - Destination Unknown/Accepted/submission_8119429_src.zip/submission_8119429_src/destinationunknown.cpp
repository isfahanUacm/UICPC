#include <bits/stdc++.h>
using namespace std;

int n, m, t, s, g, h;
vector<int> dst;
const int maxn = 2005;
vector<vector<pair<int, int>>> adj(maxn);
set<int> res;

//dijkstra
int dist[maxn];
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;

//make_DAG ~ dfs
bool vis[maxn];
//vector<vector<pair<int, int>>> DAG(maxn);

void dijkstra()
{
    pair<int, int> p;
    int w, u;
    while(!q.empty())
    {
        p = q.top(); q.pop();
        w = p.first; u = p.second;
        if(w>dist[u]) continue;

        for(auto v : adj[u])
            if(dist[v.first] > dist[u] + v.second)
                dist[v.first] = dist[u] + v.second, q.push({dist[v.first], v.first});
    }
}

void make_DAG(int u, int origin){
    vis[u] = true;
    for(auto v: adj[u]){
        if(dist[v.first] + v.second == dist[u]){ //main cindition
            //DAG[v.first].push_back({u, v.second}); //you can replace it with requirment of question
            if((u == g && v.first == h) || (u == h && v.first == g)){
                res.insert(origin);
            }
            if(!vis[v.first])
                make_DAG(v.first, origin);
        }
    }
}

int main(){
    int T, a, b, d;
    cin>>T;
    while(T--){
        //init all
        dst.clear();
        adj.clear(); adj.resize(maxn);
        res.clear();
        cin>>n>>m>>t;
        cin>>s>>g>>h;
        for (int i = 0; i < m; i++){
            cin>>a>>b>>d;
            adj[a].push_back({b, d});
            adj[b].push_back({a, d});
        }
        for (int i = 0; i < t; i++){
            cin>>a;
            dst.push_back(a);
        }
        fill_n(dist, maxn, INT_MAX);
        dist[s] = 0;
        q.push({0, s});
        dijkstra();

        for(int u : dst){
            fill_n(vis, maxn, false);
            make_DAG(u, u);
        }

        for(int r : res){
            cout<<r<<" ";
        }cout<<endl;
    }
}