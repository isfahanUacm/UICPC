#include <bits/stdc++.h>
using namespace std;
map<string, set<int>> MAP;
bool visited[1000+5];
int main(){
    int n, k; cin>>n>>k;
    int found=0, rem=n;
    while(k--){
        int x, y; string a, b;
        cin>>x>>y>>a>>b;
        if(!visited[x]){
            visited[x] = true;
            rem--;
        }
        if(!visited[y]){
            visited[y] = true;
            rem--;
        }
        if(a == b){
            found++;
            MAP[a].insert(1001);MAP[a].insert(1002);MAP[a].insert(1003);
        }
        else{
            MAP[a].insert(x);
            MAP[b].insert(y);
        }
    }
    int ans=0, oneFound=0;
    for(auto e : MAP){
        if(e.second.size() == 2){
            ans++;
        }
        else if(e.second.size() == 1){
            oneFound++;
        }
    }
    if(oneFound == rem){
        cout<<n/2-found;
    }
    else cout<<ans;
}