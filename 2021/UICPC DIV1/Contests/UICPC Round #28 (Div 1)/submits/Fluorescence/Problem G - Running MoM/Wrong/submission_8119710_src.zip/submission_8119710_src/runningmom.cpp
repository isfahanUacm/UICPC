#include <bits/stdc++.h>
using namespace std;
const int num=2*(5000)+5;
vector<int> adj[num];
int id[num], state[num], parent[num];
map<string, int> MAP;
vector<string> name;
int cycleNum=0;
void solve(int par, int cur){
    if(state[cur] == 2){
        return;
    }
    else if(state[cur] == 1){
        cycleNum++;
        id[cur] = cycleNum;
        int x=par;
        while(x != cur){
            id[x] = cycleNum;
            x = parent[x];
        }
        return;
    }
    else{
        parent[cur] = par;
        state[cur] = 1;
        for(int e : adj[cur]){
            solve(cur, e);
        }
        state[cur] = 2;
    }
}
int main(){
    int n, i=0; cin>>n;
    while(n--){
        string a, b; cin>>a>>b;
        int x, y;
        auto it = MAP.find(a);
        if(it == MAP.end()){
            i++;
            MAP[a] = i;
            name.push_back(a);
            x = i;
        }
        else{
            x = it->second;
        }
        auto it2 = MAP.find(b);
        if(it2 == MAP.end()){
            i++;
            MAP[b] = i;
            name.push_back(b);
            y = i;
        }
        else{
            y = it2->second;
        }
        adj[x].push_back(y);
    }
    for(int j=1; j<=i; j++){
        if(state[j] == 0){
            solve(parent[j], j);
        }
    }
    string s;
    while(cin>>s){
        //
        //if(s=="xxx") break;
        //

        cout<<s<<" ";
        if(id[MAP[s]] == 0) cout<<"trapped";
        else cout<<"safe";
        cout<<endl;
    }
}