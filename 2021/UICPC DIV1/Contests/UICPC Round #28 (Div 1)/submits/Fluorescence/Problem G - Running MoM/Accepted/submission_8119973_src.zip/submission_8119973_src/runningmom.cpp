#include <bits/stdc++.h>
using namespace std;
const int num=2*(5000)+5;
vector<int> adj[num];
int id[num], state[num], parent[num];
map<string, int> MAP;
int cycleNum=0;
void solve(int par, int cur){
    if(state[cur] == 2){
        return;
    }
    else if(state[cur] == 1){
        cycleNum++;
        id[cur] = cycleNum;
        int x=par;
        while(x != cur){
            id[x] = cycleNum;
            x = parent[x];
        }
        return;
    }
    else{
        parent[cur] = par;
        state[cur] = 1;
        for(int e : adj[cur]){
            solve(cur, e);
        }
        state[cur] = 2;
    }
}
bool dfs(int cur){
    for(int e : adj[cur]){
        if(id[e] != 0){
            id[cur] = 1;
            return true;
        }
        dfs(e);
        if(id[e] != 0){
            id[cur] = 1;
            return true;
        }
    }
    return false;
}
int main(){
    int n, i=0; cin>>n;
    while(n--){
        string a, b; cin>>a>>b;
        int x, y;
        auto it = MAP.find(a);
        if(it == MAP.end()){
            i++;
            MAP[a] = i;
            x = i;
        }
        else{
            x = it->second;
        }
        auto it2 = MAP.find(b);
        if(it2 == MAP.end()){
            i++;
            MAP[b] = i;
            y = i;
        }
        else{
            y = it2->second;
        }
        adj[x].push_back(y);
    }
    for(int j=1; j<=i; j++){
        if(state[j] == 0){
            solve(parent[j], j);
        }
    }
    for(int j=1; j<=i; j++){
        if(id[j] == 0){
            if(dfs(j)){
                id[j] = 1;
            }
        }
    }
    string s;
    while(cin>>s){
        cout<<s<<" ";
        if(id[MAP[s]] == 0) cout<<"trapped";
        else cout<<"safe";
        cout<<endl;
    }
}