import math
n, k = map(int, input().split())
res = 0
while n > k:
    #if n <= k:
     #   print(res + 1 + n)
      #  break
    res += 1
    n = n - math.ceil(n/k)
print(res + 1 + n)