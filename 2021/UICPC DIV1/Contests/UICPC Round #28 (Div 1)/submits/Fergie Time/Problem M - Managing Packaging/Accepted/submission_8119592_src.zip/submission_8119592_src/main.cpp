#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1002;

set<string> split(const string &str, char delim)
{
    set<string> cont;
    stringstream ss(str);
    string token;
    getline(ss, token, delim);
    while (getline(ss, token, delim))
    {
        // cout << token << ", ";
        cont.insert(token);
    }
    // cout << endl;
    return cont;
}

int main()
{
    string ans;
    while(true)
    {
        int n;
        cin >> n;

        if (n == 0)
            break;

        map<string, set<string> > graph;
        for (int i = 0; i < n; i++)
        {
            string x;
            cin >> x;
            string ss;
            getline(cin, ss);
            set<string> v = split(ss, ' ');
            graph[x] = v;
        }


        string tempAns = "";

        while (graph.size())
        {
            string target = "";
            auto targetIt = graph.begin();
            for (auto i = graph.begin(); i != graph.end(); i++)
            {
                // cout << i->second.size() << ",";
                if (i->second.size() == 0)
                {
                    target = i->first;
                    targetIt = i;
                    break;
                }

            }
            // cout << endl;
            if(target != "")
            {
                graph.erase(targetIt);
                tempAns += target + '\n';
                // cout << target << endl;
                for (auto i = graph.begin(); i != graph.end(); i++)
                {
                    i->second.erase(target);
                }
            } else
            {
                tempAns = "cannot be ordered\n";
                // cout << "cannot be ordered\n";
                break;
            }
        }
        ans += tempAns + "\n";
        // ans += "\n";
        // cout << endl;

    }
    cout << ans;
    return 0;
}