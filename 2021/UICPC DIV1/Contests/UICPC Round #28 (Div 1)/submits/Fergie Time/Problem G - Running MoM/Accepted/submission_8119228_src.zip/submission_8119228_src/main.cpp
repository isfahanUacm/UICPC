#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<vector<ll>> graph;
vector<ll> color;

bool dfsdoor(ll index)
{
    color[index] = 1;
    for (ll i: graph[index])
    {
        if (!color[i])
        {
            bool flag = dfsdoor(i);
            if (flag)
            {
                return true;
            }
        }
        else
        {
            if (color[i] == 1)
            {
                return true;
            }
        }

    }
    color[index] = 2;
    return false;
}

int main()
{
    ll n;
    cin >> n;
    unordered_map<string, ll> indexOf;
    vector<pair<string, string>> arr(n);
    ll gindex = 0;
    for (ll i = 0; i < n; i++)
    {
        cin >> arr[i].first >> arr[i].second;
        if (indexOf.find(arr[i].first) == indexOf.end())
        {
            indexOf[arr[i].first] = gindex++;
        }
        if (indexOf.find(arr[i].second) == indexOf.end())
        {
            indexOf[arr[i].second] = gindex++;
        }
    }
    graph = vector<vector<ll>>(indexOf.size());
    for (ll i = 0; i < arr.size(); i++)
    {
        graph[indexOf[arr[i].first]].push_back(indexOf[arr[i].second]);
    }

    unordered_map<string, string> ansvec(n);

    string s;
    while (cin >> s)
    {
        bool ans;
        color = vector<ll>(indexOf.size(), 0);
        ans = dfsdoor(indexOf[s]);
        if (ans)
        {
            cout << s << " " << "safe" << endl;

        }
        else
        {
            cout << s << " " << "trapped" << endl;
        }
    }
    return 0;
}
