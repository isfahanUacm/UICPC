#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define F first
#define S second
#define watch(x) cout << #x << " : " << x << endl
#define pb push_back
#define pll pair<ll, ll>

const ll maxn = 1e5 + 1;
const ll mod = 1e9 + 7;

vector<ll> getSuffixes(string s)
{
    s += (char)(*min_element(s.begin(), s.end()));
    ll n = s.size();
    vector<ll> a(n), b(n);
    {
        vector<pair<char, ll>> v;
        for(ll i = 0; i < n; i++)
        {
            v.push_back({s[i], i});
        }
        sort(v.begin(), v.end());
        for(ll i = 0; i < n; i++)
        {
            a[i] = v[i].second;
        }
        b[a[0]] = 0;
        for(ll i = 1; i < n; i++)
        {
            b[a[i]] = ((v[i].first == v[i - 1].first)? b[a[i - 1]] : b[a[i - 1]] + 1);
        }
    }
    ll k = 0;
    while(1 << k < n)
    {
        vector<pair<pair<ll, ll>, ll>> v(n);
        for(ll i = 0; i < n; i++)
        {
            v[i] = {{b[a[i]], b[(a[i] + (1 << k)) % n]}, a[i]};
        }
        sort(v.begin(), v.end());
        {
            for(ll i = 0; i < n; i++)
            {
                a[i] = v[i].second;
            }
            b[a[0]] = 0;
            for(ll i = 1; i < n; i++)
            {
                if(v[i].first.first == v[i - 1].first.first)
                {
                    b[a[i]] = (v[i].first.second == v[i - 1].first.second)? b[a[i - 1]] : b[a[i - 1]] + 1;
                }
                else
                {
                    b[a[i]] = (v[i].first.first == v[i - 1].first.first)? b[a[i - 1]] : b[a[i - 1]] + 1;
                }
            }
        }
        k++;
    }

    return a;
}
vector<string> split(const string& str, char delim)
{
    vector<string> cont;
    stringstream ss(str);
    string token;
    while(getline(ss, token, delim))
        cont.push_back(token);
    return cont;
}
int main()
{
    string s;
    while(getline(cin, s))
    {
//        watch(s.length());

        ll n;
        cin >> n;
        vector<ll> q(n);
        for(ll i = 0; i < n; i++)
        {
            cin >> q[i];
        }
        getchar();
        vector<ll> ans = getSuffixes(s);
        vector<ll> ans2;

        for(ll i = 0; i < ans.size(); i++)
        {
            if(ans[i] < s.length())
            {
                ans2.push_back(ans[i]);
            }
        }
        for(ll i = 0; i < q.size(); i++)
        {
            cout << ans2[q[i]] << " ";
        }
        cout << endl;
    }

    return 0;
}
