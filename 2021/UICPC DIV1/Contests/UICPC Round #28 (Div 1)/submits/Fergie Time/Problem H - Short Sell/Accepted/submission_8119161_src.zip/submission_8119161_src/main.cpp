#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 110;

int main()
{
    ll n, k;
    cin >> n >> k;

    vector<ll> price(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> price[i];
    }

    ll ans = 0;
    ll currentAns = 0;
    for(ll i = 0; i < n; i++)
    {
        currentAns = max(currentAns, price[i] * 100);
        currentAns = max(currentAns - k, 0ll);
        ll returnTheMoney = currentAns - price[i] * 100;
        ans = max(ans, returnTheMoney);
    }
    cout << ans;
    return 0;
}