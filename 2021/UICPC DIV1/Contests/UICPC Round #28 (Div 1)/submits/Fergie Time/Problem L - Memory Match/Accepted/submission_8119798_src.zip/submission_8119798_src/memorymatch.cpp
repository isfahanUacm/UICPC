#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;




int main()
{
    ll n;
    ll turn;
    cin >> n;
    cin >> turn;
    ll v = n/2;
    ll count = 0;
    vector <pair<string, bool>> cards(n,{"-1",false});
    for (ll i=0;i<turn;i++)
    {
        ll t1,t2;
        string s1,s2;
        cin >> t1 >> t2;
        t1--;
        t2--;
        cin >> s1 >> s2;
        cards[t1].first = s1;
        cards[t2].first = s2;
        if (s1 == s2)
        {
            cards[t1].second = true;
            cards[t2].second = true;
            v -= 1;
            count += 1;
        }
        else
        {
        cards[t1].second = false;
        cards[t2].second = false;
        }

    }
//    for (ll i=0; i<cards.size();i++)
//        cout << cards[i].first <<" " << cards[i].second<<endl;
   // cout << "v" << v << endl;
    ll ans = 0;
     for (ll i=0;i<cards.size(); i++)
     {
         if (cards[i].first != "-1")
         {
         if (!cards[i].second)
         {
             ll index = -1;
             for (ll j=i+1;j<cards.size();j++)
                 if (cards[i] == cards[j])
                 {
                     index = j;
                 }
             if (index != -1)
             {

                 ans ++;
                 count += 1;
                 v -= 1;
                 cards[i].second = true;
                 cards[index].second = true;
                // cout << i << " " << index << endl;
             }
             else
               {
                //cout <<"im v" << v << endl;

                  v -= 1;

                }
         }

         }


     }
     //cout << v << endl;


     ll ans2 = 0;
     if ((v == 1) && (count == (n/2)-1))
         ans2 += 1;
     if (v == 0)
     {

         for (ll i=0;i<cards.size(); i++)
         {
             if (cards[i].second == false)
                 ans2++;
         }
        // cout << "im in 2" << ans2 << endl;
         ans2 /=2;
     }

     cout << (ans+ans2);






}
