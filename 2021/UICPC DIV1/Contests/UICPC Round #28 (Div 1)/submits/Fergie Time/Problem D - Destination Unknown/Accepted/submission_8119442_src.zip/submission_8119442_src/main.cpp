#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<vector<pll>> graph;
vector<ll> x;

vector<ll> dist;
vector<bool> visited;

vector<vector<pll>> SPTree;

void dijkstra(ll index)
{
    multiset<pll> q;
    q.insert({0, index});
    dist[index] = 0;

    while(q.size())
    {
        ll current = q.begin()->second;
        ll currentDist = q.begin()->first;
        q.erase(q.begin());

        visited[current] = true;

        for(pll i: graph[current])
        {
            if(!visited[i.first])
            {
                if(dist[current] + i.second < dist[i.first])
                {
                    dist[i.first] = currentDist + i.second;
                    q.insert({currentDist + i.second, i.first});
                }
            }
        }
    }
}

void buildSPTree(ll index)
{
    visited[index] = true;
    for(pll i: graph[index])
    {
        if(dist[i.first] + i.second == dist[index])
        {
            SPTree[i.first].push_back({index, i.second});
            SPTree[index].push_back({i.first, i.second});
            if(!visited[i.first])
            {
                buildSPTree(i.first);
            }
        }
    }
}
int main()
{
    ll tests;
    cin >> tests;
    while(tests--)
    {
        ll n, m, t;
        cin >> n >> m >> t;
        graph = vector<vector<pll>> (n);
        ll s, g, h;
        cin >> s >> g >> h;
        s--;
        g--;
        h--;

        for(ll i = 0; i < m; i++)
        {
            ll a, b, d;
            cin >> a >> b >> d;
            a--;
            b--;
            graph[a].push_back({b, d});
            graph[b].push_back({a, d});
        }
        x = vector<ll> (t);
        for(ll i = 0; i < t; i++)
        {
            cin >> x[i];
            x[i]--;
        }
        dist = vector<ll> (n, LLONG_MAX);
        visited = vector<bool> (n, false);

        dijkstra(s);

        vector<ll> ans;
        for(ll item: x)
        {
            visited = vector<bool> (n, false);
            SPTree = vector<vector<pll>> (n);

            buildSPTree(item);

            bool flag = false;
            for(ll i = 0; i < n && !flag; i++)
            {
                for(pll j: SPTree[i])
                {
                    if(make_pair(i, j.first) == make_pair(g, h) || make_pair(i, j.first) == make_pair(h, g))
                    {
                        flag = true;
                        break;
                    }
                }
            }
            if(flag)
            {
                ans.push_back(item + 1);
            }
        }
        sort(ans.begin(), ans.end());
        for(ll i: ans)
        {
            cout << i << " ";
        }
        cout << endl;
    }
    return 0;
}
