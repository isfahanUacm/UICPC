#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl

int main()
{
    string s;
    cin>>s;
    string first="",second="",therd="";
    string ans="{";
    for(ll i=1;i<s.length();i++){
        for(ll j=i+1;j<s.length();j++){
            first=s.substr(0,i);
            second=s.substr(i,j-i);
            therd=s.substr(j);
            reverse(first.begin(), first.end());
            reverse(second.begin(), second.end());
            reverse(therd.begin(), therd.end());

            string s1=first+second+therd;
            if (s1<ans){
                ans=s1;
            }

        }
    }
    cout<<ans<<endl;

}
