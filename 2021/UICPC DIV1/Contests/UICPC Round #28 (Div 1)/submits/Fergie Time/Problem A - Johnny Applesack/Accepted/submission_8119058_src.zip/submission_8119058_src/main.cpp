#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 110;

int main()
{
    string s;

    ll n, k;
    cin >> n >> k;
    ll ans = 1;
    while(n >= k)
    {
        ll goBacks = n / k + ((n % k)? 1: 0);
        ans ++;
        n -= goBacks;
    }
    cout << ans + n;
    return 0;
}