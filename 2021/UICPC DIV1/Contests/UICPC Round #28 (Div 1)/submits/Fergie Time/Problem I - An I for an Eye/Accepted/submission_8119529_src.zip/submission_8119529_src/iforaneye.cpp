#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
unordered_map<string,char> words;
unordered_map<ll,string> wordsorder;
int main()
{
        words ["at"] = '@';
        words ["and"] = '&';
        words ["one"] = '1';
        words ["won"] = '1';
        words ["to"] = '2';
        words ["too"] = '2';
        words ["two"] = '2';
        words ["for"] = '4';
        words ["four"] = '4';
        words ["bea"] = 'b';
        words ["be"] = 'b';
        words ["bee"] = 'b';
        words ["sea"] = 'c';
        words ["see"] = 'c';
        words ["eye"] = 'i';
        words ["are"] = 'r';
        words ["you"] = 'u';
        words ["why"] = 'y';
        words ["oh"] = 'o';
        words ["owe"] = 'o';

        wordsorder [0] = "at";
        wordsorder [1] = "and";
        wordsorder [2] = "one";
        wordsorder [3] = "won";
        wordsorder [4] = "too";
        wordsorder [5] = "to";
        wordsorder [6] = "two";
        wordsorder [7] = "for";
        wordsorder [8] ="four";
        wordsorder [9] = "bea";
        wordsorder [10] = "bee";
        wordsorder [11] = "be";
        wordsorder [12] = "sea";
        wordsorder [13] = "see";
        wordsorder [14] = "eye";
        wordsorder [15] = "oh";
        wordsorder [16] = "owe";
        wordsorder [17] = "are";
        wordsorder [18] = "you";
        wordsorder [19] = "why";

    ll n;
    cin >> n;
    getchar();
    while(n--)
    {
          string s1;
          getline(cin, s1);
          string s2 = "";
          for (ll i=0; i<s1.length();i++)
              s2 += tolower(s1[i]);
          ll j =0;

          while (true)
          {
              ll indexsub;
              ll subindex=-1;
              ll locindex=-1;
              indexsub=s2.length();
              for(ll i=0;i<wordsorder.size();i++){
                 subindex= s2.find(wordsorder[i],j);
                 if(subindex !=-1 && subindex<indexsub){
                     indexsub=subindex;
                     locindex=i;

                 }
              }
              if(locindex == -1){
                  break;
              }
              char subs2=words[wordsorder[locindex]];
//              cout<<subs2<<endl;
              if(isupper(s1[indexsub])){
                 subs2=toupper(subs2);
              }
              s2=s2.substr(0,indexsub) + subs2 + s2.substr(wordsorder[locindex].length()+indexsub);
              s1=s1.substr(0,indexsub) + subs2 + s1.substr(wordsorder[locindex].length()+indexsub);
              j=indexsub+1;

          }
          cout<<s1<<endl;




      }


}
