#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define ld long double
#define pll pair<ll, ll>
#define pd pair<double, double>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
vector<pll> v;

bool isPrime(int n)
{

    if (n <= 1)
        return false;


    for (int i = 2; i < n; i++)
        if (n % i == 0)
            return false;

    return true;
}
int main()
{
   ll n;
   cin>>n;
   v= vector<pll> (n);

   for(ll i=0;i<n;i++)
   {
        cin >> v[i].first >> v[i].second;
   }
   for(ll i=0;i<n;i++)
   {
       bool ansi;
       ansi=isPrime(v[i].second);
       set<ll> numberv;
       if(ansi)
       {

           ll num=v[i].second;
           numberv.insert(num);
           ll number=0;
           while (num!=1 ) {
               while (num > 0)
               {
                   int digit = num%10;
                   num /= 10;
                   number+=(digit*digit);

               }

               num=number;
               if( numberv.find(num) != numberv.end())
               {
                   break;
               }
               numberv.insert(num);
               number=0;

           }
           if(num==1){
            cout<<v[i].first<<" "<<v[i].second<<" "<<"YES"<<endl;
           }
           else{
                cout<<v[i].first<<" "<<v[i].second<<" "<<"NO"<<endl;
           }
       }
       else{
           cout<<v[i].first<<" "<<v[i].second<<" "<<"NO"<<endl;
       }
   }

}
