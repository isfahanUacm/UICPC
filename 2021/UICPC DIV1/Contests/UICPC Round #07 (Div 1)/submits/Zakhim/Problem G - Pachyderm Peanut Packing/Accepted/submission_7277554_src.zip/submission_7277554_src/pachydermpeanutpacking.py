while True:
    n = int(input())
    if n == 0:
        break
    boxes = []
    for i in range(n):
        temp = list(map(str, input().split()))
        for k in range(len(temp) - 1):
            temp[k] = float(temp[k])
        boxes.append(temp)
    m = int(input())
    peanuts = []
    for i in range(m):
        temp = list(map(str, input().split()))
        for k in range(len(temp) - 1):
            temp[k] = float(temp[k])
        peanuts.append(temp)

    for i in peanuts:
        stats = False
        for j in boxes:
            if j[0] <= i[0] <= j[2] and j[1] <= i[1] <= j[3]:
                if j[4] == i[2]:
                    print(i[2], 'correct')
                    stats = True
                    break
        if stats:
            continue
        for j in boxes:
            if j[0] <= i[0] <= j[2] and j[1] <= i[1] <= j[3]:
                print(i[2], j[4])
                stats = True
                break
        if stats:
            continue
        print(i[2], 'floor')

    print()
