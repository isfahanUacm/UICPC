import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int[][] a=new int[n][n];
        boolean[] visited=new boolean[n];
        for (int i = 0; i <n ; ++i) {
            for (int j = 0; j <n ; ++j) {
                a[i][j]=s.nextInt();
            }
        }
        boolean alo=true;
        for (int i = 0; i <n-1 ; ++i) {
            int mini=100000000;
            int x=0,y=0;
            for (int k = 0; k <n ; ++k) {
                if (visited[k] || alo) {
                    alo= false;
                    for (int j = 0; j < n; ++j) {
                        if (k == j)
                            continue;
                        if (!visited[k] || !visited[j]) {
                            if (mini > a[k][j]) {
                                mini = a[k][j];
                                x = k;
                                y = j;
                            }
                        }
                    }
                }
            }
            y++;
            System.out.println((x+1)+" "+y);
            visited[x]= true;
            y--;
            visited[y]= true;
        }
    }
}