#include <bits/stdc++.h>
using namespace std;
const int maxm = 100001;
bool prime[maxm+1];
vector<int> a(100001,-2);
void SieveOfEratosthenes(int n)
{
    memset(prime, true, sizeof(prime));
    for (int p = 2; p * p <= n; p++)
        if (prime[p]) for (int i = p * p; i <= n; i += p) prime[i] = false;
}
int bede(int m){
    int jav=0,ind;
    while (m!=0){
        ind=m%10;
        jav+=pow(ind,2);
        m=m/10;
    }
    return jav;
}
int DP(int m){
    if(a[m]!=-2)
        return a[m];
    if(m==1)
        return 1;
    a[m]=0;
    a[m]=DP(bede(m));
    return (a[m]);
}
int main(){
    SieveOfEratosthenes(maxm);
    prime[1]= false;
    int n,temp1,temp2;
    cin>>n;
    vector<int>k,m;
    for (int i = 0; i <n ; ++i) {
        cin>>temp1>>temp2;
        if(prime[temp2]){
            if(DP(temp2)==1)
                cout<<temp1<<" "<<temp2<<" YES"<<endl;
            else
                cout<<temp1<<" "<<temp2<<" NO"<<endl;
        } else
            cout<<temp1<<" "<<temp2<<" NO"<<endl;
    }
}