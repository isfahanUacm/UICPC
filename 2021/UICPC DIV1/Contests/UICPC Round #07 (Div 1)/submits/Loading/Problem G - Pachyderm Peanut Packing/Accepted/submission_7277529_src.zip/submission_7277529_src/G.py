while (True):
    t = int(input())
    if t == 0: break
    boxs = []
    for i in range(t):
        templ= list(input().split())
        for ii in range(4):
            templ[ii] = float(templ[ii])
        boxs.append(templ)
    #print(boxs)
    n = int(input())
    pens = []
    for j in range(n):
        tempp = list(input().split())
        for jj in range(2):
            tempp[jj] = float(tempp[jj])
        tempp.append(j)
        pens.append(tempp)
    #print(pens)
    pens.sort(key = lambda x: x[0])
    boxs.sort(key = lambda x: x[0])
    for p in pens:
        for b in boxs:
            if (b[0] > p[0]):
                p.append("floor")
                continue
            #print(b)
            #print(p)
            if (p[0] >= b[0] and p[0] <= b[2]) and (p[1] >= b[1] and p[1] <= b[3]):
                if p[2] == b[4]:
                    p.append("correct")
                else:
                    p.append(b[4])
                break
        else: p.append("floor")
    
    pens.sort(key = lambda x: x[3])
    for p in pens:
        print(p[2],p[4])

    print("")
