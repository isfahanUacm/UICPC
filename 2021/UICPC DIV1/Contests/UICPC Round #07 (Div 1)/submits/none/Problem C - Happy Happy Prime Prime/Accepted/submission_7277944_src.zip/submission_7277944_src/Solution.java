import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        for (int i = 1; i <= n; i++) {
            int j = s.nextInt();
            int num = s.nextInt();
            if (!isPrime(num)) {
                System.out.print(j + " ");
                System.out.println(num + " NO");
            } else {
                if (isHappyNumber(num)) {
                    System.out.print(j + " ");
                    System.out.println(num + " YES");
                } else {
                    System.out.print(j + " ");
                    System.out.println(num + " NO");
                }
            }
        }
    }

    static boolean isPrime(int n) {
        if (n <= 1)
            return false;
        for (int i = 2; i < n; i++)
            if (n % i == 0)
                return false;

        return true;
    }

    static int numSquareSum(int n) {
        int squareSum = 0;
        while (n != 0) {
            squareSum += (n % 10) * (n % 10);
            n /= 10;
        }
        return squareSum;
    }

    static boolean isHappyNumber(int n) {
        int s, f;
        s = f = n;
        do {
            s = numSquareSum(s);
            f = numSquareSum(numSquareSum(f));

        }
        while (s != f);
        return (s == 1);
    }
}