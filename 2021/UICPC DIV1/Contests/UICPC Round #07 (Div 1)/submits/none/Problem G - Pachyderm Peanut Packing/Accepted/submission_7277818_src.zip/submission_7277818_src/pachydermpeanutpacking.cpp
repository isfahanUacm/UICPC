#include <iostream>
#include <math.h>
using namespace std;

class box
{
public:
    float x1, x2, y1, y2;
    string sb;
};

class peanuts
{
public:
    float x, y;
    string sp;
};

int main ()
{
    int n, m, i, j, tp;
    while (true)
    {
        cin>> n;
        if (n == 0)
            break;
        else
        {
            box B[n];
            for (i=0; i<n; i++)
            {
                cin>> B[i].x1>> B[i].y1>> B[i].x2>> B[i].y2;
                cin>> B[i].sb;
            }
            cin>> m;
            peanuts P[m];
            for (i=0; i<m; i++)
            {
                cin>> P[i].x>> P[i].y;
                cin>> P[i].sp;
            }

            for (i=0; i<m; i++)
            {
                tp= 0;
                for (j=0; j<n; j++)
                {
                    if (P[i].sp == B[j].sb)
                    {
                        if (P[i].x>=B[j].x1)
                            if (P[i].x<=B[j].x2)
                                if (P[i].y>=B[j].y1)
                                    if (P[i].y<=B[j].y2)
                                    {
                                        tp= 1;
                                        cout<< P[i].sp<< " "<< "correct"<< endl;
                                        break;
                                    }
                    }
                    else
                        continue;
                }
                if (tp == 0)
                {
                    for (j=0; j<n; j++)
                    {
                        if (P[i].sp != B[j].sb)
                            if (P[i].x>=B[j].x1)
                                if (P[i].x<=B[j].x2)
                                    if (P[i].y>=B[j].y1)
                                        if (P[i].y<=B[j].y2)
                                        {
                                            tp= 1;
                                            cout<< P[i].sp<< " "<< B[j].sb<< endl;
                                            break;
                                        }
                    }
                }
                if (tp == 0)
                    cout<< P[i].sp<< " "<< "floor"<< endl;
            }
            cout<< endl;
        }
    }
    return 0;
}
