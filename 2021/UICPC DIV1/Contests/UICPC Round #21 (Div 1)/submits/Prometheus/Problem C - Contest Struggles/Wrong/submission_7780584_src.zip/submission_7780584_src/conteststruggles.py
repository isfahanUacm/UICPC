def main():
    n, solved = map(int, input().split(" "))
    average, solved_average = map(int, input().split(" "))
    result = (n * average - solved * solved_average) / (n - solved)
    if result > 100:
        print("impossible")
    else:
        print("{:.7f}".format(result))


if __name__ == "__main__":
    main()