#include <bits/stdc++.h>
#include <algorithm>
#include<map>

using namespace std;


int main(){
    string s ;
    string t;
    getline(cin,s);
    getline(cin,t);
//    cout<<s<<endl<<t;

//    string res = "";
    map<char, char> res;
    unsigned int j=0;
    for(unsigned int i=0;i<s.length();i++){


        bool flag = false;
        while(s[i] != t[j]){
            if(!flag){
//                res+=t[j];
                res.insert(pair<char, char>(t[j], t[j]));
                flag = true;
            }
            j++;

        }

        if (i == s.length()-1 && j != t.length()-1){
            res.insert(pair<char, char>(t[j], t[j]));
        }
        j++;
    }

//    for(int i=0;i<res.length();i++){

//    }
//    cout<<res<<endl;
    map<char, char>::iterator itr;
    for(itr = res.begin(); itr != res.end(); itr++)
        cout<<itr->first;
    cout<< endl;

}
