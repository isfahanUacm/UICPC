#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    sort(arr, arr + n);
    
    vector<int> vc;
    vector<int> vc2;
    for (int i = 0; i < n/2; ++i) {
        vc.push_back(arr[i]);
        vc.push_back(arr[n - 1 - i]);

        vc2.push_back(arr[n - 1 - i]);
        vc2.push_back(arr[i]);
    }
    if(n%2 == 1) {
        vc.push_back(arr[n/2]);
        vc2.push_back(arr[n/2]);
    }
    bool flag = true;
    bool flag2 = true;

    reverse(vc.begin(), vc.end());
    reverse(vc2.begin(), vc2.end());

    for (int i = 1; i < n - 1; ++i) {
        if (abs(vc[i] - vc[i - 1]) > abs(vc[i] - vc[i + 1]))
            flag =false;
    }

    for (int i = 1; i < n - 1; ++i) {
        if (abs(vc2[i] - vc2[i - 1]) > abs(vc2[i] - vc2[i + 1]))
            flag2 =false;
    }

    if (flag || flag2) {
        if (flag) {
            for (auto x : vc) {
                cout << x << " ";
            }
            cout << endl;
        }
        else {
            for (auto x : vc2) {
                cout << x << " ";
            }
            cout << endl;
        }
    }
    else
        cout << "impossible" << endl;
}