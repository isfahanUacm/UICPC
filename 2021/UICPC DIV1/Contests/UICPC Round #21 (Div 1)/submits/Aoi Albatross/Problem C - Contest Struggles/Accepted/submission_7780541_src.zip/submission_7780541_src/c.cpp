#include <bits/stdc++.h>
using namespace std ;

int main(){
    double n, k, a, b;
    cin >> n >> k >> a >> b;
    
    double ans = ((n*a) - (k*b)) / (n-k);
    
    if (ans > 100) cout << "impossible" << endl;
    else if (ans <0) cout << "impossible" << endl;
    else printf("%.6lf\n", ans);


    return 0;
}