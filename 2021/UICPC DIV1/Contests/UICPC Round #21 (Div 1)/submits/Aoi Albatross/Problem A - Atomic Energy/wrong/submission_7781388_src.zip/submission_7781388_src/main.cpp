#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 6000;
ll dp[MAX];
int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        cin >> dp[i];
    }
    for (int i = n + 1; i < MAX; ++i) {
        dp[i] = LONG_LONG_MAX;
        for (int j = 1; j <= n; ++j) {
            dp[i] = min(dp[i - j] + dp[j], dp[i]);
        }
    }

    for (int i = 0; i < m; ++i) {
        ll q;
        cin >> q;
        if (q < MAX) {
            cout << dp[q] << endl;
        }
        else {
            ll mi = LONG_LONG_MAX;
            for (int j = MAX - 1; j >= 1; --j) {
                ll z = q/j;
                ll b = q%j;
                mi = min(mi, dp[j] * z + dp[b]);
            }
            cout << mi << endl;
        }
    }
}