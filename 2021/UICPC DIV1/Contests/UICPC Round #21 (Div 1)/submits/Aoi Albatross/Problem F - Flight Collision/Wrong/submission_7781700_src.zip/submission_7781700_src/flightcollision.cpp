#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
const ll mx = 1e5+10;
set<pair<ld,pair<ll,ll>>> ac;
unordered_map<ll,ll> nx;
unordered_map<ll,ll> px;
unordered_map<ll,ll> id;
unordered_map<ll,pair<ll,ll>> id2;
bool is_alive[mx];
ll n,n2;
int main(){
    memset(is_alive,true,sizeof(is_alive));
    cin >> n;
    n2 = n;
    for(ll i=1;i<=n;i++){
        ll x,v;
        cin >> x >> v;
        //id[x] = i;
        id2[i] = {x,v};
    }
    nx[n] = n+1;
    px[1] = 0;
    for(ll i=1;i<=n-1;i++){
        nx[i] = i+1;
    }
    for(ll i=n;i>=2;i--){
        px[i] = i-1;
    }
    for(ll i=1;i<n;i++){
        auto f = id2[i];
        auto s = id2[i+1];
        if(f.second==s.second)continue;
        ld t = ((ld(s.first)-ld(f.first)))/ld(ld(f.second)-ld(s.second));
        if(t>=0){
            ac.insert({t,{i,i+1}});
        }
    }
    ll m=1;
    while(ac.size()&&n2>0){
        auto u = *(ac.begin());
        ac.erase(ac.begin());
        if(is_alive[u.second.first]&&is_alive[u.second.second]){
           //m++;
            is_alive[u.second.first] = 0;
            is_alive[u.second.second] = 0;
            n2-=2;
            auto px1 = px[u.second.first];
            auto nx2 =  nx[u.second.second];
            if(px1<=0||nx2>=n+1)continue;
            px[nx2] = px1;
            nx[px1] = nx2;
            auto f = id2[px1];
            auto s = id2[nx2];
            if(f.second==s.second)continue;
            ld t = (ld(s.first+s.second*m)-ld(f.first+f.second*m))/ld(ld(f.second)-ld(s.second));
            //cout<<t<<endl;
            if(t>=0){
                ac.insert({t,{px1,nx2}});
            }

        }
    }
    ll ans=0;
    for(ll i=1;i<=n;i++){
        if(is_alive[i])ans++;
    }
    cout<<ans<<endl;
    for(ll i=1;i<=n;i++){
        if(is_alive[i]){
            cout<<i<<' ';
        }
    }
    if(ans)cout<<endl;
    return 0;
}