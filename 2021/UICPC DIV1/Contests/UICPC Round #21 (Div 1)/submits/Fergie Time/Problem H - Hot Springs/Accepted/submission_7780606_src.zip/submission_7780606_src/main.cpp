#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl

int main()
{
    ll n;
    cin>>n;
    vector<ll> arr(n);
    for(ll i=0;i<n;i++){
        cin>>arr[i];
    }
    sort(arr.begin(),arr.end());
    vector<ll> ans(n);
    ll i=n-1;

    while(arr.size()){
        ans[i]=arr[arr.size()-1];
        arr.pop_back();
        if(i-1<0){
            break;
        }
        ans[i-1]=arr[0];
        i-=2;
        if(i<0){
            break;
        }
        arr.erase(arr.begin());
    }
    i=0;
    bool j=false;
    while(i<n-3){
        ll ti1,ti,ti2;
        ti1=ans[i];
        ti=ans[i+1];
        ti2=ans[i+2];
        if(abs(ti1-ti)>abs(ti-ti2)){
           j=true;
           break;
        }
        i++;
    }
    if(!j){
        for(ll u:ans){
            cout<<u<<" ";
        }
        cout<<"\n";
    }
    else{
        cout<<"impossible"<<"\n";
    }

}
