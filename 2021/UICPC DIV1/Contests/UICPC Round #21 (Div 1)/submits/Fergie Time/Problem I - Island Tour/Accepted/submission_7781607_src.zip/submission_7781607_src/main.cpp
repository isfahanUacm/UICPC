#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

vector <ll> timeway;
vector <ll> tijmen;
vector <ll> annemarie;
vector<ll> imme;

int main()
{
    ll n;
    bool flag;
    cin >> n;
    timeway = vector <ll> (n);
    tijmen = vector<ll> (n);
    annemarie = vector<ll> (n);
    imme = vector<ll> (n);
    int ** arr1 = new int*[n];
    int ** arr2 = new int*[n];
    int ** arr3 = new int*[n];
    vector<pll> ie1(n);
    vector<pll> ie2(n);
    vector<pll> ie3(n);
    for (ll i=0;i<n;i++)
    {
        cin >> timeway[i];

    }
    for (ll i=0;i<n;i++)
    {
        cin >> tijmen[i];
        arr1[i] = new int[n];
        ie1[i].first = -1;
        ie1[i].second = -1;
    }
    for (ll i=0;i<n;i++)
    {
        cin >> annemarie[i];
        arr2[i] = new int[n];
        ie2[i].first = -1;
        ie2[i].second = -1;
    }
    for (ll i=0;i<n;i++)
    {
        cin >> imme[i];
        arr3[i] = new int[n];
        ie3[i].first = -1;
        ie3[i].second = -1;
    }

    for (ll i=0;i<n;i++)
        for (ll j=0;j<n;j++)
        {
            arr1[i][j]=0;
            arr2[i][j]=0;
            arr3[i][j]=0;
        }

    for (ll i=0;i<n;i++)
        for(ll j=0;j<n;j++)
        {
            ll st = i;
            ll sa = j;
            ll timeit = 0;
            ll timeia = 0;
            ll timeet =0;
            ll timeea = 0;
            flag = true;
            for(int k=0;k<n;k++)
            {
                ie1[k] = {-1,-1};
                ie2[k] = {-1,-1};
            }
            while(true){


                timeet = timeit + tijmen[st];
                if(ie2[st].first != -1 && ie2[st].second!= -1)
                {
                    if (((timeit > ie2[st].first && timeit < ie2[st].second) || ( timeet > ie2[st].first && timeet < ie2[st].second)) || ((ie2[st].first > timeit && ie2[st].first < timeet ) || (ie2[st].second > timeit && ie2[i].second < timeet))
                            || (timeit == ie2[st].first && timeet == ie2[st].second))
                    {
                        flag = false;
                    }

                }

                if (!flag)
                     break;
                ie1[st] = {timeit , timeet};
                timeit = timeet + timeway[st];
                st = (st+1)%n;

                timeea = timeia + annemarie[sa];
                if(ie1[sa].first != -1 && ie1[sa].second!= -1)
                {
                    if (((timeia > ie1[sa].first && timeia < ie1[sa].second) || ( timeea > ie1[sa].first && timeea < ie1[sa].second)) || ((ie1[i].first > timeia && ie1[i].first < timeea) || (ie1[i].second > timeia && ie1[i].second < timeea))
                            || (timeia == ie1[sa].first && timeea == ie1[sa].second))
                        flag = false;
                }


                if (!flag)
                {

                    break;
                }

                ie2[sa] = {timeia,timeea};
                timeia = timeea + timeway[sa];
                sa = (sa+1)%n;

                if (st == i && sa == j)
                    break;
            }
            if (flag)
                arr1[i][j] = 1;
            flag = true;
        }


    for (ll i=0;i<n;i++)
        for(ll j=0;j<n;j++)
        {
            ll st = i;
            ll si = j;
            ll timeit = 0;
            ll timeii = 0;
            ll timeet =0;
            ll timeei = 0;
            flag = true;
            for(int k=0;k<n;k++)
            {
                ie1[k] = {-1,-1};
                ie3[k] = {-1,-1};
            }
            while(true)
            {
                timeet = timeit + tijmen[st];
                if(ie3[st].first != -1 && ie3[st].second!= -1)
                {
                    if (((timeit > ie3[st].first && timeit < ie3[st].second) || ( timeet > ie3[st].first && timeet < ie3[st].second)) || ((ie3[st].first > timeit && ie3[st].first < timeet) || (ie3[st].second > timeit && ie3[st].second < timeet))
                            || (timeit == ie3[st].first && timeet == ie3[st].second))
                    {
                        flag = false;
                    }

                }

                if (!flag)
                {

                    break;
                }
                ie1[st] = {timeit , timeet};
                timeit = timeet + timeway[st];
                st = (st+1)%n;

                timeei = timeii + imme[si];
                if(ie1[si].first != -1 && ie1[si].second!= -1)
                {
                    if((timeii > ie1[si].first && timeii < ie1[si].second) || ( timeei > ie1[si].first && timeei < ie1[si].second) || ((ie1[i].first > timeii && ie1[i].first < timeei) || (ie1[i].second > timeii && ie1[i].second < timeei))
                            || (timeii == ie1[si].first && timeei == ie1[si].second))
                    {
                        flag = false;
                    }

                }
                if (!flag)
                {

                    break;
                }

                ie3[si] = {timeii,timeei};
                timeii = timeei + timeway[si];
                si = (si+1)%n;

                if (st == i && si == j)
                    break;
            }
            if (flag)
                arr2[i][j] = 1;
            flag = true;
        }


    for (ll i=0;i<n;i++)
    {
        ie2[i] = {-1,-1};
        ie3[i] = {-1,-1};
    }

    for (ll i=0;i<n;i++)
        for(ll j=0;j<n;j++)
        {
            for(int k=0;k<n;k++)
            {
                ie2[k] = {-1,-1};
                ie3[k] = {-1,-1};
            }
            ll sa = i;
            ll si = j;
            ll timeia = 0;
            ll timeii = 0;
            ll timeea =0;
            ll timeei = 0;
            flag = true;
            while(true)
            {
                timeea = timeia + annemarie[sa];
                if(ie3[sa].first != -1 && ie3[sa].second!= -1)
                {
                    if (((timeia > ie3[sa].first && timeia < ie3[sa].second) || ( timeea > ie3[sa].first && timeea < ie3[sa].second)) || ((ie3[sa].first > timeia && ie3[sa].first <timeea) || (ie3[sa].second > timeia && ie3[sa].second <timeea)) ||
                            timeia == ie3[sa].first && timeea == ie3[sa].second)
                    {
                        flag = false;
                    }

                }

                if (!flag)
                {

                    break;
                }
                ie2[sa] = {timeia , timeea};
                timeia = timeea + timeway[sa];
                sa = (sa+1)%n;

                timeei = timeii + imme[si];
                if(ie2[si].first != -1 && ie2[si].second!= -1)
                {
                    if (((timeii > ie2[si].first && timeii < ie2[si].second) || ( timeei > ie2[si].first && timeei < ie2[si].second))|| ((ie2[si].first > timeii && ie2[si].second < timeei ) || (ie2[si].second > timeii && ie2[si].second < timeei ))
                            || (timeii == ie2[si].first && timeei == ie2[si].second))
                    {
                        flag = false;
                    }

                }
                if (!flag)
                {

                    break;
                }

                ie3[si] = {timeii,timeei};
                timeii = timeei + timeway[si];
                si = (si+1)%n;

                if (sa == i && si == j)
                    break;
            }
            if (flag)
                arr3[i][j] = 1;
           flag = true;
        }
    flag = false;
//    cout <<"--------------" <<endl;
//     for (ll i=0;i<n;i++)
//     {
//         for (ll j=0;j<n;j++)
//             cout << arr1[i][j] <<" ";
//         cout << endl;
//     }
//     cout <<"--------------" <<endl;
//     for (ll i=0;i<n;i++)
//     {
//         for (ll j=0;j<n;j++)
//             cout << arr2[i][j] <<" ";
//         cout << endl;
//     }
//      cout <<"--------------" <<endl;
//     for (ll i=0;i<n;i++)
//     {
//         for (ll j=0;j<n;j++)
//             cout << arr3[i][j] <<" ";
//         cout << endl;
//     }
//     cout <<"--------------" <<endl;
    for(ll i=0;i<n;i++)
    {
        for(ll j=0;j<n;j++)
        {
            for(ll k=0;k<n;k++)
            {
                if (arr1[i][j] && arr2[i][k] && arr3[j][k])
                {
                    flag = true;
                    cout << i+1 << " " << j+1 << " " <<k+1;
                    break;
                }

            }
            if (flag)
                break;
        }
        if (flag)
            break;

    }

    if (!flag)
       cout << "impossible";


}
