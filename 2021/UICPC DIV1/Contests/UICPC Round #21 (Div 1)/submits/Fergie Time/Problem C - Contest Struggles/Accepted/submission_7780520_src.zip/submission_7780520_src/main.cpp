#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;



int main()
{
    double n,m;
    cin >> n >> m;
    double avg1,avg2;
    cin >> avg1 >> avg2;
    double sum1 = avg1 * n;
    double sum2 = avg2 * m;
    sum1 -= sum2;
    if (sum1 < 0)
        cout << "impossible";
    else {
         n -= m;
         if (n < 0 )
             cout << "impossible";
         else {
             double avg3;
             avg3 = sum1 / n;
             if (avg3 > 100)
                 cout <<"impossible";
             else {
                  cout <<fixed << setprecision(7) << avg3;
             }

         }

    }



}
