#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

using namespace std;
set<ll> A;
set<ll> B;
vector<ll> P;

vector<ll> AList;
vector<ll> BList;
vector<ll> PList;

vector<vector<ll>> graph;
bool ans;
void dfs(ll index)
{
    if(ans)
    {
        return;
    }
    A.erase(index);
    P.push_back(index);
    if(A.size() == B.size())
    {
        for(ll i: A)
        {
            AList.push_back(i);
        }
        for(ll i: B)
        {
            BList.push_back(i);
        }
        for(ll i: P)
        {
            PList.push_back(i);
        }
        ans = true;
        return;
    }

    for(ll i: graph[index])
    {
        if(A.find(i) != A.end())
        {
            dfs(i);
        }
    }
    P.pop_back();
    B.insert(index);
    if(A.size() == B.size())
    {
        for(ll i: A)
        {
            AList.push_back(i);
        }
        for(ll i: B)
        {
            BList.push_back(i);
        }
        for(ll i: P)
        {
            PList.push_back(i);
        }
        ans = true;
        return;
    }
}

int main()
{
    ll n, m;
    cin >> n >> m;
    graph = vector<vector<ll>>(n);
    for(ll i = 0; i < m; i++)
    {
        ll a, b;
        cin >> a >> b;
        a--;
        b--;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
    P = vector<ll>();

    for(ll i = 0; i < n; i++)
    {
        A.insert(i);
    }
    ans = false;
    dfs(0);

    cout << PList.size() << " " << AList.size() << endl;
    for (ll i: PList)
    {
        cout << i + 1 << " ";
    }
    cout << endl;

    if(AList.size())
    {
        for (ll i: AList)
        {
            cout << i + 1 << " ";
        }
        cout << endl;
    }
    if(BList.size())
    {
        for (ll i: BList)
        {
            cout << i + 1 << " ";
        }
        cout << endl;
    }

    return 0;
}