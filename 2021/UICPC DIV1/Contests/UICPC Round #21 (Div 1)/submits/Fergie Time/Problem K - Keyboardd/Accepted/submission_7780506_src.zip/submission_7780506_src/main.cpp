#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;

using namespace std;

int main()
{
    string s;
    string t;
    getline(cin, s);
    getline(cin, t);
    set<char> ans;
    char lastInS = '-';
    ll i = 0, j = 0;

    while(i < s.length() || j < t.length())
    {
        if(s[i] == t[j])
        {
            i++;
            j++;
        }
        else
        {
            if(s[i - 1] == t[j])
            {
                ans.insert(t[j]);
                j++;
            }
        }
    }
    for(char c: ans)
    {
        cout << c;
    }
    return 0;
}