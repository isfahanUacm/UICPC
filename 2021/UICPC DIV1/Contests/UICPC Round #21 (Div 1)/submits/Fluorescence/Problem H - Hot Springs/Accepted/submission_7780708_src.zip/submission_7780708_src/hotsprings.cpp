#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};


int main(){
    vector<int> vec;
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        int x;
        cin>>x;
        vec.push_back(x);
    }
    sort(vec.begin(), vec.end());
    vector<int> ans;
    while(!vec.empty()){
        int l = vec[vec.size()-1];
        ans.push_back(l);
        vec.pop_back();
        if(vec.empty()) break;
        int f = vec[0];
        ans.push_back(f);
        vec.erase(vec.begin());
    }
    for(int i=n-1; i>=0; i--){
        cout<<ans[i]<<" ";
    }

}