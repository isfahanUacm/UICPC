n, k = map(int, input().split())
d, s = map(int, input().split())
x = (n*d) - (k*s)
x = x/(n-k)
if x >= 0 and x <= 100:
    print ('%.7f'%x)
else:
    print("impossible")