keyboard = list(input())
display = list(input())

res = set()
j = 0
cnt = 1
ldis = len(display)

for i in range(len(keyboard)):
    flag = True
    if i + 1 != len(keyboard):
        if keyboard[i + 1] == keyboard[i]:
            cnt += 1
            continue

    counter = 0
    while j < ldis:
        if display[j] == keyboard[i]:
            counter += 1
            if j != ldis:
                j += 1
        else:
            break
    if counter > cnt:
        res.add(keyboard[i])
    cnt = 1

# print(res)
for item in res:
    print(item, end="")
