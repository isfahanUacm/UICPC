n = int(input())
res = []
for i in range(n):
    res.append(0)
line = list(map(int, input().split()))
line.sort()

j = n - 1
while j >= 0:
    res[j] = line[-1]
    j -= 1
    if j < 0:
        break
    res[j] = line[0]
    j -= 1
    line.remove(line[0])
    line.remove(line[-1])

# print(res)
print(' '.join(map(str, res)))