n, k = map(int, input().split())
d, s = map(int, input().split())
res = (d * n - k * s) / (n - k)
if res > 100 or res < 0:
    print('impossible')
else:
    print(round(res, 6))
