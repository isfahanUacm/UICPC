#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
#define ld long double
const int MAX = 100005;
int parent[MAX];
int ran[MAX];

int find(int x) {
    return (parent[x] == x ? x : parent[x] = find(parent[x]));
}

void uni(int a, int b) {
    int pa = find(a);
    int pb = find(b);
    if (pa != pb) {
        if (ran[pa] > ran[pb]) {
            parent[pb] = pa;
        }
        else if (ran[pa] < ran[pb]) {
            parent[pa] = pb;
        }
        else {
            parent[pa] = pb;
            ran[pb]++;
        }
    }
}

ld dist(pair<ld, ld> a, pair<ld, ld> b) {
    return (sqrt(abs(a.first - b.first) * abs(a.first - b.first) + abs(a.second - b.second) * abs(a.second - b.second)));
}

int main() {
    int n, e, p;
    cin >> n >>  e >> p;
    vector<pair<ld, pair<int, int>>> vc;
    vector<pair<ld, ld>> co;
    
    for (int i = 0; i < n; ++i) {
        parent[i] = i;
        ran[i] = 0;
        
        
        ld x, y;
        cin >> x >> y;
        
        if (i < e) {
            uni(find(i), find(0));
        }
        
        co.emplace_back(x, y);
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int ni = (i < e) ? find(i) : i;
            int nj = (j < e) ? find(j) : j;
            
            if (ni != nj) {
                vc.push_back({dist(co[i], co[j]), {ni, nj}});
            }
        }
    }

    for (int i = 0; i < p; ++i) {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        uni(find(x), find(y));
    }

    ld ans = 0;
    sort(vc.begin(), vc.end());

    for (auto e: vc) {
        if (find(e.second.first) != find(e.second.second)) {
            uni(e.second.first, e.second.second);
            ans += e.first;
        }
    }
    double t = ans;
    printf("%.6f\n", t);
}