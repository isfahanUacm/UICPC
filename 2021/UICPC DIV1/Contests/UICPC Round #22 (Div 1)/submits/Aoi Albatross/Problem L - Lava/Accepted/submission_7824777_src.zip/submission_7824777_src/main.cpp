#include <bits/stdc++.h>
#define ld long double
typedef long long ll;
using namespace std;
int l1, l2, n, m;
const int MAX = 1100;

ll dist[MAX];
char mp[MAX][MAX];
set<pair<ll, ll>> ss;
vector<pair<int, int>> vc;

ld calc_dist(int x1, int y1, int x2, int y2, bool first) {
    if (first)
        return (sqrt(abs(x1 - x2) * abs(x1 - x2) + abs(y1 - y2) * abs(y1 - y2)));
    else
        if (x1 == x2)
            return abs(y2 - y1);
        else if (y1 == y2)
            return abs(x2 - x1);
        else
            return INT_MAX;
}

void dijkstra(int start, bool first, int lll) {
    dist[start] = 0;
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (int i = 0; i < vc.size(); ++i) {
            if (i == u)
                continue;

            if (calc_dist(vc[u].first, vc[u].second, vc[i].first, vc[i].second, first) <= lll) {
                if (dist[i] > dist[u] + 1) {
                    ss.erase({dist[i], i});
                    dist[i] = dist[u] + 1;
                    ss.insert({dist[i], i});
                }
            }
        }
    }
}


int main() {
    cin >> l1 >> l2;
    cin >> n >> m;
    for (long long & i : dist) {
        i = INT_MAX;
    }
    int si, ei;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> mp[i][j];
            if (mp[i][j] != 'B') {
                if (mp[i][j] == 'S')
                    si = vc.size();
                if (mp[i][j] == 'G')
                    ei = vc.size();
                vc.emplace_back(i, j);
            }
        }
    }

    dijkstra(si, true, l1);
    ll ans = dist[ei];

    for (long long & i : dist) {
        i = INT_MAX;
    }
    dijkstra(si, false, l2);
    ll sans = dist[ei];

    if (sans >= INT_MAX && ans >= INT_MAX) {
        cout << "NO WAY" << endl;
    }
    else if (ans < sans) {
        cout << "GO FOR IT" << endl;
    }
    else if (ans == sans) {
        cout << "SUCCESS" << endl;
    }
    else {
        cout << "NO CHANCE" << endl;
    }
}