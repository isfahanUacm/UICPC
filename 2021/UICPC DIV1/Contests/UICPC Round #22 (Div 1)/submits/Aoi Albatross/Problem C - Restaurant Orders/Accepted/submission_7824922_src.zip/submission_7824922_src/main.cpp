#include <bits/stdc++.h>
#define ld long double
typedef long long ll;
using namespace std;
const int MAX = 30005;
int dp[MAX][100];
int cnt[MAX];

int main() {
    cout.tie(nullptr);
    std::ostream::sync_with_stdio(false);

    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    memset(dp, 0, sizeof(dp));
    memset(cnt, 0, sizeof(cnt));
    cnt[0] = 1;

    for (int i = 1; i < MAX; ++i) {
        for (int j = 0; j < n; ++j) {
            if (i >= arr[j] && cnt[i - arr[j]] > 0) {
                if (cnt[i - arr[j]] >= 2) {
                    cnt[i] = 2;
                    break;
                }
                if (cnt[i] == 0) {
                    for (int k = 0; k < n; ++k) {
                        dp[i][k] = dp[i - arr[j]][k];
                    }
                    dp[i][j]++;
                    cnt[i]++;
                }
                else {
                    bool dup = true;
                    for (int k = 0; k < n; ++k) {
                        if (dp[i - arr[j]][k] + ((k == j) ? 1 : 0) != dp[i][k]) {
                            dup = false;
                        }
                    }
                    if (!dup) {
                        cnt[i] = 2;
                        break;
                    }
                }
            }
        }
    }

    int m;
    cin >> m;
    for (int i = 0; i < m; ++i) {
        int temp;
        cin >> temp;
        if (cnt[temp] == 0) {
            cout << "Impossible" << endl;
        }
        else if (cnt[temp] >= 2) {
            cout << "Ambiguous" << endl;
        }
        else {
            for (int j = 0; j < n; ++j) {
                for (int k = 0; k < dp[temp][j]; ++k) {
                    cout << j + 1 << ' ';
                }
            }
            cout << endl;
        }
    }
}
