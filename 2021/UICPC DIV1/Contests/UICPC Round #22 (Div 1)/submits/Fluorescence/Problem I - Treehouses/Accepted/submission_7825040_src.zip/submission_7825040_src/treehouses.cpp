#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;

int n, e, p;

int parent[1005];
int Rank[1005];
int Size[1005];

vector<pair<double, double>> nodes;

void make_set(){
    for (int i = 0; i < 1005; ++i) {
        parent[i] = i;
        //Rank[i] = 0;
        //Size[i]=1;
    }
}

int find(int v){
    if (parent[v] == v) return v;
    return parent[v] = find(parent[v]);
}

void join(int u, int v){
    int a, b;
    a = find(u);
    b = find(v);
    if(a == b) return;
    //if (Rank[a] < Rank[b]) swap(a, b);
    parent[b] = a;
    //Size[a] += Size[b];
    //if (Rank[a] == Rank[b]) Rank[a]++;
}

double calc(pair<double, double> x, pair<double, double> y){
    return sqrt(((x.first - y.first)*(x.first - y.first))+((x.second - y.second)*(x.second - y.second)));
}

int main(){
    set<pair<double, pair<int, int>>> s; //dist, nodes id1 -> id2
    cin>>n>>e>>p;
    double a, b;
    int x, y;
    for (int i = 0; i < n; i++)
    {
        cin>>a>>b;
        nodes.push_back({a, b});
    }
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            s.insert({calc(nodes[i], nodes[j]), {i, j}});
        }
    }

    make_set();
    for (int i = 0; i < e; i++){
        parent[i] = 0;
    }

    for (int i = 0; i < p; i++){
        cin>>x>>y; x--, y--;
        join(x, y);
    }

    double cable = 0;
    pair<double, pair<int, int>> pr;
    while(!s.empty()){
        pr = *s.begin();
        double d = s.begin()->first;
        int id1 = s.begin()->second.first;
        int id2 = s.begin()->second.second;
        s.erase(pr);
        if(find(id1) == find(id2)) continue;
        join(id1, id2);
        cable += d;
    }
    
    //cout<<cable<<endl;
    std::cout << std::setprecision(6) << std::fixed << cable;
    
}