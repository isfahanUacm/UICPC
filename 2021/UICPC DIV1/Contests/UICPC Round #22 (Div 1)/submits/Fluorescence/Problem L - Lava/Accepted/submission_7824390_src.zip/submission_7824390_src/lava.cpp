#include<bits/stdc++.h>
using namespace std;
typedef long long int lli;
int maxf, maxe, l, w;
char grid[1005][1005];
int elsa_dist[1005][1005];
int father_dist[1005][1005];
int elsa_moves[8][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
int father_moves[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
vector<pair<int, int>> Ws;
queue<pair<int, int>> q;

bool inrange(int x, int y){
    return x>=0 && y>=0 && x<l && y<w;
}

bool can(int x1, int y1, int x2, int y2, int abl){
    return abl >= sqrt((abs(x1-x2)*abs(x1-x2)) + (abs(y1-y2)*abs(y1-y2)));
}

void bfs(bool who){
    while(!q.empty()){
        pair<int, int> u = q.front(); q.pop();
        if(who){
            //for (int i = 0; i < l; i++){
                //for (int j = 0; j < w; j++){
                for(auto next : Ws){
                    if(can(u.first, u.second, next.first, next.second, maxe)){
                        if(elsa_dist[next.first][next.second] > elsa_dist[u.first][u.second] + 1){
                            elsa_dist[next.first][next.second] = elsa_dist[u.first][u.second] + 1;
                            q.push({next.first, next.second});
                        }
                    }
                }
            //}
        }
        else{
            for(auto m : father_moves){
                for (int i = 1; i <= maxf; i++)
                {
                    int vx = u.first + m[0]*i;
                    int vy = u.second + m[1]*i;
                    
                    if(inrange(vx, vy) && grid[vx][vy] != 'B'){
                        if (can(u.first, u.second, vx, vy, maxf)){
                            if(father_dist[vx][vy] > father_dist[u.first][u.second] + 1){
                                father_dist[vx][vy] = father_dist[u.first][u.second] + 1;
                                q.push({vx, vy});
                            }
                        }
                    }
                }
            }
        }
    }
}

int main(){
    //cout<<can(0, 0, 4, 3, 4);
    cin>>maxe>>maxf>>l>>w;
    int sx, sy, gx, gy;
    for (int i = 0; i < l; i++)
    {
        for (int j = 0; j < w; j++)
        {
            cin>>grid[i][j];
            elsa_dist[i][j] = INT_MAX;
            father_dist[i][j] = INT_MAX;
            if(grid[i][j] == 'S') sx=i, sy=j;
            else if(grid[i][j] == 'G') gx=i, gy=j, Ws.push_back({i, j});
            else if(grid[i][j] == 'W') Ws.push_back({i, j});
        }
    }
    elsa_dist[sx][sy] = 0;
    q.push({sx, sy});
    bfs(true);

    father_dist[sx][sy] = 0;
    q.push({sx, sy});
    bfs(false);

    if(elsa_dist[gx][gy] == INT_MAX && father_dist[gx][gy] == INT_MAX) cout<<"NO WAY";
    else if(elsa_dist[gx][gy] == father_dist[gx][gy]) cout<<"SUCCESS";
    else if(elsa_dist[gx][gy] < father_dist[gx][gy]) cout<<"GO FOR IT";
    else cout<<"NO CHANCE";
}