#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};

int t, n;
const int num=500+5;
int b[num];
int when[num];
int x=0,y=0;
int main(){
    cin>>t>>n;
    set<pair<int,int>, greater<pair<int,int>>> SET;
    for(int i=0; i<n; i++){
        cin>>b[i];
        SET.insert({b[i],i});
    }

    for(int i=0; i<n; i++){
        int now = SET.begin()->first;
        int indx = SET.begin()->second;
        SET.erase(SET.begin());
        if(x<y){
             swap(x,y);
        }
        if(x+now<=t){
            when[indx]=x;
            x+=now;
        }
        else{
            when[indx]=y;
             y+=now;
        }
        // if(x<y){
        //     when[indx]=x;
        //     x+=now;
        // }
        // else{
        //     when[indx]=y;
        //     y+=now;
        // }
    }
    for(int i=0; i<n; i++){
        cout<<when[i]<<" ";
    }

}