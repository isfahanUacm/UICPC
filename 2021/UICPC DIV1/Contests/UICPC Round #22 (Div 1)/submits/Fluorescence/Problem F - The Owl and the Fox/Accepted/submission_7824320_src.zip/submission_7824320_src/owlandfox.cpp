#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;
//int dx[4]={0,-1,0,1};
//int dy[4]={-1,0,1,0};

int main(){
    int t;
    cin>>t;
    while (t--)
    {
        int n;
        cin>>n;
        string s = to_string(n);
        for(int i=s.size()-1; i>=0; i--){
            if(s[i] != '0'){
                s[i] = s[i]-1;
                break;
            }
        }
        n = stoi(s);
        cout<<n<<endl;
    }
    
      
    
    
}