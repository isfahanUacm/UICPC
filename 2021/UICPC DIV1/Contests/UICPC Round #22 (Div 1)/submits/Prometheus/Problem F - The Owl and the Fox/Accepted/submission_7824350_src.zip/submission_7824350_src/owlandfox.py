def main():
    n = int(input())
    for _ in range(n):
        num = input()
        for index in reversed(range(len(num))):
            if num[index] == "0":
                continue
            else:
                print(int(num[0:index] + str(int(num[index]) - 1) + num[index + 1:len(num)]))
                break


if __name__ == "__main__":
    main()
