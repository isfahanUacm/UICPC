#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<ll> parents;
vector<ll> sizes;
ll find(ll x){
    if(x == parents[x] ) return x;
    return find(parents[x]);
}
bool same(ll x, ll y){
    ll px = find(x);
    ll py = find(y);
    if(px == py){
        return true;
    }
    else{
        return false;
    }
}
int main()
{
   ll n,e,p;
   cin>>n>>e>>p;
   ll m=p;
   vector<pld> arr(n);
   set<pll> edgs;
    vector<pair<ld,pll>> graph;
   for(ll i=0;i<n;i++){
       ld x,y;
       cin>>x>>y;
       arr[i]={x,y};
   }
   for(ll i=1;i<=e-1;i++){
       graph.push_back({(ld)0,{i-1,i}});

   }
   for(ll i=0;i<p;i++){
       ll r,t;
       cin>>r>>t;
       r--;
       t--;
       edgs.insert({r,t});
       graph.push_back({(ld)0,{r,t}});

   }


   for(ll i=0;i<n-1;i++){
        pld a=arr[i];
       for(ll j=i+1;j<n;j++){
           if(edgs.find({i,j})!=edgs.end() || edgs.find({j,i}) != edgs.end()){
               continue;
           }
           pld b=arr[j];
           ld x=(a.first - b.first)*(a.first-b.first);
           ld y=(a.second - b.second)*(a.second - b.second);
           ld d=sqrt(x+y);
           graph.push_back({d,{i,j}});
           m++;
       }
   }

   sort(graph.begin(),graph.end());

   parents = vector<ll> (n,-1);
   sizes = vector<ll> (n,0);
   for(ll i = 0; i < n; i++){
      if(parents[i] == -1){
        parents[i] = i;
        sizes[i] = 1;
       }
   }
   ld ans=0;
   for(ll i = 0; i <m; i++){
       pll temp = graph[i].second;

       ll px = find(temp.first);
       ll py = find(temp.second);
       if(px != py){

            if(sizes[px] < sizes[py]){
                    parents[px] = py;
                    sizes[py] += sizes[px];
            }
            else{
                parents[py] = px;
                sizes[px] += sizes[py];
            }

               ans += graph[i].first;

            }
    }
     cout<<fixed<<setprecision(6)<<ans<<"\n";




}
