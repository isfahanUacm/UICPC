#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
vector<vector<bool>> visited;
vector<vector<char>> g;
vector<vector<ll>> dist;
ll n,m;
void bfse(ll xx , ll yy){
    multiset<pll> dis;
    dis.insert({xx,yy});
    dist[xx][yy]=0;
    while(!dis.empty()){
        pll temp=*dis.begin();
        ll x=temp.first;
        ll y=temp.second;
        dis.erase(temp);
        visited[x][y]=true;
        if(x-1>=0 && y-1>=0 && (g[x-1][y-1] == 'W' || g[x-1][y-1] == 'G' ) && !visited[x-1][y-1]){


            if(dist[x][y]+1<dist[x-1][y-1]){
                dist[x-1][y-1]=dist[x][y]+1;
                  dis.insert({x-1,y-1});
            }
            if(g[x-1][y-1] == 'G'){
                visited[x-1][y-1]=true;
                return;
            }


        }
        if(x-1>=0 && y>=0 && y<m && (g[x-1][y] == 'W' || g[x-1][y] == 'G') && !visited[x-1][y])
        {


            if(dist[x][y]+1<dist[x-1][y]){
                 dist[x-1][y]=dist[x][y]+1;
                  dis.insert({x-1,y});
            }
            if(g[x-1][y] == 'G'){
                visited[x-1][y]=true;
                return;
            }


        }
        if(x-1>=0 && y+1<m && (g[x-1][y+1] == 'W' || g[x-1][y+1] == 'G') && !visited[x-1][y+1]){


            if(dist[x][y]+1<dist[x-1][y+1]){
                 dist[x-1][y+1]=dist[x][y]+1;
                  dis.insert({x-1,y+1});
            }
            if(g[x-1][y+1] == 'G'){
                visited[x-1][y+1]=true;
                return;

            }

        }
        if(x>=0 && x<n && y-1>=0 && (g[x][y-1] == 'W' || g[x][y-1] == 'G') && !visited[x][y-1]){


            if(dist[x][y]+1<dist[x][y-1]){
                dist[x][y-1]=dist[x][y]+1;
                  dis.insert({x,y-1});
            }
            if(g[x][y-1] == 'G'){
                visited[x][y-1]=true;
                return;
            }

        }
        if(x>=0 && x<n && y+1<m && (g[x][y+1] == 'W' || g[x][y+1] == 'G') && !visited[x][y+1]){


            if(dist[x][y]+1<dist[x][y+1]){
                dist[x][y+1]=dist[x][y]+1;
                  dis.insert({x,y+1});
            }
            if(g[x][y+1] == 'G'){
                visited[x][y+1]=true;
                return;
            }

        }
        if(x+1<n && y-1>=0 && (g[x+1][y-1] == 'W' || g[x+1][y-1] == 'G') && !visited[x+1][y-1]){


            if(dist[x][y]+1<dist[x+1][y-1]){
                dist[x+1][y-1]=dist[x][y]+1;
                  dis.insert({x+1,y-1});
            }
            if(g[x+1][y-1] == 'G'){
                visited[x+1][y-1]=true;
                return;
            }

        }
        if(x+1<n && y>=0 && y<m && (g[x+1][y] == 'W' || g[x+1][y] == 'G') && !visited[x+1][y]){


            if(dist[x][y]+1<dist[x+1][y]){
                dist[x+1][y]=dist[x][y]+1;
                  dis.insert({x+1,y});
            }
            if(g[x+1][y] == 'G'){
                visited[x+1][y]=true;
                return;
            }

        }
        if(x+1<n && y+1<m && (g[x+1][y+1] == 'W' || g[x+1][y+1] == 'G')  && !visited[x+1][y+1]){


            if(dist[x][y]+1<dist[x+1][y+1]){
                dist[x+1][y+1]=dist[x][y]+1;
                  dis.insert({x+1,y+1});
            }
            if(g[x+1][y+1] == 'G'){
                visited[x+1][y+1]=true;
                return;
            }

        }
    }

}

void bfsf(ll xx,ll yy){
    multiset<pll> dis;
    dis.insert({xx,yy});
    dist[xx][yy]=0;
    while(!dis.empty()){
        pll temp=*dis.begin();
        ll x=temp.first;
        ll y=temp.second;
        dis.erase(temp);
        visited[x][y]=true;

        if(x+1<n && y>=0 && y<m && (g[x+1][y] == 'W' || g[x+1][y] == 'G')  && !visited[x+1][y]){


            if(dist[x][y]+1<dist[x+1][y]){
                dist[x+1][y]=dist[x][y]+1;
                dis.insert({x+1,y});
            }
            if(g[x+1][y] == 'G'){
                visited[x+1][y]=true;
                return;
            }

        }
        if(x-1>=0 && y>=0 && y<m && (g[x-1][y] == 'W' || g[x-1][y] == 'G')  && !visited[x-1][y]){


            if(dist[x][y]+1<dist[x-1][y]){
                dist[x-1][y]=dist[x][y]+1;
                dis.insert({x-1,y});
            }
            if(g[x-1][y] == 'G'){
                visited[x-1][y]=true;
                return;
            }

        }
        if(x>=0 && x<n && y+1<m && (g[x][y+1] == 'W' || g[x][y+1] == 'G')  && !visited[x][y+1]){


            if(dist[x][y]+1<dist[x][y+1]){
                dist[x][y+1]=dist[x][y]+1;
                dis.insert({x,y+1});
            }
            if(g[x][y+1] == 'G'){
                visited[x][y+1]=true;
                return;
            }

        }
        if(x<n && x>=0 && y-1>=0 && (g[x][y-1] == 'W' || g[x][y-1] == 'G')  && !visited[x][y-1]){


            if(dist[x][y]+1<dist[x][y-1]){
                dist[x][y-1]=dist[x][y]+1;
                dis.insert({x,y-1});
            }
            if(g[x][y-1] == 'G'){
                visited[x][y-1]=true;
                return;
            }

        }
    }

}
int main()
{
    ll e,f;
    cin>>e>>f;
    cin>>n>>m;
    vector<char> sampleg (m);
    g = vector<vector<char>> (n,sampleg);
    vector<bool> sample(m,false);
    char s;
    string ss;
    pll start;
    pll ends;
    for(ll i = 0;i<n;i++){
        cin>>ss;

        for(ll j=0;j<ss.size();j++){
            g[i][j]=ss[j];

            if(ss[j]=='S'){
                start.first=i;
                start.second=j;
            }
            if(ss[j]=='G'){
                ends.first=i;
                ends.second=j;
            }
        }

    }
    ll anse,ansf;
    visited= vector<vector<bool>> (n,sample);
    vector<ll> sampledis(m,LLONG_MAX);
    dist=vector<vector<ll>> (n,sampledis);
    bfsf(start.first,start.second);
    bool father = visited[ends.first][ends.second];
    ansf=dist[ends.first][ends.second];
    visited= vector<vector<bool>> (n,sample);
    dist=vector<vector<ll>> (n,sampledis);
    bfse(start.first,start.second);
    anse=dist[ends.first][ends.second];
    if(!visited[ends.first][ends.second] && !father && anse == LLONG_MAX && ansf == LLONG_MAX){
        cout<<"NO WAY"<<endl;
        return 0;
    }
    ld eans,fans;
    eans= ((ld)anse/e);
    fans =((ld)ansf/f);
    if(eans==fans){
        cout<<"SUCCESS"<<endl;
    }
    else if (eans < fans){
        cout<<"GO FOR IT"<<endl;
    }
    else if (eans > fans){
        cout<<"NO CHANCE"<<endl;
    }


}
