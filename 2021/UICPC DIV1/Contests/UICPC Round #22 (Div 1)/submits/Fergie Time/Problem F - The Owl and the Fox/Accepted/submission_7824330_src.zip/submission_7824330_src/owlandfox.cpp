#include <iostream>
#include <bits/stdc++.h>
#include <algorithm>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
    ll t;
    cin >> t;
    while(t--){
        ll n;
        cin>>n;
        string num =  to_string(n);
        ll i=num.size()-1;
        while(i>=0){
            if(num[i] !='0'){
                ll numi=num[i]-'0';
                numi--;
                num[i]=(char)(numi+'0');
                break;
            }
            i--;
        }

        cout<<stoi(num)<<"\n";

    }
}
