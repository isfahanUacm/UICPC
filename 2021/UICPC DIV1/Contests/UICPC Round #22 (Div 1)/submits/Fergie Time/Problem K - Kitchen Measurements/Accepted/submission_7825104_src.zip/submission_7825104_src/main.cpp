#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;
int goal;
map <string,bool> visited;
map <string,ll> dist;

vector<string> split(const string& str, char delim)
{
    vector<string> cont;
    stringstream ss(str);
    string token;
    while(getline(ss, token, delim))
        cont.push_back(token);
    return cont;
}

string tostring(vector<ll> num)
{
    string s="";
    for (int i=0;i<num.size();i++)
    {
        s += to_string(num[i]);
        s += ",";
    }
    return s;
}

ll dij(vector<ll> capacity,vector<ll> state){


    multiset <pair<ll,vector<ll>>> pr;
    pr.insert({0,state});
    ll ans = LLONG_MAX;
    ll v=0;
    string s = tostring(state);
    dist[s] = 0;
    while(pr.size())
    {

        ll currerntdis = pr.begin()->first;
        vector<ll> st = pr.begin()->second;
        pr.erase(pr.begin());
        s = tostring(st);
       //  watch(s);
        visited[s] = true;
        if (st[0] == goal)
            return currerntdis;

        for (int i=0;i<capacity.size();i++)
        {
            for(int j=0;j<capacity.size();j++)
            {
                if(i==j)
                    continue;
                vector<ll> newstate = st;
                v = 0;
                if (capacity[j]-st[j] > 0)
                {
                    if(capacity[j]-st[j] <= st[i])
                    {
                        newstate[j] = capacity[j];
                        newstate[i] -= capacity[j]-st[j];
                        v = capacity[j]-st[j];
                    }
                    else
                    {
                       newstate[i] =0;
                       newstate[j] += st[i];
                       v = st[i];
                    }
                }
                string news = tostring(newstate);
                if(v && visited.find(news) == visited.end())
                    if (dist.find(news) == dist.end() || dist[news] > currerntdis+v)
                    {
                        dist[news] = currerntdis+v;
                        pr.insert({currerntdis+v,newstate});

                    }

            }
        }

    }

    return -1;


}


int main()
{


    ll n;
    ll ans;
    cin >>n;
    vector<ll> state(n);
    vector<ll> capacity(n);
    for (int i=0;i<n;i++)
    {
        cin >> capacity[i];
        state[i] = 0;
    }
    state[0] = capacity[0];
    cin >> goal;
    //    for(int i=0;i<sizecup.size();i++)
    //    {
    //      cout << state[i] << " " << capacity[i] <<endl;
    //    }
    ans = dij(capacity, state);
    if (ans == -1)
        cout <<"impossible";
    else
    {
       cout << ans;
    }
}
