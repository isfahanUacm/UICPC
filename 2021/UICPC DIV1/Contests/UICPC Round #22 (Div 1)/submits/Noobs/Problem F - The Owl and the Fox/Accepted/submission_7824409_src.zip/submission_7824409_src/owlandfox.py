
num = []
n = int(input())


for i in range(n):
    num.append(int(input()))


for i in range(n):
    if(num[i]%10 != 0):
        num[i] = num[i] - 1;print(num[i])
    elif(num[i]%100 != 0):
        num[i] = num[i] - 10;print(num[i])
    elif (num[i] % 1000 != 0):
        num[i] = num[i] - 100;print(num[i])
    elif (num[i] % 10000 != 0):
        num[i] = num[i] - 1000;print(num[i])
    elif (num[i] % 100000 != 0):
        num[i] = num[i] - 10000;print(num[i])
    elif (num[i] % 1000000 != 0):
        num[i] = num[i] - 100000;print(num[i])
    elif (num[i] % 10000000 != 0):
        num[i] = num[i] - 1000000;print(num[i])

# print(num[i])