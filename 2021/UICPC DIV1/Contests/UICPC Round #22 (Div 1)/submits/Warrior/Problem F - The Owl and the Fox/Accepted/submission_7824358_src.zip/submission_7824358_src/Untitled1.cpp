#include <iostream>
#include<math.h>
using namespace std;
int result(int n)
{
	
	int m = 0;
	while (n%10==0)
	{
		n = n / 10;
		++m;
	}
	return (n - 1) * pow(10, m);
}
int main()
{
	int n;
	cin >> n;
	int* a = new int[n];
	for (int i = 0; i < n; ++i)
	{
		cin >> a[i];
	}
	for (int i = 0; i < n; ++i)
	{
		cout << result(a[i]) << endl;
	}
	return 0;
}
