#include <bits/stdc++.h>

using namespace std;

int findMeters(int a[2], int b[2])
{
  return abs(a[1] - b[1]) + abs(a[0] - b[0]);
}

int main()
{

  int numberOfTests;
  cin >> numberOfTests;

  for (int index = 0; index < numberOfTests; index++)
  {

    int numberOfStores;
    cin >> numberOfStores;

    int stops[numberOfStores + 2][2];

    for (int i = 0; i < numberOfStores + 2; i++)
    {
      cin >> stops[i][0] >> stops[i][1];
    }

    for (int i = 1; i < numberOfStores + 1; i++) {
      int min = findMeters(stops[0], stops[i]);
      int minIndex = i;

      for (int j = i + 1; j < numberOfStores + 1; j++) {
        if (findMeters(stops[0], stops[j]) < min) {
          minIndex = j;
          min = findMeters(stops[0], stops[j]);
        }
      }

      int temp = stops[i][0];
      stops[i][0] = stops[minIndex][0];
      stops[minIndex][0] = temp;
      
      temp = stops[i][1];
      stops[i][1] = stops[minIndex][1];
      stops[minIndex][1] = temp;
    }

    for (int i = 0; i < numberOfStores + 1; i++)
    {
      if (findMeters(stops[i], stops[i + 1]) > 20 * 50)
      {
        cout << "sad" << endl;
        break;
      }

      if (i == numberOfStores) {
        cout << "happy" << endl;
      }
    }

  }

  return 0;
}