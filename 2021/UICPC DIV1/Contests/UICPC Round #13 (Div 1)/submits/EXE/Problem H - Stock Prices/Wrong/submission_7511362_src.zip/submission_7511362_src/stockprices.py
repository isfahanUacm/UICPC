loop = int(input())

for i in range(loop):
    stuck_market = {'ask': [], 'bid': [], 'stock': []}
    stuck_sell_number = {}
    stuck_buy_number = {}
    num = int(input())
    for j in range(num):
        trans = input()
        aa = trans.split(' ')
        if 'buy' in trans:
            # number_price = []
            # number_price.append(int(aa[1]))
            # number_price.append(int(aa[4]))
            # stuck_market['bid'].append(number_price)
            stuck_market['bid'].append(int(aa[4]))
            stuck_buy_number[int(aa[4])] = int(aa[1])

        elif 'sell' in trans:
            # number_price = []
            # number_price.append(int(aa[1]))
            # number_price.append(int(aa[4]))
            # stuck_market['ask'].append(number_price)
            stuck_market['ask'].append(int(aa[4]))
            stuck_sell_number[int(aa[4])] = int(aa[1])

        # print(stuck_market)

        if len(stuck_market['ask']) and len(stuck_market['bid']):
            min_ask = min(stuck_market['ask'])
            max_bid = max(stuck_market['bid'])

            if max_bid >= min_ask:
                stuck_market['stock'].append(min_ask)

                if stuck_sell_number[min_ask] > stuck_buy_number[max_bid]:
                    stuck_sell_number[min_ask] -= stuck_buy_number[max_bid]
                    stuck_market['bid'].pop(stuck_market['bid'].index(max_bid))

                elif stuck_sell_number[min_ask] == stuck_buy_number[max_bid]:
                    stuck_market['bid'].pop(stuck_market['bid'].index(max_bid))
                    stuck_market['ask'].pop(stuck_market['ask'].index(min_ask))

                else:
                    stuck_buy_number[max_bid] -= stuck_sell_number[min_ask]
                    stuck_market['ask'].pop(stuck_market['ask'].index(min_ask))

        # print(stuck_market)
        # print(stuck_sell_number)
        # print(stuck_buy_number)

        if len(stuck_market['ask'])==0:
            print('-', end=' ')
        else:
            print(min(stuck_market['ask']), end=' ')

        if len(stuck_market['bid']) == 0:
            print('-', end=' ')
        else:
            print(max(stuck_market['bid']), end=' ')
        if len(stuck_market['stock']) == 0:
            print('-', end=' ')
        else:
            print(stuck_market['stock'][0], end=' ')
            stuck_market['stock'].pop(0)
        print()




    stuck_market.clear()


# ss = 'buy 10 shares at 100'
# words = ss.split(' ')
# print(words)