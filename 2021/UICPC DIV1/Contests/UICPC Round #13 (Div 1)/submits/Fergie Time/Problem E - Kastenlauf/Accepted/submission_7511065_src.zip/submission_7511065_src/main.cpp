#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        ll n;
        cin >> n;
        n += 2;
        pll sample;
        vector<pair<ll, ll>> points(n, sample);
        for(ll i = 0; i < n; i++)
        {
            cin >> points[i].first >> points[i].second;
        }
        vector<bool> visited(n, false);
        queue<ll> q;
        q.push(0);
        while(q.size())
        {
            ll current = q.front();
            q.pop();
            visited[current] = true;
            for(ll i = 0; i < n; i++)
            {
                if(i != current)
                {
                    if(!visited[i])
                    {
                        if(abs(points[i].first - points[current].first) + abs(points[i].second - points[current].second) <= 1000)
                        {
                            q.push(i);
                        }
                    }
                }
            }
        }
        if(visited[n - 1])
        {
            cout << "happy" << endl;
        }
        else
        {
            cout << "sad" << endl;
        }
    }
    return 0;
}