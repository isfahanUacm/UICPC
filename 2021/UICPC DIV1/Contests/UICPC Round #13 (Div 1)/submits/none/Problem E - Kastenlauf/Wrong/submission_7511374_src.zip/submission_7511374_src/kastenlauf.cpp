#include<iostream>
#include <list>
using namespace std;

class Graph
{
    int V;
    list<int> *adj;
    list<pair<int ,int>> *verl;
public:
    Graph(int V);
    void addEdge(int v, int w);
    void addver(int i ,int x, int y);
    bool isReachable(int s, int d);
};

Graph::Graph(int V)
{
    this->V = V;
    adj = new list<int>[V];
    verl = new list<pair<int , int>>[V];
}

void Graph::addEdge(int v, int w)
{
    adj[v].push_back(w);

}
void Graph::addver(int i,int x, int y)
{
    pair<int , int> p;
    p.first=x;
    p.second=y;
    verl[i].push_back(p);

}
bool Graph::isReachable(int s, int d)
{

    if (s == d)
        return true;

    bool *visited = new bool[V];
    for (int i = 0; i < V; i++)
        visited[i] = false;

    list<int> queue;

    visited[s] = true;
    queue.push_back(s);

    list<int>::iterator i;

    while (!queue.empty())
    {

        s = queue.front();
        queue.pop_front();


        for (i = adj[s].begin(); i != adj[s].end(); ++i)
        {
            pair<int , int > p1=verl[s].back();
            pair<int , int > p2=verl[*i].back();
            if (*i == d && ((p2.first - p1.first)+(p2.second-p1.second)) <= 1000)
                return true;

            if (!visited[*i] )
            {
                if(((p2.first - p1.first)+(p2.second-p1.second)) <= 1000) {
                    visited[*i] = true;
                    queue.push_back(*i);
                }
            }
        }
    }
    return false;
}
int main()
{
    int t , n ,x,y;
    cin>>t;
    while (t--) {
        cin>>n;
        n+=2;
        Graph g(n);
        for (int i = 0; i < n; ++i) {
            cin>>x>>y;
            g.addver(i,x,y);
            for (int j = 0; j < n; ++j) {
                g.addEdge(i, j);
                g.addEdge(j,i);
            }

        }

        int u = 0, v = n-1;
        if (g.isReachable(u, v))
            cout <<"happy"<<endl;
        else
            cout << "sad"<< endl;
    }
    return 0;
}
