#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mx = 110;
vector<pair<ll, ll>> polls;
bool visited[mx];
ll n;

bool canGo(ll i, ll j) {
    if ((polls[i].first - polls[j].first) * (polls[i].first - polls[j].first)
            + (polls[i].second - polls[j].second) * (polls[i].second - polls[j].second) <= 1000000) {
        return true;
    }
    return false;
}

void dfs(ll a) {
    visited[a] = true;
    for (ll i = 0; i < n; ++i) {
        if (!visited[i] && canGo(a, i))
            dfs(i);
    }
}

int main() {
    ll tc;
    cin >> tc;
    while (tc--) {
        cin >> n;
        n = n + 2;
        polls.clear();
        memset(visited, 0, sizeof(visited));
        for (ll i = 0; i < n; ++i) {
            ll x, y;
            cin >> x >> y;
            polls.emplace_back(x, y);
        }
        dfs(0);

        if (visited[n - 1]) {
            cout << "happy" << endl;
        }else {
            cout << "sad" << endl;
        }
    }
}
