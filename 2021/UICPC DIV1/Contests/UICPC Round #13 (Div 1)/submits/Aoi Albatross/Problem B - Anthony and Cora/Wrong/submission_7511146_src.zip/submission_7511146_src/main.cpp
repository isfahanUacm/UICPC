#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int n, m;
    cin >> n >> m;
    int c = n + m;
    double dp[m * 2];
    memset(dp, 0, sizeof(dp));
    dp[0] = 1;

    for (int i = 0; i < c - 1; ++i) {
        double temp;
        cin >> temp;
        for (int j = m; j >= 1; --j) {
            dp[j] = dp[j - 1] * temp + dp[j] * (1.0 - temp);
        }
        dp[0] *= (1 - temp);
    }


    printf("%.7f", dp[m]);
}
