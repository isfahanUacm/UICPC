#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    int n, m;
    cin >> n >> m;
    int c = n + m;
    double dp[n * 2];
    memset(dp, 0, sizeof(dp));

    for (int i = 0; i < c - 1; ++i) {
        double temp;
        cin >> temp;
        for (int j = 2; j <= m; ++j) {
            dp[j] += min(dp[j - 1] * temp, 1.0);
        }
        dp[1] += min(temp, 1.0);
    }
    printf("%.7f", dp[m]);
}
