import java.util.Scanner;

public class Treasure_Hunt {
    static int[][] num_move;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int row = input.nextInt(), column = input.nextInt(), r = 0, c = 0, count = 0;
        String[][] area_play = new String[row][column];
        num_move = new  int[row][column];
        for (int i = 0; i < row; i++)
            area_play[i] = input.next().split("");

        while (true) {
            if (-1 < r && r < row && -1 < c && c < column) {
                if (0 < num_move[r][c]) {
                    System.out.println("Lost");
                    break;
                }
                num_move[r][c] += 1;
                if (area_play[r][c].equals("N")) r -= 1;
                else if (area_play[r][c].equals("S")) r += 1;
                else if (area_play[r][c].equals("W")) c -= 1;
                else if (area_play[r][c].equals("E")) c += 1;
                else if (area_play[r][c].equals("T")) {
                    System.out.println(count);
                    break;
                }
                count++;
            } else {
                System.out.println("Out");
                break;
            }
        }
    }
}
