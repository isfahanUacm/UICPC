import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int testCase = s.nextInt();
        for (int j = 0; j < testCase; j++) {
            int stores = s.nextInt();

            int x1=s.nextInt();
            int y1=s.nextInt();

            int x2=s.nextInt();
            int y2=s.nextInt();
            int bottles =20;
            int temp=0;
            for (int i = 0; i < stores+1; i++) {
                int distance = Math.abs(x1-y1) + Math.abs(x2-y2);
                bottles -= distance / 50;
                x1 = x2;
                y1 = y2;
                if(i != stores) {
                    x2 = s.nextInt();
                    y2 = s.nextInt();

                }
                if (distance >= 1050){
                    temp=1;
                    bottles = 20;
                }
                else bottles = 20;
            }
            if (temp == 1){
                System.out.println("sad");
            }
            else System.out.println("happy");
        }
    }
}

