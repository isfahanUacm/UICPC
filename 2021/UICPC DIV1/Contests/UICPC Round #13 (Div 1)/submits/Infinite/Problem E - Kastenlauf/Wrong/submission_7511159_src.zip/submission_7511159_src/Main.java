import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int t = input.nextInt(), i;
		while (0 < t) {
			int n = input.nextInt();
			int[][] distance = new int[n + 2][2];
			for (i = 0; i < n + 2; i++) {
				distance[i][0] = input.nextInt();
				distance[i][1] = input.nextInt();
			}
			int xm = distance[n + 1][0], ym = distance[n + 1][1], tmp = 0;
			//System.out.println(n + 1 + " " + xm + " " + ym);
			Arrays.sort(distance, (o1, o2) -> Math.abs(o1[1] - o2[1]) + Math.abs(o1[0] - o2[0]));
			for (i = 1; i < n + 2; i++) {
				if (20 < (Math.abs(distance[i][0] - distance[i - 1][0]) + Math.abs(distance[i][1] - distance[i - 1][1])) / 50) {
					System.out.println("sad");
					break;
				}
				else{
					if (distance[i][0] == xm && distance[i][1] == ym) {
						tmp = 1;
						break;
					}
				}
			}
			if (i == n + 2 || tmp == 1) System.out.println("happy");
			t--;
		}
	}
}