#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

int main(){
    string s1,s2;
    cin >> s1 >> s2;

    int count = 0;
    int minimum = min(s1.length(), s2.length());

    for (int i = 0; i < minimum; i++) {
        if (s1[i] == s2[i]) {
            s2[i]='.';
            s1[i]='-';
            continue;
        }
        break;
    }

    for (int i = 0; i < minimum; i++) {
        if ( s1[s1.length() - i-1] == s2[s2.length() - i-1] ) {
            s2[s2.length() - i-1]='.';
            s1[s1.length() - i-1]='-';
            continue;
        }
        break;
    }

    for(int i=0;i<minimum;i++){
        if(s2[i]!='.')
            count++;
    }

//    cout << s2.length() - count << endl;
    cout <<count<<endl;
}
