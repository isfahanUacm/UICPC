a = list(input())
b = list(input())

i = 0
while(len(a)>0 and len(b)>0  and a[0]==b[0]):
    a.pop(0)
    b.pop(0)

while(len(a)>0 and len(b)>0  and a[len(a)-1]==b[len(b)-1]):
    a.pop()
    b.pop()

print(len(b))

