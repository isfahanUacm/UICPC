#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
typedef unsigned long long int ulli;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);

int main()
{
    int t, d;
    cin >> t;
    int dp[205];
    dp[0] = 0;
    for (int i = 1; i <= 20; i++) {
        dp[i] = i;
    }
    d = 20;
    for (int i = 0; i <= 9; i++) {
        if (i == 1 || i==4 || i==7) {
            dp[20 + i] = 20 + (i + 1);
        }
        else {
            dp[20 + i] = 20 + i;
        }
    }
    d = 30;
    for (int i = 0; i <= 9; i++) {
        if (i == 0)
        {
            dp[30] = 29;
        }
        else if(i == 1 || i == 4 ) {
            dp[30 + i] = 33;
        }
        else if (i == 7) {
            dp[30 + i] = 36;
        }
        else if (i == 2 || i == 5 || i == 8) {
            dp[30 + i] = 30 + i + 1;
        }
        else {
            dp[30 + i] = 30 + i;
        }
    }
    d = 40;
    for (int i = 0; i <= 9; i++) {
        if (i == 1 || i == 2) {
            dp[40 + i] = 40;
        }
        else if (i == 3) {
            dp[40 + i] = 44;
        }
        else {
            dp[40 + i] = 40 + i;
        }
    }
    d = 50;
    for (int i = 0; i <= 9; i++) {
        if (i == 1 || i == 2) {
            dp[50 + i] = 50;
        }
        else if (i == 3 || i == 4) {
            dp[50 + i] = 50 + 5;
        }
        else if (i == 7) {
            dp[50 + i] = 58;
        }
        else dp[50 + i] = 50 + i;
    }
    d = 60;
    for (int i = 0; i <= 9; i++) {
        if (i <= 2) {
            dp[60 + i] = 59;
        }
        else if (i>=3 && i <= 7) {
            dp[60 + i] = 66;
        }
        else if (i == 8) {
            dp[60 + i] = 69;
        }
        else dp[60 + i] = 60 + i;
    }
    d = 70;
    for (int i = 0; i <= 9; i++) {
        if (i == 1 || i == 2 || i == 3) {
            dp[70 + i] = 70;
        }
        else if (i == 4 || i == 5 || i == 6) {
            dp[70 + i] = 77;
        }
        else dp[70 + i] = 70 + i;
    }
    d = 80;
    for (int i = 0; i <= 9; i++) {
        if (i == 1 || i == 2 || i == 3) {
            dp[80 + i] = 80;
        }
        else if (i == 4 || i == 5 || i == 6 || i == 7) {
            dp[80 + i] = 88;
        }
        else dp[80 + i] = 80 + i;
    }
    d = 90;
    for (int i = 0; i <= 9; i++) {
        if (i <= 4) {
            dp[90 + i] = 89;
        }
        else {
            dp[90 + i] = 99;
        }
    }
    for (int i = 0; i <= 9; i++) {
        if (i <= 5) {
            dp[100 + i] = 100;
        }
        else {
            dp[100 + i] = 110;
        }
    }
    for (int i = 10; i <= 99; i++) {
        dp[100 + i] = 100+dp[i];
    }
    dp[200] = 200;
    while (t--) {
        int e;
        cin >> e;
        cout << dp[e]<<endl;
    }
}