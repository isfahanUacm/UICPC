before = input()
after = input()
lb = len(before)
la = len(after)
smaller = after if lb > la else before
grater = before if lb > la else after

end = -1
start = -1

dif = abs(lb - la)

for i in range(min(lb, la)):
    if before[i] != after[i]:
        start = i
        break
if start == -1:
    m = min(la, lb) - 1
    for i in range(m, m + dif + 1):
        if smaller[m] != grater[i]:
            start = i
            break

for i in range(min(lb, la)):
    if before[lb - i - 1] != after[la - i - 1]:
        end = la - i - 1
        break
if end == -1:
    for i in range(dif):
        if smaller[0] != grater[i]:
            end = i
            break
# print(end)
if start == -1 and end == -1:
    print(0)
elif start > end:
    if lb < la:
        print(dif)
    else:
        print(0)
else:
    print(end-start+1)