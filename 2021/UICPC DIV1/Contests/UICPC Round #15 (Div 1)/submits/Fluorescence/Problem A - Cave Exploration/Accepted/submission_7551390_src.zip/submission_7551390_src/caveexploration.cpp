#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
typedef unsigned long long int ulli;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
int n, m;
vector<vector<int>> adj;
vector<pair<int, int>> bridge;
bool vi[10000 + 5];
int Time[10000 + 5];
int Low[10000 + 5];
int par[10000 + 5];
int Count = 0;

void find_bridge(int x){
	vi[x] = true;
	Count++;
	Time[x] = Low[x] = Count;

	for (auto it = adj[x].begin(); it != adj[x].end(); it++) {
		int cur = *it;
		if (cur == -1) {
			continue;
		}
		if (!vi[cur]) {
			par[cur] = x;
			find_bridge(cur);
			Low[x] = min(Low[x], Low[cur]);
			if (Low[cur] > Time[x]) {
				bridge.push_back({ x, cur });
				for (auto xx = adj[x].begin(); xx != adj[x].end(); xx++) {
					if (*xx == cur) {
						*xx = -1;
						break;
					}
				}
				for (auto xx = adj[cur].begin(); xx != adj[cur].end(); xx++) {
					if (*xx == x) {
						*xx = -1;
						break;
					}
				}
			}
		}
		else if (cur != par[x]) {
			Low[x] = min(Low[x], Time[cur]);
		}
	}
}
int sum = 0;
void dfs( int x) {
	vi[x] =1;
	for (auto it = adj[x].begin(); it != adj[x].end(); it++) {
		int cur = *it;
		if (cur == -1)
			continue;
		else if(!vi[cur]) {
			sum++;
			dfs(cur);
		}
	}

}
int main() {
	cin >> n >> m;
	int x, y;
	vector<int> tv = { -1 };
	for (int i = 0; i < n; i++) {
		adj.push_back(tv);
	}
	for (int i = 0; i < m; i++) {
		cin >> x >> y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	fill_n(vi, 10000 + 5, 0);
	fill_n(par, 10000 + 5, -1);

	for (int i = 0; i < n; i++) {
		if (!vi[i]) {
			find_bridge(i);
		}
	}
	
	fill_n(vi, 10000 + 5, 0);
	dfs(0);
	cout << sum+1;
	
}