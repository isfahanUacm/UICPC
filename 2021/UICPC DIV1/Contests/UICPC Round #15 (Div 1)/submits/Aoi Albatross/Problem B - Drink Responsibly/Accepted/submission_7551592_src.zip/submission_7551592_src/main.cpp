#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
bool dp[2010][2010];
int sp[2010][2010];

map<int, string> id;
int arr[10];
int price[10];
int n;

int main() {
    double tm, a;
    int money;
    int alc;
    cin >> tm >> a >> n;
    money = tm * 100;
    alc = a * 60;

    for (int i = 0; i < n; ++i) {
        string t;
        int c;
        string p;
        double mm;
        cin >> t >> c >> p >> mm;
        id[i] = t;
        if (p == "1/1") {
            arr[i] = c * 60;
        }
        else if (p == "1/2") {
            arr[i] = c * 30;
        }
        else {
            arr[i] = c * 20;
        }
        price[i] = mm * 100;
    }

    memset(dp, 0, sizeof(dp));
    memset(sp, 0, sizeof(sp));
    dp[0][0] = true;


    for (int j = 0; j < 1500; ++j) {
        for (int i = 0; i < 1500; ++i) {
            for (int k = 0; k < n; ++k) {
                if ((price[k] <= i) && (arr[k] <= j) && (dp[i - price[k]][j - arr[k]])) {
//                    cout << i << ' ' << j << ' ' << ' ' << i - price[k] << ' ' << j - arr[k] << ' ' << dp[i - price[k]][j - arr[k]] << endl;
                    dp[i][j] = true;
                    sp[i][j] = k;
//                    break;
                }
            }
        }
    }
    if (dp[money][alc]) {
        map<int, int> mp;
        while (money > 0 && alc > 0) {
            int mh = money;
            int ah = alc;
//            cout << money << ' ' << alc << ' ' << sp[money][alc] << endl;
//            cout << price[sp[money][alc]] << ' ' << arr[sp[money][alc]] << endl;
//            cout << dp[money][alc] << endl;
            mp[sp[money][alc]]++;
            money -= price[sp[mh][ah]];
            alc -= arr[sp[mh][ah]];
//            cout << money << ' ' << alc << ' ' << sp[money][alc] << endl;
        }
        for (auto x : mp) {
            cout << id[x.first] << ' ' << x.second << endl;
        }
    }
    else {
        cout << "IMPOSSIBLE" << endl;
    }
}

