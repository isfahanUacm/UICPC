#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

struct p {
    ll u;
    ll r;
    ll t;
};

int main() {
    ll arr[20];
    for (long long & i : arr) {
        cin >> i;
    }

    p ps[20];
    for (ll i = 0; i < 10; ++i) {
        p temp{};
        cin >> temp.u >> temp.r >> temp.t;
        ps[i] = temp;
    }

    ll time = 0;
    for (ll w = 0; w < 30; ++w) {
        ll i = w % 10;

        if (time < ps[i].t) {
            time += arr[i * 2];
            ps[i].t = max(ps[i].t, time);
            time += arr[i * 2 + 1];
        }
        else {
            ll z = max(0ll, (time - ps[i].t) / (ps[i].u + ps[i].r));
            ps[i].t += z * (ps[i].u + ps[i].r);
            ps[i].t += ps[i].u;
            time = max(ps[i].t, time) + arr[i * 2];
            ps[i].t = max(ps[i].t + ps[i].r, time);
            time += arr[i * 2 + 1];
        }
    }
    cout << time - arr[19] << endl;
}

