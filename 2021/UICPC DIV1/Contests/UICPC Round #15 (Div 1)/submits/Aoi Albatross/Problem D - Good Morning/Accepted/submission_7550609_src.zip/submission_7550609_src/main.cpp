#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

map<int, pair<int, int>> pos;

bool possible(int a) {
    string t = to_string(a);
    pair<int, int> temp = {0, 0};
    for (auto ch : t) {
        if (temp.first > pos[ch - '0'].first || temp.second > pos[ch - '0'].second)
            return false;
        temp = pos[ch - '0'];
    }
    return true;
}
int main() {
    pos[1] = {0, 0};
    pos[2] = {0, 1};
    pos[3] = {0, 2};
    pos[4] = {1, 0};
    pos[5] = {1, 1};
    pos[6] = {1, 2};
    pos[7] = {2, 0};
    pos[8] = {2, 1};
    pos[9] = {2, 2};
    pos[0] = {3, 1};
    bool p[210];
    for (int i = 0; i <= 205; ++i) {
        p[i] = possible(i);
    }
    int tc;
    cin >> tc;
    while (tc--) {
        int n;
        cin >> n;
        int mx = 0;
        for (int i = 1; i < 210; ++i) {
            if (p[i] && abs(mx - n) > abs(i - n)) {
                mx = i;
            }
        }
        cout << mx << endl;
    }
}
