#include <bits/stdc++.h>
using namespace std ;

int main (){
    string s1,s2 ;
    cin >> s1 >> s2 ;

    int i = 0 ;
    while (s2[i] == s1[i] && i<s2.size() && i<s1.size())
        i++ ;
    int j = s1.size()-1 , k = s2.size()-1 , con = 0;
    while (j >= i && k >= i && s1[j] == s2[k]){
        con++ ;
        j-- ;
        k-- ;
    }
    int tmp1 = s1.size()-(con + i) ;
    int tmp2 = s2.size()-(con + i) ;
    cout << tmp2 << endl;

    return 0;
}