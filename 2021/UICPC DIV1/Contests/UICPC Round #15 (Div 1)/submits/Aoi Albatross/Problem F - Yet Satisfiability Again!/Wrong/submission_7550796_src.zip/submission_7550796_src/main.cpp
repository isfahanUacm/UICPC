#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {

    int tc;
    cin >> tc;
    while (tc--) {
        int n, m;
        cin >> n >> m;
        int arr[m + 10][n + 10];
        memset(arr, -1, sizeof(arr));
        getchar();

        for (int i = 0; i < m; ++i) {
            string a;
            getline(cin, a);
            stringstream ss(a);
            string t;
            while (ss >> t) {
                if (t != "v") {
                    int num = stoi(t.substr(t.find('X') + 1)) - 1;
                    if (arr[i][num] == -1) {
                        arr[i][num] = 0;
                    }
                    if (t[0] != '~') {
                        arr[i][num] = 1;
                    }
                }
            }
        }
        bool printed = false;
        for (int i = 0; i < (1 << n); ++i) {
            bool flag = true;
            for (int j = 0; j < m; ++j) {
                bool ans = false;
                for (int k = 0; k < n; ++k) {
                    if (arr[j][k] != -1) {
                        if ((arr[j][k] == 1 && (i & (1 << k))) || (arr[j][k] == 0 && !(i & (1 << k)))) {
                            ans = true;
                        }
                    }
                }
                if (!ans) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                cout << "satisfiable" << endl;
                printed = true;
                break;
            }
        }
        if (!printed) {
            cout << "unsatisfiable" << endl;
        }
    }
}

