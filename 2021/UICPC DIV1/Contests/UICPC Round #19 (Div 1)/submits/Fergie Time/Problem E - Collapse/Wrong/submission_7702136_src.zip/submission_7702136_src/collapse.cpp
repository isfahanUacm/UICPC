#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

using namespace std;
ll n;
vector<vector<pll>> graph;
vector <ll> minNeed;
vector <ll> receive;
vector<bool> visited;
vector<ll> ans;
ll src;

void topological_sort(ll index)
{
    visited[index] = true;
    if(receive[index] < minNeed[index] || minNeed[index] == 0)
    {
        for (pll item: graph[index])
        {
            ll i = item.first;
            ll w = item.second;
            if (!visited[i])
            {
                receive[i] -= w;
                if(receive[i] < minNeed[i])
                {
                    topological_sort(i);
                }
            }
        }
        ans.push_back(index);
    }
}



int main()
{
    cin >> n;
    visited = vector<bool>(n, false);
    minNeed   = vector<ll>(n);
    receive = vector<ll>(n);
    graph = vector<vector<pll>> (n);

    for (ll i = 0; i < n; i++)
    {
        cin >> minNeed[i];
        ll k;
        cin >> k;
        ll rec = 0;
        if(minNeed[i] == 0 && k == 0)
        {
            src = i;
        }
        for (ll j = 0; j < k; j++)
        {
            ll a, b;
            cin >> a >> b;
            a--;
            receive[i] += b;
            graph[a].push_back({i, b});
        }
    }
    topological_sort(src);
    cout << n - (ll)ans.size();
}
