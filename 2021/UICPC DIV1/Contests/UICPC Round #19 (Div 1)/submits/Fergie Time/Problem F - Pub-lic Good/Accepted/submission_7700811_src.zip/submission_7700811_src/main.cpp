#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000000;
using namespace std;

ll n, m;
vector<vector<ll>> graph;
vector<bool> visited;
vector<bool> color;

void bfs(ll index)
{

    queue<pll> q;
    q.push({0, index});
    while(q.size())
    {
        ll current     = q.front().second;
        ll currentDist = q.front().first;
        q.pop();
        for(ll i: graph[current])
        {
            if(!visited[i])
            {
                visited[i] = true;
                q.push({(currentDist + 1) % 2, i});
            }
        }
        if(currentDist % 2 == 0)
        {
            color[current] = false;
        }
        else
        {
            color[current] = true;
        }
    }
}

int main()
{
    cin >> n >> m;
    vector<ll> sample;
    graph = vector<vector<ll>>(n, sample);
    color = vector<bool>(n, false);
    visited = vector<bool>(n, false);

    for(ll i = 0; i < m; i++)
    {
        ll a, b;
        cin >> a >> b;
        a--;
        b--;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
    bool impossible = false;
    for(ll i = 0; i < n; i++)
    {
        if(graph[i].size() == 0)
        {
            impossible = true;
        }
        if(!visited[i])
        {
            visited[i] = true;
            bfs(i);
        }
    }
    if(impossible)
    {
        cout << "Impossible";
    }
    else
    {
        for(ll i = 0; i < n; i++)
        {
            cout << (color[i]? "pub" : "house") << " ";
        }
    }
    return 0;
}