#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;



int main()
{
    string s,sub1,sub2;
    cin >> s;
    vector<ll> m;
    ll t=0, a;

    ll counter1 , counter2, ans;
    bool flag = true;
    for(ll i=1;i<=s.size();i++){
        if(s.size()%i == 0)
        {
            string sub = s.substr(0,i);
            t = 0;
            flag = true;
            for( ll j=i; j<s.size() ; j+=i )
            {

                    sub = sub[i-1] + sub.substr(0,i-1);

                    if (sub.compare(s.substr(j,i)) != 0)
                    {
                        flag = false;
                        break;
                    }

                    sub = s.substr(j,i);



            }

            if (flag == true)
            {
                cout << i;
                break;
            }

        }


    }

    if (flag == false)
        cout << s.size();


}
