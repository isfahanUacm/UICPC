#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 21;
using namespace std;

ll n;
vector<string> forest;
bool visited[maxN][maxN][6];

pll src;
pll goal;



// (←)   :  0    initial
// (→)   :  1
// (↑)   :  2
// (↓)   :  3
// (.)   :  4
// (*)   :  5    goal

map<ll, ll> goLeft {
        {0, 5},
        {1, 4},
        {2, 2},
        {3, 3},
        {4, 0},
        {5, 1}
};

map<ll, ll> goRight {
        {5, 0},
        {4, 1},
        {2, 2},
        {3, 3},
        {0, 4},
        {1, 5}
};
map<ll, ll> goUp {
        {0, 0},
        {1, 1},
        {2, 5},
        {3, 4},
        {4, 2},
        {5, 3}
};
map<ll, ll> goDown {
        {0, 0},
        {1, 1},
        {2, 4},
        {3, 5},
        {4, 3},
        {5, 2}
};



bool dfs(ll x, ll y, ll side)
{
//    watch(x);
//    watch(y);
//    watch(side);
//    cout << "....................." << endl;
    visited[x][y][side] = true;
    if(x == goal.first && y == goal.second && side == 5)
    {
        return true;
    }

    bool ans = false;
    // up
    if(x - 1 >= 0)
    {
        if(!visited[x - 1][y][goUp[side]] && forest[x - 1][y] == '.')
        {
            ans = ans || dfs(x - 1, y, goUp[side]);
            if(ans)
            {
                return ans;
            }
        }
    }
    // left
    if(y - 1 >= 0)
    {
        if(!visited[x][y - 1][goLeft[side]] && forest[x][y - 1] == '.')
        {
            ans = ans || dfs(x, y - 1, goLeft[side]);
            if(ans)
            {
                return ans;
            }
        }
    }
    // down
    if(x + 1 < n)
    {
        if(!visited[x + 1][y][goDown[side]] && forest[x + 1][y] == '.')
        {
            ans = ans || dfs(x + 1, y, goDown[side]);
            if(ans)
            {
                return ans;
            }
        }
    }
    // right
    if(y + 1 < n)
    {
        if(!visited[x][y + 1][goRight[side]] && forest[x][y + 1] == '.')
        {
            ans = ans || dfs(x, y + 1, goRight[side]);
            if(ans)
            {
                return ans;
            }
        }
    }
    return ans;
}

int main()
{
    ll t;
    cin >> t;
    while(t--)
    {
        cin >> n;
        forest = vector<string>(n);
        fill(&visited[0][0][0], &visited[0][0][0] + maxN * maxN * 6, false);
        for(ll i = 0; i < n; i++)
        {
            cin >> forest[i];
        }
        for(ll i = 0; i < n; i++)
        {
            for(ll j = 0; j < n; j++)
            {
                if(forest[i][j] == 'H')
                {
                    goal = {i, j};
                    forest[i][j] = '.';
                }
                if(forest[i][j] == 'S')
                {
                    src = {i, j};
                    forest[i][j] = '.';
                }
            }
        }
        bool ans = dfs(src.first, src.second, 0);
        if(ans)
        {
            cout << "Yes" << endl;
        }
        else
        {
            cout << "No" << endl;
        }
    }

    return 0;
}