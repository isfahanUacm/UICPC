#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
int main()
{
   ll m , n , k;
   cin>> n>>m>>k;
   vector<ld> arrn(n);
   vector<ld> arrm(m);
   vector<ld> arrk(k);
   for(ll i = 0; i < n; i++){
       cin>>arrn[i];
   }
   for(ll i = 0; i < m; i++){
       cin>>arrm[i];
   }
   for(ll i = 0; i < k; i++){
       cin>>arrk[i];
   }
   sort(arrn.begin(),arrn.end());
   sort(arrm.begin(),arrm.end());
   sort(arrk.begin(),arrk.end());
   ll max =0 , j = 0,w=0;
   for(ll i = 0; i < n; i++){
       if(arrn[i] > arrm[j]){
           max ++;
           j++;
           continue;
       }
       ld c = (arrk[w]*arrk[w])+(arrk[w]*arrk[w]);
//       ll c = (arrn[i]*arrn[i])+(arrn[i]*arrn[i]);
       if(sqrt(c)/2 < arrn[i])
       {
           w++;
           max++;

       }
   }
   cout<< max<<endl;
}
