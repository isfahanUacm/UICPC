#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000000;
using namespace std;

vector<string> sky;
vector<vector<bool>> visited;
vector<vector<pll>> components;
vector<pll> clist;

ll n, m;

void dfs(ll x, ll y)
{
    visited[x][y] = true;
    clist.push_back({x, y});
    if(x - 1 >= 0)
    {
        if(!visited[x - 1][y] && sky[x - 1][y] == '-')
        {
            dfs(x - 1, y);
        }
    }
    if(y - 1 >= 0)
    {
        if(!visited[x][y - 1] && sky[x][y - 1] == '-')
        {
            dfs(x, y - 1);
        }
    }
    if(x + 1 < n)
    {
        if(!visited[x + 1][y] && sky[x + 1][y] == '-')
        {
            dfs(x + 1, y);
        }
    }
    if(y + 1 < m)
    {
        if(!visited[x][y + 1] && sky[x][y + 1] == '-')
        {
            dfs(x, y + 1);
        }
    }
}
int main()
{
    ll caseIndex = 1;
    while(cin >> n >> m)
    {
        vector<bool> sample(m, false);
        visited = vector<vector<bool>>(n, sample);
        sky = vector<string>(n);
        for(ll i = 0; i < n; i++)
        {
            cin >> sky[i];
        }

        components = vector<vector<pll>>();
        for(ll i = 0; i < n; i++)
        {
            for(ll j = 0; j < m; j++)
            {
                if(!visited[i][j] && sky[i][j] == '-')
                {
                    clist = vector<pll>();
                    dfs(i, j);
                    components.push_back(clist);
                }
            }
        }
        cout << "Case " << caseIndex++ << ": " << components.size() << endl;
    }
    return 0;
}