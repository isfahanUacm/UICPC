#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000000;
using namespace std;

ll n, k;
vector<ll> w;

bool check(ll maxW)
{
    vector<ll> bucket(k, 0);
    ll index = 0;
    for(ll i = 0; i < k; i++)
    {
        while(index < w.size() && bucket[i] + w[index] <= maxW)
        {
            bucket[i] += w[index];
            index++;
        }
    }
    if(index == n)
    {
        return true;
    }
    else
    {
        return false;
    }
}

ll bs(ll left, ll right)
{
    if(left == right)
    {
        return left;
    }
    ll mid = (left + right) / 2;
    if(!check(mid))
    {
        return bs(mid + 1, right);
    }
    else
    {
        return bs(left, mid);
    }
}
int main()
{
    cin >> n >> k;
    w = vector<ll>(n);
    ll left = 0;
    ll right = 0;
    for(ll i = 0; i < n; i++)
    {
        cin >> w[i];
        right += w[i];
    }
    cout << bs(left, right);
    return 0;
}