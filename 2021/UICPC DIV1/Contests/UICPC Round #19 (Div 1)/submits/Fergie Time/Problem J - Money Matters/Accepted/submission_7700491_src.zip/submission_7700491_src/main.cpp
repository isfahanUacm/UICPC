#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define pld pair<ld, ld>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 1000000;
using namespace std;

vector<vector<ll>> graph;
vector<ll> o;
vector<bool> visited;

vector<ll> clist;
vector<vector<ll>> components;

void dfs(ll index)
{
    visited[index] = true;
    clist.push_back(index);
    for(ll i: graph[index])
    {
        if(!visited[i])
        {
            dfs(i);
        }
    }
}
int main()
{
    ll n, m;
    cin >> n >> m;
    vector<ll> sample;
    graph   = vector<vector<ll>>(n, sample);
    visited = vector<bool>(n);
    o       = vector<ll>(n);
    for(ll i = 0; i < n; i++)
    {
        cin >> o[i];
    }
    for(ll i = 0; i < m; i++)
    {
        ll a, b;
        cin >> a >> b;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
    components = vector<vector<ll>>();
    for(ll i = 0; i < n; i++)
    {
        if(!visited[i])
        {
            clist = vector<ll>();
            dfs(i);
            components.push_back(clist);
        }
    }
    bool ans = true;
    for(ll i = 0; i < components.size(); i++)
    {
        ll csum = 0;
        for(ll j = 0; j < components[i].size(); j++)
        {
            csum += o[components[i][j]];
        }
        if(csum != 0)
        {
            ans = false;
            break;
        }
    }
    if(ans)
    {
        cout << "POSSIBLE";
    }
    else
    {
        cout << "IMPOSSIBLE";
    }


    return 0;
}