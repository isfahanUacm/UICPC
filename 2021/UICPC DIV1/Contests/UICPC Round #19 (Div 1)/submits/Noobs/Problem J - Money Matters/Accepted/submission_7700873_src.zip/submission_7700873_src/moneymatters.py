parent = []
rank = []
result = []
s = []


def make_set(v):
    parent.append(v)
    rank.append(0)


def find_set(v):
    if v == parent[v]:
        return v
    parent[v] = find_set(parent[v])
    return parent[v]


def union_sets(a, b):
    a = find_set(a)
    b = find_set(b)
    if a != b:
        if rank[a] < rank[b]:
            a, b = b, a
        parent[b] = a
        s[a] += s[b]

        if rank[a] == rank[b]:
            rank[a] += 1


n, m = map(int, input().split())
for i in range(n):
    make_set(i)
    s.append(int(input()))

for i in range(m):
    x, y = map(int, input().split())
    union_sets(x, y)

node = set()
for i in range(n):
    node.add(find_set(i))

flag = True
for nod in node:
    if s[nod] != 0:
        print('IMPOSSIBLE')
        flag = False
        break

if flag:
    print('POSSIBLE')