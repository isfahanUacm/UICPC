import java.util.Scanner;
public class countingstars {

static int r = 0;
static int c = 0;
static int result = 0;
static char[][] road;
static boolean[][] visited;

public static void foo(int i , int j) {
	if (i == 0 || i == r + 1 || j == 0 || j == c + 1)
		return;
	
	visited[i][j] = true;
	
	if (road[i + 1][j] == '-' && !visited[i + 1][j])
		foo (i + 1 , j);
	
	if (road[i - 1][j] == '-' && !visited[i - 1][j])
		foo (i - 1 , j);
	
	if (road[i][j + 1] == '-' && !visited[i][j + 1])
		foo (i , j + 1);
	
	if (road[i][j - 1] == '-' && !visited[i][j - 1])
		foo (i , j - 1);
}

public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
int index = 1;

while (scan.hasNext())
	{
	r = scan.nextInt();
	c = scan.nextInt();
	road = new char[r + 2][c + 2];
	visited = new boolean[r + 2][c + 2];
	
	for (int i = 1; i < r + 1; i++)
		{
		String str = scan.next();
		for (int j = 1; j < c + 1; j++)
			road[i][j] = str.charAt(j - 1);
		}
	
	result = 0;
	
	for (int i = 1; i < r + 1; i++)
		for (int j = 1; j < c + 1; j++)
			{
			if (road[i][j] == '-')
				{
				if (!visited[i + 1][j] && !visited[i - 1][j] && !visited[i][j + 1] && !visited[i][j - 1])
					{
					result++;
					foo(i , j);
					}
				}
			}
	
	System.out.println("Case " + index + ": " + result);
	index++;
	}

scan.close();
	}
}