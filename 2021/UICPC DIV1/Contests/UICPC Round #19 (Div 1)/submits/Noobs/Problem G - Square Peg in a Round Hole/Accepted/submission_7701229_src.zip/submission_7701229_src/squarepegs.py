import math

n, m, k = map(int, input().split())
nls = list(map(int, input().split()))
mls = list(map(int, input().split()))
kls = list(map(int, input().split()))

items = []
for i in range(m):
    items.append(mls[i])

for i in range(k):
    x = kls[i]
    items.append(math.sqrt(2 * ((x / 2) ** 2)))

items.sort()
nls.sort()
# print(nls)
# print(items)

result = 0
for i in range(m + k):
    for j in range(n):
        if items[i] < nls[j]:
            nls[j] = -1
            result += 1
            break

print(result)
