n, m, k = map(int, input().split())
nls = list(map(int, input().split()))
mls = list(map(int, input().split()))
kls = list(map(int, input().split()))

items = []
for i in range(m):
    items.append((mls[i], 2))

for i in range(k):
    items.append((kls[i], 1))

items.sort()
# print(nls)
# print(items)

result = 0
for i in range(len(nls)):
    for j in range(len(items)):
        if items[j][1] == 2:
            if items[j][0] < nls[i]:
                result += 1
            break
        else:
            if items[j][0] * 1.4 < 2 * nls[i]:
                result += 1
            break

print(result)
