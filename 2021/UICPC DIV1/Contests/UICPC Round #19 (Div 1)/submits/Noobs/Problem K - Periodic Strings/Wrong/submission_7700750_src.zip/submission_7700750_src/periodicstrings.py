inputstr = input()
le = len(inputstr)
rot = 1
res = ""
flag = False
for i in range(le):
    if flag:
        break
    j = 1
    l = inputstr[:i + 1]
    while i * j + i + j + 1 < le:
        l = l[-1:] + l[:-1]
        test = inputstr[i * j + j:i * j + i + j + 1]
        if inputstr[i * j + j:i * j + i + j + 1] == l:
            rot += 1
            j += 1
            if i * j + i + j + 1 == le:
                print(i + 1)
                flag = True
                break
            continue
        else:
            break

if not flag:
    print(le)