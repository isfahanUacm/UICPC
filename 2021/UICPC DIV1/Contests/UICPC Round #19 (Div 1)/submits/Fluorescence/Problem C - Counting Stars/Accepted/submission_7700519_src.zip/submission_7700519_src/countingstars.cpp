#include <bits/stdc++.h>
using namespace std;
int n, m;
bool inrange(int i, int j){
    return i>= 0 && i<m && j>=0 && j<n;
}
int main(){
    int t = 0;
    int moves[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
    while(cin>>m>>n){
        t++;
        char map[m][n];
        bool vis[m][n]; memset(vis, false, sizeof(vis));
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                cin>>map[i][j];
            }
        }

        queue<pair<int, int>> q;
        bool beenThere = false;
        int cnt = 0;
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (map[i][j] == '-' && !vis[i][j]){
                    q.push({i, j});
                    vis[i][j] = true;
                    beenThere = true;
                    while (!q.empty())
                    {
                        int x = q.front().first;
                        int y = q.front().second;
                        q.pop();
                        for(auto p:moves){
                            if(inrange(x+p[0], y+p[1]) && map[x+p[0]][y+p[1]] == '-' && !vis[x+p[0]][y+p[1]]){
                                q.push({x+p[0], y+p[1]});
                                vis[x+p[0]][y+p[1]] = true;
                            }
                        }
                    }
                    if(beenThere){
                        cnt++;
                        beenThere = false;
                    }
                    
                }
            }
        }

        cout<<"Case "<<t<<": "<<cnt<<endl;
    }
}