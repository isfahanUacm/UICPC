#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;

int n, m, k;
int r[100 + 5];
int s[200 + 5];

int main() {
	cin >> n >> m >> k;
	for(int i = 0; i < n; i++) {
		cin >> r[i];
		//r[i]--;
		r[i] = (2*r[i])* (2 * r[i]);
	}
	sort(r, r + n, greater<int>());
	for (int i = 0; i < m; i++) {
		cin >> s[i];
		s[i] = (2*s[i])* (2 * s[i]);
	}
	int j = m;
	for (int i = 0; i < k; i++) {
		int e;
		cin >> e;
		s[j] = 2*e*e;
		j++;
	}
	sort(s, s + m + k, greater<int>());
	int i = 0;
	int count = 0;
	for (int j = 0; j < m+k; j++) {
		if (i == n) break;
		if (r[i] > s[j]) {
			count++;
			i++;
		}
	}
	cout << count;
}