#include <bits/stdc++.h>
using namespace std;
int n, m;
int weight[10005];
bool vis[10005];
int sum = 0;
vector<vector<int>> adj(50005);

void dfs(int u){
    vis[u] = true;
    sum += weight[u];
    for(int v: adj[u]){
        if(!vis[v]) 
            dfs(v);
    }
}

int main(){
    cin>>n>>m;
    fill_n(vis, n, false);
    for (int i = 0; i <n; i++)
    {
        cin>>weight[i];
    }

    int x, y;
    for (int i = 0; i < m; i++)
    {
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    
    bool pos = true;
    for (int i = 0; i < n; i++)
    {
        if(!vis[i]) {
            sum = 0;
            dfs(i);
            if(sum != 0) {
                pos = false;
                break;
            }
        }
    }

    if (m == 0) cout<<"IMPOSSIBLE\n";
    else if(pos) cout<<"POSSIBLE\n";
    else cout<<"IMPOSSIBLE\n";
    
}