#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;
typedef unsigned long long int ulli;
// std::cout << std::setprecision(3) << std::fixed << doubllle;
// sort(arr, arr + n, greater<int>());
//c = ::tolower(c);
//for (int i = 0; i < s.size(); i++) {
//s[i] = tolower(s[i]);
//multiset<lli, greater<lli>> mset;

int n;
const int num = 100000 + 5;
int Exp[num];
int sum[num];
vector<vector<pair<int, int>>> adj(num);
set<int> dead;
int Count;
bool alive[num];

void bfs(int cur) {
	dead.erase(dead.begin());
	Count--;
	for (auto p : adj[cur]) {
		int child = p.first;
		int w = p.second;
		if (alive[child]) {
			sum[child] -= w;
			if (sum[child] < Exp[child]) {
				alive[child] = 0;
				dead.insert(child);
			}
		}
	}
	while (!dead.empty()) {
		bfs(*dead.begin());
		//dead.erase(dead.begin());
	}
}

int main() {
	cin >> n;
	Count = n;
	fill_n(alive, n + 5, 1);
	fill_n(sum, n + 5, 0);
	for (int i = 1; i <= n; i++) {
		int m;
		cin >> Exp[i];
		cin >> m;
		while (m--) {
			int u, w;
			cin >> u >> w;
			sum[i] += w;
			adj[u].push_back({ i, w });
		}
	}
	dead.insert(1);
	alive[1] = 0;
	bfs(1);
	cout << Count;
}