#include <bits/stdc++.h>
using namespace std;
int n, m;
bool vis[10005];
int sum = 0;
int label[10005];
int dist[10005];
vector<vector<int>> adj(10005);
bool pos = true;
void dfs(int u){
    vis[u] = true;
    //sum++;
    if (adj[u].size()>=1){
        if(dist[u]%2==0) label[u] = 0;
        else label[u] = 1;
    }else{
        pos = false;
    }
    for(int v: adj[u]){
        if(!vis[v]){
            dist[v] = dist[u]+1;
            dfs(v);
        }
    }
}

int main(){
    cin>>n>>m;
    fill_n(vis, n, false);
    fill_n(label, n,0);
    fill_n(dist, n, 0);
    int x, y;
    for (int i = 0; i < m; i++)
    {
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    /*for (int i = 1; i < n+1; i++)
    {
        if(!vis[i]){
            //sum = 0;
            dfs(i);
        }
    }*/

    queue<int> q;
    for (int i = 1; i < n+1; i++)
    {
        if (!vis[i]){
            q.push(i);
            vis[i] = true;
            while (!q.empty())
            {
                x = q.front(); q.pop();
                if(adj[x].size()<=0) {
                    pos = false;
                    break;
                }
                for(int j:adj[x]){
                    if(!vis[j]){
                        label[j] = label[x]?0:1;
                        vis[j]  =true;
                        q.push(j);
                    }
                }
            }   
        }
        if (!pos) break;
    }
    

    if(pos){
        for (int i = 1; i < n+1; i++)
        {
            if(label[i]==1) cout<<"pub ";
            else if(label[i] == 0) cout<<"house ";
        }
        
    }else{
        cout<<"Impossible\n";
    }
}