#include <bits/stdc++.h>
using namespace std;
int n, m;
bool vis[10005];
int sum = 0;
int label[10005];
vector<vector<int>> adj(10005);
bool pos = true;
void dfs(int u){
    vis[u] = true;
    sum++;
    if (adj[u].size()>=1){
        if(sum%2==0) label[u] = 0;
        else label[u] = 1;
    }else{
        //cout<<u<<endl;
        pos = false;
    }
    for(int v: adj[u]){
        if(!vis[v]) 
            dfs(v);
    }
}

int main(){
    cin>>n>>m;
    fill_n(vis, n, false);
    fill_n(label, n,-1);
    int x, y;
    for (int i = 0; i < m; i++)
    {
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    for (int i = 1; i < n+1; i++)
    {
        if(!vis[i]){
            sum = 0;
            dfs(i);
            //cout<<i<<"  "<<sum<<endl;
        }
    }

    if(pos){
        for (int i = 1; i < n+1; i++)
        {
            if(label[i]==1) cout<<"pub ";
            else if(label[i] == 0) cout<<"house ";
        }
        
    }else{
        cout<<"Impossible\n";
    }
}