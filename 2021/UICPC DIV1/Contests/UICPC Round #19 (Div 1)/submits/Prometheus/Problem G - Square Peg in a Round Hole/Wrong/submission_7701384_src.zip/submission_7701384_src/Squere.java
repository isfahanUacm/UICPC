import java.util.Scanner;
import java.lang.*;
import static java.lang.Math.sqrt;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author golnoosh
 */
public class Squere {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int m = input.nextInt();
        int k = input.nextInt();
        
        ArrayList<Integer> plots = new ArrayList<>();
        ArrayList<Double> houses = new ArrayList<>();
        
        for(int i=0; i<n; i++)
            plots.add(input.nextInt());
        for(int i=0; i<m; i++)
           houses.add(input.nextDouble());
        for(int i=0; i<k; i++)
            houses.add((input.nextInt()*sqrt(2))/2);
        
        Collections.sort(plots, Collections.reverseOrder()); 
        Collections.sort(houses, Collections.reverseOrder()); 
        

        int count = 0;
        
        int i = 0 ;
        for(int j = i; j<Math.min(k+m, n); j++)
        {
            if(houses.get(j) < plots.get(i)){
                count++;
                i++;
            }    
        }
        System.out.println(count);
        
    }
    
}
