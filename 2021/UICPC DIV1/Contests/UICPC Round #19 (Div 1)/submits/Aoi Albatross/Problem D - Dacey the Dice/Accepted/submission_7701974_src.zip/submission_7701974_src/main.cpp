#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAX = 150;
char mp[MAX][MAX];
bool visited[MAX][MAX][8][8][8];
int n;

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < n;
}

pair<int, int> mv[] = {
        {0, 1},
        {0, -1},
        {1, 0},
        {-1, 0},
};

void dfs(int x, int y, int d, int t, int l) {
    visited[x][y][d][t][l] = true;
    for (int i = 0; i < 4; i++) {
        auto temp = mv[i];
        int nx = x + temp.first;
        int ny = y + temp.second;
        if (ir(nx, ny) && mp[nx][ny] != '*') {
            if (i == 0) {
                if(!visited[nx][ny][d][l][7 - t]) {
                    dfs(nx, ny, d, l, 7 - t);
                }
            }
            else if (i == 1) {
                if(!visited[nx][ny][d][7 - l][t]) {
                    dfs(nx, ny, d, 7 - l, t);
                }
            }
            else if (i == 2) {
                if(!visited[nx][ny][7 - t][d][l]) {
                    dfs(nx, ny, 7 - t, d, l);
                }
            }
            else if (i == 3) {
                if(!visited[nx][ny][t][7 - d][l]) {
                    dfs(nx, ny, t, 7 - d, l);
                }
            }
        }
    }
}

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        memset(visited, 0, sizeof(visited));
        cin >> n;
        int hx, hy;
        int sx = 0, sy = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                cin >> mp[i][j];
                if (mp[i][j] == 'H') {
                    hx = i;
                    hy = j;
                }
                if (mp[i][j] == 'S') {
                    sx = i;
                    sy = j;
                }
            }
        }
        dfs(sx, sy, 3, 1, 5);
        bool flag = false;
        for (int i = 1; i <= 6; ++i) {
            for (int j = 1; j <= 6; ++j) {
                if (visited[hx][hy][i][2][j]) {
                    flag = true;
                }
            }
        }
        if(flag) {
            cout << "YES" << endl;
        }
        else {
            cout << "NO" << endl;
        }
    }
}