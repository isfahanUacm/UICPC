n,m,k = map(int, input().split())
r = list(map(int, input().split()))
rh = list(map(int, input().split()))
rh.extend([(((int(x)**2+int(x)**2)**0.5)/2) for x in input().split()])
ans = 0
r.sort(reverse=True)
rh.sort(reverse=True)
j=0
for i in rh:
    if(j>=len(r)):
        break
    if(i<r[j]):
       j+=1
print(j)



