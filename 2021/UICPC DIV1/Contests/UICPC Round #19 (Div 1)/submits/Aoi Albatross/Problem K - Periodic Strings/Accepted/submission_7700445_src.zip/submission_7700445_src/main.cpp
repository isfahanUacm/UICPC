#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main() {
    string a;
    cin >> a;
    int n = a.length();
    int ans = n;

    for (int i = n; i >= 1; --i) {
        if (n % i != 0)
            continue;

        string temp = a.substr(0, i);
        bool flag = true;
        int pos = 0;
        for (int j = 1; j <= n; ++j) {
            if (a[j - 1] != temp[pos]) {
                flag = false;
                continue;
            }
            if (j % i == 0) {
                pos--;
            }
            pos++;
            pos %= i;
        }
        if (flag) {
            ans = i;
        }
    }
    cout << ans << endl;
}