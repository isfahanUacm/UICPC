#include <bits/stdc++.h>
using namespace std ;

int n , m , dp[1000][10000];
string s;
unordered_set<string> str;
bool ans = false;

bool solve(int f , int num){
    if(s[f] == ' ') solve(f+1 , num);

    if (f >= m) return false;
    if (num == 1){
        if (str.find(s.substr(f , m-f)) != str.end()){
            return ans = true;
        }
        else 
            return false;
    }

    if (dp[f][num] != -1) return dp[f][num];

    for (int i=f ; i<m && s[i] != ' ' ; i++)
        if (str.find(s.substr(f,i-f+1)) != str.end())
            if (solve(i+1 , num-1)) return true;
    
    return dp[f][num] = false;

}

int main(){
    cin >> n;

    for (int i=0 ; i<n ; i++){
        cin >> s;
        str.insert(s);
    }
    cin.ignore();
    
    memset(dp,-1,sizeof(dp));
    getline (cin , s) ;
    m = s.size() ;
    ans = false ;
    solve(0,5);
    if (ans) {
        memset(dp,-1,sizeof(dp));
        getline (cin , s) ;
        m = s.size() ;
        ans = false ;
        solve(0,7);
        if (ans) {
            memset(dp,-1,sizeof(dp));
            getline (cin , s) ;
            m = s.size() ;
            ans = false ;
            solve(0,5);
            if (ans) cout << "haiku" << endl;
            else cout << "come back next year" << endl;
        }else{ 
            getline (cin , s);
            cout << "come back next year" << endl;
        }
    }else {
        getline (cin , s) ;
        getline (cin , s) ;
        cout << "come back next year" << endl;
    }
    

    return 0;
}