#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,k;
vector<ll> w;
ll sum=0,l=0,h;
bool ok(ll mid){
    ll bn =0;
    for(ll i=0;i<w.size();i++){
        ll sk=0;
        bn++;
        while(sk<=mid&&i<w.size()){
            sk+=w[i];
            i++;
        }
    }
    return bn<k;

}
int main(){
    cin >> n >> k;
    w.resize(n);
    for(ll i=0;i<n;i++){
        cin >> w[i];
        sum+=w[i];
        if(l<w[i])l = w[i];
    }
    h = sum;
    ll mid;
    while(l<h){
        mid = (l+h)/2;
        if(ok(mid))
            h = mid - 1;
        else
            l = mid;
    }
    if (ok(l + 1))
        cout << l + 1;
    else
        cout<<l<<endl;
    return 0;
}