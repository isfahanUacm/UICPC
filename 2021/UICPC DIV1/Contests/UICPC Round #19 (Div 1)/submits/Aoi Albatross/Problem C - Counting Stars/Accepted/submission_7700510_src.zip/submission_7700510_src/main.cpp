#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAX = 150;
char mp[MAX][MAX];
bool visited[MAX][MAX];
int n, m;

bool ir(int x, int y) {
    return x >= 0 && x < n && y >= 0 && y < m;
}

pair<int, int> mv[] = {
        {0, 1},
        {1, 0},
        {0, -1},
        {-1, 0}
};

void dfs(int x, int y) {
    visited[x][y] = true;
    for (auto t : mv) {
        int nx = x + t.first;
        int ny = y + t.second;
        if (ir(nx, ny) && !visited[nx][ny] && mp[nx][ny] == '-') {
            dfs(x + t.first, y + t.second);
        }
    }
}

int main() {
    int tc = 1;
    while (cin >> n >> m) {
        memset(visited, 0, sizeof(visited));
        int c = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                cin >> mp[i][j];
            }
        }

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                if (mp[i][j] == '-' && !visited[i][j]) {
                    dfs(i, j);
                    c++;
                }
            }
        }

        cout << "Case " << tc++ << ": " << c << endl;
    }
}