#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int MAX = 1e5 + 10;
vector<int> adj[MAX];
int c[MAX];
int visited[MAX];

void dfs(int x, int color) {
    c[x] = color;
    visited[x] = true;
    for (auto v : adj[x]) {
        if (!visited[v]) {
            dfs(v, color ^ 1);
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    for (int i = 0; i < n; ++i) {
        if (adj[i].empty()) {
            cout << "Impossible" << endl;
            return 0;
        }
    }

    for (int i = 0; i < n; ++i) {
        if (!visited[i]) {
            dfs(i, 0);
        }
    }
    for (int i = 0; i < n; ++i) {
        if (c[i]) {
            cout << "pub ";
        }
        else {
            cout << "house ";
        }
    }
    cout << endl;
}