#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll MAX = 1e5 + 10;
ll dist[MAX];
vector<ll> parent[MAX];
set<pair<ll, ll>> ss;
vector<pair<ll, ll>> adj[MAX];
bool visited[MAX];
bool isValid[MAX];
set<ll> st;
ll disc[MAX];
ll low[MAX];
ll t = 0;
ll s, e;

void dfs(ll v, ll p) {
    visited[v] = true;
    low[v] = disc[v] = t++;
    ll children = 0;
    for (auto temp : adj[v]) {
        auto x = temp.first;
        if (!isValid[x])
            continue;
        if (x == p) continue;
        if (visited[x]) {
            low[v] = min(low[v], disc[x]);
        }
        else {
            dfs(x, v);
            low[v] = min(low[v], low[x]);
            if (low[x] >= disc[v] && p != -1) {
                st.insert(v);
            }
            children++;
        }
    }
    if (p == -1 && children > 1) {
        st.insert(v);
    }
}


void dijkstra(ll start) {
    dist[start] = 0;
    parent[start].clear();
    ss.insert({0, start});
    while (!ss.empty()) {
        ll u = ss.begin()->second;
        ss.erase(ss.begin());
        for (auto v : adj[u]) {
            if (dist[v.first] > dist[u] + v.second) {
                ss.erase({dist[v.first], v.first});
                dist[v.first] = dist[u] + v.second;
                ss.insert({dist[v.first], v.first});
                parent[v.first].clear();
                parent[v.first].push_back(u);
            }
            else if (dist[v.first] == dist[u] + v.second) {
                parent[v.first].push_back(u);
            }
        }
    }
}

void path(ll x) {
    isValid[x] = true;
    if (x == s)
        return;
    for (auto temp: parent[x]) {
        if (!isValid[temp])
            path(temp);
    }
}

int main() {
    ll n, m;
    cin >> n >> m;
    for (ll i = 0; i < n; ++i) {
        dist[i] = LONG_LONG_MAX;
    }
    for (ll i = 0; i < m; ++i) {
        ll w, a, b;
        cin >> a >> b >> w;
        adj[a].emplace_back(b, w);
        adj[b].emplace_back(a, w);
    }
    cin >> s >> e;
    dijkstra(s);
    path(e);
    dfs(s, -1);
    st.insert(s);
    st.insert(e);
    for (auto x : st) {
        cout << x << ' ';
    }
    cout << endl;
}
