#include <bits/stdc++.h> 
using namespace std ;

int n,m;
vector <int> num ;
vector <vector <int> > g;
vector <bool> vis , visp; 

void dfs(int num){
    vis[num] = true;
    visp[num] = true;

    for (int i=0 ; i<g[num].size() ; i++)
        if (!vis[g[num][i]])
            dfs(g[num][i]);
}

bool solve(){

    for (int i=0 ; i<n ; i++)
        if (!vis[i]){
            visp.clear();
            visp.resize(n , false);
            dfs(i) ;
            int sum = 0;
            for (int j=0 ; j<n ; j++)
                if (visp[j])
                    sum+=num[j];
            if (sum != 0) return false;
        }
    return true ;
}


int main(){
    cin >> n >> m;
    num.resize(n);
    g.resize(n);
    vis.resize(n, false);


    int tmp1 , tmp2;

    for (int i=0 ; i<n ; i++)
        cin >> num[i];
    for (int i=0 ; i<m ; i++){
        cin >> tmp1 >> tmp2;
        g[tmp1].push_back(tmp2);
        g[tmp2].push_back(tmp1);
    }

    if (solve()) cout << "POSSIBLE" << endl;
    else cout << "IMPOSSIBLE" << endl;

    return 0;
}