#include <bits/stdc++.h>
using namespace std;
//1
//3 2 1
//1 2
//2 3
//2

int main()
{
    int m, n, l, t;
    cin >> t;
    while(t--)
    {
        cin >> n >> m >> l;
        map <int , int> a;
        int b, c;
        bool isfallen[n];
        fill(isfallen, isfallen +n, 0);
        for(int i = 0; i < m; i++)
        {
            cin >> b >> c;
            a[b] = c;
        }
        int cnt = 0;

        for(int i = 0; i < l; i++)
        {
            cin >> b;
            while(a.find(b) != a.end())
            {
                if(!isfallen[b])
                {
                    isfallen[b] = true;
                    b = a[b];
                    cnt++;
                }
                else
                    break;
            }
            if(a.find(b) == a.end())
                if(!isfallen[b])
                {
                    cnt++;
                    isfallen[b] = true;
                }
        }

        cout << cnt << endl;

    }
}
