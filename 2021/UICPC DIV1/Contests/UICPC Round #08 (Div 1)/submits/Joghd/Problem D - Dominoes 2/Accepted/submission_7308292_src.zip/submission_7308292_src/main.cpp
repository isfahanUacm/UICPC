#include <iostream>
#include <string>
using namespace std;
void faling(int dom,int *fall,int n,int *a,int *b,int m) {
    if(fall[dom]==1)
        return;
    fall[dom]=1;
    for(int i=0;i<m;i++) {
        if(dom+1 == a[i])
            faling(b[i]-1,fall,n,a,b,m);
    }
}
int que() {
    int n, m, l;
    cin >> n >> m >> l;
    int fall[n];
    for(int i=0;i<n;i++)
        fall[i]=0;
    int a[m],b[m];
    for(int i=0;i<m;i++)
        cin >> a[i] >> b[i];
    int x;
    for(int i=0;i<l;i++) {
        cin >> x;
        faling(x-1,fall,n,a,b,m);
    }
    int ans=0;
    for(int i=0;i<n;i++)
        ans+=fall[i];
    return ans;
}
int main() {
    int n;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++)
        a[i] = que();
    for(int i=0;i<n;i++)
        cout << a[i] << endl;
}
