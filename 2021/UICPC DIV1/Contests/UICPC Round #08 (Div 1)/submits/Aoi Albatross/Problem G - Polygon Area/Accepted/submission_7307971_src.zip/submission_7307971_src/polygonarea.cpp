#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct vertex{
	ll x;
	ll y;
};
ll ut(vertex v1,vertex v2){
	return v1.x*v2.y-v1.y*v2.x;
}
int main(){
	ll n;
	while(true){
		ll area=0;
		cin >> n;
		if(n==0)break;
		std::vector<vertex> v(n);
		for(ll i=0;i<n;i++){
			cin >> v[i].x >> v[i].y;
		}
		for(ll i=0;i<n;i++){
			area +=(ut(v[i],v[(i+1)%n]));
		}
		if(area<0){
			printf("CW %.1f\n",-double(area)/2.0);
		}
		else{
			printf("CCW %.1f\n",double(area)/2.0);
		}
	}
	return 0;
}