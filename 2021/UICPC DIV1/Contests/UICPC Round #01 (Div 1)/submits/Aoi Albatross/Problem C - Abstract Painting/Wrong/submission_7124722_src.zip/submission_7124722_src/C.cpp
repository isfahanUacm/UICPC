#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mo = 1e9+7;
ll add(ll a,ll b){
	return (a+b)%mo;
}
ll mul(ll a,ll b){
	return (a*b)%mo;
}
ll power(ll a, ll b){
	if(b==0)
		return 1;
	ll ans = power(a,b/2);
	return mul(mul(b%2 ? a:1,ans),ans);
}
int main(){
	ll t;
	cin >> t;
	while(t--){
		ll r,c;
		cin >> r >> c;
		if(r==1 && r==c){
			cout<<18<<endl;
			continue;
		}
		if(r==1&&c!=1){
			cout<<mul(108,c-1)<<endl;
			continue;
		}
		if(r!=1&&c==1){
			cout<<mul(108,r-1)<<endl;
			continue;
		}
		cout<<mul(mul(18,power(6,add(r,c)-2)),power(2,mul(r-1,c-1)));
	}
	return 0;
}