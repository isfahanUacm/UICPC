#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mo = 1e9+7;
ll add(ll a,ll b){
	return (a+b)%mo;
}
ll mul(ll a,ll b){
	return (a*b)%mo;
}

int main(){
	ll t;
	cin >> t;
	while(t--){
		ll r,c;
		cin >> r >> c;
		if(r==1 && r==c){
			cout<<18<<endl;
			continue;
		}
		if(r==1&&c!=1){
			cout<<mul(108,c-1)<<endl;
			continue;
		}
		if(r!=1&&c==1){
			cout<<mul(108,r-1)<<endl;
			continue;
		}
		cout<<mul(mul(mul(1296,r-1),c-1),((mul(r,c)) -(add(c,r)-1)))<<endl;
	}
	return 0;
}