
import java.lang.reflect.Array;
import java.util.*;

class Main{
    public static void main( String [] args) {
        Scanner reader = new Scanner(System.in);
        int n = reader.nextInt();
        int [] array = new int[201] ;
        int [] f = new int[201] ;
        int [] l = new int[201] ;

        ArrayList<Integer> max = new ArrayList<>();
        int maxx ;
        int andis = 0;
        for (int i = 0; i < n; i++)
        {
            f[i] = reader.nextInt();
            l[i] = reader.nextInt();
            for (int j = f[i] ; j <= l[i] ; j++)
            {
                array[j] ++ ;
            }


        }
        for (int i = 0; i < n; i++) {
            maxx = array[f[i]];
            andis = f[i];
            for (int j = f[i] + 1; j <= l[i]; j++) {
                if (array[j] > maxx || array[j] == maxx) {
                    maxx = array[j];
                    andis = j;


                }

            }
            if ( ! max.contains(andis))
                max.add(andis);
        }
        System.out.println(max.size());




    }
}