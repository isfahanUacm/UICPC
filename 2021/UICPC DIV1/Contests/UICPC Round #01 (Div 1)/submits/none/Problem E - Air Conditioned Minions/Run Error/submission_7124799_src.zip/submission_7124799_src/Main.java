import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class Main{
    public static void main( String [] args) {
        Scanner reader = new Scanner(System.in);
        int n = reader.nextInt();
        int [] array = new int[100] ;
        ArrayList<Integer> max = new ArrayList<>();
        int maxx ;
        int andis = 0;
        for (int i = 0; i < n; i++)
        {
            int f = reader.nextInt();
            int l = reader.nextInt();
            for (int j = f ; j <= l ; j++)
            {
                array[j] ++ ;
            }
            maxx = array[f];
            for (int j = f+1 ; j <= l ; j++)
            {
                if(array[j] > maxx || array[j] == maxx)
                {
                    maxx = array[j] ;
                    andis = j ;


                }

            }
            if ( ! max.contains(andis))
                max.add(andis);


        }
        System.out.println(max.size());




    }
}