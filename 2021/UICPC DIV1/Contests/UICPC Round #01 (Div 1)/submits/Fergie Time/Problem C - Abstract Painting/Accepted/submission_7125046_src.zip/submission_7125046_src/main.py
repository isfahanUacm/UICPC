n = int(input())
modd = 10**9 + 7
for i in range(n):
    r, c = map(int, input().split())
    ans = pow(3, c, modd) * pow(3, r, modd) * pow(2, r * c, modd)
    print(ans % modd)
