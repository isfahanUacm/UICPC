#include <bits/stdc++.h>
using namespace std;

void sortFunction(int** arr , int size)
{
    for (int i=0; i < size-1; i++)
    {
        for (int j = 0; j < size-i-1; j++)
            if (arr[j][0] > arr[j+1][0])
            {
                swap(arr[j][0], arr[j+1][0]);
                swap(arr[j][1], arr[j+1][1]);
            }
    }
}

int main()
{
    int t ;
    cin >>t;

    int ** array = new int* [t];
    for(int i=0 ; i<t ; i++ )
    {
        array[i] = new int[2];
    }


    for(int i=0 ; i<t ; i++ )
    {
        cin >> array[i][0] >> array[i][1];
    }
    sortFunction(array , t);

    int count = 0;

    for(int i=0 ; i<t ; i++ )
    {
        for(int j=1 ; j<t ; j++ )
        {
            if( array[j][0] > array[i][1] )
            {
                count ++ ;
                break;
            }
        }
    }

    cout << count << endl;












}
