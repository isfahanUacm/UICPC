#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ld long double
#define watch(x) cout << #x << " : " << x << endl;
#define pll pair<ll, ll>
const ll mod = 1e9 + 7;
const ll maxN = 1000;
string waste;

void watchstack(stack<ll> s)
{
    while (s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main()
{
    string s;
    cin >> s;
    stack<ll> st;
    for(ll i = 0; i < s.length(); i++)
    {
        if(s[i] == '<')
        {
            if(st.size())
            {
                st.pop();
            }
        }
        else
        {
            st.push(s[i]);
        }
    }
    string ans;
    while(st.size())
    {
        char temp = st.top();
        st.pop();
        ans = temp + ans;
    }
    cout << ans;
    return 0;
}
