#include <bits/stdc++.h>
using namespace std;
vector<pair<int,int>> Move;
int Count=0;
void chess(int x1, int y1, int x2, int y2)
{
    int i=x1 ,j=y1 ;
    vector<int> dis;
    bool flag=0;
    while((i>=1) && (i<=8) && (j>=1) && (j<=8)){
        
        //cout<<"xxxxxxxxx1"<<endl;
        i++ ;
        j++ ;
        if((i<1) || (i>8) || (j<1) || (j>8))
            break;
        if(abs(x2-i) == abs(y2-j))
        {
            Move.push_back({i,j});
            Count++;
            flag =1;
            break;
        }
        else{
            int d = abs(y2-j) + abs(x2-i);
            dis.push_back(d);
        }
    }
    if(!flag){
        //cout<<"xxxxxxxxx2"<<endl;
        i=x1 ,j=y1 ;
        while(i>=1 && i<=8 && j>=1 && j<=8){
            i--;
            j--;
            if((i<1) || (i>8) || (j<1) || (j>8))
                break;
            if(abs(x2-i) == abs(y2-j)){
               Move.push_back({i,j});
               Count++;
               flag =1;
               break;
            }
        else{
            int d = abs(y2-j) + abs(x2-i);
            dis.push_back(d);
        }
        }
        
    }
    if(!flag){
        //cout<<"xxxxxxxxx3"<<endl;
        i=x1 ,j=y1 ;
        while(i>=1 && i<=8 && j>=1 && j<=8){
            i++;
            j--;
            if((i<1) || (i>8) || (j<1) || (j>8))
                break;
            if(abs(x2-i) == abs(y2-j))
        {
            Move.push_back({i,j});
            Count++;
            flag =1;
            break;
        }
        else{
            int d = abs(y2-j) + abs(x2-i);
            dis.push_back(d);
        }
        }  
    }
    if(!flag){
        //cout<<"xxxxxxxxx3"<<endl;
        i=x1 ,j=y1 ;
        while(i>=1 && i<=8 && j>=1 && j<=8){
            i--;
            j++;
            if((i<1) || (i>8) || (j<1) || (j>8))
               break;
            if(abs(x2-i) == abs(y2-j)){
            Move.push_back({i,j});
            Count++;
            flag =1;
            break;
        }
        else{
            int d = abs(y2-j) + abs(x2-i);
            dis.push_back(d);
        }
        }
        
    }

}

int main()
{
    int t;
    cin >>t;
    while(t--)
    {
        Count=0;
        Move.clear();
        char c1 ,c2;
        int y1, y2 , x1,x2;
        cin >>c1 >>y1 >>c2 >>y2;
        bool b1=0, w1=0, b2=0, w2=0;
        x1 = c1 - 64;
        x2 = c2 - 64;
        
        //
        if((x1+y1) % 2 == 0)
            b1 = 1;
        else 
            w1 =1;

        if((x2+y2) % 2 == 0)
            b2 =1;
        else
            w2 =1;
        //
        if(b1 && w2)
            cout<<"Impossible";
        else if(w1 && b2)
            cout<<"Impossible";
        else if(x1 == x2 && y1 == y2)
        {
            cout<<0 << " " << char(x1+64) <<" " << y1;
        }
        else{
            Move.push_back({x1,y1});

            if(abs(x2-x1) == abs(y2-y1)){

            }
            else{
                 chess(x1,y1, x2,y2);
            }
            Count++;
            Move.push_back({x2,y2});
            cout<< Count<<" ";
            for(auto it : Move){
                cout<< char(it.first + 64) << " " << it.second << " ";
            }
        }
        cout<<endl;
    }
}