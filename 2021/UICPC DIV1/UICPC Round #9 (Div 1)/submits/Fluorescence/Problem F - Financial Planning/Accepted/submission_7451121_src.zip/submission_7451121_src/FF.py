import math
n,m = map(int, input().split())
li=[]
for i in range(n):
    p,c = map(int, input().split())
    minDay = math.ceil(c/p)
    maxDay = math.ceil((c+m)/p)
    FirstDayProfit = minDay*p - c
    li.append([p,c,minDay,maxDay,FirstDayProfit])

li.sort(key = lambda x:x[2])

days = li[0][2]
j=1
if j<n:
    while (days==li[j][2] and j<n):
        j+=1
        if j==n: 
            break

money = 0
DailyProfit = 0
for i in range(j):
    money += li[i][4]
    DailyProfit += li[i][0]

while (money<m):
    days+=1
    money += DailyProfit
    if j<n:
        while (li[j][2]<=days and j<n):
            money += li[j][4]
            DailyProfit+=li[j][0]
            j+=1
            if j==n:
                break

print(days)