#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

struct arr {
    int elements[50];
    int size;
};

int func(int may,arr* charlist,int counter,int lastmay) {
    if(counter == 26)
        return may;
    int a1 = func(may,charlist,counter+1,lastmay);
    int newlastindex = -2;
    for(int i=0;i<charlist[counter].size;i++) {
        if(charlist[counter].elements[i] > lastmay) {
            newlastindex = charlist[counter].elements[i];
            break;
        }
    }
    if(newlastindex == -2) return a1;
    else return max(a1, func(may+1,charlist,counter+1,newlastindex));
}

int main()
{
    arr charlist[26];
    for(int i=0;i<26;i++) charlist[i].size = 0;
    string s;
    cin >> s;
    for(int i=0;i<s.size();i++){
        charlist[s[i]-'a'].elements[charlist[s[i]-'a'].size] = i;
        charlist[s[i]-'a'].size++;
    }
    for(int i=0;i<26;i++) sort(charlist->elements,charlist->elements+charlist->size);
    cout << 26 - func(0,charlist,0,-1);






}
