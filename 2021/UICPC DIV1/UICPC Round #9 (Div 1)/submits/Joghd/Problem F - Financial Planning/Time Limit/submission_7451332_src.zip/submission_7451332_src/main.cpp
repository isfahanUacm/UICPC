#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
int m;int minn;
int nde(int a,int b) {
    if((m+b)%a ==0)
        return (m+b)/a;
    return (m+b)/a +1;
}
struct pc {
    int a;
    int b;
};

void find(int a,int b,int size,int count,pc* pcs) {
    if(count == size && a==0)
        return;
    if(count == size) {
        if(minn > nde(a,b))
            minn = nde(a,b);
    }
    else {
        find(a,b,size,count+1,pcs);
        find(a+pcs[count].a,b+pcs[count].b,size,count+1,pcs);
    }
}

int main()
{

    int n;
    cin >> n >> m;
    minn = 2147483647;
    pc pcs[n];
    for(int i=0;i<n;i++)
        cin >> pcs[i].a >> pcs[i].b;
    find(0,0,n,0,pcs);
    cout << minn;



}
