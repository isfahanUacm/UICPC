import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String string = scanner.next();
        for(int i = 0;i<string.length();i++) {
            if(string.charAt(i) == '<') {
                if(i==0)
                 string = string.substring(1);
                else
                    string = string.substring(0,i-1) + string.substring(1+i);
                i-=2;
            }

        }
        System.out.println(string);
    }
}

