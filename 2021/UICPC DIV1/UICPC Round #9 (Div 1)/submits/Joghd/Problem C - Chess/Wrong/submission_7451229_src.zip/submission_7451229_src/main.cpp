#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
string help(int i,int type) {
    string s = "";
    char c;
    if(type==0)
        c= i+'A';
    else
        c= i+'1';
    s = s+c;
    return s;
}
string help2(int x1,int y1,int x2,int y2) {
    int y = (x1 - x2 + y1 + y2) /2;
    int x = y + x2 -y2;
    if(y>=0 && y<8 && x>=0 && x<8)
        return help(x,0) +" "+help(y,1);
    y= (x2 - x1 + y1 + y2) /2;
    x = y + x1 -y1;
    return help(x,0) +" "+help(y,1);

}
string func(int x1,int y1,int x2,int y2) {
    if((x1+y1)%2 != (x2+y2)%2)
       return "impossible";
    if(x1==x2 && y1==y2)
        return "0 "+help(x1,0)+" "+help(y1,1);
    if(x1-x2 == y1 - y2 || x1-x2 == y2-y1)
        return "1 "+help(x1,0)+" "+help(y1,1) +" "+help(x2,0)+" "+help(y2,1);
    return "2 "+help(x1,0)+" "+help(y1,1) +" "+help2(x1,y1,x2,y2)+" "+help(x2,0)+" "+help(y2,1);

}

int main()
{

    int n;
    cin >> n;
    string ans[n];
    for(int i=0;i<n;i++) {
        string x1,x2,y1,y2;
        cin >> x1 >> y1 >> x2 >> y2;
        ans[i] = func(x1[0]-'A',y1[0]-'1',x2[0]-'A',y2[0]-'1') + "\n";
    }
    for(int i=0;i<n;i++) cout << ans[i];







}
