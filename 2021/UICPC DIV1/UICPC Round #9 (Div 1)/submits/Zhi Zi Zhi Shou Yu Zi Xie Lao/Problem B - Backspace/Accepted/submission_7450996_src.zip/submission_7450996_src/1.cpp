#include <bits/stdc++.h>
using  namespace std;
int main() {
    string s;
    stack<char> ss;
    cin >> s;
    for (int i = 0 ; i < s.length() ; i++){
        if (s[i]=='<') ss.pop();
        else ss.push(s[i]);
    }

    int p = ss.size();
    string res="";
    for (int i = 0 ; i <  p; i++)
    {
        res += ss.top();
        ss.pop();
    }
    for (int i = 0 ; i < p; i++)
    {
        cout<<res[p-1-i];
    }


    return 0;
}