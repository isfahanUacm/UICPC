#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
string m = "abcdefghijklmnopqrstuvwxyz";
ll lcs(string s){
	ll ans=0;
	ll ml = m.length();
	ll sl = s.length();
	ll **lc = new ll * [ml+1];
	for(ll i=0;i<=ml;i++)
		lc[i]=new ll [sl+1];
	for(ll i=0;i<=ml;i++){
		for(ll j=0;j<=sl;j++){
			if(i==0||j==0)
				lc[i][j]=0;
			else if(m[i-1]==s[j-1]){
				lc[i][j]=lc[i-1][j-1]+1;
			}
			else
				lc[i][j]=max(lc[i-1][j],lc[i][j-1]);

		}
	}
	return lc[ml][sl];
}
int main(){
	string s;
	cin >> s;
	cout<<26-lcs(s)<<endl;
	return 0;
}