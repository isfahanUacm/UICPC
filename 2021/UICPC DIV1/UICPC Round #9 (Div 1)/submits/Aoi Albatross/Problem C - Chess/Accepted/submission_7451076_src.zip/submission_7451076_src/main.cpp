#include <iostream>
#include <vector>

using namespace std;

int main() {
    int tc;
    cin >> tc;
    while (tc--) {
        vector<pair<int, int>> moves;
        char a, b, c, d;
        cin >> a >> b >> c >> d;
        int x, y, u, v;
        x = a - 'A';
        y = b - '1';
        u = c - 'A';
        v = d - '1';

        if ((x + y) % 2 != (u + v) % 2) {
            cout << "Impossible" << endl;
            continue;
        }
        moves.emplace_back(x, y);
        bool flag = false;
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                if (x == i && y == j)
                    continue;
                if (abs(x - i) == abs(y - j) && abs(u - i) == abs(v - j)) {
                    x = i; y = j;
                    moves.emplace_back(x, y);
                    flag = true;
                    break;
                }
            }
            if (flag)
                break;
        }

        if (u != x || v != y) {
            moves.emplace_back(u, v);
        }

        cout << moves.size() - 1 << ' ';
        for (auto t : moves) {
            cout << char(t.first + 'A') << ' ' << t.second + 1<< ' ';
        }
        cout << endl;
    }
}
