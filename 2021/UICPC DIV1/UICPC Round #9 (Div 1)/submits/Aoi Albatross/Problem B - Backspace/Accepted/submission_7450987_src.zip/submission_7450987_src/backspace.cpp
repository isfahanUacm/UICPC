#include <bits/stdc++.h>
using namespace std;
typedef long long ll;


int main(){
	string s;
	cin >> s;
	string ans = "";
	for(auto c:s){
		if(c=='<'){
			ans.pop_back();
		}
		else
			ans+=c;
	}
	cout<<ans<<endl;
}