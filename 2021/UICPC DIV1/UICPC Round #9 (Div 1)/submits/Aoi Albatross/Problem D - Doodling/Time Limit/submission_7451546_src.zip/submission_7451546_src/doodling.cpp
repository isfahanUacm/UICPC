#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
set<pair<ll,ll>> tmp;

ll solve(ll i,ll j,ll a){
    tmp.insert({i,j});
    ll ans=0;
    if ((i==n-1 && j==m-1) || (i==0 && j==m-1) || (i==n-1 && j==0))
        return 1;

    if (a==-1){
        if (i+1<n && j+1<m) ans=1+solve(i+1,j+1,-1);
        else if (i+1==n && j+1<m) ans=1+solve(i-1,j+1,-4);
        else if (i+1<n && j+1==m) ans=1+solve(i+1,j-1,-2);
    }else if (a==-2){
        if (i+1<n && j-1>=0) ans=1+solve(i+1,j-1,-2);
        else if (i+1==n && j-1>=0) ans=1+solve(i-1,j-1,-3);
        else if (i+1<n && j-1==-1) ans=1+solve(i+1,j+1,-1);
    }else if (a==-3){
        if (i-1>=0 && j-1>=0) ans=1+solve(i-1,j-1,-3);
        else if (i-1==-1 && j-1>=0) ans=1+solve(i+1,j-1,-2);
        else if (i-1>=0 && j-1==-1) ans=1+solve(i-1,j+1,-4);
    }else {
        if (i-1>=0 && j+1<=m-1) ans=1+solve(i-1,j+1,-4);
        else if (i-1==-1 && j+1<m) ans=1+solve(i+1,j+1,-1);
        else if (i-1>=0 && j+1==m) ans=1+solve(i-1,j-1,-3);
    }
    return ans;
}

int main()
{
    ll t;
    cin>>t;
    for (ll i=0;i<t;i++){
        tmp.clear();
        cin>>m>>n;
        solve(0,0,-1);
        cout<<tmp.size()<<endl;
    }
}
