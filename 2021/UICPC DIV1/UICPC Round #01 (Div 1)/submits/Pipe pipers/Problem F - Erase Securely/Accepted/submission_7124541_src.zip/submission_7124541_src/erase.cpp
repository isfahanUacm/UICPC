#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
using namespace std;

int main(){
   string s1;
   string s2;
   string rev;
   int n;
   cin>>n;
   cin>>s1;
   cin>>s2;

   if(n%2){
       for(int i=0;i<s1.length();i++){
           if(s1[i]=='1')
               rev+='0';
           else
               rev+='1';
       }

   }
   else{
       rev=s1;
   }
//   cout<<rev<<endl;
   if(rev==s2)
       cout<<"Deletion succeeded"<<endl;
   else
       cout<<"Deletion failed"<<endl;

}

