#include <bits/stdc++.h>
using namespace std;
//unsigned

unsigned long long Pow2Function (unsigned long long n)
{
    if(n==0)
        return 1;
    if(n==1)
        return 2;
    else
    {
        unsigned long long rec = n/2;
        if(n%2 != 0)
        {
            return (((rec*rec) % 1000000007)*2) % 1000000007;
        }
        else
        {
            return (rec*rec) % 1000000007;
        }
    }
}

unsigned long long int how( int r, int c ,unsigned long long int** a)
{
    int mul = r*c;
    if( mul == 1 )
    {
        a[r-1][c-1] = 18;
        return 18;
    }
    if( mul == 2)
    {
       a[r-1][c-1] =108;
       a[c-1][r-1] = 108;
       return 108;
    }
    else
    {
        unsigned long long int output;
        unsigned long long int o1 = pow(6 , (r+c-2));
        unsigned long long int t = (r-1)*(c-1) % (1000000007);
        unsigned long long int o2 = Pow2Function(t) ;


        output= 18 * o1 * o2;
        a[r-1][c-1] = output;
        if(c<14)
        {
            a[c-1][r-1] = output;
        }

        return output;
    }
}

int main()
{
    int t;
    cin >> t;
    unsigned long long int ** array = new unsigned long long int* [14];

    for(int i=0 ;i<14; i++)
    {
        array[i]= new unsigned long long int [2000];
    }

    for(int i=0 ;i<14; i++)
    {
        for(int j=0; j<2000 ; j++)
        {
            array[i][j]=0;
        }
    }

    while( t-- )
    {
        int r, c;
        cin >> r >> c;

        if( array[r-1][c-1] != 0 )
        {
            cout << array[r-1][c-1] <<endl ;
        }

        else
        {
           cout << how(r, c, array) << endl;
        }

    }


}
