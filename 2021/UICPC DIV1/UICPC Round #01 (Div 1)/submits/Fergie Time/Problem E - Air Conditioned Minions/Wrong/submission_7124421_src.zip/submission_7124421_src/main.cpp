#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pll pair<ll, ll>
#define watch(x) cout << #x << " : " << x << endl
const ll mod = 1e9 + 7;
const ll maxN = 200200;
string waste;

void watchstack(stack<ll> s)
{
    while(s.size())
    {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

bool have_eshterak(pll a, pll b)
{
    pll F = min(a, b);
    pll S = max(a, b);
    return F.second >= S.first;
}
pll eshterak(pll a, pll b)
{
    return {max(a.first, b.first), min(a.second, b.second)};
}
int main ()
{
    ll n;
    cin >> n;
    vector<pll> v;
    for(ll i = 0; i < n; i++)
    {
        ll l, r;
        cin >> l >> r;
        v.push_back({l, r});
    }
    for(ll i = 0; i < v.size(); i++)
    {
        for(ll j = i + 1; j < v.size(); j++)
        {
            if(have_eshterak(v[i], v[j]))
            {
                v[i] = eshterak(v[i], v[j]);
                v.erase(v.begin() + j);
            }
        }
    }
    cout << v.size();
    return 0;
}
