#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll ds,d=0;
ll dp[110][210],dis[110],pr[110];
ll solve(ll f,ll i){
	f-=dis[i];
	if(f<0)
		return INT_MAX;
	if(dp[i][f]!=-1)
		return dp[i][f];
	if(ds==i){
		return f<100 ? INT_MAX:0;
	}
	dp[i][f]=INT_MAX;
	for(ll j=0;j<=200-f;j++){
		dp[i][f] = min(dp[i][f],j*pr[i]+solve(f+j,i+1));
	}
	return dp[i][f];
}

int main(){
	memset(dp,-1,sizeof(dp));
	cin >> ds;
	ll i=0;
	while(true){
		ll rd;
		cin >> rd >> pr[i];
		dis[i]=rd-d;
		d=rd;
		if(dis[i]>200){
			cout<<"Impossible"<<endl;
			return 0;
		}
		if(rd==ds){
			ds = i+1;
			break;
		}
		i++;
	}
	ll ans = solve(100,0);	

	cout<<ans<<endl;

	return 0;
}