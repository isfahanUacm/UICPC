#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    pair<int , int> a[n];
    for(int i = 0; i < n; i++)
    {
        cin >> a[i].first >> a[i].second;
    }
    sort(a , a+n);

//    for(int i = 0; i < n; i++)
//    {
//        cout << a[i].first << " " << a[i].second << endl;
//    }

    int cnt = 0, saven = n;

    int r , l;
    if(a[1].first <= a[0].second)
    {
        l = a[1].first;
        if(a[1].second > a[0].second)
            r = a[0].second;
        else
            r = a[1].second;
    }
    else
    {
        cnt++;
        l = a[1].first;
        r = a[1].second;
    }

    bool flag =  false;
    for(int i = 2; i < saven; i++)
    {
        if(a[i].first <= r)
        {
            l = a[i].first;
            if(a[i].second < r)
                r = a[i].second;
        }
        else
        {
            cnt++;
            l = a[i].first;
            r = a[i].second;
        }
    }

    cnt++;

    cout << cnt << endl;
}
