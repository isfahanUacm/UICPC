#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    string a , b;
    cin >> a >> b;

    if(n % 2 == 0)
    {
        if(a == b)
            cout << "Deletion succeeded" << endl;
        else
            cout << "Deletion failed" << endl;
    }
    else
    {
        for(int i = 0; i < a.size(); i++)
        {
            if(a[i] == b[i])
            {
                cout << "Deletion failed" << endl;
                return 0;
            }
        }

        cout << "Deletion succeeded" << endl;
    }
}
